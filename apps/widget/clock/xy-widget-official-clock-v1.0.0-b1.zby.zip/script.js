(function () {
  'use strict';

  var WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  var hoursEl = document.getElementById('clock-hours');
  var minutesEl = document.getElementById('clock-minutes');
  var secondsEl = document.getElementById('clock-seconds');
  var dateEl = document.getElementById('clock-date');

  function pad(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function tick() {
    var now = new Date();
    if (hoursEl !== null) hoursEl.textContent = pad(now.getHours());
    if (minutesEl !== null) minutesEl.textContent = pad(now.getMinutes());
    if (secondsEl !== null) secondsEl.textContent = pad(now.getSeconds());
    if (dateEl !== null) {
      dateEl.textContent = now.getFullYear() + '年' + pad(now.getMonth() + 1) + '月' + pad(now.getDate()) + '日 ' + WEEKDAYS[now.getDay()];
    }
  }

  tick();
  setInterval(tick, 1000);
})();
