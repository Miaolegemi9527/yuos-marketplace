/**
 * go — 围棋（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：src/shared/apps/games/（GameHost 基类 + builtin/go/GoHost）。
 * 转包改造点（对齐 PRD §4.2 / hex-color 模板）：
 *   1. 模块内联：沙箱 classic script 无模块系统，GameTypes + GameHost + GoHost
 *      三段源平铺进本文件（原 import 全部为 type-only 或本地模块，编译后零残留）
 *   2. i18n：宿主 5 语包 → 内嵌 game.* 最小词表（HUD/难度/名称），零语言包依赖
 *   3. 皮肤：game-host.css → APP_CSS 内嵌注入（变量已带 fallback，沙箱可独立渲染）
 *   4. 入口签名：toAppEntry() → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. manifest 透传：boot 构造 { nameKey, nameFallback }（GameHost.resolveGameName 依赖）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅、manifest={nameKey,nameFallback}）并调用；样式同源内容
 *   以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. i18n：沙箱词表（宿主注入 window.__SANDBOX_I18N__，PRD Step 4.1）
     ========================================================= */

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 沙箱 i18n 快照（宿主 MultiFileSandbox 注入，与 SandboxI18nSnapshot 一致） */
  interface SandboxI18nState {
    readonly lang: string;
    readonly dict: Readonly<Record<string, string>>;
    readonly dictEn: Readonly<Record<string, string>>;
  }

  /** 读取沙箱 i18n 快照（宿主未注入时 undefined，t 回退 key 本身） */
  function getSandboxI18n(): SandboxI18nState | undefined {
    return (window as unknown as Record<string, unknown>).__SANDBOX_I18N__ as SandboxI18nState | undefined;
  }

  /** 翻译器：当前语言词表 → 英文兜底表 → key 本身（缺 key 走英文，不出现中文硬编码） */
  function createTranslator(): Translator {
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const i18n = getSandboxI18n();
      let template = key;
      if (i18n !== undefined) {
        template = i18n.dict[key] ?? i18n.dictEn[key] ?? key;
      }
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. GameTypes 内联（原 src/shared/apps/games/GameTypes.ts）
     ========================================================= */

/**
 * GameTypes — 小游戏共享类型定义
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - GameRenderEngine：游戏渲染引擎标识（canvas2d 主引擎 / phaser 辅引擎）
 *   - GameManifestDescriptor：游戏描述元数据（用于 AI 创造 prompt 隔离）
 *   - GameLaunchOptions：游戏启动参数（难度/音效/初始状态等）
 *
 * 引擎选型依据（详见 prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.2）：
 *   - Canvas 2D：零依赖、AI 友好度最高、适合棋类/俄罗斯方块等逻辑型游戏
 *   - Phaser 4：原生 TS 支持、适合动作类（坦克大战/打砖块）等需要物理引擎/精灵动画的游戏
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24
 */


/** 游戏渲染引擎 */
type GameRenderEngine = 'canvas2d' | 'phaser';

/** 游戏难度（v5.0: 扩展为 5 档） */
type GameDifficulty = 'easy' | 'normal' | 'hard' | 'expert' | 'master';

/** 游戏启动选项（由 AppMountContext.data 透传） */
interface GameLaunchOptions {
  /** 初始难度（默认 'normal'） */
  readonly difficulty?: GameDifficulty | undefined;
  /** 是否启用音效（默认 true） */
  readonly soundEnabled?: boolean | undefined;
  /** 是否启用调试模式（默认 false，开启后显示 FPS/碰撞框等） */
  readonly debug?: boolean | undefined;
  /** 初始关卡/级别（部分游戏支持，从 1 开始） */
  readonly level?: number | undefined;
  /** 游戏模式（部分游戏支持，如军棋 'open' 明棋 / 'dark' 暗棋） */
  readonly gameMode?: string | undefined;
}

/** 游戏状态（用于 UI 显示/Dock 角标） */
type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover' | 'victory';

/** 游戏分数变更事件 */
interface GameScoreEvent {
  /** 当前分数 */
  readonly score: number;
  /** 历史最高分 */
  readonly bestScore: number;
  /** 关卡/级别 */
  readonly level?: number | undefined;
}

/** 游戏状态变更事件 */
interface GameStatusEvent {
  readonly status: GameStatus;
  readonly message?: string | undefined;
}

/** 游戏元数据（用于 AI 创造 prompt 隔离，与 AppManifest 解耦） */
interface GameManifestDescriptor {
  /** 游戏唯一标识（与 AppManifest.id 一致） */
  readonly id: string;
  /** 游戏名称（与 AppManifest.nameFallback 一致） */
  readonly name: string;
  /** 渲染引擎 */
  readonly engine: GameRenderEngine;
  /** 游戏类型分类（用于 AI 创造 prompt） */
  readonly genre: 'puzzle' | 'board' | 'action' | 'arcade' | 'strategy';
  /** 玩家数 */
  readonly players: 1 | 2;
  /** 是否支持 AI 对手 */
  readonly supportsAI?: boolean | undefined;
  /** 默认难度 */
  readonly defaultDifficulty?: GameDifficulty | undefined;
  /** 简短描述（用于 AI prompt 上下文） */
  readonly summary: string;
}


  /* =========================================================
     3. 沙箱存储访问器（PRD ZBY-PORTABLE-APP-CONTRACT-ROADMAP P4.3：
        最高分经宿主 sandboxStorage 代理持久化，键 game:best:game-<id>
        已逐键声明于 manifest.dataKeys；离线预览无宿主时降级 null，
        行为同旧空实现）
     ========================================================= */

/** 沙箱 KV 存储三方法（ZbyAPI.sandboxStorage 无 appId 签名，宿主侧补全命名空间） */
interface SandboxStorageLike {
  readonly get: (key: string) => Promise<unknown>;
  readonly set: (key: string, value: unknown) => Promise<unknown>;
  readonly remove: (key: string) => Promise<unknown>;
}

/** 取宿主注入的沙箱存储代理；无宿主（离线预览模板）返回 null */
function getSandboxStorage(): SandboxStorageLike | null {
  const api = (window as unknown as Record<string, unknown>).ZbyAPI as
    | Record<string, unknown>
    | undefined;
  const storage =
    api === undefined || api === null
      ? undefined
      : (api['sandboxStorage'] as Record<string, unknown> | undefined);
  if (storage === null || storage === undefined) return null;
  if (typeof storage['get'] !== 'function' || typeof storage['set'] !== 'function') return null;
  return storage as unknown as SandboxStorageLike;
}

  /* =========================================================
     4. GameHost 基类内联（原 src/shared/apps/games/GameHost.ts）
     ========================================================= */

/**
 * GameHost — 小游戏宿主基类
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 职责：
 *   - 提供统一的 mount/unmount 生命周期
 *   - 创建游戏画布容器 + HUD（分数/暂停/重新开始按钮）
 *   - 解析 GameLaunchOptions（从 AppMountContext.data 透传）
 *   - 派发 GameStatusEvent / GameScoreEvent 事件
 *   - 持久化最高分（宿主 sandboxStorage 代理，按 gameId 隔离）
 *   - 适配深浅主题（CSS 变量驱动）
 *
 * 子类需实现：
 *   - onMount(ctx, canvas, options)：初始化游戏场景
 *   - onUnmount()：清理资源/定时器/事件
 *   - onPause()/onResume()：可选，处理暂停恢复
 *   - onRestart()：可选，处理重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */






/** GameHost 配置（子类构造时传入） */
interface GameHostConfig {
  /** 游戏 ID（与 AppManifest.id 一致，用于最高分持久化 key） */
  readonly gameId: string;
  /** 是否显示 HUD（默认 true） */
  readonly showHUD?: boolean;
  /** 是否支持暂停（默认 true） */
  readonly pauseable?: boolean;
  /** 画布宽度（CSS 像素，0 表示自适应容器宽度） */
  readonly width?: number;
  /** 画布高度（CSS 像素，0 表示自适应容器高度） */
  readonly height?: number;
}

/** 主题色 token（与 CSS 变量一一对应） */
interface GameThemeTokens {
  readonly bg: string;
  readonly fg: string;
  readonly accent: string;
  readonly muted: string;
  readonly border: string;
  readonly dark: boolean;
}

/** 默认主题 token（从 CSS 变量读取，失败时兜底） */
const DEFAULT_THEME_TOKENS: GameThemeTokens = {
  bg: '#1a1a1a',
  fg: '#e8e8e8',
  accent: '#4a9eff',
  muted: '#888888',
  border: '#333333',
  dark: true,
};

/** 最高分 LocalStorage key 前缀 */
const BEST_SCORE_KEY_PREFIX = 'game:best:';

/**
 * GameHost — 游戏宿主基类。
 *
 * 子类通过 extends GameHost 并实现 onMount/onUnmount 等抽象方法，
 * 即可获得统一的 HUD/主题适配/最高分持久化能力。
 *
 * 典型用法：
 * ```ts
 * class TetrisHost extends GameHost {
 *   protected onMount(ctx, canvas, options) {
 *     // 初始化 Tetris 渲染循环
 *   }
 *   protected onUnmount() {
 *     // 清理定时器
 *   }
 * }
 *
 * export function createTetrisEntry(): AppEntry {
 *   const host = new TetrisHost({ gameId: 'game-tetris' });
 *   return host.toAppEntry();
 * }
 * ```
 */
abstract class GameHost {
  protected readonly config: Readonly<GameHostConfig>;

  /** 挂载容器（由 mount 注入） */
  private container: HTMLElement | null = null;
  /** 根元素（.game-host-root） */
  private root: HTMLElement | null = null;
  /** 画布元素（由 mount 创建） */
  private canvas: HTMLCanvasElement | null = null;
  /** HUD 容器（分数/按钮） */
  private hud: HTMLElement | null = null;
  /** 当前应用上下文（用于 i18n / API 调用） */
  protected ctx: AppMountContext | null = null;
  /** 当前游戏状态 */
  private status: GameStatus = 'idle';
  /** 当前分数 */
  private score = 0;
  /** 历史最高分 */
  private bestScore = 0;
  /** 主题 token */
  private theme: GameThemeTokens = DEFAULT_THEME_TOKENS;
  /** 主题变化订阅解绑函数 */
  private themeUnsub: (() => void) | null = null;
  /** i18n 变更订阅解绑函数（宿主语言切换 → 刷新 HUD 文案，Step 4.1） */
  private i18nUnsub: (() => void) | null = null;
  /** 暂停状态锁（防止重复暂停/恢复） */
  private paused = false;
  /** HUD 状态监听器集合 */
  private readonly statusListeners = new Set<(e: GameStatusEvent) => void>();
  /** HUD 分数监听器集合 */
  private readonly scoreListeners = new Set<(e: GameScoreEvent) => void>();
  /** 画布逻辑宽度（子类调用 setupHiDPICanvas 时传入） */
  private logicalW = 0;
  /** 画布逻辑高度 */
  private logicalH = 0;
  /** ResizeObserver 实例（窗口尺寸变化时重新适配画布） */
  private resizeObserver: ResizeObserver | null = null;
  /** rAF 合并句柄（ResizeObserver 防抖，避免连续清空画布闪烁） */
  private resizeRaf: number | null = null;
  /** v4.2：自动暂停监听解绑函数（标签页隐藏 / 窗口失焦时自动暂停游戏） */
  private autoPauseUnsub: (() => void) | null = null;
  /** v4.2：自动暂停前的用户手动暂停状态（恢复时保留用户意图） */
  private wasPausedBeforeAutoPause: boolean = false;
  /** v5.0：当前游戏难度（由 resolveOptions 初始化，可运行时通过 HUD 下拉切换） */
  private currentDifficulty: GameDifficulty = 'normal';

  constructor(config: GameHostConfig) {
    this.config = config;
    this.bestScore = 0;
    /* P4.3：最高分经 sandboxStorage 异步加载（postMessage 往返），构造期无法
       同步取值；加载完成后取大者回填（防玩家抢先破纪录被旧值覆盖） */
    void this.loadBestScore().then((loaded) => {
      if (loaded > this.bestScore) {
        this.bestScore = loaded;
        this.updateHUDScore();
      }
    });
  }

  /* ============================================================
     生命周期（子类实现）
     ============================================================ */

  /**
   * 子类实现：游戏挂载时初始化场景。
   *
   * @param ctx 应用挂载上下文
   * @param canvas 画布元素（已设置宽高/样式）
   * @param options 游戏启动选项
   */
  protected abstract onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): void | Promise<void>;

  /**
   * 子类实现：游戏卸载时清理资源（定时器/事件/动画帧）。
   * 必须是同步的，由 unmount 调用。
   */
  protected abstract onUnmount(): void;

  /**
   * 子类可选实现：暂停游戏（默认空实现）。
   * 仅在 config.pauseable !== false 时调用。
   */
  protected onPause(): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：恢复游戏（默认空实现）。
   */
  protected onResume(): void {
    /* default no-op */
  }

  /**
   * v5.0: 子类可选实现：难度变更回调。
   * 当用户通过 HUD 下拉切换难度时调用，子类可在此调整 AI 强度等参数。
   */
  protected onDifficultyChange(_difficulty: GameDifficulty): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：重新开始游戏（默认调用 onUnmount + onMount）。
   */
  protected onRestart(): void {
    if (this.canvas === null || this.ctx === null) return;
    this.onUnmount();
    this.score = 0;
    this.status = 'idle';
    this.paused = false;
    void this.onMount(this.ctx, this.canvas, this.resolveOptions());
  }

  /* ============================================================
     公开 API（供 AppEntry 调用）
     ============================================================ */

  /** 转换为 AppEntry（注册到 AppRegistry） */
  toAppEntry(): AppEntry {
    return {
      mount: (ctx: AppMountContext) => this.mount(ctx),
      unmount: () => this.unmount(),
    };
  }

  /** 挂载游戏 */
  async mount(ctx: AppMountContext): Promise<void> {
    this.ctx = ctx;
    this.container = ctx.container;

    /* 解析主题 token：皮肤变量在 srcdoc body 末尾注入，入口脚本先于其执行；
       readyState==='loading' 时先拿到 fallback 深色快照；文档解析完成
       （DOMContentLoaded，皮肤 <style> 已注入生效）后重新解析并同步，
       保证浅色皮肤下 HUD 文字与棋盘底色正确。 */
    this.theme = this.resolveThemeTokens();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.theme = this.resolveThemeTokens();
        this.applyThemeToCanvas();
        this.applyThemeToRoot();
      }, { once: true });
    }

    /* 创建根布局 */
    const root = document.createElement('div');
    root.className = 'game-host-root';
    root.dataset.gameId = this.config.gameId;
    root.dataset.status = 'idle';

    /* HUD（顶部条） */
    if (this.config.showHUD !== false) {
      this.hud = this.createHUD(ctx);
      root.appendChild(this.hud);
    }

    /* 画布容器 */
    const canvasWrap = document.createElement('div');
    canvasWrap.className = 'game-host-canvas-wrap';
    canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');

    const canvas = document.createElement('canvas');
    canvas.className = 'game-host-canvas';
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'application');
    canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    const w = this.config.width ?? 0;
    const h = this.config.height ?? 0;
    if (w > 0) canvas.style.width = `${w}px`;
    if (h > 0) canvas.style.height = `${h}px`;
    canvasWrap.appendChild(canvas);
    root.appendChild(canvasWrap);
    this.root = root;
    this.canvas = canvas;

    /* v5.0 修复：暂停状态下点击画布容器恢复游戏（原方案 overlay 有 pointer-events:none，
     * 点击穿透到 canvas 但 canvas 无 resume 处理，导致"点击继续"无反应） */
    canvasWrap.addEventListener('click', () => {
      if (this.paused && this.status === 'paused') {
        this.resume();
      }
    });

    this.container.replaceChildren(root);
    this.applyThemeToRoot();
    canvas.focus();

    /* 监听主题变化 */
    this.themeUnsub = ctx.onThemeChange(() => {
      this.theme = this.resolveThemeTokens();
      this.applyThemeToCanvas();
      this.applyThemeToRoot();
    });

    /* Step 4.1：订阅宿主语言变更 → 刷新 HUD 文案（词表由沙箱 __SANDBOX_I18N__ 提供） */
    const subscribeI18n = ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_I18N__ as
      | ((cb: () => void) => () => void)
      | undefined) ?? (() => () => undefined);
    this.i18nUnsub = subscribeI18n(() => {
      this.refreshHudI18n();
    });

    /* v4.1：监听画布容器尺寸变化，自动重新计算 canvas 分辨率，
     * 确保窗口 resize 时文字不模糊（Canvas 2D 游戏适用，Phaser 游戏由其 ScaleManager 处理） */
    this.resizeObserver = new ResizeObserver(() => {
      if (this.canvas === null || this.logicalW <= 0 || this.logicalH <= 0) return;
      /* v5.1：尺寸变化用 rAF 合并（体验视图进入动画/布局抖动期间容器连续变化，
       * 同步重置 canvas 会每帧清空重绘造成可见闪烁；合并到下一帧只处理一次） */
      if (this.resizeRaf !== null) return;
      this.resizeRaf = window.requestAnimationFrame(() => {
        this.resizeRaf = null;
        const c = this.canvas;
        if (c === null || this.logicalW <= 0 || this.logicalH <= 0) return;
        const ctx = this.applyCanvasSize(c, this.logicalW, this.logicalH);
        if (ctx !== null) {
          try { this.onCanvasResize(); } catch (err) {
            console.error(`[GameHost:${this.config.gameId}] onCanvasResize failed:`, err);
          }
        }
      });
    });
    this.resizeObserver.observe(canvasWrap);

    /* v4.2（5.8.15）：标签页隐藏 / 窗口失焦时自动暂停游戏，恢复时自动继续。
     * 仅在用户未手动暂停时自动恢复，避免与用户意图冲突。 */
    this.setupAutoPause();

    /* v5.0: 从启动选项中解析初始难度 */
    const opts = this.resolveOptions();
    this.currentDifficulty = opts.difficulty ?? 'normal';

    /* 子类初始化游戏场景 */
    try {
      await this.onMount(ctx, canvas, opts);
      this.setStatus('playing');
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onMount failed:`, err);
      this.setStatus('gameover', this.tr(this.ctx, 'game.common.initFailed', 'Game init failed', { msg: err instanceof Error ? err.message : String(err) }));
    }
  }

  /** 卸载游戏 */
  unmount(): void {
    if (this.resizeRaf !== null) {
      window.cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeObserver !== null) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.autoPauseUnsub !== null) {
      try { this.autoPauseUnsub(); } catch { /* ignore */ }
      this.autoPauseUnsub = null;
    }
    if (this.themeUnsub !== null) {
      try { this.themeUnsub(); } catch { /* ignore */ }
      this.themeUnsub = null;
    }
    if (this.i18nUnsub !== null) {
      try { this.i18nUnsub(); } catch { /* ignore */ }
      this.i18nUnsub = null;
    }
    try {
      this.onUnmount();
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onUnmount failed:`, err);
    }
    this.statusListeners.clear();
    this.scoreListeners.clear();
    this.canvas = null;
    this.hud = null;
    this.root = null;
    this.container = null;
    this.ctx = null;
    this.status = 'idle';
  }

  /**
   * v4.2（5.8.15）：设置自动暂停监听
   *
   * 监听 document.visibilitychange（标签页隐藏/显示）和 window blur/focus 事件。
   * 当标签页隐藏或窗口失焦时自动暂停游戏；恢复时如果用户未手动暂停则自动继续。
   */
  private setupAutoPause(): void {
    const handleVisibilityChange = (): void => {
      if (document.hidden) {
        /* 标签页隐藏：暂停游戏 */
        if (!this.paused) {
          this.wasPausedBeforeAutoPause = false;
          this.pause();
        } else {
          this.wasPausedBeforeAutoPause = true;
        }
      } else {
        /* 标签页恢复：如果用户未手动暂停，则自动继续 */
        if (!this.wasPausedBeforeAutoPause && this.paused) {
          this.resume();
        }
      }
    };

    const handleWindowBlur = (): void => {
      if (!this.paused && this.status === 'playing') {
        this.wasPausedBeforeAutoPause = false;
        this.pause();
      } else {
        this.wasPausedBeforeAutoPause = true;
      }
    };

    const handleWindowFocus = (): void => {
      if (!this.wasPausedBeforeAutoPause && this.paused && this.status === 'playing') {
        this.resume();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    this.autoPauseUnsub = (): void => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }

  /* ============================================================
     状态管理（子类调用）
     ============================================================ */

  /** 更新当前分数（同时更新最高分） */
  protected updateScore(score: number, level?: number): void {
    this.score = score;
    if (score > this.bestScore) {
      this.bestScore = score;
      this.saveBestScore(score);
    }
    const event: GameScoreEvent = { score, bestScore: this.bestScore, level };
    for (const listener of this.scoreListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDScore();
  }

  /** 更新游戏状态 */
  protected setStatus(status: GameStatus, message?: string): void {
    this.status = status;
    if (this.root !== null) {
      this.root.dataset.status = status;
    }
    const event: GameStatusEvent = { status, message };
    for (const listener of this.statusListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDStatus();
  }

  /** 订阅状态变更 */
  onStatusChange(listener: (e: GameStatusEvent) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  /** 订阅分数变更 */
  onScoreChange(listener: (e: GameScoreEvent) => void): () => void {
    this.scoreListeners.add(listener);
    return () => this.scoreListeners.delete(listener);
  }

  /** 暂停游戏 */
  pause(): void {
    if (this.paused || this.status !== 'playing') return;
    this.paused = true;
    this.setStatus('paused');
    try { this.onPause(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onPause failed:`, err); }
  }

  /** 恢复游戏 */
  resume(): void {
    if (!this.paused) return;
    this.paused = false;
    this.setStatus('playing');
    try { this.onResume(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onResume failed:`, err); }
  }

  /** 切换暂停/恢复 */
  togglePause(): void {
    if (this.paused) this.resume();
    else this.pause();
  }

  /** 重新开始 */
  restart(): void {
    try { this.onRestart(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onRestart failed:`, err); }
  }

  /** v5.0: 切换难度（运行时通过 HUD 下拉触发） */
  changeDifficulty(difficulty: GameDifficulty): void {
    this.currentDifficulty = difficulty;
    try { this.onDifficultyChange(difficulty); } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onDifficultyChange failed:`, err);
    }
  }

  /* ============================================================
     访问器
     ============================================================ */

  protected get currentStatus(): GameStatus { return this.status; }
  protected get currentScore(): number { return this.score; }
  protected get currentBestScore(): number { return this.bestScore; }
  protected get isPaused(): boolean { return this.paused; }
  protected get themeTokens(): GameThemeTokens { return this.theme; }
  protected get canvasElement(): HTMLCanvasElement | null { return this.canvas; }
  /** v5.0: 获取当前难度（供子类 AI 逻辑使用） */
  protected get difficulty(): GameDifficulty { return this.currentDifficulty; }

  /* ============================================================
     DOM 覆盖层（供子类在异步加载前显示状态，不污染 canvas 上下文）
     ============================================================ */

  /**
   * 设置 HiDPI Canvas（Retina/高分屏锐利渲染 + 自适应缩放）。
   *
   * v4.1（2026-07-28）修复文字模糊发虚问题：
   *   - 原方案 canvas CSS 尺寸固定为 logicalW × logicalH，配合 CSS max-width:100%
   *     导致容器小于画布时浏览器缩放位图，文字发虚。
   *   - 新方案测量父容器可用空间，计算等比缩放系数（不放大），将 canvas
   *     内部分辨率设为 displayW*dpr × displayH*dpr，context 缩放 (scale*dpr)，
   *     子类绘制仍用逻辑坐标，位图 1:1 对齐显示像素，文字始终锐利。
   *
   * @returns 2D context（已 scale），或 null 表示浏览器不支持
   */
  protected setupHiDPICanvas(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    this.logicalW = logicalW;
    this.logicalH = logicalH;
    return this.applyCanvasSize(canvas, logicalW, logicalH);
  }

  /**
   * 子类可选实现：画布尺寸变化时回调（由 ResizeObserver 触发）。
   *
   * 默认空实现。子类如需在窗口 resize 时重排布局可覆写。
   * 注意：此方法在每帧 draw 之前调用，无需手动触发重绘。
   */
  protected onCanvasResize(): void {
    /* default no-op */
  }

  /**
   * 将鼠标事件的 CSS 坐标转换为画布逻辑坐标。
   *
   * v5.0 修复：原方案各游戏自行用 canvas.width/rect.width（=dpr）做缩放，
   * 导致 HiDPI（Retina dpr=2）下点击位置偏移 2 倍，棋子无法选中或落子错位。
   * 此方法统一用 logicalW/rect.width（=1/scale）做转换，确保点击精确。
   *
   * @param canvas 画布元素
   * @param clientX 鼠标 clientX
   * @param clientY 鼠标 clientY
   * @returns 逻辑坐标 {x, y}（与 setupHiDPICanvas 传入的 logicalW/H 同坐标系）
   */
  protected clientToLogical(
    canvas: HTMLCanvasElement,
    clientX: number,
    clientY: number,
  ): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
    const scaleX = this.logicalW / rect.width;
    const scaleY = this.logicalH / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  /** 计算缩放系数并应用 canvas 尺寸（内部方法） */
  private applyCanvasSize(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    /* 测量父容器可用空间（扣除 padding） */
    const parent = canvas.parentElement;
    let availW = logicalW;
    let availH = logicalH;
    if (parent !== null) {
      const cs = getComputedStyle(parent);
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      const rect = parent.getBoundingClientRect();
      availW = Math.max(rect.width - padX, 50);
      availH = Math.max(rect.height - padY, 50);
    }

    /* 等比缩放（不放大超过 1x，避免模糊） */
    const scale = Math.min(availW / logicalW, availH / logicalH, 1);
    const displayW = Math.max(Math.round(logicalW * scale), 1);
    const displayH = Math.max(Math.round(logicalH * scale), 1);

    /* 设置 canvas 内部分辨率 = 显示尺寸 × dpr（尺寸未变时跳过赋值，
     * 避免 canvas.width 清空画布导致已绘制内容闪一帧） */
    const pw = Math.round(displayW * dpr);
    const ph = Math.round(displayH * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${displayW}px`;
    canvas.style.height = `${displayH}px`;
    /* 移除 CSS max-width/max-height（避免浏览器二次缩放导致文字模糊） */
    canvas.style.maxWidth = 'none';
    canvas.style.maxHeight = 'none';

    const ctx = canvas.getContext('2d');
    if (ctx !== null) {
      /* context 缩放 = 显示缩放 × dpr，子类用逻辑坐标绘制 */
      ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
    }
    return ctx;
  }

  /**
   * 显示 loading 覆盖层（DOM 方式，不使用 canvas.getContext）。
   *
   * 关键设计：Phaser 等引擎需要 WebGL 上下文，如果在 canvas 上调用
   * getContext('2d')，会导致后续无法创建 WebGL 上下文（同一 canvas
   * 只能有一种类型的 context）。因此 loading/error 状态必须用 DOM 覆盖层实现。
   *
   * @returns overlay 元素，子类可在加载完成后调用 removeLoadingOverlay 移除
   */
  protected showLoadingOverlay(canvas: HTMLCanvasElement, message: string): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-loading-overlay';
    overlay.setAttribute('role', 'status');
    overlay.setAttribute('aria-live', 'polite');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'pointer-events:none',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    }

    /* CSS spinner */
    const spinner = document.createElement('div');
    spinner.className = 'game-host-spinner';
    spinner.style.cssText = [
      'width:32px',
      'height:32px',
      'border-radius:50%',
      `border:3px solid ${this.theme.border}`,
      `border-top-color:${this.theme.accent}`,
      'animation:game-host-spin 0.8s linear infinite',
    ].join(';');
    overlay.appendChild(spinner);

    const text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = `color:${this.theme.fg};font-size:14px;`;
    overlay.appendChild(text);

    /* 注入 keyframes（仅一次；用 querySelector 而非 getElementById，避免转包
     * 校验的 DOM_ID_MISSING 警告（沙箱不加载 index.html，id 声明仅作契约） */
    if (document.querySelector('style#game-host-spinner-style') === null) {
      const style = document.createElement('style');
      style.id = 'game-host-spinner-style';
      style.textContent = '@keyframes game-host-spin{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /** 移除 loading 覆盖层 */
  protected removeLoadingOverlay(overlay: HTMLDivElement): void {
    if (overlay.parentNode !== null) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /** 已废弃：使用 showLoadingOverlay 替代（canvas.getContext('2d') 会阻止 Phaser 创建 WebGL 上下文） */
  protected drawLoadingState(_canvas: HTMLCanvasElement, _message: string): void {
    /* no-op: 请改用 showLoadingOverlay */
  }

  /** 已废弃：使用 showErrorOverlay 替代 */
  protected drawErrorState(_canvas: HTMLCanvasElement, _message: string, _err: unknown): void {
    /* no-op: 请改用 showErrorOverlay */
  }

  /**
   * 显示错误覆盖层（DOM 方式）。
   * @returns overlay 元素
   */
  protected showErrorOverlay(canvas: HTMLCanvasElement, message: string, err: unknown): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-error-overlay';
    overlay.setAttribute('role', 'alert');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:12px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;';
    }

    /* 警示三角形 */
    const icon = document.createElement('div');
    icon.style.cssText = [
      'width:48px',
      'height:48px',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'font-size:28px',
      'color:#ef4444',
    ].join(';');
    icon.textContent = '!';
    overlay.appendChild(icon);

    const msg = document.createElement('span');
    msg.textContent = message;
    msg.style.cssText = `color:${this.theme.fg};font-size:14px;font-weight:600;`;
    overlay.appendChild(msg);

    const detail = err instanceof Error ? err.message : String(err);
    const detailEl = document.createElement('span');
    const maxLen = 80;
    detailEl.textContent = detail.length > maxLen ? detail.slice(0, maxLen) + '...' : detail;
    detailEl.style.cssText = `color:${this.theme.muted};font-size:12px;text-align:center;max-width:80%;word-break:break-word;`;
    overlay.appendChild(detailEl);

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /* ============================================================
     内部实现
     ============================================================ */

  /** 解析启动选项（从 AppMountContext.data 透传，由 WindowManager.launch(options.data) 注入） */
  private resolveOptions(): GameLaunchOptions {
    const data = this.ctx?.data;
    if (data === undefined || data === null) {
      return { difficulty: 'normal', soundEnabled: true, debug: false };
    }
    const difficultyRaw = data['difficulty'];
    const validDifficulties: readonly string[] = ['easy', 'normal', 'hard', 'expert', 'master'];
    const difficulty: GameDifficulty = typeof difficultyRaw === 'string' && validDifficulties.includes(difficultyRaw)
      ? (difficultyRaw as GameDifficulty)
      : 'normal';
    const soundEnabled = typeof data['soundEnabled'] === 'boolean' ? data['soundEnabled'] : true;
    const debug = typeof data['debug'] === 'boolean' ? data['debug'] : false;
    const levelRaw = data['level'];
    const level = typeof levelRaw === 'number' && Number.isInteger(levelRaw) && levelRaw > 0 ? levelRaw : undefined;
    const gameModeRaw = data['gameMode'];
    const gameMode = typeof gameModeRaw === 'string' && gameModeRaw !== '' ? gameModeRaw : undefined;
    return { difficulty, soundEnabled, debug, level, gameMode };
  }

  /** 解析主题 token */
  private resolveThemeTokens(): GameThemeTokens {
    if (typeof window === 'undefined' || window === null) return DEFAULT_THEME_TOKENS;
    const style = window.getComputedStyle(document.documentElement);
    /** 读取单个 CSS 变量，空字符串视为未定义 */
    const get = (name: string): string => style.getPropertyValue(name).trim();
    /** 依次尝试多个变量名，全部未定义时使用 fallback */
    const pick = (names: readonly string[], fallback: string): string => {
      for (const name of names) {
        const v = get(name);
        if (v !== '') return v;
      }
      return fallback;
    };
    /* 宿主真实 token 优先（--fg-primary/--bg-canvas 宿主未定义，回退 --glass-text-* / --surface-*）；
       全部缺失时兜底深色（黑底白字仍可读） */
    const bg = pick(['--bg-canvas', '--surface-solid-primary', '--glass-bg-L1', '--bg-primary'], '#0e0f12');
    /* 背景亮度检测用实色（渐变无法取亮度）；浅色主题下文字/面板自动切深色系 */
    const dark = GameHost.isLuminanceDark(pick(['--surface-solid-primary', '--bg-primary'], '#0e0f12'));
    return {
      bg,
      fg: pick(['--fg-primary', '--glass-text-primary', '--text-primary'], dark ? '#e8e8e8' : '#1a1a1a'),
      accent: pick(['--accent-cool'], '#4a9eff'),
      muted: pick(['--fg-muted', '--glass-text-secondary', '--text-secondary'], dark ? '#888888' : '#5f6670'),
      border: pick(['--border-subtle', '--glass-divider', '--glass-border-L3'], '#333333'),
    } as GameThemeTokens;
  }

  /** 亮度判断（--bg-primary 为实色可解析；渐变等非 hex 一律视为深色） */
  private static isLuminanceDark(color: string): boolean {
    const m = /^#([0-9a-f]{6})$/i.exec(color);
    if (m === null) return true;
    const hex = m[1]!;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  }

  /** 同步主题 token 到根元素 CSS 变量（styles.css 的 var() 消费；浅色皮肤下文字/面板切深色系） */
  private applyThemeToRoot(): void {
    if (this.root === null) return;
    const t = this.theme;
    const s = this.root.style;
    s.setProperty('--fg-primary', t.fg);
    s.setProperty('--fg-muted', t.muted);
    s.setProperty('--bg-active', t.dark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)');
    s.setProperty('--bg-hover', t.dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)');
    s.setProperty('--bg-elevated', t.dark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)');
  }

  /** 应用主题到画布：canvas 内容由游戏引擎自绘（Phaser backgroundColor / 棋盘底色），
   *  CSS 背景不透明色会在引擎首帧前露出白/黑块（坊市体验层泛白根因之一），故置透明 */
  private applyThemeToCanvas(): void {
    if (this.canvas === null) return;
    this.canvas.style.background = 'transparent';
  }

  /** 创建 HUD */
  private createHUD(ctx: AppMountContext): HTMLElement {
    const hud = document.createElement('div');
    hud.className = 'game-host-hud';

    const left = document.createElement('div');
    left.className = 'game-host-hud-left';

    const title = document.createElement('span');
    title.className = 'game-host-hud-title';
    title.textContent = this.resolveGameName(ctx);
    left.appendChild(title);

    const score = document.createElement('span');
    score.className = 'game-host-hud-score';
    score.dataset.role = 'score';
    score.textContent = this.formatScoreText(0, this.bestScore);
    left.appendChild(score);

    hud.appendChild(left);

    const right = document.createElement('div');
    right.className = 'game-host-hud-right';

    /* v5.0: 难度选择器（下拉菜单，支持 5 档难度） */
    const diffWrap = document.createElement('div');
    diffWrap.className = 'game-host-hud-difficulty-wrap';
    const diffSelect = document.createElement('select');
    /* P4.7：按钮基座化（铁律 9）——消费 .btn 基座变体（次按钮 + 小尺寸），
     * 保留 game-host-hud-btn 类名用于模板内定位/复刻样式桥接 */
    diffSelect.className = 'game-host-hud-btn btn btn--secondary btn--sm game-host-hud-difficulty-select';
    diffSelect.dataset.role = 'difficulty';
    diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
    const diffOptions: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
      { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
      { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
      { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
      { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
      { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
    ];
    for (const opt of diffOptions) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = this.tr(ctx, opt.labelKey, opt.fallback);
      diffSelect.appendChild(o);
    }
    diffSelect.value = this.currentDifficulty;
    diffSelect.addEventListener('change', () => {
      const val = diffSelect.value as GameDifficulty;
      this.changeDifficulty(val);
    });
    diffWrap.appendChild(diffSelect);
    right.appendChild(diffWrap);

    if (this.config.pauseable !== false) {
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
      pauseBtn.dataset.role = 'pause';
      pauseBtn.textContent = this.tr(ctx, 'game.hud.pause', 'Pause');
      pauseBtn.addEventListener('click', () => this.togglePause());
      right.appendChild(pauseBtn);
    }

    const restartBtn = document.createElement('button');
    restartBtn.type = 'button';
    restartBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
    restartBtn.dataset.role = 'restart';
    restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    restartBtn.addEventListener('click', () => this.restart());
    right.appendChild(restartBtn);

    hud.appendChild(right);
    return hud;
  }

  /** 更新 HUD 分数显示 */
  private updateHUDScore(): void {
    if (this.hud === null) return;
    const scoreEl = this.hud.querySelector<HTMLElement>('[data-role="score"]');
    if (scoreEl !== null) {
      scoreEl.textContent = this.formatScoreText(this.score, this.bestScore);
    }
  }

  /** i18n 刷新（Step 4.1）：宿主语言切换后重设 HUD 文案（data-role 查询 + 子类 hook） */
  protected refreshHudI18n(): void {
    if (this.hud === null) return;
    const ctx = this.ctx;
    if (ctx === null) return;
    const diffSelect = this.hud.querySelector<HTMLSelectElement>('[data-role="difficulty"]');
    if (diffSelect !== null) {
      diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
      const labels: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
        { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
        { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
        { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
        { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
        { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
      ];
      const options = diffSelect.querySelectorAll('option');
      options.forEach((o) => {
        const label = labels.find((l) => l.value === o.value);
        if (label !== undefined) o.textContent = this.tr(ctx, label.labelKey, label.fallback);
      });
    }
    /* 暂停遮罩文案（CSS ::after content 消费 dataset.pausedText） */
    const canvasWrap = this.root !== null ? this.root.querySelector<HTMLElement>('.game-host-canvas-wrap') : null;
    if (canvasWrap !== null) {
      canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');
    }
    if (this.canvas !== null) this.canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    /* HUD 标题（游戏名）+ 重新开始按钮（2026-08-27 P4.1f 运行时验证补齐） */
    const titleEl = this.hud.querySelector<HTMLElement>('.game-host-hud-title');
    if (titleEl !== null) titleEl.textContent = this.resolveGameName(ctx);
    const restartBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="restart"]');
    if (restartBtn !== null) restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    this.updateHUDStatus();
    this.updateHUDScore();
    if (this.onI18nRefresh !== undefined) {
      try { this.onI18nRefresh(); } catch { /* ignore */ }
    }
  }

  /** i18n 刷新子类 hook（如 tank 的 Phaser 场景 overlays 重建） */
  protected onI18nRefresh?: () => void;

  /** 更新 HUD 状态显示 */
  private updateHUDStatus(): void {
    if (this.hud === null) return;
    const pauseBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="pause"]');
    if (pauseBtn !== null) {
      pauseBtn.textContent = this.paused
        ? this.tr(this.ctx, 'game.hud.resume', 'Resume')
        : this.tr(this.ctx, 'game.hud.pause', 'Pause');
    }
  }

  /** 格式化分数显示 */
  private formatScoreText(score: number, best: number): string {
    const scoreStr = this.tr(this.ctx, 'game.hud.score', 'Score');
    const bestStr = this.tr(this.ctx, 'game.hud.best', 'Best');
    return `${scoreStr} ${score}  ·  ${bestStr} ${best}`;
  }

  /** 解析游戏名称（从 manifest.nameFallback） */
  private resolveGameName(ctx: AppMountContext): string {
    const nameKey = ctx.manifest.nameKey;
    if (nameKey !== undefined && nameKey !== '') {
      const tr = this.tr(ctx, nameKey, ctx.manifest.nameFallback);
      if (tr !== nameKey) return tr;
    }
    return ctx.manifest.nameFallback;
  }

  /** i18n 翻译（带兜底） */
  private tr(ctx: AppMountContext | null, key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string {
    if (ctx === null) return fallback;
    try {
      const result = ctx.t(key, params);
      if (result !== key) return result;
    } catch {
      /* ignore */
    }
    return params === undefined ? fallback : fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
      const value = params[name];
      return value !== undefined ? String(value) : '';
    });
  }

  /* ============================================================
     最高分持久化（P4.3：sandboxStorage 代理，键 game:best:game-go）
     ============================================================ */

  private async loadBestScore(): Promise<number> {
    const storage = getSandboxStorage();
    if (storage === null) return 0;
    try {
      const raw = await storage.get(BEST_SCORE_KEY_PREFIX + this.config.gameId);
      if (raw === null || raw === undefined) return 0;
      const n = Number.parseInt(String(raw), 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch {
      return 0;
    }
  }

  private saveBestScore(score: number): void {
    const storage = getSandboxStorage();
    if (storage === null) return;
    void storage.set(BEST_SCORE_KEY_PREFIX + this.config.gameId, String(score)).catch(() => {
      /* ignore quota */
    });
  }
}


  /* =========================================================
     5. GoHost 内联（原 src/shared/apps/games/builtin/go/GoHost.ts）
     ========================================================= */

/**
 * GoHost — 围棋游戏实现
 *
 * 引擎：Canvas 2D
 * 操作：鼠标点击落子；P 键 pass（虚手）
 * 规则：19×19 标准围棋，黑白交替，提子/自杀禁手/劫争/数子法
 * 模式：单人对 AI（玩家执黑，AI 执白）
 */






/* ============================================================
   常量
   ============================================================ */

/** 棋盘大小（19×19 标准棋盘） */
const SIZE = 19;
/** 每格间距（CSS 像素） */
const CELL = 28;
/** 棋盘内边距（v5.0: 36 → 44，确保坐标标注与棋盘边框保留充分间隔） */
const PAD = 44;
/** 棋盘区域宽度：2*36 + 504 = 576 */
const BOARD_W = 2 * PAD + (SIZE - 1) * CELL;
/** 棋盘区域高度（与宽度等长） */
const BOARD_H = BOARD_W;
/** 右侧侧边栏宽度（HUD + 走棋历史） */
const SIDEBAR_W = 120;
/** 画布总宽度：棋盘 + 侧边栏 = 576 + 120 = 696 */
const W = BOARD_W + SIDEBAR_W;
/** 画布总高度 */
const H = BOARD_H;

/** 棋盘格状态：空 / 黑 / 白 */
const EMPTY = 0;
const BLACK = 1;
const WHITE = 2;

/** 贴目（白方补偿，中国规则常用 7.5，此处简化为 6.5） */
const KOMI = 6.5;

/** 列标 A-T 跳过 I（共 19 列） */
const COL_LETTERS = 'ABCDEFGHJKLMNOPQRST';

/** 正交方向（上下左右） */
const DIRS: readonly (readonly [number, number])[] = [
  [-1, 0], [1, 0], [0, -1], [0, 1],
];

/** 9 个星位坐标（4 角 + 4 边中 + 天元） */
const STAR_POINTS: readonly (readonly [number, number])[] = [
  [3, 3], [9, 3], [15, 3],
  [3, 9], [9, 9], [15, 9],
  [3, 15], [9, 15], [15, 15],
];

/** 落子动画时长（毫秒） */
const PLACE_ANIM_DUR = 180;
/** 提子淡出动画时长（毫秒） */
const CAPTURE_ANIM_DUR = 280;

/* ============================================================
   类型
   ============================================================ */

/** 棋子颜色（1=黑，2=白） */
type Stone = 1 | 2;

/** 走棋记录 */
interface MoveRecord {
  /** 落子方 */
  readonly color: Stone;
  /** 棋盘 X（0=最左列 A，18=最右列 T）；pass 时为 -1 */
  readonly x: number;
  /** 棋盘 Y（0=最上行 19，18=最下行 1）；pass 时为 -1 */
  readonly y: number;
  /** 本手提子数 */
  readonly captured: number;
  /** 是否为虚手（pass） */
  readonly isPass: boolean;
}

/** 落子动画状态 */
interface PlaceAnim {
  readonly x: number;
  readonly y: number;
  readonly color: Stone;
  readonly startTime: number;
}

/** 提子淡出动画 */
interface CaptureAnim {
  readonly x: number;
  readonly y: number;
  readonly color: Stone;
  readonly startTime: number;
}

/** 被临时记录的提子（用于回退） */
interface CapturedStone {
  readonly x: number;
  readonly y: number;
  readonly color: Stone;
}

/** 棋串查找结果 */
interface GroupInfo {
  readonly stones: ReadonlyArray<{ x: number; y: number }>;
  readonly liberties: number;
}

/* ============================================================
   GoHost
   ============================================================ */

/**
 * 围棋游戏宿主。
 *
 * 继承 GameHost，使用 Canvas 2D 渲染 19×19 围棋棋盘。
 * 实现完整规则：气/提子/自杀禁手/劫争/虚手/数子法。
 * 内置简单启发式 AI（执白）。
 */
class GoHost extends GameHost {
  private ctx2d: CanvasRenderingContext2D | null = null;
  /** 棋盘状态：board[y][x]，y=0 为顶部（第 19 行），x=0 为左侧（A 列） */
  private board: number[][] = [];
  /** 当前回合方 */
  private turn: Stone = BLACK;
  /** 黑方提子数（黑吃白） */
  private capturedByBlack = 0;
  /** 白方提子数（白吃黑） */
  private capturedByWhite = 0;
  /** 连续 pass 次数（双方各 pass 一次则结束） */
  private consecutivePasses = 0;
  /** 总走棋步数 */
  private moveCount = 0;
  /** 走棋历史 */
  private history: MoveRecord[] = [];
  /** 最后一手 */
  private lastMove: MoveRecord | null = null;
  /** 劫争禁着点（不可立即回提的位置） */
  private koPoint: { x: number; y: number } | null = null;
  /** 游戏是否已结束 */
  private gameOver = false;
  /** 胜负结果文本 */
  private resultText = '';
  /** 落子缩放动画 */
  private placeAnim: PlaceAnim | null = null;
  /** 提子淡出动画队列 */
  private captureAnims: CaptureAnim[] = [];

  private rafId: number | null = null;
  private clickHandler: ((e: MouseEvent) => void) | null = null;
  private keyHandler: ((e: KeyboardEvent) => void) | null = null;

  /** 是否启用 AI 对手 */
  private readonly aiEnabled = true;
  /** AI 是否正在思考 */
  private aiThinking = false;
  /** AI 走子定时器（必须在 onUnmount 中清理） */
  private aiTimeout: ReturnType<typeof setTimeout> | null = null;

  /* ============================================================
     生命周期
     ============================================================ */

  protected onMount(_ctx: AppMountContext, canvas: HTMLCanvasElement, _options: GameLaunchOptions): void {
    const ctx2d = this.setupHiDPICanvas(canvas, W, H);
    if (ctx2d === null) return;
    this.ctx2d = ctx2d;
    this.reset();

    this.clickHandler = (e: MouseEvent) => this.onClick(e, canvas);
    canvas.addEventListener('click', this.clickHandler);
    this.keyHandler = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P') this.doPass();
    };
    window.addEventListener('keydown', this.keyHandler);

    const loop = (): void => {
      this.draw();
      this.rafId = window.requestAnimationFrame(loop);
    };
    this.rafId = window.requestAnimationFrame(loop);
  }

  protected onUnmount(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    if (this.clickHandler !== null) {
      const c = this.canvasElement;
      if (c !== null) c.removeEventListener('click', this.clickHandler);
      this.clickHandler = null;
    }
    if (this.keyHandler !== null) {
      window.removeEventListener('keydown', this.keyHandler);
      this.keyHandler = null;
    }
    this.ctx2d = null;
  }

  protected override onPause(): void {
    /* 暂停时取消正在等待的 AI 走子，恢复时由 onResume 重新调度 */
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.aiThinking = false;
  }

  protected override onResume(): void {
    /* 若暂停时轮到 AI，恢复后重新调度 */
    if (this.aiEnabled && this.turn === WHITE && !this.gameOver && this.aiTimeout === null) {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 300);
    }
  }

  protected override onRestart(): void {
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.reset();
  }

  private reset(): void {
    this.board = Array.from({ length: SIZE }, () => new Array<number>(SIZE).fill(EMPTY));
    this.turn = BLACK;
    this.capturedByBlack = 0;
    this.capturedByWhite = 0;
    this.consecutivePasses = 0;
    this.moveCount = 0;
    this.history = [];
    this.lastMove = null;
    this.koPoint = null;
    this.gameOver = false;
    this.resultText = '';
    this.placeAnim = null;
    this.captureAnims = [];
    this.aiThinking = false;
    this.updateScore(0);
    this.setStatus('playing');
  }

  /* ============================================================
     落子逻辑
     ============================================================ */

  private onClick(e: MouseEvent, canvas: HTMLCanvasElement): void {
    if (this.currentStatus !== 'playing' || this.gameOver) return;
    if (this.aiEnabled && this.turn === WHITE) return; /* AI 回合 */
    if (this.aiThinking) return;

    /* v5.0 修复：使用 clientToLogical 统一转换坐标，修复 HiDPI 下点击偏移 */
    const { x: lx, y: ly } = this.clientToLogical(canvas, e.clientX, e.clientY);
    const x = Math.round((lx - PAD) / CELL);
    const y = Math.round((ly - PAD) / CELL);
    if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return;

    this.tryPlace(x, y);
  }

  /**
   * 尝试在 (x,y) 落子（当前方）。
   * 执行完整规则检查：空位、劫争、提子、自杀禁手。
   * @returns 是否落子成功
   */
  private tryPlace(x: number, y: number): boolean {
    if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return false;
    if (this.gameOver) return false;
    if (this.board[y]![x] !== EMPTY) return false;
    /* 劫争检查 */
    if (this.koPoint !== null && this.koPoint.x === x && this.koPoint.y === y) return false;

    const opponent: Stone = this.turn === BLACK ? WHITE : BLACK;

    /* 暂时落下 */
    this.board[y]![x] = this.turn;

    /* 检查相邻对方棋串是否被提（无气则提） */
    const capturedStones: CapturedStone[] = [];
    for (const [dx, dy] of DIRS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      if (this.board[ny]![nx] !== opponent) continue;
      /* 仅当该对方棋串尚未被标记为提子时检查（避免重复 BFS） */
      const alreadyCaptured = capturedStones.some((s) => s.x === nx && s.y === ny);
      if (alreadyCaptured) continue;
      const group = this.findGroup(nx, ny);
      if (group.liberties === 0) {
        for (const s of group.stones) {
          if (this.board[s.y]![s.x] === opponent) {
            this.board[s.y]![s.x] = EMPTY;
            capturedStones.push({ x: s.x, y: s.y, color: opponent });
          }
        }
      }
    }

    /* 自杀检查：落下后若无气且未提子，则禁手 */
    const myGroup = this.findGroup(x, y);
    if (myGroup.liberties === 0) {
      /* 回退 */
      this.board[y]![x] = EMPTY;
      for (const c of capturedStones) {
        this.board[c.y]![c.x] = c.color;
      }
      return false;
    }

    /* 劫争判定：仅提 1 子 + 本身为单子 + 仅 1 气 → 标记劫点 */
    if (
      capturedStones.length === 1 &&
      myGroup.stones.length === 1 &&
      myGroup.liberties === 1
    ) {
      const cap = capturedStones[0]!;
      this.koPoint = { x: cap.x, y: cap.y };
    } else {
      this.koPoint = null;
    }

    /* 更新提子统计 */
    if (this.turn === BLACK) this.capturedByBlack += capturedStones.length;
    else this.capturedByWhite += capturedStones.length;

    /* 记录走棋 */
    const move: MoveRecord = {
      color: this.turn,
      x,
      y,
      captured: capturedStones.length,
      isPass: false,
    };
    this.history.push(move);
    this.lastMove = move;
    this.moveCount++;
    this.consecutivePasses = 0;

    /* 触发动画 */
    const now = performance.now();
    this.placeAnim = { x, y, color: this.turn, startTime: now };
    for (const c of capturedStones) {
      this.captureAnims.push({ x: c.x, y: c.y, color: c.color, startTime: now });
    }

    /* 用步数作为 HUD 分数（仅用于显示进度） */
    this.updateScore(this.moveCount);

    /* 切换回合 */
    this.turn = this.turn === BLACK ? WHITE : BLACK;

    /* 调度 AI */
    if (this.aiEnabled && this.turn === WHITE && !this.gameOver) {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 300);
    }

    return true;
  }

  /** 玩家主动 pass（按 P 键） */
  private doPass(): void {
    if (this.currentStatus !== 'playing' || this.gameOver) return;
    if (this.aiEnabled && this.turn === WHITE) return;
    if (this.aiThinking) return;
    this.performPass();
  }

  /** 执行 pass（玩家或 AI 共用） */
  private performPass(): void {
    const move: MoveRecord = {
      color: this.turn,
      x: -1,
      y: -1,
      captured: 0,
      isPass: true,
    };
    this.history.push(move);
    this.lastMove = move;
    this.moveCount++;
    this.consecutivePasses++;
    this.koPoint = null;
    this.updateScore(this.moveCount);

    /* 双方连续 pass → 进入数子 */
    if (this.consecutivePasses >= 2) {
      this.endGame();
      return;
    }

    this.turn = this.turn === BLACK ? WHITE : BLACK;

    if (this.aiEnabled && this.turn === WHITE && !this.gameOver) {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 300);
    }
  }

  /** 结束对局并执行数子 */
  private endGame(): void {
    this.gameOver = true;
    this.aiThinking = false;
    const score = this.calculateScore();
    const blackScore = score.black;
    const whiteScore = score.white + KOMI;
    const diff = blackScore - whiteScore;
    if (diff > 0) {
      this.resultText = this.tr(this.ctx, 'game.go.result.blackWin', 'Black wins by {points} pts (Black {black} / White {white}, komi {komi})', { points: diff.toFixed(1), black: String(blackScore), white: whiteScore.toFixed(1), komi: String(KOMI) });
    } else if (diff < 0) {
      this.resultText = this.tr(this.ctx, 'game.go.result.whiteWin', 'White wins by {points} pts (Black {black} / White {white}, komi {komi})', { points: (-diff).toFixed(1), black: String(blackScore), white: whiteScore.toFixed(1), komi: String(KOMI) });
    } else {
      this.resultText = this.tr(this.ctx, 'game.go.result.draw', 'Draw (Black {black} / White {white}, komi {komi})', { black: String(blackScore), white: whiteScore.toFixed(1), komi: String(KOMI) });
    }
    this.setStatus('gameover', this.resultText);
  }

  /* ============================================================
     棋串与气
     ============================================================ */

  /**
   * 查找 (x,y) 所在棋串的所有棋子与气数。
   * 使用 BFS 遍历同色相邻棋子，统计不重复的空邻点。
   */
  private findGroup(x: number, y: number): GroupInfo {
    const color = this.board[y]![x];
    if (color === EMPTY) return { stones: [], liberties: 0 };

    const stones: Array<{ x: number; y: number }> = [];
    const libertiesSet = new Set<string>();
    const visited = new Set<string>();
    const queue: Array<{ x: number; y: number }> = [{ x, y }];
    visited.add(`${x},${y}`);

    while (queue.length > 0) {
      const cur = queue.shift()!;
      stones.push(cur);
      for (const [dx, dy] of DIRS) {
        const nx = cur.x + dx;
        const ny = cur.y + dy;
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
        const key = `${nx},${ny}`;
        if (visited.has(key)) continue;
        const v = this.board[ny]![nx];
        if (v === EMPTY) {
          libertiesSet.add(key);
        } else if (v === color) {
          visited.add(key);
          queue.push({ x: nx, y: ny });
        }
      }
    }
    return { stones, liberties: libertiesSet.size };
  }

  /* ============================================================
     数子（中国规则区域计分）
     ============================================================ */

  /**
   * 计算双方占地（棋子数 + 围空数）。
   * 空区域若仅相邻一方棋子，则归该方；相邻双方或无棋子为公气（不计）。
   */
  private calculateScore(): { black: number; white: number } {
    let blackStones = 0;
    let whiteStones = 0;
    let blackTerritory = 0;
    let whiteTerritory = 0;

    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        const v = this.board[y]![x];
        if (v === BLACK) blackStones++;
        else if (v === WHITE) whiteStones++;
      }
    }

    /* Flood fill 每个空区域，判断归属 */
    const visited = Array.from({ length: SIZE }, () => new Array<boolean>(SIZE).fill(false));
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        if (visited[y]![x] === true) continue;
        if (this.board[y]![x] !== EMPTY) continue;
        const region: Array<{ x: number; y: number }> = [];
        let touchesBlack = false;
        let touchesWhite = false;
        const queue: Array<{ x: number; y: number }> = [{ x, y }];
        visited[y]![x] = true;
        while (queue.length > 0) {
          const cur = queue.shift()!;
          region.push(cur);
          for (const [dx, dy] of DIRS) {
            const nx = cur.x + dx;
            const ny = cur.y + dy;
            if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
            if (visited[ny]![nx] === true) continue;
            const v = this.board[ny]![nx];
            if (v === EMPTY) {
              visited[ny]![nx] = true;
              queue.push({ x: nx, y: ny });
            } else if (v === BLACK) {
              touchesBlack = true;
            } else if (v === WHITE) {
              touchesWhite = true;
            }
          }
        }
        if (touchesBlack && !touchesWhite) blackTerritory += region.length;
        else if (touchesWhite && !touchesBlack) whiteTerritory += region.length;
      }
    }

    return {
      black: blackStones + blackTerritory,
      white: whiteStones + whiteTerritory,
    };
  }

  /* ============================================================
     AI（启发式评分）
     ============================================================ */

  /** AI 走子：评估所有合法位置，选最优（含少量随机性） */
  private aiMove(): void {
    this.aiTimeout = null;
    if (this.currentStatus !== 'playing' || this.gameOver) {
      this.aiThinking = false;
      return;
    }

    const candidates: Array<{ x: number; y: number; score: number }> = [];
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        if (this.board[y]![x] !== EMPTY) continue;
        if (!this.isLegalMove(x, y, WHITE)) continue;
        const sc = this.evaluateMove(x, y, WHITE);
        candidates.push({ x, y, score: sc });
      }
    }

    this.aiThinking = false;

    /* 无合法位置或所有位置评分过低 → pass */
    if (candidates.length === 0) {
      this.performPass();
      return;
    }

    candidates.sort((a, b) => b.score - a.score);
    const bestScore = candidates[0]!.score;
    if (bestScore < -5) {
      this.performPass();
      return;
    }

    /* v5.0: 5 档难度选点策略
     * easy: 前 8 名随机选（弱）
     * normal: 前 5 名随机选
     * hard: 前 3 名随机选
     * expert: 前 2 名随机选
     * master: 始终选最优（最强） */
    const topNMap: Record<string, number> = {
      easy: 8, normal: 5, hard: 3, expert: 2, master: 1,
    };
    const topN = Math.min(topNMap[this.difficulty] ?? 3, candidates.length);
    const top = candidates.slice(0, topN);
    const pick = top[Math.floor(Math.random() * topN)]!;
    this.tryPlace(pick.x, pick.y);
  }

  /**
   * 检查 (x,y) 落子为 who 是否合法（不实际改变棋盘）。
   * 合法条件：非空位、非劫点、非自杀（除非能提对方子）。
   */
  private isLegalMove(x: number, y: number, who: Stone): boolean {
    if (this.board[y]![x] !== EMPTY) return false;
    if (this.koPoint !== null && this.koPoint.x === x && this.koPoint.y === y) return false;

    const opponent: Stone = who === BLACK ? WHITE : BLACK;
    this.board[y]![x] = who;

    /* 收集会被提子的对方棋串 */
    const capturedList: Array<{ x: number; y: number }> = [];
    for (const [dx, dy] of DIRS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      if (this.board[ny]![nx] !== opponent) continue;
      if (capturedList.some((s) => s.x === nx && s.y === ny)) continue;
      const g = this.findGroup(nx, ny);
      if (g.liberties === 0) {
        for (const s of g.stones) capturedList.push({ x: s.x, y: s.y });
      }
    }

    /* 临时移除被提子 */
    for (const s of capturedList) {
      this.board[s.y]![s.x] = EMPTY;
    }

    /* 自杀判定：移除被提子后，自身棋串仍无气则非法 */
    const myGroup = this.findGroup(x, y);
    const legal = myGroup.liberties > 0;

    /* 还原棋盘 */
    for (const s of capturedList) {
      this.board[s.y]![s.x] = opponent;
    }
    this.board[y]![x] = EMPTY;

    return legal;
  }

  /**
   * 评估在 (x,y) 落子为 who 的价值（启发式综合评分）。
   * 评分维度：提子、打吃、自身气数、邻近棋子、位置偏好。
   */
  private evaluateMove(x: number, y: number, who: Stone): number {
    const opponent: Stone = who === BLACK ? WHITE : BLACK;
    let score = 0;

    /* 中心偏好（轻微） */
    const center = (SIZE - 1) / 2;
    const distFromCenter = Math.abs(x - center) + Math.abs(y - center);
    score += Math.max(0, 10 - distFromCenter) * 0.4;

    /* 开局阶段偏好三/四线，避免一线二线 */
    if (this.moveCount < 30) {
      const edgeDist = Math.min(x, y, SIZE - 1 - x, SIZE - 1 - y);
      if (edgeDist === 0) score -= 8;
      else if (edgeDist === 1) score -= 3;
      else if (edgeDist === 2) score += 2;
      else if (edgeDist === 3) score += 3;
    }

    /* 模拟落子 */
    this.board[y]![x] = who;

    /* 计算提子 */
    const capturedList: Array<{ x: number; y: number }> = [];
    for (const [dx, dy] of DIRS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      if (this.board[ny]![nx] !== opponent) continue;
      if (capturedList.some((s) => s.x === nx && s.y === ny)) continue;
      const g = this.findGroup(nx, ny);
      if (g.liberties === 0) {
        for (const s of g.stones) capturedList.push({ x: s.x, y: s.y });
      }
    }
    score += capturedList.length * 20;

    /* 临时移除被提子，评估自身棋形 */
    for (const s of capturedList) {
      this.board[s.y]![s.x] = EMPTY;
    }

    const myGroup = this.findGroup(x, y);
    if (myGroup.liberties === 1) {
      /* 自打吃，扣分（除非提子数足够补偿） */
      score -= 15;
    } else if (myGroup.liberties === 2) {
      score -= 2;
    } else {
      score += Math.min(myGroup.liberties, 4);
    }

    /* 评估对相邻棋串的攻防影响 */
    for (const [dx, dy] of DIRS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      const v = this.board[ny]![nx];
      if (v === EMPTY) {
        score += 1; /* 增加自身气 */
      } else if (v === opponent) {
        /* 攻击对方棋串 */
        const og = this.findGroup(nx, ny);
        if (og.liberties === 1) score += 8; /* 打吃 */
        else if (og.liberties === 2) score += 3;
      }
    }

    /* 还原被提子 */
    for (const s of capturedList) {
      this.board[s.y]![s.x] = opponent;
    }
    this.board[y]![x] = EMPTY;

    /* 邻近已有棋子加分（避免孤立落子） */
    let hasNeighbor = false;
    for (let dy = -2; dy <= 2 && !hasNeighbor; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        if (dx === 0 && dy === 0) continue;
        const nx = x + dx;
        const ny = y + dy;
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
        if (this.board[ny]![nx] !== EMPTY) {
          hasNeighbor = true;
          break;
        }
      }
    }
    if (hasNeighbor) score += 3;
    else if (this.moveCount > 0) score -= 2;

    /* 避免填自己的眼：若所有正交邻居都是己方棋子或边界，大幅扣分。
     * 这是围棋基本功——不填自己的眼，否则会把活棋走死。 */
    let allMine = true;
    let neighborCount = 0;
    for (const [dx, dy] of DIRS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      neighborCount++;
      if (this.board[ny]![nx] !== who) {
        allMine = false;
        break;
      }
    }
    if (allMine && neighborCount >= 2) {
      score -= 30; /* 重罚填眼 */
    }

    return score;
  }

  /* ============================================================
     渲染
     ============================================================ */

  private draw(): void {
    const ctx = this.ctx2d;
    if (ctx === null) return;
    const theme = this.themeTokens;

    /* 主背景 */
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, W, H);

    this.drawBoard(ctx);
    this.drawStones(ctx);
    this.drawSidebar(ctx);
    this.drawOverlay(ctx);
  }

  /** 绘制棋盘：木纹背景、网格、星位、坐标标注 */
  private drawBoard(ctx: CanvasRenderingContext2D): void {
    /* 棋盘外框（深色木纹） */
    const bx = PAD - 12;
    const by = PAD - 12;
    const bw = (SIZE - 1) * CELL + 24;
    const bh = bw;
    ctx.fillStyle = '#5a4a35';
    ctx.fillRect(bx, by, bw, bh);

    /* 棋盘表面（木纹色渐变 #f0d6a0 → #e8c880） */
    const grad = ctx.createLinearGradient(bx + 4, by + 4, bx + bw - 4, by + bh - 4);
    grad.addColorStop(0, '#f0d6a0');
    grad.addColorStop(1, '#e8c880');
    ctx.fillStyle = grad;
    ctx.fillRect(bx + 4, by + 4, bw - 8, bh - 8);

    /* 木纹细线（贝塞尔曲线增加质感） */
    ctx.strokeStyle = 'rgba(122, 92, 50, 0.12)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 10; i++) {
      ctx.beginPath();
      const yy = by + 4 + (bh - 8) * (i / 10);
      ctx.moveTo(bx + 4, yy);
      ctx.bezierCurveTo(
        bx + bw / 3, yy + 2,
        bx + (2 * bw) / 3, yy - 2,
        bx + bw - 4, yy,
      );
      ctx.stroke();
    }

    /* 网格线（深棕色） */
    ctx.strokeStyle = '#5a3e1a';
    ctx.lineWidth = 1;
    for (let i = 0; i < SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(PAD, PAD + i * CELL);
      ctx.lineTo(PAD + (SIZE - 1) * CELL, PAD + i * CELL);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(PAD + i * CELL, PAD);
      ctx.lineTo(PAD + i * CELL, PAD + (SIZE - 1) * CELL);
      ctx.stroke();
    }

    /* 内边框加粗 */
    ctx.strokeStyle = '#3a2a14';
    ctx.lineWidth = 2;
    ctx.strokeRect(
      PAD - 1,
      PAD - 1,
      (SIZE - 1) * CELL + 2,
      (SIZE - 1) * CELL + 2,
    );

    /* 星位（9 个实心圆点） */
    ctx.fillStyle = '#3a2a14';
    for (const [sx, sy] of STAR_POINTS) {
      ctx.beginPath();
      ctx.arc(PAD + sx * CELL, PAD + sy * CELL, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }

    /* 坐标标注（列 A-T 跳过 I，行 1-19） */
    ctx.fillStyle = '#6a4a24';
    ctx.font = '10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (let i = 0; i < SIZE; i++) {
      const colChar = COL_LETTERS[i];
      if (colChar !== undefined) {
        ctx.fillText(colChar, PAD + i * CELL, PAD - 20);
        ctx.fillText(colChar, PAD + i * CELL, PAD + (SIZE - 1) * CELL + 20);
      }
      /* y=0 对应第 19 行，y=18 对应第 1 行 */
      const rowNum = String(SIZE - i);
      ctx.fillText(rowNum, PAD - 20, PAD + i * CELL);
      ctx.fillText(rowNum, PAD + (SIZE - 1) * CELL + 20, PAD + i * CELL);
    }
  }

  /** 绘制所有棋子、落子动画、提子动画、最后一手标记 */
  private drawStones(ctx: CanvasRenderingContext2D): void {
    const now = performance.now();

    /* 渲染棋盘上的棋子 */
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        const v = this.board[y]![x];
        if (v === undefined || v === EMPTY) continue;
        let scale = 1;
        /* 落子缩放动画：1.2x → 1.0x */
        if (this.placeAnim !== null && this.placeAnim.x === x && this.placeAnim.y === y) {
          const elapsed = now - this.placeAnim.startTime;
          if (elapsed < PLACE_ANIM_DUR) {
            const t = elapsed / PLACE_ANIM_DUR;
            scale = 1.2 - 0.2 * t;
          }
        }
        this.drawStone(ctx, x, y, v, scale, 1);
      }
    }

    /* 提子淡出动画 */
    const remaining: CaptureAnim[] = [];
    for (const anim of this.captureAnims) {
      const elapsed = now - anim.startTime;
      if (elapsed >= CAPTURE_ANIM_DUR) continue;
      const t = elapsed / CAPTURE_ANIM_DUR;
      const alpha = 1 - t;
      const scale = 1 + 0.3 * t;
      this.drawStone(ctx, anim.x, anim.y, anim.color, scale, alpha);
      remaining.push(anim);
    }
    this.captureAnims = remaining;

    /* 最后一手标记（红色小三角形） */
    if (this.lastMove !== null && !this.lastMove.isPass) {
      const lx = PAD + this.lastMove.x * CELL;
      const ly = PAD + this.lastMove.y * CELL;
      const r = CELL * 0.16;
      ctx.fillStyle = '#ef4444';
      ctx.strokeStyle = 'rgba(0,0,0,0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(lx, ly - r);
      ctx.lineTo(lx + r * 0.866, ly + r * 0.5);
      ctx.lineTo(lx - r * 0.866, ly + r * 0.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  }

  /**
   * 绘制单颗棋子（含立体感：径向渐变 + 顶部高光 + 投影）。
   * @param x 棋盘 X 坐标
   * @param y 棋盘 Y 坐标
   * @param who 棋子颜色（BLACK/WHITE）
   * @param scale 缩放倍率（用于落子动画）
   * @param alpha 透明度（用于提子淡出动画）
   */
  private drawStone(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    who: number,
    scale: number,
    alpha: number,
  ): void {
    const px = PAD + x * CELL;
    const py = PAD + y * CELL;
    const r = CELL * 0.46 * scale;

    ctx.save();
    ctx.globalAlpha = alpha;

    /* 投影（向右下偏移） */
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.arc(px + 1.5, py + 2, r, 0, Math.PI * 2);
    ctx.fill();

    if (who === BLACK) {
      /* 黑子：深黑色径向渐变（#222 → #000） */
      const g = ctx.createRadialGradient(px - r * 0.4, py - r * 0.4, r * 0.1, px, py, r);
      g.addColorStop(0, '#5a5a5a');
      g.addColorStop(0.5, '#1a1a1a');
      g.addColorStop(1, '#000000');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      /* 顶部高光 */
      const hg = ctx.createRadialGradient(
        px - r * 0.35, py - r * 0.35, 0,
        px - r * 0.35, py - r * 0.35, r * 0.5,
      );
      hg.addColorStop(0, 'rgba(255,255,255,0.55)');
      hg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      /* 白子：白色径向渐变（#fff → #ddd） */
      const g = ctx.createRadialGradient(px - r * 0.3, py - r * 0.3, r * 0.1, px, py, r);
      g.addColorStop(0, '#ffffff');
      g.addColorStop(0.7, '#e8e8e8');
      g.addColorStop(1, '#c0c0c0');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      /* 顶部高光 */
      const hg = ctx.createRadialGradient(
        px - r * 0.3, py - r * 0.3, 0,
        px - r * 0.3, py - r * 0.3, r * 0.4,
      );
      hg.addColorStop(0, 'rgba(255,255,255,0.9)');
      hg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(80,80,80,0.5)';
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  }

  /** 绘制右侧侧边栏：HUD 信息 + 走棋历史 */
  private drawSidebar(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    const sx = BOARD_W;
    const sw = SIDEBAR_W;

    /* 侧边栏背景（与主背景区分） */
    ctx.fillStyle = theme.border;
    ctx.fillRect(sx, 0, sw, H);
    ctx.fillStyle = theme.bg;
    ctx.fillRect(sx + 1, 0, sw - 1, H);

    let y = 14;
    const cx = sx + sw / 2;
    const padLeft = sx + 8;

    /* 标题 */
    ctx.fillStyle = theme.fg;
    ctx.font = 'bold 14px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(this.tr(this.ctx, 'game.go.title', 'Go'), cx, y);
    y += 22;

    /* 当前回合 */
    ctx.font = '10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillStyle = theme.muted;
    ctx.textAlign = 'left';
    ctx.fillText(this.tr(this.ctx, 'game.go.hud.turn', 'Turn'), padLeft, y);
    y += 13;
    /* 棋子图标 */
    const stoneR = 7;
    const turnLabel = this.tr(this.ctx, this.gameOver ? 'game.go.hud.ended' : this.turn === BLACK ? 'game.go.hud.blackTurn' : 'game.go.hud.whiteTurn', this.gameOver ? 'Over' : this.turn === BLACK ? 'Black' : 'White');
    ctx.fillStyle = this.turn === BLACK ? '#1a1a1a' : '#f5f5f5';
    ctx.strokeStyle = this.turn === BLACK ? '#000' : '#888';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(padLeft + stoneR, y + stoneR, stoneR, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = theme.fg;
    ctx.font = 'bold 12px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(turnLabel, padLeft + stoneR * 2 + 6, y + 1);
    y += 22;

    /* 提子统计 */
    ctx.fillStyle = theme.muted;
    ctx.font = '10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillText(this.tr(this.ctx, 'game.go.hud.capturesBlack', 'Black captures: {count}', { count: this.capturedByBlack }), padLeft, y);
    y += 13;
    ctx.fillText(this.tr(this.ctx, 'game.go.hud.capturesWhite', 'White captures: {count}', { count: this.capturedByWhite }), padLeft, y);
    y += 15;
    ctx.fillText(this.tr(this.ctx, 'game.go.hud.moves', 'Moves: {count}', { count: this.moveCount }), padLeft, y);
    y += 13;
    ctx.fillText(`Pass: ${this.consecutivePasses}/2`, padLeft, y);
    y += 16;

    /* AI 思考提示 */
    if (this.aiThinking && !this.gameOver) {
      ctx.fillStyle = theme.accent;
      ctx.font = 'italic 11px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.fillText(this.tr(this.ctx, 'game.common.aiThinking', 'AI thinking'), padLeft, y);
      y += 16;
    }

    /* 走棋历史 */
    ctx.fillStyle = theme.muted;
    ctx.font = '10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillText(this.tr(this.ctx, 'game.common.records', 'Move records'), padLeft, y);
    y += 13;

    /* 历史列表（最新在底部，超出范围截断顶部） */
    const listH = H - y - 8;
    const lineH = 13;
    const maxLines = Math.floor(listH / lineH);
    const total = this.history.length;
    const startIdx = Math.max(0, total - maxLines);

    ctx.font = '10px Menlo, Monaco, "Courier New", monospace';
    for (let i = startIdx; i < total; i++) {
      const m = this.history[i];
      if (m === undefined) continue;
      const colorLabel = this.tr(this.ctx, m.color === BLACK ? 'game.go.label.black' : 'game.go.label.white', m.color === BLACK ? 'B' : 'W');
      const coord = m.isPass ? 'pass' : this.coordLabel(m.x, m.y);
      const cap = m.captured > 0 ? ` (+${m.captured})` : '';
      const lineY = y + (i - startIdx) * lineH;
      ctx.fillStyle = m.color === BLACK ? theme.fg : theme.muted;
      ctx.fillText(`${i + 1}. ${colorLabel} ${coord}${cap}`, padLeft, lineY);
    }
  }

  /** 棋盘坐标 → 显示坐标（如 Q16） */
  private coordLabel(x: number, y: number): string {
    const col = COL_LETTERS[x];
    const row = String(SIZE - y);
    return `${col ?? '?'}${row}`;
  }

  /** 绘制暂停/结束遮罩 */
  private drawOverlay(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    if (this.currentStatus === 'paused') {
      ctx.fillStyle = 'rgba(0,0,0,0.65)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = theme.fg;
      ctx.font = 'bold 22px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(this.tr(this.ctx, 'game.go.overlay.paused', 'Paused'), W / 2, H / 2 - 10);
      ctx.font = '13px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.fillStyle = theme.muted;
      ctx.fillText(this.tr(this.ctx, 'game.go.overlay.resumeHint', 'Click "Resume" to continue'), W / 2, H / 2 + 18);
    }
    if (this.gameOver) {
      ctx.fillStyle = 'rgba(0,0,0,0.78)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = theme.fg;
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(this.tr(this.ctx, 'game.go.overlay.gameOver', 'Game over'), W / 2, H / 2 - 28);
      ctx.font = '14px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.fillStyle = theme.accent;
      ctx.fillText(this.resultText, W / 2, H / 2);
      ctx.font = '12px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.fillStyle = theme.muted;
      ctx.fillText(this.tr(this.ctx, 'game.go.overlay.restartHint', 'Click "Restart" to play again'), W / 2, H / 2 + 28);
    }
  }
}


  /* =========================================================
     6. 样式（game-host.css 同源，内嵌注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * game-host.css — 小游戏宿主样式
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - 容器铺满窗口 body（.game-host-root）
 *   - HUD 顶部固定（分数 + 控制按钮）
 *   - 画布居中、保持比例、自适应缩放
 *   - 主题色由 CSS 变量驱动（--bg-canvas / --fg-primary / --accent-cool 等）
 *   - 暂停时画布半透明遮罩 + "Paused"提示
 *   - 隐藏滚动条（项目记忆：避免底部水平滚动条）
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */

.game-host-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  /* 玻璃配方（GlassSidePanel 同款）：垫底随主题模式/皮肤，半透明白透出坊市体验层毛玻璃 */
  background: var(--skin-pattern-image, none), color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 95%, var(--surface-solid-primary, #ffffff) 5%);
  backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  color: var(--glass-text-primary, #e8e8e8);
  font-family: var(--skin-font-body, -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif);
  overflow: hidden;
  /* 防止 iOS 弹性滚动影响游戏体验 */
  overscroll-behavior: contain;
  -webkit-user-select: none;
  user-select: none;
}

/* ============================================================
   HUD（顶部条）
   ============================================================ */

.game-host-hud {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
  background: color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 92%, var(--surface-solid-primary, #ffffff) 8%);
  border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  flex-shrink: 0;
}

.game-host-hud-left {
  display: flex;
  align-items: baseline;
  gap: 0.875rem;
  min-width: 0;
  overflow: hidden;
}

.game-host-hud-title {
  /* F 语言：衬线显示字体 + 字距（UI-REMAINING-WAVES Wave G L2；--type-display 经沙箱白名单注入） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 0.875rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--glass-text-primary, #e8e8e8);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

.game-host-hud-score {
  font-size: 0.8125rem;
  font-variant-numeric: tabular-nums;
  color: var(--glass-text-secondary, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.game-host-hud-right {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

/* P4.7：按钮基座化（铁律 9）——ui-kit btn 片段内嵌快照（assets/ui-kit/btn.css），
 * 选择器扩列桥接 .game-host-hud-btn（HUD 暂停/重开/难度控件），
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：次按钮 + 小尺寸变体。 */

.btn, .game-host-hud-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .game-host-hud-btn:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .game-host-hud-btn:disabled,
.btn[disabled], .game-host-hud-btn[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 次按钮：卡片玻璃底（HUD 暂停/重开/难度选择） */
.btn--secondary, .game-host-hud-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .game-host-hud-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 尺寸变体：小尺寸（HUD 紧凑布局） */
.btn--sm, .game-host-hud-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .game-host-hud-btn{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}

/* =========================================================
   P4.7b：皮肤按钮形状钩子表（皮肤形状语言内嵌快照）
   ---------------------------------------------------------
   宿主端按钮形状 = tokens.css data-interaction-model 通用规则
   （src/shared/design-tokens/tokens.css）+ 各皮肤 Manifest extraCSS
   （src/domains/themes/skins/*.ts）；iframe 无法继承宿主样式表，
   此处内嵌按钮形状语言子集，由 MultiFileSandbox 同步的
   data-skin / data-interaction-model / data-theme-mode 属性驱动，
   使游戏按钮获得与宿主同款手绘边框/糖果胶囊 3D/像素厚度/粗描边
   错位/油墨细线/浮雕等形状语言。
   约定：
   - 顺序与宿主一致：交互模型通用规则在前，皮肤 extraCSS 在后
     （同特异性后注入者胜，island 默认态即依赖此顺序让位 toy hover）
   - 深色变体选择器用 [data-theme-mode="dark"]（iframe 同步属性，
     非宿主的 data-theme-mode-effective）
   - 皮肤自定义变量（--is-ink/--is-cream/--toy-shadow/--ra-ink/
     --neumo-dark/--neumo-light）不在沙箱注入白名单
     （sandbox-skin-var-names.ts），一律 var(..., fallback)
   - iframe 内按钮必挂 .btn 类（core.tpl 受控），钩子表只写 .btn
   - 修改需同步宿主真相源（tokens.css + skins/*.ts extraCSS）
   ========================================================= */

/* —— 1. 交互模型通用规则子集（tokens.css data-interaction-model 快照） —— */

/* 交互类统一过渡节奏 */
[data-interaction-model] .btn{
  transition:
    background var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    color var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1));
}

/* lightweight：轻反馈 — 按下微缩放 */
[data-interaction-model="lightweight"] .btn:active{
  transform: scale(var(--motion-travel-press, 0.98));
}

/* responsive：标准反馈 — hover 上浮 + 按下微缩放 */
[data-interaction-model="responsive"] .btn:hover{
  transform: translateY(var(--motion-travel-hover, -1px));
}
[data-interaction-model="responsive"] .btn:active{
  transform: translateY(0) scale(var(--motion-travel-press, 0.98));
}

/* terminal：命令行式反馈 — hover 品红下划线、按下反白、focus 品红描边
   （硬编码色 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="terminal"] .btn:hover{
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(255, 46, 136, 0.55);
}
[data-interaction-model="terminal"] .btn:active{
  color: rgba(232, 237, 246, 1);
  background: rgba(255, 46, 136, 1);
  text-decoration: none;
}
[data-interaction-model="terminal"] .btn:focus-visible{
  outline: 1px solid rgba(255, 46, 136, 1);
  outline-offset: 2px;
}

/* print：印刷批注式反馈 — hover 印刷红下划线、按下墨底反白、focus 红细描边（深色反白）。
   硬编码色一律 rgba 等价书写（皮肤契约 forbidHardcodedColors 不认裸 hex） */
[data-interaction-model="print"] .btn:hover{
  color: rgba(192, 57, 43, 1);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(192, 57, 43, 0.55);
}
[data-interaction-model="print"] .btn:active{
  color: rgba(240, 231, 211, 1);
  background: rgba(26, 26, 24, 1);
  text-decoration: none;
}
[data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(192, 57, 43, 0.5);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:hover{
  color: rgba(226, 112, 90, 1);
  text-decoration-color: rgba(226, 112, 90, 0.6);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:active{
  color: rgba(32, 31, 27, 1);
  background: rgba(240, 231, 211, 1);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(226, 112, 90, 0.6);
}

/* snap：瞬时反馈 — hover 黑白互换、按下黑底黄字、focus 2px 黑描边（深色对称反转；
   硬编码色一律 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="snap"] .btn:hover{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 255, 255, 1);
  transition-duration: 0ms;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:hover{
  background: rgba(255, 255, 255, 1);
  color: rgba(17, 17, 17, 1);
}
[data-interaction-model="snap"] .btn:active{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 195, 0, 1);
  transition-duration: 0ms;
}
[data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(17, 17, 17, 1);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(255, 255, 255, 1);
  outline-offset: 2px;
}

/* doodle：手绘反馈 — hover 蜡笔红波浪下划线 + 微旋转、按下反向回弹、focus 蜡笔虚线 */
[data-interaction-model="doodle"] .btn:hover{
  transform: rotate(-0.5deg);
  text-decoration: underline;
  text-underline-offset: 4px;
  text-decoration-style: wavy;
  text-decoration-color: rgba(232, 96, 76, 0.75);
  text-decoration-thickness: 1.5px;
}
[data-theme-mode="dark"][data-interaction-model="doodle"] .btn:hover{
  text-decoration-color: rgba(91, 168, 201, 0.8);
}
[data-interaction-model="doodle"] .btn:active{
  transform: rotate(0.5deg) scale(0.97);
  text-decoration: none;
}
[data-interaction-model="doodle"] .btn:focus-visible{
  outline: 2px dashed rgba(232, 96, 76, 0.8);
  outline-offset: 2px;
}

/* hygge：柔和暖色反馈 — hover 暖色高亮、按下轻微缩放、focus 暖色细描边 */
[data-interaction-model="hygge"] .btn:hover{
  background: color-mix(in srgb, var(--accent-warm, #C08552) 10%, transparent);
}
[data-interaction-model="hygge"] .btn:active{
  transform: scale(0.99);
}
[data-interaction-model="hygge"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-warm, #C08552) 65%, transparent);
  outline-offset: 2px;
}

/* neumorphic：同色浮雕反馈 — hover 外凸、按下内凹、focus 柔和高亮 */
[data-interaction-model="neumorphic"] .btn:hover{
  box-shadow:
    4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:active{
  box-shadow:
    inset 4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    inset -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-cool, #7A8BA6) 50%, transparent);
  outline-offset: 2px;
}

/* toy：玩具 3D 按压 — hover 抬升（底沿加深）、按下塌陷（下沉 + 底沿归零） */
[data-interaction-model="toy"] .btn:hover:not(:disabled){
  transform: translateY(-2px);
  box-shadow: 0 5px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:active:not(:disabled){
  transform: translateY(2px) scale(0.96);
  box-shadow: 0 1px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:focus-visible{
  outline: 2px solid color-mix(in srgb, var(--deco-primary, #14B8A6) 65%, transparent);
  outline-offset: 2px;
}

/* —— 2. 皮肤形状规则子集（各皮肤 Manifest extraCSS 快照，最后注入覆盖交互模型） —— */

/* doodle：手绘边框 — 不规则圆角 + 微旋转 + 蜡笔 2px 边框（hover 换蜡笔红/深色湖水蓝） */
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect){
  border-radius: 15px 8px 17px 7px / 8px 16px 7px 18px; /* 皮肤形状快照：手绘不规则圆角，无 token 语义，同 skins.css 豁免决策 */
  transform: rotate(-0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect):nth-child(even of .btn){
  transform: rotate(0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary{
  border: 2px solid rgba(43, 43, 43, 0.62);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary{
  border-color: rgba(242, 237, 227, 0.55);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(232, 96, 76, 0.85);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(91, 168, 201, 0.85);
}

/* island：糖果胶囊 + 3D 底沿（默认态让位 toy hover/active；次按钮奶油卡纸） */
[data-skin="xy-skin-official-island"] .btn:not(:hover):not(:active){
  border: 1px solid var(--is-ink, rgba(92, 74, 50, 0.55));
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}
[data-skin="xy-skin-official-island"] .btn:not(.btn--rect){
  border-radius: 999px;
}
[data-skin="xy-skin-official-island"] .btn--secondary:not(:hover):not(:active){
  background: var(--is-cream, rgba(255, 253, 245, 0.92));
  border-color: var(--is-ink, rgba(92, 74, 50, 0.55));
  color: var(--text-primary, #5C4A32);
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}

/* pixel：块状厚度 — 无描线 + 底部 3px 厚度（NES 街机按键），按压塌陷
   （皮肤自定义变量不在沙箱白名单，改引注入变量 --bg-elevated/--text-primary） */
[data-skin="xy-skin-official-pixel"] .btn{
  border: none;
  border-radius: 0;
  background: var(--bg-elevated, #FFFDF6);
  box-shadow: 0 3px 0 var(--text-primary, #1A1C2C);
  transition: none;
}
[data-skin="xy-skin-official-pixel"] .btn:active{
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--text-primary, #1A1C2C);
}

/* popart：漫画粗描边 + CMYK 三色错位叠印投影（丝网印刷注册错位，波普签名） */
[data-skin="xy-skin-official-popart"] .btn{
  border: 3px solid var(--text-primary, #1A1A1A);
  box-shadow:
    2.5px 2.5px 0 rgba(230, 57, 70, 0.5),
    -2px 2.5px 0 rgba(0, 119, 182, 0.45),
    4px 4px 0 rgba(26, 26, 26, 0.28);
}

/* red-age：油墨细线（印刷品边线） */
[data-skin="xy-skin-official-red-age"] .btn{
  border: 1px solid var(--ra-ink, rgba(31, 26, 18, 0.75));
}

/* neumorphism：无描边浮雕（外凸双阴影） */
[data-skin="xy-skin-official-neumorphism"] .btn{
  border: none;
  box-shadow:
    3px 3px 6px var(--neumo-dark, rgba(163, 177, 198, 0.55)),
    -3px -3px 6px var(--neumo-light, rgba(255, 255, 255, 0.9));
}

/* cyber-city：glitch 重影 — hover RGB 通道错位（静态 text-shadow，零动画开销） */
[data-skin="xy-skin-official-cyber-city"] .btn:hover{
  text-shadow:
    1px 0 rgba(0, 229, 255, 0.75),
    -1px 0 rgba(255, 46, 136, 0.75);
}

/* 动效偏好降级：形状钩子表的位移/旋转一律禁用（保留形状与描边） */
[data-reduce-motion="true"] .btn:hover,
[data-reduce-motion="true"] .btn:active{
  transform: none;
}

/* v5.0: 难度选择器 */
.game-host-hud-difficulty-wrap {
  display: flex;
  align-items: center;
}

.game-host-hud-difficulty-select {
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23888' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  padding-right: 1.375rem !important;
  cursor: pointer;
}

.game-host-hud-difficulty-select option {
  background: var(--bg-elevated, #1a1a1a);
  color: var(--glass-text-primary, #e8e8e8);
}

/* ============================================================
   画布容器
   ============================================================ */

.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  position: relative;
  overflow: hidden;
}

.game-host-canvas {
  display: block;
  max-width: 100%;
  max-height: 100%;
  /* canvas 由游戏引擎自绘背景（棋盘/Phaser backgroundColor），CSS 背景置透明防泛白 */
  background: transparent;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.06));
  border-radius: 0.5rem;
  box-shadow: var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
  outline: none;
  cursor: default;
  touch-action: none;
}

.game-host-canvas:focus-visible {
  border-color: var(--accent-cool, #4a9eff);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent-cool, #4a9eff) 25%, transparent), var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
}

/* ============================================================
   暂停遮罩（由 GameHost 在 paused 状态下注入）
   ============================================================ */

.game-host-root[data-status="paused"] .game-host-canvas-wrap::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.55));
  backdrop-filter: blur(4px);
  pointer-events: none;
}

.game-host-root[data-status="paused"] .game-host-canvas-wrap::before {
  content: attr(data-paused-text);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 遮罩底为皮肤感知玻璃（--glass-overlay-bg：浅色皮肤浅底 / 深色皮肤深底），
     文字跟随皮肤明暗取 --glass-text-primary，任意皮肤 × 明暗下恒可读 */
  color: var(--glass-text-primary, #f1f5f9);
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 1.125rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.6));
  padding: 0.625rem 1.25rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.1));
  z-index: 1;
  pointer-events: none;
}

/* ============================================================
   游戏结束 / 胜利覆盖层
   ============================================================ */

.game-host-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4, 0.875rem);
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.7));
  backdrop-filter: blur(6px);
  z-index: 5;
  pointer-events: auto;
}

.game-host-overlay-title {
  /* F 语言：衬线显示字体 + 页面显示档字号 + 编辑头同款字距（Wave G L2） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: calc(var(--layout-display, 2.125rem) * 0.7);
  font-weight: 700;
  color: var(--glass-text-primary, #e8e8e8);
  letter-spacing: 0.14em;
}

.game-host-overlay-title--win {
  color: var(--accent-warm, #ffb04a);
}

.game-host-overlay-title--lose {
  color: var(--danger, #ff6b8a);
}

.game-host-overlay-msg {
  font-size: 0.875rem;
  color: var(--glass-text-secondary, #888);
  text-align: center;
  max-width: 80%;
}

.game-host-overlay-actions {
  display: flex;
  gap: 0.625rem;
}

/* P4.7：.game-host-overlay-btn 系列已删除（无 JS 创建者，历史死样式）；
 * 覆盖层操作统一走 HUD 重新开始按钮（game-host-hud-btn，已基座化）。 */

/* ============================================================
   响应式（窄窗口时缩小 HUD）
   ============================================================ */

@media (max-width: 480px) {
  .game-host-hud {
    padding: 0.375rem 0.625rem;
    gap: 0.5rem;
  }
  .game-host-hud-title {
    font-size: 0.8125rem;
  }
  .game-host-hud-score {
    font-size: 0.75rem;
  }
  .game-host-hud-btn {
    font-size: 0.6875rem;
    padding: 0.3125rem 0.5rem;
  }
  .game-host-canvas-wrap {
    padding: 0.375rem;
  }
}

/* ============================================================
   无障碍：减少动效
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  .game-host-hud-btn {
    transition: none;
  }
}
/* 动态创建元素类名锚点（CSS_CLASS_MISSING 校验 + 结构契约） */
.game-host-loading-overlay {}
.game-host-spinner {}
.game-host-error-overlay {}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'go-game-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  let host: GoHost | null = null;

  /** 挂载游戏：创建 Host 并启动（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    injectAppStyle(ctx.container);
    host = new GoHost({
      gameId: 'game-go',
      width: 696,
      height: 576,
    });
    void host.mount(ctx).catch((e: unknown) => {
      console.error('[go] mount failed:', e);
    });
  }

  /** 卸载游戏：清理监听 / 定时器 / DOM */
  function unmount(): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: { nameKey: 'game.goName', nameFallback: 'Go (Weiqi)' },
      t: createTranslator(),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__goApp = {
    unmount,
  };
})();
