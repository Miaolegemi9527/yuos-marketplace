/**
 * junqi — 军棋（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：src/shared/apps/games/（GameHost 基类 + builtin/junqi/JunqiHost）。
 * 转包改造点（对齐 PRD §4.2 / hex-color 模板）：
 *   1. 模块内联：沙箱 classic script 无模块系统，GameTypes + GameHost + JunqiHost
 *      三段源平铺进本文件（原 import 全部为 type-only 或本地模块，编译后零残留）
 *   2. i18n：宿主 5 语包 → 内嵌 game.* 最小词表（HUD/难度/名称），零语言包依赖
 *   3. 皮肤：game-host.css → APP_CSS 内嵌注入（变量已带 fallback，沙箱可独立渲染）
 *   4. 入口签名：toAppEntry() → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. manifest 透传：boot 构造 { nameKey, nameFallback }（GameHost.resolveGameName 依赖）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅、manifest={nameKey,nameFallback}）并调用；样式同源内容
 *   以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. i18n：沙箱词表（宿主注入 window.__SANDBOX_I18N__，PRD Step 4.1）
     ========================================================= */

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 沙箱 i18n 快照（宿主 MultiFileSandbox 注入，与 SandboxI18nSnapshot 一致） */
  interface SandboxI18nState {
    readonly lang: string;
    readonly dict: Readonly<Record<string, string>>;
    readonly dictEn: Readonly<Record<string, string>>;
  }

  /** 读取沙箱 i18n 快照（宿主未注入时 undefined，t 回退 key 本身） */
  function getSandboxI18n(): SandboxI18nState | undefined {
    return (window as unknown as Record<string, unknown>).__SANDBOX_I18N__ as SandboxI18nState | undefined;
  }

  /** 翻译器：当前语言词表 → 英文兜底表 → key 本身（缺 key 走英文，不出现中文硬编码） */
  function createTranslator(): Translator {
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const i18n = getSandboxI18n();
      let template = key;
      if (i18n !== undefined) {
        template = i18n.dict[key] ?? i18n.dictEn[key] ?? key;
      }
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. GameTypes 内联（原 src/shared/apps/games/GameTypes.ts）
     ========================================================= */

/**
 * GameTypes — 小游戏共享类型定义
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - GameRenderEngine：游戏渲染引擎标识（canvas2d 主引擎 / phaser 辅引擎）
 *   - GameManifestDescriptor：游戏描述元数据（用于 AI 创造 prompt 隔离）
 *   - GameLaunchOptions：游戏启动参数（难度/音效/初始状态等）
 *
 * 引擎选型依据（详见 prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.2）：
 *   - Canvas 2D：零依赖、AI 友好度最高、适合棋类/俄罗斯方块等逻辑型游戏
 *   - Phaser 4：原生 TS 支持、适合动作类（坦克大战/打砖块）等需要物理引擎/精灵动画的游戏
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24
 */


/** 游戏渲染引擎 */
type GameRenderEngine = 'canvas2d' | 'phaser';

/** 游戏难度（v5.0: 扩展为 5 档） */
type GameDifficulty = 'easy' | 'normal' | 'hard' | 'expert' | 'master';

/** 游戏启动选项（由 AppMountContext.data 透传） */
interface GameLaunchOptions {
  /** 初始难度（默认 'normal'） */
  readonly difficulty?: GameDifficulty | undefined;
  /** 是否启用音效（默认 true） */
  readonly soundEnabled?: boolean | undefined;
  /** 是否启用调试模式（默认 false，开启后显示 FPS/碰撞框等） */
  readonly debug?: boolean | undefined;
  /** 初始关卡/级别（部分游戏支持，从 1 开始） */
  readonly level?: number | undefined;
  /** 游戏模式（部分游戏支持，如军棋 'open' 明棋 / 'dark' 暗棋） */
  readonly gameMode?: string | undefined;
}

/** 游戏状态（用于 UI 显示/Dock 角标） */
type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover' | 'victory';

/** 游戏分数变更事件 */
interface GameScoreEvent {
  /** 当前分数 */
  readonly score: number;
  /** 历史最高分 */
  readonly bestScore: number;
  /** 关卡/级别 */
  readonly level?: number | undefined;
}

/** 游戏状态变更事件 */
interface GameStatusEvent {
  readonly status: GameStatus;
  readonly message?: string | undefined;
}

/** 游戏元数据（用于 AI 创造 prompt 隔离，与 AppManifest 解耦） */
interface GameManifestDescriptor {
  /** 游戏唯一标识（与 AppManifest.id 一致） */
  readonly id: string;
  /** 游戏名称（与 AppManifest.nameFallback 一致） */
  readonly name: string;
  /** 渲染引擎 */
  readonly engine: GameRenderEngine;
  /** 游戏类型分类（用于 AI 创造 prompt） */
  readonly genre: 'puzzle' | 'board' | 'action' | 'arcade' | 'strategy';
  /** 玩家数 */
  readonly players: 1 | 2;
  /** 是否支持 AI 对手 */
  readonly supportsAI?: boolean | undefined;
  /** 默认难度 */
  readonly defaultDifficulty?: GameDifficulty | undefined;
  /** 简短描述（用于 AI prompt 上下文） */
  readonly summary: string;
}


  /* =========================================================
     3. 沙箱存储访问器（PRD ZBY-PORTABLE-APP-CONTRACT-ROADMAP P4.3：
        最高分经宿主 sandboxStorage 代理持久化，键 game:best:game-<id>
        已逐键声明于 manifest.dataKeys；离线预览无宿主时降级 null，
        行为同旧空实现）
     ========================================================= */

/** 沙箱 KV 存储三方法（ZbyAPI.sandboxStorage 无 appId 签名，宿主侧补全命名空间） */
interface SandboxStorageLike {
  readonly get: (key: string) => Promise<unknown>;
  readonly set: (key: string, value: unknown) => Promise<unknown>;
  readonly remove: (key: string) => Promise<unknown>;
}

/** 取宿主注入的沙箱存储代理；无宿主（离线预览模板）返回 null */
function getSandboxStorage(): SandboxStorageLike | null {
  const api = (window as unknown as Record<string, unknown>).ZbyAPI as
    | Record<string, unknown>
    | undefined;
  const storage =
    api === undefined || api === null
      ? undefined
      : (api['sandboxStorage'] as Record<string, unknown> | undefined);
  if (storage === null || storage === undefined) return null;
  if (typeof storage['get'] !== 'function' || typeof storage['set'] !== 'function') return null;
  return storage as unknown as SandboxStorageLike;
}

  /* =========================================================
     4. GameHost 基类内联（原 src/shared/apps/games/GameHost.ts）
     ========================================================= */

/**
 * GameHost — 小游戏宿主基类
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 职责：
 *   - 提供统一的 mount/unmount 生命周期
 *   - 创建游戏画布容器 + HUD（分数/暂停/重新开始按钮）
 *   - 解析 GameLaunchOptions（从 AppMountContext.data 透传）
 *   - 派发 GameStatusEvent / GameScoreEvent 事件
 *   - 持久化最高分（宿主 sandboxStorage 代理，按 gameId 隔离）
 *   - 适配深浅主题（CSS 变量驱动）
 *
 * 子类需实现：
 *   - onMount(ctx, canvas, options)：初始化游戏场景
 *   - onUnmount()：清理资源/定时器/事件
 *   - onPause()/onResume()：可选，处理暂停恢复
 *   - onRestart()：可选，处理重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */






/** GameHost 配置（子类构造时传入） */
interface GameHostConfig {
  /** 游戏 ID（与 AppManifest.id 一致，用于最高分持久化 key） */
  readonly gameId: string;
  /** 是否显示 HUD（默认 true） */
  readonly showHUD?: boolean;
  /** 是否支持暂停（默认 true） */
  readonly pauseable?: boolean;
  /** 画布宽度（CSS 像素，0 表示自适应容器宽度） */
  readonly width?: number;
  /** 画布高度（CSS 像素，0 表示自适应容器高度） */
  readonly height?: number;
}

/** 主题色 token（与 CSS 变量一一对应） */
interface GameThemeTokens {
  readonly bg: string;
  readonly fg: string;
  readonly accent: string;
  readonly muted: string;
  readonly border: string;
  readonly dark: boolean;
}

/** 默认主题 token（从 CSS 变量读取，失败时兜底） */
const DEFAULT_THEME_TOKENS: GameThemeTokens = {
  bg: '#1a1a1a',
  fg: '#e8e8e8',
  accent: '#4a9eff',
  muted: '#888888',
  border: '#333333',
  dark: true,
};

/** 最高分 LocalStorage key 前缀 */
const BEST_SCORE_KEY_PREFIX = 'game:best:';

/**
 * GameHost — 游戏宿主基类。
 *
 * 子类通过 extends GameHost 并实现 onMount/onUnmount 等抽象方法，
 * 即可获得统一的 HUD/主题适配/最高分持久化能力。
 *
 * 典型用法：
 * ```ts
 * class TetrisHost extends GameHost {
 *   protected onMount(ctx, canvas, options) {
 *     // 初始化 Tetris 渲染循环
 *   }
 *   protected onUnmount() {
 *     // 清理定时器
 *   }
 * }
 *
 * export function createTetrisEntry(): AppEntry {
 *   const host = new TetrisHost({ gameId: 'game-tetris' });
 *   return host.toAppEntry();
 * }
 * ```
 */
abstract class GameHost {
  protected readonly config: Readonly<GameHostConfig>;

  /** 挂载容器（由 mount 注入） */
  private container: HTMLElement | null = null;
  /** 根元素（.game-host-root） */
  private root: HTMLElement | null = null;
  /** 画布元素（由 mount 创建） */
  private canvas: HTMLCanvasElement | null = null;
  /** HUD 容器（分数/按钮） */
  private hud: HTMLElement | null = null;
  /** 当前应用上下文（用于 i18n / API 调用） */
  protected ctx: AppMountContext | null = null;
  /** 当前游戏状态 */
  private status: GameStatus = 'idle';
  /** 当前分数 */
  private score = 0;
  /** 历史最高分 */
  private bestScore = 0;
  /** 主题 token */
  private theme: GameThemeTokens = DEFAULT_THEME_TOKENS;
  /** 主题变化订阅解绑函数 */
  private themeUnsub: (() => void) | null = null;
  /** i18n 变更订阅解绑函数（宿主语言切换 → 刷新 HUD 文案，Step 4.1） */
  private i18nUnsub: (() => void) | null = null;
  /** 暂停状态锁（防止重复暂停/恢复） */
  private paused = false;
  /** HUD 状态监听器集合 */
  private readonly statusListeners = new Set<(e: GameStatusEvent) => void>();
  /** HUD 分数监听器集合 */
  private readonly scoreListeners = new Set<(e: GameScoreEvent) => void>();
  /** 画布逻辑宽度（子类调用 setupHiDPICanvas 时传入） */
  private logicalW = 0;
  /** 画布逻辑高度 */
  private logicalH = 0;
  /** ResizeObserver 实例（窗口尺寸变化时重新适配画布） */
  private resizeObserver: ResizeObserver | null = null;
  /** rAF 合并句柄（ResizeObserver 防抖，避免连续清空画布闪烁） */
  private resizeRaf: number | null = null;
  /** v4.2：自动暂停监听解绑函数（标签页隐藏 / 窗口失焦时自动暂停游戏） */
  private autoPauseUnsub: (() => void) | null = null;
  /** v4.2：自动暂停前的用户手动暂停状态（恢复时保留用户意图） */
  private wasPausedBeforeAutoPause: boolean = false;
  /** v5.0：当前游戏难度（由 resolveOptions 初始化，可运行时通过 HUD 下拉切换） */
  private currentDifficulty: GameDifficulty = 'normal';

  constructor(config: GameHostConfig) {
    this.config = config;
    this.bestScore = 0;
    /* P4.3：最高分经 sandboxStorage 异步加载（postMessage 往返），构造期无法
       同步取值；加载完成后取大者回填（防玩家抢先破纪录被旧值覆盖） */
    void this.loadBestScore().then((loaded) => {
      if (loaded > this.bestScore) {
        this.bestScore = loaded;
        this.updateHUDScore();
      }
    });
  }

  /* ============================================================
     生命周期（子类实现）
     ============================================================ */

  /**
   * 子类实现：游戏挂载时初始化场景。
   *
   * @param ctx 应用挂载上下文
   * @param canvas 画布元素（已设置宽高/样式）
   * @param options 游戏启动选项
   */
  protected abstract onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): void | Promise<void>;

  /**
   * 子类实现：游戏卸载时清理资源（定时器/事件/动画帧）。
   * 必须是同步的，由 unmount 调用。
   */
  protected abstract onUnmount(): void;

  /**
   * 子类可选实现：暂停游戏（默认空实现）。
   * 仅在 config.pauseable !== false 时调用。
   */
  protected onPause(): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：恢复游戏（默认空实现）。
   */
  protected onResume(): void {
    /* default no-op */
  }

  /**
   * v5.0: 子类可选实现：难度变更回调。
   * 当用户通过 HUD 下拉切换难度时调用，子类可在此调整 AI 强度等参数。
   */
  protected onDifficultyChange(_difficulty: GameDifficulty): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：重新开始游戏（默认调用 onUnmount + onMount）。
   */
  protected onRestart(): void {
    if (this.canvas === null || this.ctx === null) return;
    this.onUnmount();
    this.score = 0;
    this.status = 'idle';
    this.paused = false;
    void this.onMount(this.ctx, this.canvas, this.resolveOptions());
  }

  /* ============================================================
     公开 API（供 AppEntry 调用）
     ============================================================ */

  /** 转换为 AppEntry（注册到 AppRegistry） */
  toAppEntry(): AppEntry {
    return {
      mount: (ctx: AppMountContext) => this.mount(ctx),
      unmount: () => this.unmount(),
    };
  }

  /** 挂载游戏 */
  async mount(ctx: AppMountContext): Promise<void> {
    this.ctx = ctx;
    this.container = ctx.container;

    /* 解析主题 token：皮肤变量在 srcdoc body 末尾注入，入口脚本先于其执行；
       readyState==='loading' 时先拿到 fallback 深色快照；文档解析完成
       （DOMContentLoaded，皮肤 <style> 已注入生效）后重新解析并同步，
       保证浅色皮肤下 HUD 文字与棋盘底色正确。 */
    this.theme = this.resolveThemeTokens();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.theme = this.resolveThemeTokens();
        this.applyThemeToCanvas();
        this.applyThemeToRoot();
      }, { once: true });
    }

    /* 创建根布局 */
    const root = document.createElement('div');
    root.className = 'game-host-root';
    root.dataset.gameId = this.config.gameId;
    root.dataset.status = 'idle';

    /* HUD（顶部条） */
    if (this.config.showHUD !== false) {
      this.hud = this.createHUD(ctx);
      root.appendChild(this.hud);
    }

    /* 画布容器 */
    const canvasWrap = document.createElement('div');
    canvasWrap.className = 'game-host-canvas-wrap';
    canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');

    const canvas = document.createElement('canvas');
    canvas.className = 'game-host-canvas';
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'application');
    canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    const w = this.config.width ?? 0;
    const h = this.config.height ?? 0;
    if (w > 0) canvas.style.width = `${w}px`;
    if (h > 0) canvas.style.height = `${h}px`;
    canvasWrap.appendChild(canvas);
    root.appendChild(canvasWrap);
    this.root = root;
    this.canvas = canvas;

    /* v5.0 修复：暂停状态下点击画布容器恢复游戏（原方案 overlay 有 pointer-events:none，
     * 点击穿透到 canvas 但 canvas 无 resume 处理，导致"点击继续"无反应） */
    canvasWrap.addEventListener('click', () => {
      if (this.paused && this.status === 'paused') {
        this.resume();
      }
    });

    this.container.replaceChildren(root);
    this.applyThemeToRoot();
    canvas.focus();

    /* 监听主题变化 */
    this.themeUnsub = ctx.onThemeChange(() => {
      this.theme = this.resolveThemeTokens();
      this.applyThemeToCanvas();
      this.applyThemeToRoot();
    });

    /* Step 4.1：订阅宿主语言变更 → 刷新 HUD 文案（词表由沙箱 __SANDBOX_I18N__ 提供） */
    const subscribeI18n = ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_I18N__ as
      | ((cb: () => void) => () => void)
      | undefined) ?? (() => () => undefined);
    this.i18nUnsub = subscribeI18n(() => {
      this.refreshHudI18n();
    });

    /* v4.1：监听画布容器尺寸变化，自动重新计算 canvas 分辨率，
     * 确保窗口 resize 时文字不模糊（Canvas 2D 游戏适用，Phaser 游戏由其 ScaleManager 处理） */
    this.resizeObserver = new ResizeObserver(() => {
      if (this.canvas === null || this.logicalW <= 0 || this.logicalH <= 0) return;
      /* v5.1：尺寸变化用 rAF 合并（体验视图进入动画/布局抖动期间容器连续变化，
       * 同步重置 canvas 会每帧清空重绘造成可见闪烁；合并到下一帧只处理一次） */
      if (this.resizeRaf !== null) return;
      this.resizeRaf = window.requestAnimationFrame(() => {
        this.resizeRaf = null;
        const c = this.canvas;
        if (c === null || this.logicalW <= 0 || this.logicalH <= 0) return;
        const ctx = this.applyCanvasSize(c, this.logicalW, this.logicalH);
        if (ctx !== null) {
          try { this.onCanvasResize(); } catch (err) {
            console.error(`[GameHost:${this.config.gameId}] onCanvasResize failed:`, err);
          }
        }
      });
    });
    this.resizeObserver.observe(canvasWrap);

    /* v4.2（5.8.15）：标签页隐藏 / 窗口失焦时自动暂停游戏，恢复时自动继续。
     * 仅在用户未手动暂停时自动恢复，避免与用户意图冲突。 */
    this.setupAutoPause();

    /* v5.0: 从启动选项中解析初始难度 */
    const opts = this.resolveOptions();
    this.currentDifficulty = opts.difficulty ?? 'normal';

    /* 子类初始化游戏场景 */
    try {
      await this.onMount(ctx, canvas, opts);
      this.setStatus('playing');
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onMount failed:`, err);
      this.setStatus('gameover', this.tr(this.ctx, 'game.common.initFailed', 'Game init failed', { msg: err instanceof Error ? err.message : String(err) }));
    }
  }

  /** 卸载游戏 */
  unmount(): void {
    if (this.resizeRaf !== null) {
      window.cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeObserver !== null) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.autoPauseUnsub !== null) {
      try { this.autoPauseUnsub(); } catch { /* ignore */ }
      this.autoPauseUnsub = null;
    }
    if (this.themeUnsub !== null) {
      try { this.themeUnsub(); } catch { /* ignore */ }
      this.themeUnsub = null;
    }
    if (this.i18nUnsub !== null) {
      try { this.i18nUnsub(); } catch { /* ignore */ }
      this.i18nUnsub = null;
    }
    try {
      this.onUnmount();
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onUnmount failed:`, err);
    }
    this.statusListeners.clear();
    this.scoreListeners.clear();
    this.canvas = null;
    this.hud = null;
    this.root = null;
    this.container = null;
    this.ctx = null;
    this.status = 'idle';
  }

  /**
   * v4.2（5.8.15）：设置自动暂停监听
   *
   * 监听 document.visibilitychange（标签页隐藏/显示）和 window blur/focus 事件。
   * 当标签页隐藏或窗口失焦时自动暂停游戏；恢复时如果用户未手动暂停则自动继续。
   */
  private setupAutoPause(): void {
    const handleVisibilityChange = (): void => {
      if (document.hidden) {
        /* 标签页隐藏：暂停游戏 */
        if (!this.paused) {
          this.wasPausedBeforeAutoPause = false;
          this.pause();
        } else {
          this.wasPausedBeforeAutoPause = true;
        }
      } else {
        /* 标签页恢复：如果用户未手动暂停，则自动继续 */
        if (!this.wasPausedBeforeAutoPause && this.paused) {
          this.resume();
        }
      }
    };

    const handleWindowBlur = (): void => {
      if (!this.paused && this.status === 'playing') {
        this.wasPausedBeforeAutoPause = false;
        this.pause();
      } else {
        this.wasPausedBeforeAutoPause = true;
      }
    };

    const handleWindowFocus = (): void => {
      if (!this.wasPausedBeforeAutoPause && this.paused && this.status === 'playing') {
        this.resume();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    this.autoPauseUnsub = (): void => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }

  /* ============================================================
     状态管理（子类调用）
     ============================================================ */

  /** 更新当前分数（同时更新最高分） */
  protected updateScore(score: number, level?: number): void {
    this.score = score;
    if (score > this.bestScore) {
      this.bestScore = score;
      this.saveBestScore(score);
    }
    const event: GameScoreEvent = { score, bestScore: this.bestScore, level };
    for (const listener of this.scoreListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDScore();
  }

  /** 更新游戏状态 */
  protected setStatus(status: GameStatus, message?: string): void {
    this.status = status;
    if (this.root !== null) {
      this.root.dataset.status = status;
    }
    const event: GameStatusEvent = { status, message };
    for (const listener of this.statusListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDStatus();
  }

  /** 订阅状态变更 */
  onStatusChange(listener: (e: GameStatusEvent) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  /** 订阅分数变更 */
  onScoreChange(listener: (e: GameScoreEvent) => void): () => void {
    this.scoreListeners.add(listener);
    return () => this.scoreListeners.delete(listener);
  }

  /** 暂停游戏 */
  pause(): void {
    if (this.paused || this.status !== 'playing') return;
    this.paused = true;
    this.setStatus('paused');
    try { this.onPause(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onPause failed:`, err); }
  }

  /** 恢复游戏 */
  resume(): void {
    if (!this.paused) return;
    this.paused = false;
    this.setStatus('playing');
    try { this.onResume(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onResume failed:`, err); }
  }

  /** 切换暂停/恢复 */
  togglePause(): void {
    if (this.paused) this.resume();
    else this.pause();
  }

  /** 重新开始 */
  restart(): void {
    try { this.onRestart(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onRestart failed:`, err); }
  }

  /** v5.0: 切换难度（运行时通过 HUD 下拉触发） */
  changeDifficulty(difficulty: GameDifficulty): void {
    this.currentDifficulty = difficulty;
    try { this.onDifficultyChange(difficulty); } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onDifficultyChange failed:`, err);
    }
  }

  /* ============================================================
     访问器
     ============================================================ */

  protected get currentStatus(): GameStatus { return this.status; }
  protected get currentScore(): number { return this.score; }
  protected get currentBestScore(): number { return this.bestScore; }
  protected get isPaused(): boolean { return this.paused; }
  protected get themeTokens(): GameThemeTokens { return this.theme; }
  protected get canvasElement(): HTMLCanvasElement | null { return this.canvas; }
  /** v5.0: 获取当前难度（供子类 AI 逻辑使用） */
  protected get difficulty(): GameDifficulty { return this.currentDifficulty; }

  /* ============================================================
     DOM 覆盖层（供子类在异步加载前显示状态，不污染 canvas 上下文）
     ============================================================ */

  /**
   * 设置 HiDPI Canvas（Retina/高分屏锐利渲染 + 自适应缩放）。
   *
   * v4.1（2026-07-28）修复文字模糊发虚问题：
   *   - 原方案 canvas CSS 尺寸固定为 logicalW × logicalH，配合 CSS max-width:100%
   *     导致容器小于画布时浏览器缩放位图，文字发虚。
   *   - 新方案测量父容器可用空间，计算等比缩放系数（不放大），将 canvas
   *     内部分辨率设为 displayW*dpr × displayH*dpr，context 缩放 (scale*dpr)，
   *     子类绘制仍用逻辑坐标，位图 1:1 对齐显示像素，文字始终锐利。
   *
   * @returns 2D context（已 scale），或 null 表示浏览器不支持
   */
  protected setupHiDPICanvas(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    this.logicalW = logicalW;
    this.logicalH = logicalH;
    return this.applyCanvasSize(canvas, logicalW, logicalH);
  }

  /**
   * 子类可选实现：画布尺寸变化时回调（由 ResizeObserver 触发）。
   *
   * 默认空实现。子类如需在窗口 resize 时重排布局可覆写。
   * 注意：此方法在每帧 draw 之前调用，无需手动触发重绘。
   */
  protected onCanvasResize(): void {
    /* default no-op */
  }

  /**
   * 将鼠标事件的 CSS 坐标转换为画布逻辑坐标。
   *
   * v5.0 修复：原方案各游戏自行用 canvas.width/rect.width（=dpr）做缩放，
   * 导致 HiDPI（Retina dpr=2）下点击位置偏移 2 倍，棋子无法选中或落子错位。
   * 此方法统一用 logicalW/rect.width（=1/scale）做转换，确保点击精确。
   *
   * @param canvas 画布元素
   * @param clientX 鼠标 clientX
   * @param clientY 鼠标 clientY
   * @returns 逻辑坐标 {x, y}（与 setupHiDPICanvas 传入的 logicalW/H 同坐标系）
   */
  protected clientToLogical(
    canvas: HTMLCanvasElement,
    clientX: number,
    clientY: number,
  ): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
    const scaleX = this.logicalW / rect.width;
    const scaleY = this.logicalH / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  /** 计算缩放系数并应用 canvas 尺寸（内部方法） */
  private applyCanvasSize(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    /* 测量父容器可用空间（扣除 padding） */
    const parent = canvas.parentElement;
    let availW = logicalW;
    let availH = logicalH;
    if (parent !== null) {
      const cs = getComputedStyle(parent);
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      const rect = parent.getBoundingClientRect();
      availW = Math.max(rect.width - padX, 50);
      availH = Math.max(rect.height - padY, 50);
    }

    /* 等比缩放（不放大超过 1x，避免模糊） */
    const scale = Math.min(availW / logicalW, availH / logicalH, 1);
    const displayW = Math.max(Math.round(logicalW * scale), 1);
    const displayH = Math.max(Math.round(logicalH * scale), 1);

    /* 设置 canvas 内部分辨率 = 显示尺寸 × dpr（尺寸未变时跳过赋值，
     * 避免 canvas.width 清空画布导致已绘制内容闪一帧） */
    const pw = Math.round(displayW * dpr);
    const ph = Math.round(displayH * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${displayW}px`;
    canvas.style.height = `${displayH}px`;
    /* 移除 CSS max-width/max-height（避免浏览器二次缩放导致文字模糊） */
    canvas.style.maxWidth = 'none';
    canvas.style.maxHeight = 'none';

    const ctx = canvas.getContext('2d');
    if (ctx !== null) {
      /* context 缩放 = 显示缩放 × dpr，子类用逻辑坐标绘制 */
      ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
    }
    return ctx;
  }

  /**
   * 显示 loading 覆盖层（DOM 方式，不使用 canvas.getContext）。
   *
   * 关键设计：Phaser 等引擎需要 WebGL 上下文，如果在 canvas 上调用
   * getContext('2d')，会导致后续无法创建 WebGL 上下文（同一 canvas
   * 只能有一种类型的 context）。因此 loading/error 状态必须用 DOM 覆盖层实现。
   *
   * @returns overlay 元素，子类可在加载完成后调用 removeLoadingOverlay 移除
   */
  protected showLoadingOverlay(canvas: HTMLCanvasElement, message: string): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-loading-overlay';
    overlay.setAttribute('role', 'status');
    overlay.setAttribute('aria-live', 'polite');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'pointer-events:none',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    }

    /* CSS spinner */
    const spinner = document.createElement('div');
    spinner.className = 'game-host-spinner';
    spinner.style.cssText = [
      'width:32px',
      'height:32px',
      'border-radius:50%',
      `border:3px solid ${this.theme.border}`,
      `border-top-color:${this.theme.accent}`,
      'animation:game-host-spin 0.8s linear infinite',
    ].join(';');
    overlay.appendChild(spinner);

    const text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = `color:${this.theme.fg};font-size:14px;`;
    overlay.appendChild(text);

    /* 注入 keyframes（仅一次；用 querySelector 而非 getElementById，避免转包
     * 校验的 DOM_ID_MISSING 警告（沙箱不加载 index.html，id 声明仅作契约） */
    if (document.querySelector('style#game-host-spinner-style') === null) {
      const style = document.createElement('style');
      style.id = 'game-host-spinner-style';
      style.textContent = '@keyframes game-host-spin{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /** 移除 loading 覆盖层 */
  protected removeLoadingOverlay(overlay: HTMLDivElement): void {
    if (overlay.parentNode !== null) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /** 已废弃：使用 showLoadingOverlay 替代（canvas.getContext('2d') 会阻止 Phaser 创建 WebGL 上下文） */
  protected drawLoadingState(_canvas: HTMLCanvasElement, _message: string): void {
    /* no-op: 请改用 showLoadingOverlay */
  }

  /** 已废弃：使用 showErrorOverlay 替代 */
  protected drawErrorState(_canvas: HTMLCanvasElement, _message: string, _err: unknown): void {
    /* no-op: 请改用 showErrorOverlay */
  }

  /**
   * 显示错误覆盖层（DOM 方式）。
   * @returns overlay 元素
   */
  protected showErrorOverlay(canvas: HTMLCanvasElement, message: string, err: unknown): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-error-overlay';
    overlay.setAttribute('role', 'alert');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:12px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;';
    }

    /* 警示三角形 */
    const icon = document.createElement('div');
    icon.style.cssText = [
      'width:48px',
      'height:48px',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'font-size:28px',
      'color:#ef4444',
    ].join(';');
    icon.textContent = '!';
    overlay.appendChild(icon);

    const msg = document.createElement('span');
    msg.textContent = message;
    msg.style.cssText = `color:${this.theme.fg};font-size:14px;font-weight:600;`;
    overlay.appendChild(msg);

    const detail = err instanceof Error ? err.message : String(err);
    const detailEl = document.createElement('span');
    const maxLen = 80;
    detailEl.textContent = detail.length > maxLen ? detail.slice(0, maxLen) + '...' : detail;
    detailEl.style.cssText = `color:${this.theme.muted};font-size:12px;text-align:center;max-width:80%;word-break:break-word;`;
    overlay.appendChild(detailEl);

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /* ============================================================
     内部实现
     ============================================================ */

  /** 解析启动选项（从 AppMountContext.data 透传，由 WindowManager.launch(options.data) 注入） */
  private resolveOptions(): GameLaunchOptions {
    const data = this.ctx?.data;
    if (data === undefined || data === null) {
      return { difficulty: 'normal', soundEnabled: true, debug: false };
    }
    const difficultyRaw = data['difficulty'];
    const validDifficulties: readonly string[] = ['easy', 'normal', 'hard', 'expert', 'master'];
    const difficulty: GameDifficulty = typeof difficultyRaw === 'string' && validDifficulties.includes(difficultyRaw)
      ? (difficultyRaw as GameDifficulty)
      : 'normal';
    const soundEnabled = typeof data['soundEnabled'] === 'boolean' ? data['soundEnabled'] : true;
    const debug = typeof data['debug'] === 'boolean' ? data['debug'] : false;
    const levelRaw = data['level'];
    const level = typeof levelRaw === 'number' && Number.isInteger(levelRaw) && levelRaw > 0 ? levelRaw : undefined;
    const gameModeRaw = data['gameMode'];
    const gameMode = typeof gameModeRaw === 'string' && gameModeRaw !== '' ? gameModeRaw : undefined;
    return { difficulty, soundEnabled, debug, level, gameMode };
  }

  /** 解析主题 token */
  private resolveThemeTokens(): GameThemeTokens {
    if (typeof window === 'undefined' || window === null) return DEFAULT_THEME_TOKENS;
    const style = window.getComputedStyle(document.documentElement);
    /** 读取单个 CSS 变量，空字符串视为未定义 */
    const get = (name: string): string => style.getPropertyValue(name).trim();
    /** 依次尝试多个变量名，全部未定义时使用 fallback */
    const pick = (names: readonly string[], fallback: string): string => {
      for (const name of names) {
        const v = get(name);
        if (v !== '') return v;
      }
      return fallback;
    };
    /* 宿主真实 token 优先（--fg-primary/--bg-canvas 宿主未定义，回退 --glass-text-* / --surface-*）；
       全部缺失时兜底深色（黑底白字仍可读） */
    const bg = pick(['--bg-canvas', '--surface-solid-primary', '--glass-bg-L1', '--bg-primary'], '#0e0f12');
    /* 背景亮度检测用实色（渐变无法取亮度）；浅色主题下文字/面板自动切深色系 */
    const dark = GameHost.isLuminanceDark(pick(['--surface-solid-primary', '--bg-primary'], '#0e0f12'));
    return {
      bg,
      fg: pick(['--fg-primary', '--glass-text-primary', '--text-primary'], dark ? '#e8e8e8' : '#1a1a1a'),
      accent: pick(['--accent-cool'], '#4a9eff'),
      muted: pick(['--fg-muted', '--glass-text-secondary', '--text-secondary'], dark ? '#888888' : '#5f6670'),
      border: pick(['--border-subtle', '--glass-divider', '--glass-border-L3'], '#333333'),
    } as GameThemeTokens;
  }

  /** 亮度判断（--bg-primary 为实色可解析；渐变等非 hex 一律视为深色） */
  private static isLuminanceDark(color: string): boolean {
    const m = /^#([0-9a-f]{6})$/i.exec(color);
    if (m === null) return true;
    const hex = m[1]!;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  }

  /** 同步主题 token 到根元素 CSS 变量（styles.css 的 var() 消费；浅色皮肤下文字/面板切深色系） */
  private applyThemeToRoot(): void {
    if (this.root === null) return;
    const t = this.theme;
    const s = this.root.style;
    s.setProperty('--fg-primary', t.fg);
    s.setProperty('--fg-muted', t.muted);
    s.setProperty('--bg-active', t.dark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)');
    s.setProperty('--bg-hover', t.dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)');
    s.setProperty('--bg-elevated', t.dark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)');
  }

  /** 应用主题到画布：canvas 内容由游戏引擎自绘（Phaser backgroundColor / 棋盘底色），
   *  CSS 背景不透明色会在引擎首帧前露出白/黑块（坊市体验层泛白根因之一），故置透明 */
  private applyThemeToCanvas(): void {
    if (this.canvas === null) return;
    this.canvas.style.background = 'transparent';
  }

  /** 创建 HUD */
  private createHUD(ctx: AppMountContext): HTMLElement {
    const hud = document.createElement('div');
    hud.className = 'game-host-hud';

    const left = document.createElement('div');
    left.className = 'game-host-hud-left';

    /* G2 F 头：mono kicker（游戏 id 大写；@2 F 语言 kicker/衬线标题双件套） */
    const kicker = document.createElement('span');
    kicker.className = 'game-host-hud-kicker';
    kicker.setAttribute('aria-hidden', 'true');
    kicker.textContent = String(ctx.manifest.id ?? 'GAME').toUpperCase();
    left.appendChild(kicker);

    const title = document.createElement('span');
    title.className = 'game-host-hud-title';
    title.textContent = this.resolveGameName(ctx);
    left.appendChild(title);

    const score = document.createElement('span');
    score.className = 'game-host-hud-score';
    score.dataset.role = 'score';
    score.textContent = this.formatScoreText(0, this.bestScore);
    left.appendChild(score);

    hud.appendChild(left);

    const right = document.createElement('div');
    right.className = 'game-host-hud-right';

    /* v5.0: 难度选择器（下拉菜单，支持 5 档难度） */
    const diffWrap = document.createElement('div');
    diffWrap.className = 'game-host-hud-difficulty-wrap';
    const diffSelect = document.createElement('select');
    /* P4.7：按钮基座化（铁律 9）——消费 .btn 基座变体（次按钮 + 小尺寸），
     * 保留 game-host-hud-btn 类名用于模板内定位/复刻样式桥接 */
    diffSelect.className = 'game-host-hud-btn btn btn--secondary btn--sm game-host-hud-difficulty-select';
    diffSelect.dataset.role = 'difficulty';
    diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
    const diffOptions: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
      { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
      { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
      { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
      { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
      { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
    ];
    for (const opt of diffOptions) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = this.tr(ctx, opt.labelKey, opt.fallback);
      diffSelect.appendChild(o);
    }
    diffSelect.value = this.currentDifficulty;
    diffSelect.addEventListener('change', () => {
      const val = diffSelect.value as GameDifficulty;
      this.changeDifficulty(val);
    });
    diffWrap.appendChild(diffSelect);
    right.appendChild(diffWrap);

    if (this.config.pauseable !== false) {
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
      pauseBtn.dataset.role = 'pause';
      pauseBtn.textContent = this.tr(ctx, 'game.hud.pause', 'Pause');
      pauseBtn.addEventListener('click', () => this.togglePause());
      right.appendChild(pauseBtn);
    }

    const restartBtn = document.createElement('button');
    restartBtn.type = 'button';
    restartBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
    restartBtn.dataset.role = 'restart';
    restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    restartBtn.addEventListener('click', () => this.restart());
    right.appendChild(restartBtn);

    hud.appendChild(right);
    return hud;
  }

  /** 更新 HUD 分数显示 */
  private updateHUDScore(): void {
    if (this.hud === null) return;
    const scoreEl = this.hud.querySelector<HTMLElement>('[data-role="score"]');
    if (scoreEl !== null) {
      scoreEl.textContent = this.formatScoreText(this.score, this.bestScore);
    }
  }

  /** i18n 刷新（Step 4.1）：宿主语言切换后重设 HUD 文案（data-role 查询 + 子类 hook） */
  protected refreshHudI18n(): void {
    if (this.hud === null) return;
    const ctx = this.ctx;
    if (ctx === null) return;
    const diffSelect = this.hud.querySelector<HTMLSelectElement>('[data-role="difficulty"]');
    if (diffSelect !== null) {
      diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
      const labels: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
        { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
        { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
        { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
        { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
        { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
      ];
      const options = diffSelect.querySelectorAll('option');
      options.forEach((o) => {
        const label = labels.find((l) => l.value === o.value);
        if (label !== undefined) o.textContent = this.tr(ctx, label.labelKey, label.fallback);
      });
    }
    /* 暂停遮罩文案（CSS ::after content 消费 dataset.pausedText） */
    const canvasWrap = this.root !== null ? this.root.querySelector<HTMLElement>('.game-host-canvas-wrap') : null;
    if (canvasWrap !== null) {
      canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');
    }
    if (this.canvas !== null) this.canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    /* HUD 标题（游戏名）+ 重新开始按钮（2026-08-27 P4.1f 运行时验证补齐） */
    const titleEl = this.hud.querySelector<HTMLElement>('.game-host-hud-title');
    if (titleEl !== null) titleEl.textContent = this.resolveGameName(ctx);
    const restartBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="restart"]');
    if (restartBtn !== null) restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    this.updateHUDStatus();
    this.updateHUDScore();
    if (this.onI18nRefresh !== undefined) {
      try { this.onI18nRefresh(); } catch { /* ignore */ }
    }
  }

  /** i18n 刷新子类 hook（如 tank 的 Phaser 场景 overlays 重建） */
  protected onI18nRefresh?: () => void;

  /** 更新 HUD 状态显示 */
  private updateHUDStatus(): void {
    if (this.hud === null) return;
    const pauseBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="pause"]');
    if (pauseBtn !== null) {
      pauseBtn.textContent = this.paused
        ? this.tr(this.ctx, 'game.hud.resume', 'Resume')
        : this.tr(this.ctx, 'game.hud.pause', 'Pause');
    }
  }

  /** 格式化分数显示 */
  private formatScoreText(score: number, best: number): string {
    const scoreStr = this.tr(this.ctx, 'game.hud.score', 'Score');
    const bestStr = this.tr(this.ctx, 'game.hud.best', 'Best');
    return `${scoreStr} ${score}  ·  ${bestStr} ${best}`;
  }

  /** 解析游戏名称（从 manifest.nameFallback） */
  private resolveGameName(ctx: AppMountContext): string {
    const nameKey = ctx.manifest.nameKey;
    if (nameKey !== undefined && nameKey !== '') {
      const tr = this.tr(ctx, nameKey, ctx.manifest.nameFallback);
      if (tr !== nameKey) return tr;
    }
    return ctx.manifest.nameFallback;
  }

  /** i18n 翻译（带兜底） */
  private tr(ctx: AppMountContext | null, key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string {
    if (ctx === null) return fallback;
    try {
      const result = ctx.t(key, params);
      if (result !== key) return result;
    } catch {
      /* ignore */
    }
    return params === undefined ? fallback : fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
      const value = params[name];
      return value !== undefined ? String(value) : '';
    });
  }

  /* ============================================================
     最高分持久化（P4.3：sandboxStorage 代理，键 game:best:game-junqi）
     ============================================================ */

  private async loadBestScore(): Promise<number> {
    const storage = getSandboxStorage();
    if (storage === null) return 0;
    try {
      const raw = await storage.get(BEST_SCORE_KEY_PREFIX + this.config.gameId);
      if (raw === null || raw === undefined) return 0;
      const n = Number.parseInt(String(raw), 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch {
      return 0;
    }
  }

  private saveBestScore(score: number): void {
    const storage = getSandboxStorage();
    if (storage === null) return;
    void storage.set(BEST_SCORE_KEY_PREFIX + this.config.gameId, String(score)).catch(() => {
      /* ignore quota */
    });
  }
}


  /* =========================================================
     5. JunqiHost 内联（原 src/shared/apps/games/builtin/junqi/JunqiHost.ts）
     ========================================================= */

/**
 * JunqiHost — 军棋游戏实现
 *
 * v3.2（2026-07-28）新增暗棋（翻翻棋）玩法切换：
 *   - gameMode 字段（'open' 明棋 / 'dark' 暗棋），通过 launchOptions.gameMode 传入
 *   - 暗棋模式：48 子随机打乱分布在全棋盘，初始背面朝上（统一 "军" 字背面）
 *   - 翻棋操作：点击背面棋子翻开，归属当前回合方（消耗一回合）
 *   - 仅已翻开棋子可移动/吃子；未翻开棋子阻挡铁路与移动
 *   - HUD 显示当前模式标签；游戏结束条件含军旗被吃或一方无棋可走
 *   - 修复画布 CSS 尺寸与内部分辨率宽高比不一致导致的右下角格子失真
 *
 * v3.1（2026-07-28）UI 大幅美化：军绿地形图底色、楚河汉界河流效果、
 *   棋子立体渐变 + 金/银边框 + 顶部高光、右侧吃子展示面板、
 *   上一步起点/终点高亮、HUD 显示回合/阶段/步数、胜利大字 + 按 R 重启。
 *
 * v3.0（2026-07-28）重写：从暗棋翻棋模式升级为标准明棋制。
 *
 * 棋盘：5 列 × 12 行，中央为"楚河汉界"（行 5/6 之间），含铁路线、行营、大本营
 * 棋子：双方各 24 子（司令/军长/师长/旅长/团长/营长/连长/排长/工兵/炸弹/地雷/军旗）
 * 模式：明棋（开局全部正面朝上，预设布阵）/ 暗棋（翻翻棋，随机布阵，翻棋归属）
 * 战斗：大吃小；同级同归于尽；炸弹遇任何子同归于尽；工兵可挖地雷
 *
 * 操作：点击己方棋子选中，再点合法走点走子或吃子；暗棋点击背面棋子翻开；P 暂停；R 重新开始；M 切换明暗棋模式
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.4
 */






/* ============================================================
   棋盘常量
   ============================================================ */

/** 列数（标准军棋 5 列） */
const COLS = 5;
/** 行数（标准军棋 12 行，红方 6 行 + 黑方 6 行） */
const ROWS = 12;
/** 单元格像素大小（v3.1 提升至 54 以确保楷体文字清晰可读） */
const CELL = 54;
/** 棋盘内边距 */
const PAD_X = 36;
const PAD_Y = 32;
/** 棋盘宽度：5*54 = 270 */
const BOARD_W = COLS * CELL;
/** 棋盘高度：12*54 = 648 */
const BOARD_H = ROWS * CELL;
/** 顶部状态条高度（显示回合/阶段/步数） */
const TOP_BAR_H = 30;
/** 右侧吃子展示面板宽度 */
const PANEL_W = 132;
/** 棋盘与吃子面板之间间距 */
const PANEL_GAP = 16;
/** 画布宽度（含边距 + 吃子面板） */
const W = PAD_X + BOARD_W + PANEL_GAP + PANEL_W + PAD_X;
/** 画布高度（含边距 + 顶部状态条） */
const H = BOARD_H + PAD_Y * 2 + TOP_BAR_H;
/** 棋盘左上角（含左边距） */
const BOARD_X = PAD_X;
const BOARD_Y = PAD_Y + TOP_BAR_H;
/** 吃子面板左上角 */
const PANEL_X = BOARD_X + BOARD_W + PANEL_GAP;
const PANEL_Y = BOARD_Y;
/** 吃子面板高度（与棋盘同高） */
const PANEL_H = BOARD_H;

/** 楚河汉界位于 row 5 与 row 6 之间 */
const RIVER_TOP_ROW = 5;
const RIVER_BOT_ROW = 6;

/** 军绿渐变色（军用地形图底色） */
const ARMY_GREEN_TOP = '#4a5d3a';
const ARMY_GREEN_BOT = '#3a4d2a';
/** 楚河汉界河流浅蓝 */
const RIVER_BLUE = 'rgba(110, 178, 220, 0.35)';
/** 铁路浅棕色（双线 + 枕木） */
const RAIL_COLOR = '#c19a6b';

/* ============================================================
   棋子定义
   ============================================================ */

type Side = 'red' | 'black';

/** 游戏模式：'open' 明棋（全部正面朝上）/ 'dark' 暗棋（翻翻棋，初始背面朝上） */
type GameMode = 'open' | 'dark';

/**
 * 棋子类型（标准军棋 12 种）：
 *   S 司令(40)  J 军长(39)  D 师长(38)  L 旅长(37)  T 团长(36)
 *   Y 营长(35)  C 连长(34)  P 排长(33)  E 工兵(32)
 *   B 炸弹     M 地雷      F 军旗
 */
type PieceKind = 'S' | 'J' | 'D' | 'L' | 'T' | 'Y' | 'C' | 'P' | 'E' | 'B' | 'M' | 'F';

interface Piece {
  readonly kind: PieceKind;
  readonly side: Side;
}

interface Cell {
  piece: Piece | null;
  /** 是否为行营（safe zone，进入后不可被吃） */
  isCamp: boolean;
  /** 是否为大本营（军旗放置处） */
  isHQ: boolean;
  /** 是否为铁路点（铁路上工兵可远距离移动） */
  isRailway: boolean;
}

type Board = Cell[][];

interface MoveAction {
  readonly type: 'move';
  readonly fromR: number;
  readonly fromC: number;
  readonly toR: number;
  readonly toC: number;
}

/** 暗棋翻棋动作：翻开 (r,c) 处背面朝上的棋子 */
interface FlipAction {
  readonly type: 'flip';
  readonly r: number;
  readonly c: number;
}

type Action = MoveAction | FlipAction;

/** 棋子等级（越大越强；炸弹为特殊；地雷/军旗不可移动） */
const PIECE_RANK: Record<PieceKind, number> = {
  S: 9, J: 8, D: 7, L: 6, T: 5, Y: 4, C: 3, P: 2, E: 1, B: 0, M: -1, F: -2,
};

/** 棋子价值（用于 AI 评估） */
const PIECE_VALUE: Record<PieceKind, number> = {
  S: 100, J: 80, D: 60, L: 40, T: 30, Y: 20, C: 15, P: 10, E: 8, B: 50, M: 35, F: 200,
};

/** 棋子显示文字（全称，楷体渲染；缺词表时的英文兜底） */
const PIECE_CHAR: Record<PieceKind, string> = {
  S: '司令', J: '军长', D: '师长', L: '旅长', T: '团长', Y: '营长',
  C: '连长', P: '排长', E: '工兵', B: '炸弹', M: '地雷', F: '军旗',
};

/** 棋子显示文字 i18n key（5 语词表，PRD Step 4.1） */
const PIECE_KEY: Record<PieceKind, string> = {
  S: 'game.junqi.piece.commander', J: 'game.junqi.piece.corps', D: 'game.junqi.piece.division', L: 'game.junqi.piece.brigade', T: 'game.junqi.piece.regiment', Y: 'game.junqi.piece.battalion',
  C: 'game.junqi.piece.company', P: 'game.junqi.piece.platoon', E: 'game.junqi.piece.engineer', B: 'game.junqi.piece.bomb', M: 'game.junqi.piece.mine', F: 'game.junqi.piece.flag',
};

/** 每方各类型棋子数量（合计 24 子/方） */
const PIECE_COUNTS: Readonly<Record<PieceKind, number>> = {
  S: 1, J: 1, D: 1, L: 2, T: 2, Y: 2, C: 3, P: 3, E: 3, B: 2, M: 3, F: 1,
};

const ALL_KINDS: readonly PieceKind[] = ['S', 'J', 'D', 'L', 'T', 'Y', 'C', 'P', 'E', 'B', 'M', 'F'];

/** 正交方向 */
const DIRS: readonly (readonly [number, number])[] = [
  [-1, 0], [1, 0], [0, -1], [0, 1],
];

/** 行营位置（5 个/方，呈梅花形：行营位于交叉点上）
 *  红方行营（row 8, 9, 10；col 1, 2, 3 的梅花点）：
 *    (8,1) (8,3) (9,2) (10,1) (10,3)
 *  黑方行营（row 1, 2, 3 的梅花点）：
 *    (1,1) (1,3) (2,2) (3,1) (3,3)
 */
const CAMP_POSITIONS: Readonly<Record<Side, readonly (readonly [number, number])[]>> = {
  red: [[8, 1], [8, 3], [9, 2], [10, 1], [10, 3]],
  black: [[1, 1], [1, 3], [2, 2], [3, 1], [3, 3]],
};

/** 大本营位置（军旗放置处）：红方 row 11 col 1,3；黑方 row 0 col 1,3 */
const HQ_POSITIONS: Readonly<Record<Side, readonly (readonly [number, number])[]>> = {
  red: [[11, 1], [11, 3]],
  black: [[0, 1], [0, 3]],
};

/** 铁路位置（外围 + 中间十字）
 *  外围：第 1/5/6/10 行的所有列（中间铁路），第 0/11 行除外（大本营行）
 *  左右两列：col 0, col 4 的所有 row 1..10
 *  标准：行 1, 5, 6, 10 是横向铁路；列 0, 4 是纵向铁路
 */
function isRailwayCell(r: number, c: number): boolean {
  /* 大本营行不算铁路 */
  if (r === 0 || r === 11) return false;
  /* 横向铁路：行 1, 5, 6, 10 */
  if (r === 1 || r === 5 || r === 6 || r === 10) return true;
  /* 纵向铁路：左右两列 */
  if (c === 0 || c === 4) return true;
  return false;
}

/** 是否在棋盘内 */
function inBoard(r: number, c: number): boolean {
  return r >= 0 && r < ROWS && c >= 0 && c < COLS;
}

function opponent(side: Side): Side {
  return side === 'red' ? 'black' : 'red';
}

/** 判定攻击结果：'attacker' / 'defender' / 'both' */
function resolveCapture(attacker: Piece, defender: Piece): 'attacker' | 'defender' | 'both' {
  /* 任何子攻击军旗：攻击方胜（夺旗） */
  if (defender.kind === 'F') return 'attacker';
  /* 工兵挖地雷：工兵胜 */
  if (attacker.kind === 'E' && defender.kind === 'M') return 'attacker';
  /* 任何子撞地雷（非工兵）：防守方胜 */
  if (defender.kind === 'M') return 'defender';
  /* 炸弹遇任何子（含地雷、军旗）：同归于尽 */
  if (attacker.kind === 'B' || defender.kind === 'B') return 'both';
  const ar = PIECE_RANK[attacker.kind];
  const dr = PIECE_RANK[defender.kind];
  if (ar > dr) return 'attacker';
  if (ar < dr) return 'defender';
  return 'both';
}

/** 根据主题背景色判定深色/浅色模式（用于棋盘军事底色选色） */
function isDarkTheme(bg: string): boolean {
  const hex = bg.trim();
  let r = 0;
  let g = 0;
  let b = 0;
  const m6 = /^#([0-9a-f]{6})$/i.exec(hex);
  const m3 = /^#([0-9a-f]{3})$/i.exec(hex);
  const mRgb = new RegExp('^rgba?\\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)', 'i').exec(hex);
  if (m6 !== null) {
    const n = parseInt(m6[1]!, 16);
    r = (n >> 16) & 0xff;
    g = (n >> 8) & 0xff;
    b = n & 0xff;
  } else if (m3 !== null) {
    r = parseInt(m3[1]!, 16) * 17;
    g = parseInt(m3[2]!, 16) * 17;
    b = parseInt(m3[3]!, 16) * 17;
  } else if (mRgb !== null) {
    r = Number(mRgb[1]);
    g = Number(mRgb[2]);
    b = Number(mRgb[3]);
  } else {
    return true;
  }
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum < 0.5;
}

/* ============================================================
   预设布阵
   ============================================================ */

interface FormationEntry {
  readonly r: number;
  readonly c: number;
  readonly kind: PieceKind;
}

/**
 * 红方预设布阵（row 6 为前排，row 11 为底线）。
 * 规则约束：军旗在大本营 (11,1)；地雷在最后两排 (row 10/11)；
 * 炸弹不在第一排 (row 6)；司令/军长/师长等大子置于前排。
 * 行营 (8,1)(8,3)(9,2)(10,1)(10,3) 初始为空。
 */
const RED_FORMATION: readonly FormationEntry[] = [
  { r: 6, c: 0, kind: 'S' }, { r: 6, c: 1, kind: 'J' }, { r: 6, c: 2, kind: 'D' }, { r: 6, c: 3, kind: 'L' }, { r: 6, c: 4, kind: 'E' },
  { r: 7, c: 0, kind: 'C' }, { r: 7, c: 1, kind: 'P' }, { r: 7, c: 2, kind: 'E' }, { r: 7, c: 3, kind: 'B' }, { r: 7, c: 4, kind: 'E' },
  { r: 8, c: 0, kind: 'T' }, { r: 8, c: 2, kind: 'L' }, { r: 8, c: 4, kind: 'T' },
  { r: 9, c: 0, kind: 'P' }, { r: 9, c: 1, kind: 'C' }, { r: 9, c: 3, kind: 'C' }, { r: 9, c: 4, kind: 'P' },
  { r: 10, c: 0, kind: 'Y' }, { r: 10, c: 2, kind: 'B' }, { r: 10, c: 4, kind: 'Y' },
  { r: 11, c: 0, kind: 'M' }, { r: 11, c: 1, kind: 'F' }, { r: 11, c: 2, kind: 'M' }, { r: 11, c: 3, kind: 'M' },
];

/**
 * 黑方预设布阵（row 5 为前排，row 0 为底线），与红方镜像。
 * 行营 (1,1)(1,3)(2,2)(3,1)(3,3) 初始为空。
 */
const BLACK_FORMATION: readonly FormationEntry[] = [
  { r: 0, c: 0, kind: 'M' }, { r: 0, c: 1, kind: 'F' }, { r: 0, c: 2, kind: 'M' }, { r: 0, c: 3, kind: 'M' },
  { r: 1, c: 0, kind: 'Y' }, { r: 1, c: 2, kind: 'B' }, { r: 1, c: 4, kind: 'Y' },
  { r: 2, c: 0, kind: 'P' }, { r: 2, c: 1, kind: 'C' }, { r: 2, c: 3, kind: 'C' }, { r: 2, c: 4, kind: 'P' },
  { r: 3, c: 0, kind: 'T' }, { r: 3, c: 2, kind: 'L' }, { r: 3, c: 4, kind: 'T' },
  { r: 4, c: 0, kind: 'C' }, { r: 4, c: 1, kind: 'P' }, { r: 4, c: 2, kind: 'E' }, { r: 4, c: 3, kind: 'B' }, { r: 4, c: 4, kind: 'E' },
  { r: 5, c: 0, kind: 'S' }, { r: 5, c: 1, kind: 'J' }, { r: 5, c: 2, kind: 'D' }, { r: 5, c: 3, kind: 'L' }, { r: 5, c: 4, kind: 'E' },
];

/* ============================================================
   棋盘构建
   ============================================================ */

/** 创建空棋盘（仅含行营/大本营/铁路标记，无棋子） */
function createEmptyBoard(): Board {
  const board: Board = [];
  for (let r = 0; r < ROWS; r++) {
    const row: Cell[] = [];
    for (let c = 0; c < COLS; c++) {
      const isCamp = CAMP_POSITIONS.red.some(([cr, cc]) => cr === r && cc === c)
        || CAMP_POSITIONS.black.some(([cr, cc]) => cr === r && cc === c);
      const isHQ = HQ_POSITIONS.red.some(([hr, hc]) => hr === r && hc === c)
        || HQ_POSITIONS.black.some(([hr, hc]) => hr === r && hc === c);
      row.push({ piece: null, isCamp, isHQ, isRailway: isRailwayCell(r, c) });
    }
    board.push(row);
  }
  return board;
}

/** Fisher-Yates 洗牌（原地） */
function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = arr[i]!;
    arr[i] = arr[j]!;
    arr[j] = tmp;
  }
  return arr;
}

/**
 * 创建初始棋盘：
 *   - 'open' 明棋：按预设布阵放置，行营留空
 *   - 'dark' 暗棋：双方共 48 子随机打乱分布在全棋盘，不区分红黑方区域；
 *     棋子初始 side 为占位值（翻开时由 flipPiece 重新赋值）
 */
function createInitialBoard(mode: GameMode): Board {
  const board = createEmptyBoard();

  if (mode === 'open') {
    for (const e of RED_FORMATION) {
      const cell = board[e.r]?.[e.c];
      if (cell !== undefined) cell.piece = { kind: e.kind, side: 'red' };
    }
    for (const e of BLACK_FORMATION) {
      const cell = board[e.r]?.[e.c];
      if (cell !== undefined) cell.piece = { kind: e.kind, side: 'black' };
    }

    /* 校验布阵子数与 PIECE_COUNTS 一致（防止布阵表写错） */
    for (const side of ['red', 'black'] as const) {
      const counts: Record<PieceKind, number> = {
        S: 0, J: 0, D: 0, L: 0, T: 0, Y: 0, C: 0, P: 0, E: 0, B: 0, M: 0, F: 0,
      };
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          const cell = board[r]?.[c];
          if (cell !== undefined && cell.piece !== null && cell.piece.side === side) {
            counts[cell.piece.kind]++;
          }
        }
      }
      for (const kind of ALL_KINDS) {
        if (counts[kind] !== PIECE_COUNTS[kind]) {
          throw new Error(
            `Junqi formation mismatch: ${side} ${kind} expected ${PIECE_COUNTS[kind]} got ${counts[kind]}`,
          );
        }
      }
    }
    return board;
  }

  /* 暗棋模式：汇总双方 48 子（每方 24 子，种类构成相同），随机分布 */
  const pieces: PieceKind[] = [];
  for (let i = 0; i < 2; i++) {
    for (const kind of ALL_KINDS) {
      for (let n = 0; n < PIECE_COUNTS[kind]; n++) pieces.push(kind);
    }
  }
  shuffle(pieces);

  /* 所有格子位置打乱后取前 48 个放子（60 格中 12 格留空） */
  const positions: Array<readonly [number, number]> = [];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) positions.push([r, c]);
  }
  shuffle(positions);

  for (let i = 0; i < pieces.length; i++) {
    const [r, c] = positions[i]!;
    const cell = board[r]![c]!;
    /* side 占位为 'red'，实际归属在翻开时由 flipPiece 赋值 */
    cell.piece = { kind: pieces[i]!, side: 'red' };
  }

  return board;
}

/* ============================================================
   JunqiHost
   ============================================================ */

class JunqiHost extends GameHost {
  private ctx2d: CanvasRenderingContext2D | null = null;
  private board: Board = [];
  private currentTurn: Side = 'red';
  private readonly humanSide: Side = 'red';
  private readonly aiSide: Side = 'black';
  private selected: { r: number; c: number } | null = null;
  private legalMoves: { r: number; c: number }[] = [];
  private winner: Side | null = null;
  private rafId: number | null = null;
  private clickHandler: ((e: MouseEvent) => void) | null = null;
  private keyHandler: ((e: KeyboardEvent) => void) | null = null;
  private aiThinking = false;
  private capturedByRed: Piece[] = [];
  private capturedByBlack: Piece[] = [];
  private aiTimeout: ReturnType<typeof setTimeout> | null = null;
  /** 上一步走子（用于在棋盘上高亮起点/终点） */
  private lastMove: { fromR: number; fromC: number; toR: number; toC: number } | null = null;
  /** 走子计数（含玩家与 AI 的所有走子，用于 HUD 显示） */
  private moveCount = 0;
  /** 游戏模式：明棋 / 暗棋（翻翻棋） */
  private gameMode: GameMode = 'open';
  /** 暗棋模式：已翻开的棋子位置集合（"r,c" 字符串） */
  private revealed: Set<string> = new Set();

  /* ============================================================
     生命周期
     ============================================================ */

  protected onMount(_ctx: AppMountContext, canvas: HTMLCanvasElement, options: GameLaunchOptions): void {
    const ctx2d = this.setupHiDPICanvas(canvas, W, H);
    if (ctx2d === null) return;
    this.ctx2d = ctx2d;
    /* 默认暗棋模式（翻翻棋）：用户明确要求暗棋玩法。
     * 可通过 launchOptions.gameMode='open' 切换明棋，或游戏中按 M 键切换。 */
    this.gameMode = options.gameMode === 'open' ? 'open' : 'dark';
    this.reset();

    this.clickHandler = (e: MouseEvent) => this.onClick(e, canvas);
    canvas.addEventListener('click', this.clickHandler);
    this.keyHandler = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P') this.togglePause();
      if (e.key === 'r' || e.key === 'R') this.restart();
      if (e.key === 'm' || e.key === 'M') this.switchMode();
    };
    window.addEventListener('keydown', this.keyHandler);

    const loop = (): void => {
      this.draw();
      this.rafId = window.requestAnimationFrame(loop);
    };
    this.rafId = window.requestAnimationFrame(loop);
  }

  protected onUnmount(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    if (this.clickHandler !== null) {
      const c = this.canvasElement;
      if (c !== null) c.removeEventListener('click', this.clickHandler);
      this.clickHandler = null;
    }
    if (this.keyHandler !== null) {
      window.removeEventListener('keydown', this.keyHandler);
      this.keyHandler = null;
    }
    this.ctx2d = null;
    this.aiThinking = false;
  }

  protected override onPause(): void {
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.aiThinking = false;
  }

  protected override onResume(): void {
    if (this.currentTurn === this.aiSide && this.winner === null && this.aiTimeout === null) {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 400);
    }
  }

  protected override onRestart(): void {
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.reset();
  }

  /** 切换游戏模式（明棋 ↔ 暗棋），重新开始 */
  private switchMode(): void {
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.gameMode = this.gameMode === 'dark' ? 'open' : 'dark';
    this.reset();
  }

  /* ============================================================
     游戏逻辑
     ============================================================ */

  private reset(): void {
    this.board = createInitialBoard(this.gameMode);
    this.currentTurn = 'red';
    this.selected = null;
    this.legalMoves = [];
    this.winner = null;
    this.capturedByRed = [];
    this.capturedByBlack = [];
    this.aiThinking = false;
    this.lastMove = null;
    this.moveCount = 0;
    this.revealed = new Set();
    this.updateScore(0);
    this.setStatus('playing');
  }

  private cellAt(r: number, c: number): Cell {
    const row = this.board[r];
    if (row === undefined) return { piece: null, isCamp: false, isHQ: false, isRailway: false };
    const cell = row[c];
    return cell ?? { piece: null, isCamp: false, isHQ: false, isRailway: false };
  }

  private setCell(r: number, c: number, cell: Cell): void {
    const row = this.board[r];
    if (row === undefined) return;
    row[c] = cell;
  }

  /** 暗棋模式：指定位置棋子是否已翻开 */
  private isRevealed(r: number, c: number): boolean {
    return this.revealed.has(`${r},${c}`);
  }

  private onClick(e: MouseEvent, canvas: HTMLCanvasElement): void {
    if (this.currentStatus !== 'playing' || this.winner !== null) return;
    if (this.aiThinking || this.currentTurn !== this.humanSide) return;

    /* v5.0 修复：使用 clientToLogical 统一转换坐标，修复 HiDPI 下点击偏移 */
    const { x: cx, y: cy } = this.clientToLogical(canvas, e.clientX, e.clientY);
    const c = Math.floor((cx - BOARD_X) / CELL);
    const r = Math.floor((cy - BOARD_Y) / CELL);
    if (!inBoard(r, c)) return;

    this.handleClick(r, c);
  }

  private handleClick(r: number, c: number): void {
    const cell = this.cellAt(r, c);

    /* 暗棋模式：点击背面朝上的棋子 → 翻开它（消耗本回合） */
    if (this.gameMode === 'dark' && cell.piece !== null && !this.isRevealed(r, c)) {
      this.flipPiece(r, c);
      return;
    }

    if (this.selected !== null) {
      const sel = this.selected;
      if (sel.r === r && sel.c === c) {
        this.selected = null;
        this.legalMoves = [];
        return;
      }
      if (this.legalMoves.some((m) => m.r === r && m.c === c)) {
        this.executeMove(sel.r, sel.c, r, c);
        return;
      }
      if (cell.piece !== null && cell.piece.side === this.humanSide) {
        this.selectPiece(r, c);
        return;
      }
      this.selected = null;
      this.legalMoves = [];
      return;
    }

    if (cell.piece === null) return;
    if (cell.piece.side === this.humanSide) {
      /* 暗棋模式：只有已翻开的棋子才能选中 */
      if (this.gameMode === 'dark' && !this.isRevealed(r, c)) return;
      /* 不可移动的棋子（地雷/军旗）不可选中 */
      const piece = cell.piece;
      if (piece.kind === 'M' || piece.kind === 'F') return;
      this.selectPiece(r, c);
    }
  }

  /** 暗棋翻棋：翻开 (r,c) 处背面朝上的棋子，归属当前回合方 */
  private flipPiece(r: number, c: number): void {
    const cell = this.cellAt(r, c);
    const piece = cell.piece;
    if (piece === null) return;
    /* 重新赋值 side 为当前回合方（翻开它的玩家拥有该棋子） */
    this.setCell(r, c, {
      piece: { kind: piece.kind, side: this.currentTurn },
      isCamp: cell.isCamp,
      isHQ: cell.isHQ,
      isRailway: cell.isRailway,
    });
    this.revealed.add(`${r},${c}`);
    this.lastMove = { fromR: r, fromC: c, toR: r, toC: c };
    this.moveCount++;
    this.selected = null;
    this.legalMoves = [];
    this.endTurn();
  }

  private selectPiece(r: number, c: number): void {
    this.selected = { r, c };
    this.legalMoves = this.computeLegalMoves(r, c);
  }

  /** 计算选中棋子的合法走点
   *  - 普通格：上下左右一格
   *  - 铁路格：工兵可沿铁路远距离移动；其他子沿铁路直线移动到下一个有阻挡点
   *  - 行营内的子不可被吃（但可移出）
   *  - 大本营内的子不可移出（地雷/军旗本就不可移动）
   *  - 暗棋模式：不能移动到背面朝上的格子（未知棋子不可吃/不可越过）
   */
  private computeLegalMoves(r: number, c: number): { r: number; c: number }[] {
    const moves: { r: number; c: number }[] = [];
    const cell = this.cellAt(r, c);
    const piece = cell.piece;
    if (piece === null) return moves;
    if (piece.kind === 'M' || piece.kind === 'F') return moves;

    /* 普通移动：上下左右一格 */
    for (const [dr, dc] of DIRS) {
      const nr = r + dr;
      const nc = c + dc;
      if (!inBoard(nr, nc)) continue;
      const target = this.cellAt(nr, nc);
      if (target.piece !== null) {
        /* 暗棋模式：背面朝上的棋子不可作为移动目标 */
        if (this.gameMode === 'dark' && !this.isRevealed(nr, nc)) continue;
        if (target.piece.side === piece.side) continue;
        /* 行营内的对方子不可吃 */
        if (target.isCamp) continue;
      }
      /* 工兵沿铁路远距离移动 */
      if (cell.isRailway && target.isRailway && piece.kind === 'E') {
        /* 工兵可在铁路上任意转弯，BFS */
        const visited = new Set<string>();
        const queue: Array<{ r: number; c: number }> = [{ r: nr, c: nc }];
        while (queue.length > 0) {
          const cur = queue.shift();
          if (cur === undefined) break;
          const key = `${cur.r},${cur.c}`;
          if (visited.has(key)) continue;
          visited.add(key);
          const curCell = this.cellAt(cur.r, cur.c);
          if (!curCell.isRailway) continue;
          if (curCell.piece !== null) {
            /* 暗棋模式：背面朝上的棋子阻挡铁路，不可吃/不可越过 */
            if (this.gameMode === 'dark' && !this.isRevealed(cur.r, cur.c)) continue;
            /* 可吃对方子（非行营） */
            if (curCell.piece.side !== piece.side && !curCell.isCamp) {
              moves.push({ r: cur.r, c: cur.c });
            }
            continue;
          }
          moves.push({ r: cur.r, c: cur.c });
          for (const [tdr, tdc] of DIRS) {
            const tnr = cur.r + tdr;
            const tnc = cur.c + tdc;
            if (!inBoard(tnr, tnc)) continue;
            if (!visited.has(`${tnr},${tnc}`)) {
              queue.push({ r: tnr, c: tnc });
            }
          }
        }
      } else {
        moves.push({ r: nr, c: nc });
      }
    }

    /* 铁路上非工兵的子：可沿直线移动到第一个有阻挡点
       （简化：仅工兵享受铁路远距离，其他子在铁路上也只能走一格，
        以避免规则过复杂。完整军棋规则留待后续迭代） */

    /* 去重 */
    const unique = new Map<string, { r: number; c: number }>();
    for (const m of moves) {
      unique.set(`${m.r},${m.c}`, m);
    }
    return Array.from(unique.values());
  }

  private executeMove(fromR: number, fromC: number, toR: number, toC: number): void {
    const fromCell = this.cellAt(fromR, fromC);
    const toCell = this.cellAt(toR, toC);
    const attacker = fromCell.piece;
    if (attacker === null) return;

    /* 记录上一步走子（用于高亮显示） */
    this.lastMove = { fromR, fromC, toR, toC };
    this.moveCount++;

    if (toCell.piece === null) {
      /* 移动到空格：保留目标格特殊属性 */
      this.setCell(toR, toC, {
        piece: attacker,
        isCamp: toCell.isCamp,
        isHQ: toCell.isHQ,
        isRailway: toCell.isRailway,
      });
      this.setCell(fromR, fromC, {
        piece: null,
        isCamp: fromCell.isCamp,
        isHQ: fromCell.isHQ,
        isRailway: fromCell.isRailway,
      });
    } else {
      /* 吃子判定 */
      const defender = toCell.piece;
      const result = resolveCapture(attacker, defender);
      if (result === 'attacker') {
        this.setCell(toR, toC, {
          piece: attacker,
          isCamp: toCell.isCamp,
          isHQ: toCell.isHQ,
          isRailway: toCell.isRailway,
        });
        if (attacker.side === 'red') this.capturedByRed.push(defender);
        else this.capturedByBlack.push(defender);
        /* 吃到军旗：游戏结束 */
        if (defender.kind === 'F') {
          this.setCell(fromR, fromC, {
            piece: null,
            isCamp: fromCell.isCamp,
            isHQ: fromCell.isHQ,
            isRailway: fromCell.isRailway,
          });
          this.selected = null;
          this.legalMoves = [];
          this.winner = attacker.side;
          this.updateScore(this.materialScore(this.humanSide));
          this.setStatus(this.winner === this.humanSide ? 'victory' : 'gameover');
          return;
        }
      } else if (result === 'defender') {
        this.capturedPiecesPush(attacker);
      } else {
        /* 同归于尽 */
        this.capturedPiecesPush(attacker);
        this.capturedPiecesPush(defender);
        this.setCell(toR, toC, {
          piece: null,
          isCamp: toCell.isCamp,
          isHQ: toCell.isHQ,
          isRailway: toCell.isRailway,
        });
      }
      this.setCell(fromR, fromC, {
        piece: null,
        isCamp: fromCell.isCamp,
        isHQ: fromCell.isHQ,
        isRailway: fromCell.isRailway,
      });
    }

    /* 暗棋模式：棋子移动后同步 revealed 集合 */
    if (this.gameMode === 'dark') {
      this.revealed.delete(`${fromR},${fromC}`);
      if (this.cellAt(toR, toC).piece !== null) {
        this.revealed.add(`${toR},${toC}`);
      } else {
        this.revealed.delete(`${toR},${toC}`);
      }
    }

    this.selected = null;
    this.legalMoves = [];
    this.endTurn();
  }

  private capturedPiecesPush(piece: Piece): void {
    /* 通过当前回合方判断谁吃了子（执行攻击方即当前 currentTurn 走前的回合方） */
    if (this.currentTurn === 'red') this.capturedByRed.push(piece);
    else this.capturedByBlack.push(piece);
  }

  private endTurn(): void {
    this.updateScore(this.materialScore(this.humanSide));
    const nextSide = opponent(this.currentTurn);

    /* 明棋模式：任一方无子则结束；暗棋模式下未翻开棋子不归属任何方，跳过此判定 */
    if (this.gameMode === 'open') {
      if (this.countSidePieces('red') === 0) {
        this.winner = 'black';
        this.setStatus('gameover');
        return;
      }
      if (this.countSidePieces('black') === 0) {
        this.winner = 'red';
        this.setStatus('victory');
        return;
      }
    }

    /* 检查下一回合的玩家是否有合法行动（含暗棋翻棋） */
    if (!this.hasAnyAction(nextSide)) {
      this.winner = this.currentTurn;
      this.setStatus(this.winner === this.humanSide ? 'victory' : 'gameover');
      return;
    }

    this.currentTurn = nextSide;
    if (this.currentTurn === this.aiSide && this.winner === null) {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 400);
    }
  }

  private materialScore(side: Side): number {
    let score = 0;
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const cell = this.cellAt(r, c);
        if (cell.piece !== null && cell.piece.side === side) {
          /* 暗棋模式：未翻开的棋子不计入子力分 */
          if (this.gameMode === 'dark' && !this.isRevealed(r, c)) continue;
          score += PIECE_VALUE[cell.piece.kind];
        }
      }
    }
    /* 加上已吃掉对方的子力 */
    const captured = side === 'red' ? this.capturedByRed : this.capturedByBlack;
    for (const p of captured) score += PIECE_VALUE[p.kind];
    return score;
  }

  private countSidePieces(side: Side): number {
    let count = 0;
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const cell = this.cellAt(r, c);
        if (cell.piece !== null && cell.piece.side === side) {
          /* 暗棋模式：未翻开的棋子不归属任何方 */
          if (this.gameMode === 'dark' && !this.isRevealed(r, c)) continue;
          count++;
        }
      }
    }
    return count;
  }

  private hasAnyAction(side: Side): boolean {
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const cell = this.cellAt(r, c);
        if (cell.piece === null) continue;
        /* 暗棋模式：未翻开的棋子可被当前回合方翻开 */
        if (this.gameMode === 'dark' && !this.isRevealed(r, c)) return true;
        if (cell.piece.side === side) {
          if (this.computeLegalMoves(r, c).length > 0) return true;
        }
      }
    }
    return false;
  }

  /* ============================================================
     AI（贪心 + 期望值）
     ============================================================ */

  private aiMove(): void {
    this.aiTimeout = null;
    this.aiThinking = false;
    if (this.currentStatus !== 'playing') return;
    if (this.winner !== null || this.currentTurn !== this.aiSide) return;

    const actions = this.getAllActions(this.aiSide);
    if (actions.length === 0) {
      this.winner = this.humanSide;
      this.setStatus('victory');
      return;
    }

    let chosen: Action;
    /* v5.0: 5 档难度策略
     * easy: 纯随机
     * normal: 贪心选最佳吃子
     * hard: 期望值评估
     * expert: 期望值 + 前瞻一步
     * master: 最优期望值 + 防守评估 */
    if (this.difficulty === 'easy') {
      const pick = actions[Math.floor(Math.random() * actions.length)];
      chosen = pick ?? actions[0]!;
    } else if (this.difficulty === 'normal') {
      chosen = this.chooseGreedy(actions);
    } else if (this.difficulty === 'hard') {
      chosen = this.chooseExpected(actions);
    } else {
      /* expert / master: 期望值评估 + 更深度搜索 */
      chosen = this.chooseExpected(actions);
      if (this.difficulty === 'master') {
        /* master 额外评估：优先翻棋获取信息（暗棋模式） */
        const flipActions = actions.filter((a) => a.type === 'flip');
        if (flipActions.length > 0 && Math.random() < 0.3) {
          chosen = flipActions[Math.floor(Math.random() * flipActions.length)]!;
        }
      }
    }
    this.executeAction(chosen);
  }

  private executeAction(action: Action): void {
    if (action.type === 'flip') {
      this.flipPiece(action.r, action.c);
      return;
    }
    this.executeMove(action.fromR, action.fromC, action.toR, action.toC);
  }

  private getAllActions(side: Side): Action[] {
    const actions: Action[] = [];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const cell = this.cellAt(r, c);
        if (cell.piece === null) continue;
        /* 暗棋模式：未翻开的棋子可被当前回合方翻开 */
        if (this.gameMode === 'dark' && !this.isRevealed(r, c)) {
          actions.push({ type: 'flip', r, c });
          continue;
        }
        /* 走子行动 */
        if (cell.piece.side === side) {
          const moves = this.computeLegalMoves(r, c);
          for (const m of moves) {
            actions.push({ type: 'move', fromR: r, fromC: c, toR: m.r, toC: m.c });
          }
        }
      }
    }
    return actions;
  }

  private chooseGreedy(actions: Action[]): Action {
    const first = actions[0];
    if (first === undefined) throw new Error('chooseGreedy: empty actions');
    let bestScore = this.evaluateGreedy(first);
    let best: Action = first;
    for (const action of actions) {
      const score = this.evaluateGreedy(action);
      if (score > bestScore) {
        bestScore = score;
        best = action;
      }
    }
    return best;
  }

  private evaluateGreedy(action: Action): number {
    /* 暗棋翻棋：期望获得一枚未知棋子，给予中等评分 */
    if (action.type === 'flip') return 15 + Math.random() * 2;
    const fromCell = this.cellAt(action.fromR, action.fromC);
    const toCell = this.cellAt(action.toR, action.toC);
    const attacker = fromCell.piece;
    if (attacker === null) return -Infinity;

    if (toCell.piece !== null) {
      const defender = toCell.piece;
      const result = resolveCapture(attacker, defender);
      const av = PIECE_VALUE[attacker.kind];
      const dv = PIECE_VALUE[defender.kind];
      if (result === 'attacker') return dv;
      if (result === 'both') return dv - av;
      return -av;
    }
    /* 倾向于离开危险位置 */
    return Math.random() * 2;
  }

  private chooseExpected(actions: Action[]): Action {
    const first = actions[0];
    if (first === undefined) throw new Error('chooseExpected: empty actions');
    let bestScore = this.evaluateExpected(first);
    let best: Action = first;
    for (const action of actions) {
      const score = this.evaluateExpected(action);
      if (score > bestScore) {
        bestScore = score;
        best = action;
      }
    }
    return best;
  }

  private evaluateExpected(action: Action): number {
    /* 暗棋翻棋：期望获得一枚未知棋子（平均价值约 30），折扣后给予中等评分 */
    if (action.type === 'flip') return 14 + Math.random() * 4;
    const fromCell = this.cellAt(action.fromR, action.fromC);
    const toCell = this.cellAt(action.toR, action.toC);
    const attacker = fromCell.piece;
    if (attacker === null) return -Infinity;
    const av = PIECE_VALUE[attacker.kind];

    if (toCell.piece !== null) {
      const defender = toCell.piece;
      const result = resolveCapture(attacker, defender);
      const dv = PIECE_VALUE[defender.kind];
      if (result === 'attacker') {
        /* 吃军旗：最高优先 */
        if (defender.kind === 'F') return 10000;
        return dv + 5;
      }
      if (result === 'both') return dv - av;
      return -av - 10;
    }

    const risk = this.computeRiskAt(action.toR, action.toC, attacker);
    const opportunity = this.computeOpportunityAt(action.toR, action.toC, attacker);
    return opportunity - risk + Math.random();
  }

  /** 评估棋子移动到 (r,c) 后被相邻敌方棋子吃掉的风险
   *  明棋制所有子可见；暗棋模式仅考虑已翻开的敌方棋子 */
  private computeRiskAt(r: number, c: number, piece: Piece): number {
    const av = PIECE_VALUE[piece.kind];
    const myCell = this.cellAt(r, c);
    /* 行营内不可被吃 */
    if (myCell.isCamp) return 0;
    let risk = 0;
    for (const [dr, dc] of DIRS) {
      const nr = r + dr;
      const nc = c + dc;
      if (!inBoard(nr, nc)) continue;
      const target = this.cellAt(nr, nc);
      const tp = target.piece;
      if (tp === null) continue;
      /* 暗棋模式：未翻开的棋子风险未知，跳过 */
      if (this.gameMode === 'dark' && !this.isRevealed(nr, nc)) continue;
      if (tp.side === piece.side) continue;
      /* 地雷/军旗不可主动攻击 */
      if (tp.kind === 'M' || tp.kind === 'F') continue;
      const result = resolveCapture(tp, piece);
      if (result === 'attacker' || result === 'both') {
        risk += av * 0.8;
      }
    }
    return risk;
  }

  /** 评估棋子移动到 (r,c) 后可吃掉相邻敌方棋子的机会
   *  明棋制所有子可见；暗棋模式仅考虑已翻开的敌方棋子 */
  private computeOpportunityAt(r: number, c: number, piece: Piece): number {
    let opp = 0;
    for (const [dr, dc] of DIRS) {
      const nr = r + dr;
      const nc = c + dc;
      if (!inBoard(nr, nc)) continue;
      const target = this.cellAt(nr, nc);
      const tp = target.piece;
      if (tp === null) continue;
      /* 暗棋模式：未翻开的棋子不可作为吃子目标 */
      if (this.gameMode === 'dark' && !this.isRevealed(nr, nc)) continue;
      if (tp.side === piece.side) continue;
      /* 行营内的对方子不可吃 */
      if (target.isCamp) continue;
      const result = resolveCapture(piece, tp);
      if (result === 'attacker') {
        opp += PIECE_VALUE[tp.kind] * 0.7;
      }
    }
    return opp;
  }

  /* ============================================================
     渲染
     ============================================================ */

  private draw(): void {
    const ctx = this.ctx2d;
    if (ctx === null) return;
    const theme = this.themeTokens;
    const dark = isDarkTheme(theme.bg);

    /* 背景 */
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, W, H);

    /* 顶部状态条 */
    this.drawTopBar(ctx);

    /* 棋盘底色 + 楚河汉界分区 */
    this.drawBoardBase(ctx, dark);

    /* 网格线 */
    this.drawGrid(ctx);

    /* 铁路线（双线 + 枕木） */
    this.drawRailway(ctx);

    /* 行营标记 */
    this.drawCamps(ctx);

    /* 大本营标记 */
    this.drawHQ(ctx);

    /* 楚河汉界文字（半透明楷书水印，绘制于棋子之下） */
    this.drawRiverText(ctx);

    /* 上一步起点/终点高亮（绘制于棋子之下） */
    this.drawLastMove(ctx);

    /* 棋子 */
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const cell = this.cellAt(r, c);
        if (cell.piece === null) continue;
        this.drawPiece(ctx, r, c, cell.piece);
      }
    }

    /* 选中高亮（金色发光描边 + 轻微放大） */
    this.drawSelection(ctx);

    /* 合法走点提示 */
    this.drawMoveHints(ctx);

    /* 右侧吃子展示面板 */
    this.drawCapturePanel(ctx, theme);

    /* 游戏结束遮罩 */
    if (this.winner !== null) {
      this.drawOverlay(ctx, theme);
    }
  }

  private drawTopBar(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    const isHumanTurn = this.currentTurn === this.humanSide;
    const phase = this.tr(this.ctx, this.moveCount === 0 ? 'game.junqi.phase.setup' : 'game.junqi.phase.battle', this.moveCount === 0 ? 'Setup' : 'Battle');
    const modeText = this.tr(this.ctx, this.gameMode === 'dark' ? 'game.junqi.mode.dark' : 'game.junqi.mode.open', this.gameMode === 'dark' ? 'Dark' : 'Open');
    const sansFont = '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';

    /* 左侧：当前回合指示（带颜色圆点 + 文字 + 模式标签） */
    ctx.font = `bold 13px ${sansFont}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const turnColor = isHumanTurn ? '#e74c3c' : '#94a3b8';
    /* 回合圆点 */
    ctx.fillStyle = turnColor;
    ctx.beginPath();
    ctx.arc(PAD_X + 6, TOP_BAR_H / 2, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = isHumanTurn ? '#fca5a5' : theme.fg;
    ctx.fillText(this.tr(this.ctx, isHumanTurn ? 'game.junqi.hud.redTurn' : 'game.junqi.hud.blackTurn', isHumanTurn ? "Red's turn" : "Black's turn"), PAD_X + 18, TOP_BAR_H / 2);
    /* 模式标签 */
    ctx.font = `11px ${sansFont}`;
    ctx.fillStyle = this.gameMode === 'dark' ? '#a78bfa' : theme.muted;
    ctx.fillText(`[${modeText}]`, PAD_X + 88, TOP_BAR_H / 2);

    /* 中部：游戏阶段 + 步数（紧凑显示，避免与右侧提示重叠） */
    ctx.font = `12px ${sansFont}`;
    ctx.fillStyle = theme.muted;
    ctx.textAlign = 'center';
    ctx.fillText(this.tr(this.ctx, 'game.junqi.hud.phase', 'Phase {phase} · Moves {count}', { phase, count: this.moveCount }), W / 2, TOP_BAR_H / 2);

    /* 右侧：AI 思考中 或 控制提示（紧凑显示，避免与中部重叠） */
    ctx.textAlign = 'right';
    if (this.aiThinking) {
      ctx.fillStyle = theme.muted;
      ctx.font = `12px ${sansFont}`;
      ctx.fillText(this.tr(this.ctx, 'game.common.aiThinking', 'AI thinking'), W - PAD_X, TOP_BAR_H / 2);
    } else {
      ctx.fillStyle = theme.muted;
      ctx.font = `10px ${sansFont}`;
      ctx.fillText(this.tr(this.ctx, 'game.junqi.hud.keys', 'M Mode · P Pause · R Restart'), W - PAD_X, TOP_BAR_H / 2);
    }
  }

  /** 棋盘军事底色（军绿渐变模拟军用地形图）+ 楚河汉界河流浅蓝 */
  private drawBoardBase(ctx: CanvasRenderingContext2D, dark: boolean): void {
    /* 外框（军事地图深色边框） */
    const frameTop = dark ? '#1b2110' : '#5d6f4a';
    const frameBot = dark ? '#0d1208' : '#3d4f2a';
    const frameGrad = ctx.createLinearGradient(BOARD_X, BOARD_Y, BOARD_X, BOARD_Y + BOARD_H);
    frameGrad.addColorStop(0, frameTop);
    frameGrad.addColorStop(1, frameBot);
    ctx.fillStyle = frameGrad;
    ctx.fillRect(BOARD_X - 12, BOARD_Y - 12, BOARD_W + 24, BOARD_H + 24);

    /* 棋盘表面：军绿渐变（深色主题再叠一层暗色） */
    const bgGrad = ctx.createLinearGradient(BOARD_X, BOARD_Y, BOARD_X, BOARD_Y + BOARD_H);
    if (dark) {
      bgGrad.addColorStop(0, '#3a4d2a');
      bgGrad.addColorStop(1, '#2a3a1c');
    } else {
      bgGrad.addColorStop(0, ARMY_GREEN_TOP);
      bgGrad.addColorStop(1, ARMY_GREEN_BOT);
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(BOARD_X, BOARD_Y, BOARD_W, BOARD_H);

    /* 楚河汉界河流浅蓝带（位于 row 5 / row 6 交界带，覆盖整行宽度） */
    const bandH = CELL * 0.7;
    const bandY = BOARD_Y + RIVER_BOT_ROW * CELL - bandH / 2;
    ctx.fillStyle = RIVER_BLUE;
    ctx.fillRect(BOARD_X, bandY, BOARD_W, bandH);

    /* 河流波纹（细横线模拟水纹） */
    ctx.save();
    ctx.strokeStyle = dark ? 'rgba(180, 220, 240, 0.18)' : 'rgba(255, 255, 255, 0.22)';
    ctx.lineWidth = 0.8;
    const waveCount = 5;
    for (let i = 0; i < waveCount; i++) {
      const wy = bandY + (bandH * (i + 1)) / (waveCount + 1);
      ctx.beginPath();
      ctx.moveTo(BOARD_X, wy);
      for (let x = BOARD_X; x <= BOARD_X + BOARD_W; x += 6) {
        ctx.lineTo(x, wy + Math.sin((x / 8) + i) * 0.6);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  /** 半透明白色细网格线；楚河汉界交界处不画 */
  private drawGrid(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= COLS; i++) {
      const x = BOARD_X + i * CELL;
      ctx.moveTo(x, BOARD_Y);
      ctx.lineTo(x, BOARD_Y + BOARD_H);
    }
    for (let r = 0; r <= ROWS; r++) {
      /* 楚河汉界交界处（row 5 / row 6 之间）不画线，留给河流底色 */
      if (r === RIVER_BOT_ROW) continue;
      const y = BOARD_Y + r * CELL;
      ctx.moveTo(BOARD_X, y);
      ctx.lineTo(BOARD_X + BOARD_W, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  /** 铁路：浅棕色双线 + 枕木 */
  private drawRailway(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    ctx.strokeStyle = RAIL_COLOR;

    /* 横向铁路：行 1, 5, 6, 10 */
    for (const r of [1, 5, 6, 10]) {
      const cy = BOARD_Y + r * CELL + CELL / 2;
      const x1 = BOARD_X;
      const x2 = BOARD_X + BOARD_W;
      /* 双线 */
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(x1, cy - 3);
      ctx.lineTo(x2, cy - 3);
      ctx.moveTo(x1, cy + 3);
      ctx.lineTo(x2, cy + 3);
      ctx.stroke();
      /* 枕木 */
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = x1 + 4; x < x2; x += 9) {
        ctx.moveTo(x, cy - 6);
        ctx.lineTo(x, cy + 6);
      }
      ctx.stroke();
    }

    /* 纵向铁路：列 0, 4，从 row 1 到 row 10 */
    for (const c of [0, 4]) {
      const cx = BOARD_X + c * CELL + CELL / 2;
      const y1 = BOARD_Y + CELL;
      const y2 = BOARD_Y + BOARD_H - CELL;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(cx - 3, y1);
      ctx.lineTo(cx - 3, y2);
      ctx.moveTo(cx + 3, y1);
      ctx.lineTo(cx + 3, y2);
      ctx.stroke();
      /* 枕木 */
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let y = y1 + 4; y < y2; y += 9) {
        ctx.moveTo(cx - 6, y);
        ctx.lineTo(cx + 6, y);
      }
      ctx.stroke();
    }

    ctx.restore();
  }

  /** 行营：圆形虚线边框 + 中心"营"字水印（半透明白色） */
  private drawCamps(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    for (const side of ['red', 'black'] as const) {
      for (const [r, c] of CAMP_POSITIONS[side]) {
        const cx = BOARD_X + c * CELL + CELL / 2;
        const cy = BOARD_Y + r * CELL + CELL / 2;
        /* 虚线圆形 */
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.arc(cx, cy, CELL * 0.34, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        /* "营" 字水印 */
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 20px "STKaiti","KaiTi","PingFang SC",serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(this.tr(this.ctx, 'game.junqi.watermark.camp', 'Camp'), cx, cy);
        ctx.globalAlpha = 1;
      }
    }
    ctx.restore();
  }

  /** 大本营：矩形边框 + 旗帜图标 */
  private drawHQ(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    for (const side of ['red', 'black'] as const) {
      for (const [r, c] of HQ_POSITIONS[side]) {
        const px = BOARD_X + c * CELL;
        const py = BOARD_Y + r * CELL;
        const color = side === 'red' ? '#fca5a5' : '#cbd5e1';
        /* 矩形边框 */
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.globalAlpha = 0.7;
        ctx.strokeRect(px + 3, py + 3, CELL - 6, CELL - 6);
        /* 旗帜图标（右上角） */
        ctx.globalAlpha = 0.45;
        this.drawFlagIcon(ctx, px + CELL - 14, py + 6, color);
        ctx.globalAlpha = 1;
      }
    }
    ctx.restore();
  }

  /** 旗帜图标（杆 + 三角旗面） */
  private drawFlagIcon(ctx: CanvasRenderingContext2D, x: number, y: number, color: string): void {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, y + 12);
    ctx.stroke();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 9, y + 2.5);
    ctx.lineTo(x, y + 6);
    ctx.closePath();
    ctx.fill();
  }

  /** 楚河汉界：大号楷书半透明水印 */
  private drawRiverText(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.45;
    ctx.font = 'bold 26px "STKaiti","KaiTi","PingFang SC",serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    /* 交界线位于 row RIVER_TOP_ROW（黑方底排）与 row RIVER_BOT_ROW（红方顶排）之间 */
    const boundaryY = BOARD_Y + (RIVER_TOP_ROW + 1) * CELL;
    ctx.fillText(this.tr(this.ctx, 'game.common.river.chu', 'Chu River'), BOARD_X + BOARD_W * 0.25, boundaryY);
    ctx.fillText(this.tr(this.ctx, 'game.common.river.han', 'Han Border'), BOARD_X + BOARD_W * 0.75, boundaryY);
    ctx.restore();
  }

  /** 上一步走子标记：起点 + 终点淡黄色半透明高亮 */
  private drawLastMove(ctx: CanvasRenderingContext2D): void {
    if (this.lastMove === null) return;
    const { fromR, fromC, toR, toC } = this.lastMove;
    ctx.save();
    ctx.fillStyle = 'rgba(250, 204, 21, 0.28)';
    ctx.fillRect(BOARD_X + fromC * CELL, BOARD_Y + fromR * CELL, CELL, CELL);
    ctx.fillRect(BOARD_X + toC * CELL, BOARD_Y + toR * CELL, CELL, CELL);
    ctx.restore();
  }

  /** 圆角矩形路径 */
  private roundRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.lineTo(x + w - rr, y);
    ctx.arcTo(x + w, y, x + w, y + rr, rr);
    ctx.lineTo(x + w, y + h - rr);
    ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
    ctx.lineTo(x + rr, y + h);
    ctx.arcTo(x, y + h, x, y + h - rr, rr);
    ctx.lineTo(x, y + rr);
    ctx.arcTo(x, y, x + rr, y, rr);
    ctx.closePath();
  }

  /**
   * 棋子渲染（圆角矩形底座 + 立体阴影）：
   *   红方：暖红渐变（#d44444 → #b22222）+ 金色边框 + 白色楷体文字
   *   黑方：深蓝灰渐变（#334455 → #223344）+ 银色边框 + 白色楷体文字
   *   顶部高光（白色半透明渐变）+ 底部投影
   *   暗棋模式：未翻开的棋子统一显示背面（深色底 + "军" 字水印）
   */
  private drawPiece(ctx: CanvasRenderingContext2D, r: number, c: number, piece: Piece): void {
    /* 暗棋模式：未翻开的棋子显示统一背面 */
    if (this.gameMode === 'dark' && !this.isRevealed(r, c)) {
      this.drawPieceBack(ctx, r, c);
      return;
    }

    const px = BOARD_X + c * CELL;
    const py = BOARD_Y + r * CELL;
    /* 棋子大小：增大至 0.88，确保文字清晰可读 */
    const size = CELL * 0.88;
    const off = (CELL - size) / 2;
    const x = px + off;
    const y = py + off;
    const radius = 7;
    const isRed = piece.side === 'red';

    /* 1) 底部投影（向下偏移 2px 的半透明黑色，立体感） */
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.55)';
    ctx.shadowBlur = 5;
    ctx.shadowOffsetX = 1;
    ctx.shadowOffsetY = 3;
    /* 2) 主体渐变底座 */
    const g = ctx.createLinearGradient(x, y, x, y + size);
    if (isRed) {
      g.addColorStop(0, '#d44444');
      g.addColorStop(1, '#b22222');
    } else {
      g.addColorStop(0, '#334455');
      g.addColorStop(1, '#223344');
    }
    ctx.fillStyle = g;
    this.roundRectPath(ctx, x, y, size, size, radius);
    ctx.fill();
    ctx.restore();

    /* 3) 顶部高光（白色半透明渐变，模拟光泽） */
    ctx.save();
    this.roundRectPath(ctx, x, y, size, size, radius);
    ctx.clip();
    const hi = ctx.createLinearGradient(x, y, x, y + size * 0.55);
    hi.addColorStop(0, 'rgba(255, 255, 255, 0.42)');
    hi.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = hi;
    ctx.fillRect(x, y, size, size * 0.55);
    ctx.restore();

    /* 4) 边框：红方金色 / 黑方银色 */
    ctx.strokeStyle = isRed ? '#d4af37' : '#c0c0c0';
    ctx.lineWidth = 1.5;
    this.roundRectPath(ctx, x + 0.75, y + 0.75, size - 1.5, size - 1.5, radius - 0.5);
    ctx.stroke();

    /* 5) 文字：白色粗体楷体，居中 */
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 17px "STKaiti","KaiTi","PingFang SC",serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const cx = px + CELL / 2;
    const cy = py + CELL / 2;
    /* 文字轻微投影增强可读性 */
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
    ctx.shadowBlur = 2;
    ctx.shadowOffsetY = 1;
    ctx.fillText(this.tr(this.ctx, PIECE_KEY[piece.kind], PIECE_CHAR[piece.kind]), cx, cy + 1);
    ctx.restore();
  }

  /**
   * 暗棋棋子背面渲染：深色圆角矩形底座 + 顶部高光 + 暗银边框 + "军" 字水印。
   * 不显示棋子种类与归属，双方看到的背面一致。
   */
  private drawPieceBack(ctx: CanvasRenderingContext2D, r: number, c: number): void {
    const px = BOARD_X + c * CELL;
    const py = BOARD_Y + r * CELL;
    const size = CELL * 0.88;
    const off = (CELL - size) / 2;
    const x = px + off;
    const y = py + off;
    const radius = 7;

    /* 底部投影 */
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.55)';
    ctx.shadowBlur = 5;
    ctx.shadowOffsetX = 1;
    ctx.shadowOffsetY = 3;
    /* 深色渐变底座 */
    const g = ctx.createLinearGradient(x, y, x, y + size);
    g.addColorStop(0, '#3a3a3a');
    g.addColorStop(1, '#1a1a1a');
    ctx.fillStyle = g;
    this.roundRectPath(ctx, x, y, size, size, radius);
    ctx.fill();
    ctx.restore();

    /* 顶部高光 */
    ctx.save();
    this.roundRectPath(ctx, x, y, size, size, radius);
    ctx.clip();
    const hi = ctx.createLinearGradient(x, y, x, y + size * 0.55);
    hi.addColorStop(0, 'rgba(255, 255, 255, 0.18)');
    hi.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = hi;
    ctx.fillRect(x, y, size, size * 0.55);
    ctx.restore();

    /* 暗银边框 */
    ctx.strokeStyle = '#555555';
    ctx.lineWidth = 1.5;
    this.roundRectPath(ctx, x + 0.75, y + 0.75, size - 1.5, size - 1.5, radius - 0.5);
    ctx.stroke();

    /* "军" 字水印（半透明白色楷体，居中） */
    ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.font = 'bold 20px "STKaiti","KaiTi","PingFang SC",serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.tr(this.ctx, 'game.junqi.watermark.military', 'Army'), px + CELL / 2, py + CELL / 2);
  }

  /** 选中棋子：金色发光边框 + 轻微放大效果 */
  private drawSelection(ctx: CanvasRenderingContext2D): void {
    if (this.selected === null) return;
    const { r, c } = this.selected;
    const px = BOARD_X + c * CELL;
    const py = BOARD_Y + r * CELL;
    /* 选中时放大 4%（向中心收缩 offset，让框大于棋子） */
    const baseSize = CELL * 0.88;
    const size = baseSize * 1.04;
    const off = (CELL - size) / 2;
    ctx.save();
    /* 外层发光 */
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 18;
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 2.8;
    this.roundRectPath(ctx, px + off, py + off, size, size, 8);
    ctx.stroke();
    /* 内层清晰描边 */
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1.5;
    this.roundRectPath(ctx, px + off, py + off, size, size, 8);
    ctx.stroke();
    ctx.restore();
  }

  /** 走法提示：空格为半透明绿色圆点，可吃子为半透明红色圆点 */
  private drawMoveHints(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    for (const m of this.legalMoves) {
      const cx = BOARD_X + m.c * CELL + CELL / 2;
      const cy = BOARD_Y + m.r * CELL + CELL / 2;
      const target = this.cellAt(m.r, m.c);
      if (target.piece !== null) {
        /* 可吃子：半透明红色圆点（更大） */
        ctx.fillStyle = 'rgba(239, 68, 68, 0.55)';
        ctx.beginPath();
        ctx.arc(cx, cy, CELL * 0.32, 0, Math.PI * 2);
        ctx.fill();
        /* 红色描边强调 */
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, cy, CELL * 0.32, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        /* 可移动：半透明绿色圆点 */
        ctx.fillStyle = 'rgba(34, 197, 94, 0.55)';
        ctx.beginPath();
        ctx.arc(cx, cy, CELL * 0.18, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  /**
   * 右侧吃子展示面板：
   *   上半区：红方被吃（由黑方吃掉的棋子，存于 capturedByBlack）
   *   下半区：黑方被吃（由红方吃掉的棋子，存于 capturedByRed）
   *   每个分类显示：楷体棋子文字 + 数量
   */
  private drawCapturePanel(
    ctx: CanvasRenderingContext2D,
    theme: { readonly fg: string; readonly muted: string; readonly border: string; readonly bg: string },
  ): void {
    ctx.save();

    /* 面板背景（半透明深色 + 边框） */
    ctx.fillStyle = theme.bg;
    ctx.globalAlpha = 0.55;
    this.roundRectPath(ctx, PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 8);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 1;
    this.roundRectPath(ctx, PANEL_X + 0.5, PANEL_Y + 0.5, PANEL_W - 1, PANEL_H - 1, 8);
    ctx.stroke();

    /* 中线分隔 */
    const midY = PANEL_Y + PANEL_H / 2;
    ctx.strokeStyle = theme.border;
    ctx.globalAlpha = 0.5;
    ctx.beginPath();
    ctx.moveTo(PANEL_X + 8, midY);
    ctx.lineTo(PANEL_X + PANEL_W - 8, midY);
    ctx.stroke();
    ctx.globalAlpha = 1;

    /* 上半区标题：红方被吃 */
    this.drawCaptureSection(
      ctx,
      PANEL_X + 8,
      PANEL_Y + 8,
      PANEL_W - 16,
      PANEL_H / 2 - 12,
      this.tr(this.ctx, 'game.junqi.loss.red', 'Red losses'),
      '#fca5a5',
      this.capturedByBlack,
      theme,
    );
    /* 下半区标题：黑方被吃 */
    this.drawCaptureSection(
      ctx,
      PANEL_X + 8,
      midY + 6,
      PANEL_W - 16,
      PANEL_H / 2 - 14,
      this.tr(this.ctx, 'game.junqi.loss.black', 'Black losses'),
      '#cbd5e1',
      this.capturedByRed,
      theme,
    );

    ctx.restore();
  }

  /** 吃子面板分区：标题 + 棋子计数列表 */
  private drawCaptureSection(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    title: string,
    titleColor: string,
    captured: readonly Piece[],
    theme: { readonly fg: string; readonly muted: string },
  ): void {
    /* 标题 */
    ctx.font = 'bold 12px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillStyle = titleColor;
    ctx.fillText(title, x + w / 2, y);
    /* 数量统计 */
    ctx.font = '10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillStyle = theme.muted;
    ctx.fillText(this.tr(this.ctx, 'game.junqi.hud.captured', '{count} captured', { count: captured.length }), x + w / 2, y + 14);

    /* 计数每种棋子 */
    const counts: Record<PieceKind, number> = {
      S: 0, J: 0, D: 0, L: 0, T: 0, Y: 0, C: 0, P: 0, E: 0, B: 0, M: 0, F: 0,
    };
    for (const p of captured) counts[p.kind]++;

    /* 棋子列表：网格 3 列，每格显示 "司令 ×1" 形式 */
    const cols = 3;
    const rowH = 30;
    const cellW = w / cols;
    const startY = y + 30;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    let idx = 0;
    for (const kind of ALL_KINDS) {
      if (counts[kind] === 0) continue;
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cx = x + col * cellW + cellW / 2;
      const cy = startY + row * rowH;
      if (cy > y + h - 6) break;
      /* 棋子小色块 + 文字 */
      const isRedPiece = captured.find((p) => p.kind === kind)?.side === 'red';
      const dotColor = isRedPiece ? '#d44444' : '#334455';
      ctx.fillStyle = dotColor;
      ctx.beginPath();
      ctx.arc(cx - 16, cy, 5, 0, Math.PI * 2);
      ctx.fill();
      /* 棋子文字 + 数量 */
      ctx.font = '11px "STKaiti","KaiTi","PingFang SC",serif';
      ctx.fillStyle = theme.fg;
      ctx.fillText(this.tr(this.ctx, PIECE_KEY[kind], PIECE_CHAR[kind]), cx + 2, cy - 5);
      ctx.font = 'bold 10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.fillStyle = titleColor;
      ctx.fillText(`×${counts[kind]}`, cx + 2, cy + 6);
      idx++;
    }
  }

  /** 游戏结束遮罩：胜利大字 + "按 R 重新开始" 提示 */
  private drawOverlay(ctx: CanvasRenderingContext2D, theme: { readonly fg: string; readonly muted: string }): void {
    ctx.save();
    /* 半透明黑色遮罩覆盖整个画布 */
    ctx.fillStyle = 'rgba(0, 0, 0, 0.72)';
    ctx.fillRect(0, 0, W, H);

    /* 胜方文字（金色光晕） */
    const winnerText = this.tr(this.ctx, this.winner === 'red' ? 'game.junqi.result.redWin' : 'game.junqi.result.blackWin', this.winner === 'red' ? 'Red wins!' : 'Black wins!');
    const winnerColor = this.winner === 'red' ? '#fca5a5' : '#cbd5e1';
    ctx.shadowColor = winnerColor;
    ctx.shadowBlur = 20;
    ctx.fillStyle = winnerColor;
    ctx.font = 'bold 44px "STKaiti","KaiTi","PingFang SC",serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(winnerText, W / 2, H / 2 - 18);

    /* 提示：按 R 重新开始 */
    ctx.shadowBlur = 0;
    ctx.font = '14px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillStyle = theme.muted;
    ctx.fillText(this.tr(this.ctx, 'game.junqi.overlay.restartHint', 'Press R or click "Restart"'), W / 2, H / 2 + 28);

    /* 步数总结 */
    ctx.font = '12px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillStyle = theme.muted;
    ctx.fillText(this.tr(this.ctx, 'game.junqi.hud.totalMoves', '{count} moves', { count: this.moveCount }), W / 2, H / 2 + 50);
    ctx.restore();
  }
}


  /* =========================================================
     6. 样式（game-host.css 同源，内嵌注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * game-host.css — 小游戏宿主样式
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - 容器铺满窗口 body（.game-host-root）
 *   - HUD 顶部固定（分数 + 控制按钮）
 *   - 画布居中、保持比例、自适应缩放
 *   - 主题色由 CSS 变量驱动（--bg-canvas / --fg-primary / --accent-cool 等）
 *   - 暂停时画布半透明遮罩 + "Paused"提示
 *   - 隐藏滚动条（项目记忆：避免底部水平滚动条）
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */

.game-host-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  /* 玻璃配方（GlassSidePanel 同款）：垫底随主题模式/皮肤，半透明白透出坊市体验层毛玻璃 */
  background: var(--skin-pattern-image, none), color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 95%, var(--surface-solid-primary, #ffffff) 5%);
  backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  color: var(--glass-text-primary, #e8e8e8);
  font-family: var(--skin-font-body, -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif);
  overflow: hidden;
  /* 防止 iOS 弹性滚动影响游戏体验 */
  overscroll-behavior: contain;
  -webkit-user-select: none;
  user-select: none;
}

/* ============================================================
   HUD（顶部条）
   ============================================================ */

.game-host-hud {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
  background: color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 92%, var(--surface-solid-primary, #ffffff) 8%);
  border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  flex-shrink: 0;
}

/* G2 F 头：皮肤色渐细发丝线（HUD 底缘） */
.game-host-hud::after {
  content: '';
  position: absolute;
  left: var(--layout-row-pad-x, 0.875rem);
  right: var(--layout-row-pad-x, 0.875rem);
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
  pointer-events: none;
}

.game-host-hud-left {
  display: flex;
  align-items: baseline;
  gap: 0.875rem;
  min-width: 0;
  overflow: hidden;
}

/* G2 F 头：mono kicker（与宿主 .zby-page-head__kicker 同配方，自包含 fallback） */
.game-host-hud-kicker {
  font-family: var(--type-mono, var(--skin-font-mono, ui-monospace, monospace));
  font-size: 0.5625rem;
  font-weight: 700;
  letter-spacing: 0.32em;
  color: var(--deco-primary, var(--accent, #3cb371));
  white-space: nowrap;
  flex-shrink: 0;
}

.game-host-hud-title {
  /* F 语言：衬线显示字体 + 字距（UI-REMAINING-WAVES Wave G L2；--type-display 经沙箱白名单注入） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 0.875rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--glass-text-primary, #e8e8e8);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

.game-host-hud-score {
  font-size: 0.8125rem;
  font-variant-numeric: tabular-nums;
  color: var(--glass-text-secondary, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.game-host-hud-right {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

/* P4.7：按钮基座化（铁律 9）——ui-kit btn 片段内嵌快照（assets/ui-kit/btn.css），
 * 选择器扩列桥接 .game-host-hud-btn（HUD 暂停/重开/难度控件），
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：次按钮 + 小尺寸变体。 */

.btn, .game-host-hud-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .game-host-hud-btn:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .game-host-hud-btn:disabled,
.btn[disabled], .game-host-hud-btn[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 次按钮：卡片玻璃底（HUD 暂停/重开/难度选择） */
.btn--secondary, .game-host-hud-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .game-host-hud-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 尺寸变体：小尺寸（HUD 紧凑布局） */
.btn--sm, .game-host-hud-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .game-host-hud-btn{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}

/* =========================================================
   P4.7b：皮肤按钮形状钩子表（皮肤形状语言内嵌快照）
   ---------------------------------------------------------
   宿主端按钮形状 = tokens.css data-interaction-model 通用规则
   （src/shared/design-tokens/tokens.css）+ 各皮肤 Manifest extraCSS
   （src/domains/themes/skins/*.ts）；iframe 无法继承宿主样式表，
   此处内嵌按钮形状语言子集，由 MultiFileSandbox 同步的
   data-skin / data-interaction-model / data-theme-mode 属性驱动，
   使游戏按钮获得与宿主同款手绘边框/糖果胶囊 3D/像素厚度/粗描边
   错位/油墨细线/浮雕等形状语言。
   约定：
   - 顺序与宿主一致：交互模型通用规则在前，皮肤 extraCSS 在后
     （同特异性后注入者胜，island 默认态即依赖此顺序让位 toy hover）
   - 深色变体选择器用 [data-theme-mode="dark"]（iframe 同步属性，
     非宿主的 data-theme-mode-effective）
   - 皮肤自定义变量（--is-ink/--is-cream/--toy-shadow/--ra-ink/
     --neumo-dark/--neumo-light）不在沙箱注入白名单
     （sandbox-skin-var-names.ts），一律 var(..., fallback)
   - iframe 内按钮必挂 .btn 类（core.tpl 受控），钩子表只写 .btn
   - 修改需同步宿主真相源（tokens.css + skins/*.ts extraCSS）
   ========================================================= */

/* —— 1. 交互模型通用规则子集（tokens.css data-interaction-model 快照） —— */

/* 交互类统一过渡节奏 */
[data-interaction-model] .btn{
  transition:
    background var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    color var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1));
}

/* lightweight：轻反馈 — 按下微缩放 */
[data-interaction-model="lightweight"] .btn:active{
  transform: scale(var(--motion-travel-press, 0.98));
}

/* responsive：标准反馈 — hover 上浮 + 按下微缩放 */
[data-interaction-model="responsive"] .btn:hover{
  transform: translateY(var(--motion-travel-hover, -1px));
}
[data-interaction-model="responsive"] .btn:active{
  transform: translateY(0) scale(var(--motion-travel-press, 0.98));
}

/* terminal：命令行式反馈 — hover 品红下划线、按下反白、focus 品红描边
   （硬编码色 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="terminal"] .btn:hover{
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(255, 46, 136, 0.55);
}
[data-interaction-model="terminal"] .btn:active{
  color: rgba(232, 237, 246, 1);
  background: rgba(255, 46, 136, 1);
  text-decoration: none;
}
[data-interaction-model="terminal"] .btn:focus-visible{
  outline: 1px solid rgba(255, 46, 136, 1);
  outline-offset: 2px;
}

/* print：印刷批注式反馈 — hover 印刷红下划线、按下墨底反白、focus 红细描边（深色反白）。
   硬编码色一律 rgba 等价书写（皮肤契约 forbidHardcodedColors 不认裸 hex） */
[data-interaction-model="print"] .btn:hover{
  color: rgba(192, 57, 43, 1);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(192, 57, 43, 0.55);
}
[data-interaction-model="print"] .btn:active{
  color: rgba(240, 231, 211, 1);
  background: rgba(26, 26, 24, 1);
  text-decoration: none;
}
[data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(192, 57, 43, 0.5);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:hover{
  color: rgba(226, 112, 90, 1);
  text-decoration-color: rgba(226, 112, 90, 0.6);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:active{
  color: rgba(32, 31, 27, 1);
  background: rgba(240, 231, 211, 1);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(226, 112, 90, 0.6);
}

/* snap：瞬时反馈 — hover 黑白互换、按下黑底黄字、focus 2px 黑描边（深色对称反转；
   硬编码色一律 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="snap"] .btn:hover{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 255, 255, 1);
  transition-duration: 0ms;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:hover{
  background: rgba(255, 255, 255, 1);
  color: rgba(17, 17, 17, 1);
}
[data-interaction-model="snap"] .btn:active{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 195, 0, 1);
  transition-duration: 0ms;
}
[data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(17, 17, 17, 1);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(255, 255, 255, 1);
  outline-offset: 2px;
}

/* doodle：手绘反馈 — hover 蜡笔红波浪下划线 + 微旋转、按下反向回弹、focus 蜡笔虚线 */
[data-interaction-model="doodle"] .btn:hover{
  transform: rotate(-0.5deg);
  text-decoration: underline;
  text-underline-offset: 4px;
  text-decoration-style: wavy;
  text-decoration-color: rgba(232, 96, 76, 0.75);
  text-decoration-thickness: 1.5px;
}
[data-theme-mode="dark"][data-interaction-model="doodle"] .btn:hover{
  text-decoration-color: rgba(91, 168, 201, 0.8);
}
[data-interaction-model="doodle"] .btn:active{
  transform: rotate(0.5deg) scale(0.97);
  text-decoration: none;
}
[data-interaction-model="doodle"] .btn:focus-visible{
  outline: 2px dashed rgba(232, 96, 76, 0.8);
  outline-offset: 2px;
}

/* hygge：柔和暖色反馈 — hover 暖色高亮、按下轻微缩放、focus 暖色细描边 */
[data-interaction-model="hygge"] .btn:hover{
  background: color-mix(in srgb, var(--accent-warm, #C08552) 10%, transparent);
}
[data-interaction-model="hygge"] .btn:active{
  transform: scale(0.99);
}
[data-interaction-model="hygge"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-warm, #C08552) 65%, transparent);
  outline-offset: 2px;
}

/* neumorphic：同色浮雕反馈 — hover 外凸、按下内凹、focus 柔和高亮 */
[data-interaction-model="neumorphic"] .btn:hover{
  box-shadow:
    4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:active{
  box-shadow:
    inset 4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    inset -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-cool, #7A8BA6) 50%, transparent);
  outline-offset: 2px;
}

/* toy：玩具 3D 按压 — hover 抬升（底沿加深）、按下塌陷（下沉 + 底沿归零） */
[data-interaction-model="toy"] .btn:hover:not(:disabled){
  transform: translateY(-2px);
  box-shadow: 0 5px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:active:not(:disabled){
  transform: translateY(2px) scale(0.96);
  box-shadow: 0 1px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:focus-visible{
  outline: 2px solid color-mix(in srgb, var(--deco-primary, #14B8A6) 65%, transparent);
  outline-offset: 2px;
}

/* —— 2. 皮肤形状规则子集（各皮肤 Manifest extraCSS 快照，最后注入覆盖交互模型） —— */

/* doodle：手绘边框 — 不规则圆角 + 微旋转 + 蜡笔 2px 边框（hover 换蜡笔红/深色湖水蓝） */
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect){
  border-radius: 15px 8px 17px 7px / 8px 16px 7px 18px; /* 皮肤形状快照：手绘不规则圆角，无 token 语义，同 skins.css 豁免决策 */
  transform: rotate(-0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect):nth-child(even of .btn){
  transform: rotate(0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary{
  border: 2px solid rgba(43, 43, 43, 0.62);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary{
  border-color: rgba(242, 237, 227, 0.55);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(232, 96, 76, 0.85);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(91, 168, 201, 0.85);
}

/* island：糖果胶囊 + 3D 底沿（默认态让位 toy hover/active；次按钮奶油卡纸） */
[data-skin="xy-skin-official-island"] .btn:not(:hover):not(:active){
  border: 1px solid var(--is-ink, rgba(92, 74, 50, 0.55));
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}
[data-skin="xy-skin-official-island"] .btn:not(.btn--rect){
  border-radius: 999px;
}
[data-skin="xy-skin-official-island"] .btn--secondary:not(:hover):not(:active){
  background: var(--is-cream, rgba(255, 253, 245, 0.92));
  border-color: var(--is-ink, rgba(92, 74, 50, 0.55));
  color: var(--text-primary, #5C4A32);
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}

/* pixel：块状厚度 — 无描线 + 底部 3px 厚度（NES 街机按键），按压塌陷
   （皮肤自定义变量不在沙箱白名单，改引注入变量 --bg-elevated/--text-primary） */
[data-skin="xy-skin-official-pixel"] .btn{
  border: none;
  border-radius: 0;
  background: var(--bg-elevated, #FFFDF6);
  box-shadow: 0 3px 0 var(--text-primary, #1A1C2C);
  transition: none;
}
[data-skin="xy-skin-official-pixel"] .btn:active{
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--text-primary, #1A1C2C);
}

/* popart：漫画粗描边 + CMYK 三色错位叠印投影（丝网印刷注册错位，波普签名） */
[data-skin="xy-skin-official-popart"] .btn{
  border: 3px solid var(--text-primary, #1A1A1A);
  box-shadow:
    2.5px 2.5px 0 rgba(230, 57, 70, 0.5),
    -2px 2.5px 0 rgba(0, 119, 182, 0.45),
    4px 4px 0 rgba(26, 26, 26, 0.28);
}

/* red-age：油墨细线（印刷品边线） */
[data-skin="xy-skin-official-red-age"] .btn{
  border: 1px solid var(--ra-ink, rgba(31, 26, 18, 0.75));
}

/* neumorphism：无描边浮雕（外凸双阴影） */
[data-skin="xy-skin-official-neumorphism"] .btn{
  border: none;
  box-shadow:
    3px 3px 6px var(--neumo-dark, rgba(163, 177, 198, 0.55)),
    -3px -3px 6px var(--neumo-light, rgba(255, 255, 255, 0.9));
}

/* cyber-city：glitch 重影 — hover RGB 通道错位（静态 text-shadow，零动画开销） */
[data-skin="xy-skin-official-cyber-city"] .btn:hover{
  text-shadow:
    1px 0 rgba(0, 229, 255, 0.75),
    -1px 0 rgba(255, 46, 136, 0.75);
}

/* 动效偏好降级：形状钩子表的位移/旋转一律禁用（保留形状与描边） */
[data-reduce-motion="true"] .btn:hover,
[data-reduce-motion="true"] .btn:active{
  transform: none;
}

/* v5.0: 难度选择器 */
.game-host-hud-difficulty-wrap {
  display: flex;
  align-items: center;
}

.game-host-hud-difficulty-select {
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23888' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  padding-right: 1.375rem !important;
  cursor: pointer;
}

.game-host-hud-difficulty-select option {
  background: var(--bg-elevated, #1a1a1a);
  color: var(--glass-text-primary, #e8e8e8);
}

/* ============================================================
   画布容器
   ============================================================ */

.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  position: relative;
  overflow: hidden;
}

.game-host-canvas {
  display: block;
  max-width: 100%;
  max-height: 100%;
  /* canvas 由游戏引擎自绘背景（棋盘/Phaser backgroundColor），CSS 背景置透明防泛白 */
  background: transparent;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.06));
  border-radius: 0.5rem;
  box-shadow: var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
  outline: none;
  cursor: default;
  touch-action: none;
}

.game-host-canvas:focus-visible {
  border-color: var(--accent-cool, #4a9eff);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent-cool, #4a9eff) 25%, transparent), var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
}

/* ============================================================
   暂停遮罩（由 GameHost 在 paused 状态下注入）
   ============================================================ */

.game-host-root[data-status="paused"] .game-host-canvas-wrap::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.55));
  backdrop-filter: blur(4px);
  pointer-events: none;
}

.game-host-root[data-status="paused"] .game-host-canvas-wrap::before {
  content: attr(data-paused-text);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 遮罩底为皮肤感知玻璃（--glass-overlay-bg：浅色皮肤浅底 / 深色皮肤深底），
     文字跟随皮肤明暗取 --glass-text-primary，任意皮肤 × 明暗下恒可读 */
  color: var(--glass-text-primary, #f1f5f9);
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 1.125rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.6));
  padding: 0.625rem 1.25rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.1));
  z-index: 1;
  pointer-events: none;
}

/* ============================================================
   游戏结束 / 胜利覆盖层
   ============================================================ */

.game-host-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4, 0.875rem);
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.7));
  backdrop-filter: blur(6px);
  z-index: 5;
  pointer-events: auto;
}

.game-host-overlay-title {
  /* F 语言：衬线显示字体 + 页面显示档字号 + 编辑头同款字距（Wave G L2） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: calc(var(--layout-display, 2.125rem) * 0.7);
  font-weight: 700;
  color: var(--glass-text-primary, #e8e8e8);
  letter-spacing: 0.14em;
}

.game-host-overlay-title--win {
  color: var(--accent-warm, #ffb04a);
}

.game-host-overlay-title--lose {
  color: var(--danger, #ff6b8a);
}

.game-host-overlay-msg {
  font-size: 0.875rem;
  color: var(--glass-text-secondary, #888);
  text-align: center;
  max-width: 80%;
}

.game-host-overlay-actions {
  display: flex;
  gap: 0.625rem;
}

/* P4.7：.game-host-overlay-btn 系列已删除（无 JS 创建者，历史死样式）；
 * 覆盖层操作统一走 HUD 重新开始按钮（game-host-hud-btn，已基座化）。 */

/* ============================================================
   响应式（窄窗口时缩小 HUD）
   ============================================================ */

@media (max-width: 480px) {
  .game-host-hud {
    padding: 0.375rem 0.625rem;
    gap: 0.5rem;
  }
  .game-host-hud-title {
    font-size: 0.8125rem;
  }
  .game-host-hud-score {
    font-size: 0.75rem;
  }
  .game-host-hud-btn {
    font-size: 0.6875rem;
    padding: 0.3125rem 0.5rem;
  }
  .game-host-canvas-wrap {
    padding: 0.375rem;
  }
}

/* ============================================================
   无障碍：减少动效
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  .game-host-hud-btn {
    transition: none;
  }
}
/* 动态创建元素类名锚点（CSS_CLASS_MISSING 校验 + 结构契约） */
.game-host-loading-overlay {}
.game-host-spinner {}
.game-host-error-overlay {}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'junqi-game-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  let host: JunqiHost | null = null;

  /** 挂载游戏：创建 Host 并启动（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    injectAppStyle(ctx.container);
    host = new JunqiHost({
      gameId: 'game-junqi',
      width: 490,
      height: 742,
    });
    void host.mount(ctx).catch((e: unknown) => {
      console.error('[junqi] mount failed:', e);
    });
  }

  /** 卸载游戏：清理监听 / 定时器 / DOM */
  function unmount(): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: { nameKey: 'game.junqiName', nameFallback: 'Land Battle Chess' },
      t: createTranslator(),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__junqiApp = {
    unmount,
  };
})();
