/**
 * chess — 中国象棋（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：src/shared/apps/games/（GameHost 基类 + builtin/chess/ChessHost）。
 * 转包改造点（对齐 PRD §4.2 / hex-color 模板）：
 *   1. 模块内联：沙箱 classic script 无模块系统，GameTypes + GameHost + ChessHost
 *      三段源平铺进本文件（原 import 全部为 type-only 或本地模块，编译后零残留）
 *   2. i18n：宿主 5 语包 → 内嵌 game.* 最小词表（HUD/难度/名称），零语言包依赖
 *   3. 皮肤：game-host.css → APP_CSS 内嵌注入（变量已带 fallback，沙箱可独立渲染）
 *   4. 入口签名：toAppEntry() → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. manifest 透传：boot 构造 { nameKey, nameFallback }（GameHost.resolveGameName 依赖）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅、manifest={nameKey,nameFallback}）并调用；样式同源内容
 *   以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. i18n：沙箱词表（宿主注入 window.__SANDBOX_I18N__，PRD Step 4.1）
     ========================================================= */

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 沙箱 i18n 快照（宿主 MultiFileSandbox 注入，与 SandboxI18nSnapshot 一致） */
  interface SandboxI18nState {
    readonly lang: string;
    readonly dict: Readonly<Record<string, string>>;
    readonly dictEn: Readonly<Record<string, string>>;
  }

  /** 读取沙箱 i18n 快照（宿主未注入时 undefined，t 回退 key 本身） */
  function getSandboxI18n(): SandboxI18nState | undefined {
    return (window as unknown as Record<string, unknown>).__SANDBOX_I18N__ as SandboxI18nState | undefined;
  }

  /** 翻译器：当前语言词表 → 英文兜底表 → key 本身（缺 key 走英文，不出现中文硬编码） */
  function createTranslator(): Translator {
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const i18n = getSandboxI18n();
      let template = key;
      if (i18n !== undefined) {
        template = i18n.dict[key] ?? i18n.dictEn[key] ?? key;
      }
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. GameTypes 内联（原 src/shared/apps/games/GameTypes.ts）
     ========================================================= */

/**
 * GameTypes — 小游戏共享类型定义
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - GameRenderEngine：游戏渲染引擎标识（canvas2d 主引擎 / phaser 辅引擎）
 *   - GameManifestDescriptor：游戏描述元数据（用于 AI 创造 prompt 隔离）
 *   - GameLaunchOptions：游戏启动参数（难度/音效/初始状态等）
 *
 * 引擎选型依据（详见 prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.2）：
 *   - Canvas 2D：零依赖、AI 友好度最高、适合棋类/俄罗斯方块等逻辑型游戏
 *   - Phaser 4：原生 TS 支持、适合动作类（坦克大战/打砖块）等需要物理引擎/精灵动画的游戏
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24
 */


/** 游戏渲染引擎 */
type GameRenderEngine = 'canvas2d' | 'phaser';

/** 游戏难度（v5.0: 扩展为 5 档） */
type GameDifficulty = 'easy' | 'normal' | 'hard' | 'expert' | 'master';

/** 游戏启动选项（由 AppMountContext.data 透传） */
interface GameLaunchOptions {
  /** 初始难度（默认 'normal'） */
  readonly difficulty?: GameDifficulty | undefined;
  /** 是否启用音效（默认 true） */
  readonly soundEnabled?: boolean | undefined;
  /** 是否启用调试模式（默认 false，开启后显示 FPS/碰撞框等） */
  readonly debug?: boolean | undefined;
  /** 初始关卡/级别（部分游戏支持，从 1 开始） */
  readonly level?: number | undefined;
  /** 游戏模式（部分游戏支持，如军棋 'open' 明棋 / 'dark' 暗棋） */
  readonly gameMode?: string | undefined;
}

/** 游戏状态（用于 UI 显示/Dock 角标） */
type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover' | 'victory';

/** 游戏分数变更事件 */
interface GameScoreEvent {
  /** 当前分数 */
  readonly score: number;
  /** 历史最高分 */
  readonly bestScore: number;
  /** 关卡/级别 */
  readonly level?: number | undefined;
}

/** 游戏状态变更事件 */
interface GameStatusEvent {
  readonly status: GameStatus;
  readonly message?: string | undefined;
}

/** 游戏元数据（用于 AI 创造 prompt 隔离，与 AppManifest 解耦） */
interface GameManifestDescriptor {
  /** 游戏唯一标识（与 AppManifest.id 一致） */
  readonly id: string;
  /** 游戏名称（与 AppManifest.nameFallback 一致） */
  readonly name: string;
  /** 渲染引擎 */
  readonly engine: GameRenderEngine;
  /** 游戏类型分类（用于 AI 创造 prompt） */
  readonly genre: 'puzzle' | 'board' | 'action' | 'arcade' | 'strategy';
  /** 玩家数 */
  readonly players: 1 | 2;
  /** 是否支持 AI 对手 */
  readonly supportsAI?: boolean | undefined;
  /** 默认难度 */
  readonly defaultDifficulty?: GameDifficulty | undefined;
  /** 简短描述（用于 AI prompt 上下文） */
  readonly summary: string;
}


  /* =========================================================
     3. 沙箱存储访问器（PRD ZBY-PORTABLE-APP-CONTRACT-ROADMAP P4.3：
        最高分经宿主 sandboxStorage 代理持久化，键 game:best:game-<id>
        已逐键声明于 manifest.dataKeys；离线预览无宿主时降级 null，
        行为同旧空实现）
     ========================================================= */

/** 沙箱 KV 存储三方法（ZbyAPI.sandboxStorage 无 appId 签名，宿主侧补全命名空间） */
interface SandboxStorageLike {
  readonly get: (key: string) => Promise<unknown>;
  readonly set: (key: string, value: unknown) => Promise<unknown>;
  readonly remove: (key: string) => Promise<unknown>;
}

/** 取宿主注入的沙箱存储代理；无宿主（离线预览模板）返回 null */
function getSandboxStorage(): SandboxStorageLike | null {
  const api = (window as unknown as Record<string, unknown>).ZbyAPI as
    | Record<string, unknown>
    | undefined;
  const storage =
    api === undefined || api === null
      ? undefined
      : (api['sandboxStorage'] as Record<string, unknown> | undefined);
  if (storage === null || storage === undefined) return null;
  if (typeof storage['get'] !== 'function' || typeof storage['set'] !== 'function') return null;
  return storage as unknown as SandboxStorageLike;
}

  /* =========================================================
     4. GameHost 基类内联（原 src/shared/apps/games/GameHost.ts）
     ========================================================= */

/**
 * GameHost — 小游戏宿主基类
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 职责：
 *   - 提供统一的 mount/unmount 生命周期
 *   - 创建游戏画布容器 + HUD（分数/暂停/重新开始按钮）
 *   - 解析 GameLaunchOptions（从 AppMountContext.data 透传）
 *   - 派发 GameStatusEvent / GameScoreEvent 事件
 *   - 持久化最高分（宿主 sandboxStorage 代理，按 gameId 隔离）
 *   - 适配深浅主题（CSS 变量驱动）
 *
 * 子类需实现：
 *   - onMount(ctx, canvas, options)：初始化游戏场景
 *   - onUnmount()：清理资源/定时器/事件
 *   - onPause()/onResume()：可选，处理暂停恢复
 *   - onRestart()：可选，处理重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */






/** GameHost 配置（子类构造时传入） */
interface GameHostConfig {
  /** 游戏 ID（与 AppManifest.id 一致，用于最高分持久化 key） */
  readonly gameId: string;
  /** 是否显示 HUD（默认 true） */
  readonly showHUD?: boolean;
  /** 是否支持暂停（默认 true） */
  readonly pauseable?: boolean;
  /** 画布宽度（CSS 像素，0 表示自适应容器宽度） */
  readonly width?: number;
  /** 画布高度（CSS 像素，0 表示自适应容器高度） */
  readonly height?: number;
}

/** 主题色 token（与 CSS 变量一一对应） */
interface GameThemeTokens {
  readonly bg: string;
  readonly fg: string;
  readonly accent: string;
  readonly muted: string;
  readonly border: string;
  readonly dark: boolean;
}

/** 默认主题 token（从 CSS 变量读取，失败时兜底） */
const DEFAULT_THEME_TOKENS: GameThemeTokens = {
  bg: '#1a1a1a',
  fg: '#e8e8e8',
  accent: '#4a9eff',
  muted: '#888888',
  border: '#333333',
  dark: true,
};

/** 最高分 LocalStorage key 前缀 */
const BEST_SCORE_KEY_PREFIX = 'game:best:';

/**
 * GameHost — 游戏宿主基类。
 *
 * 子类通过 extends GameHost 并实现 onMount/onUnmount 等抽象方法，
 * 即可获得统一的 HUD/主题适配/最高分持久化能力。
 *
 * 典型用法：
 * ```ts
 * class TetrisHost extends GameHost {
 *   protected onMount(ctx, canvas, options) {
 *     // 初始化 Tetris 渲染循环
 *   }
 *   protected onUnmount() {
 *     // 清理定时器
 *   }
 * }
 *
 * export function createTetrisEntry(): AppEntry {
 *   const host = new TetrisHost({ gameId: 'game-tetris' });
 *   return host.toAppEntry();
 * }
 * ```
 */
abstract class GameHost {
  protected readonly config: Readonly<GameHostConfig>;

  /** 挂载容器（由 mount 注入） */
  private container: HTMLElement | null = null;
  /** 根元素（.game-host-root） */
  private root: HTMLElement | null = null;
  /** 画布元素（由 mount 创建） */
  private canvas: HTMLCanvasElement | null = null;
  /** HUD 容器（分数/按钮） */
  private hud: HTMLElement | null = null;
  /** 当前应用上下文（用于 i18n / API 调用） */
  protected ctx: AppMountContext | null = null;
  /** 当前游戏状态 */
  private status: GameStatus = 'idle';
  /** 当前分数 */
  private score = 0;
  /** 历史最高分 */
  private bestScore = 0;
  /** 主题 token */
  private theme: GameThemeTokens = DEFAULT_THEME_TOKENS;
  /** 主题变化订阅解绑函数 */
  private themeUnsub: (() => void) | null = null;
  /** i18n 变更订阅解绑函数（宿主语言切换 → 刷新 HUD 文案，Step 4.1） */
  private i18nUnsub: (() => void) | null = null;
  /** 暂停状态锁（防止重复暂停/恢复） */
  private paused = false;
  /** HUD 状态监听器集合 */
  private readonly statusListeners = new Set<(e: GameStatusEvent) => void>();
  /** HUD 分数监听器集合 */
  private readonly scoreListeners = new Set<(e: GameScoreEvent) => void>();
  /** 画布逻辑宽度（子类调用 setupHiDPICanvas 时传入） */
  private logicalW = 0;
  /** 画布逻辑高度 */
  private logicalH = 0;
  /** ResizeObserver 实例（窗口尺寸变化时重新适配画布） */
  private resizeObserver: ResizeObserver | null = null;
  /** rAF 合并句柄（ResizeObserver 防抖，避免连续清空画布闪烁） */
  private resizeRaf: number | null = null;
  /** v4.2：自动暂停监听解绑函数（标签页隐藏 / 窗口失焦时自动暂停游戏） */
  private autoPauseUnsub: (() => void) | null = null;
  /** v4.2：自动暂停前的用户手动暂停状态（恢复时保留用户意图） */
  private wasPausedBeforeAutoPause: boolean = false;
  /** v5.0：当前游戏难度（由 resolveOptions 初始化，可运行时通过 HUD 下拉切换） */
  private currentDifficulty: GameDifficulty = 'normal';

  constructor(config: GameHostConfig) {
    this.config = config;
    this.bestScore = 0;
    /* P4.3：最高分经 sandboxStorage 异步加载（postMessage 往返），构造期无法
       同步取值；加载完成后取大者回填（防玩家抢先破纪录被旧值覆盖） */
    void this.loadBestScore().then((loaded) => {
      if (loaded > this.bestScore) {
        this.bestScore = loaded;
        this.updateHUDScore();
      }
    });
  }

  /* ============================================================
     生命周期（子类实现）
     ============================================================ */

  /**
   * 子类实现：游戏挂载时初始化场景。
   *
   * @param ctx 应用挂载上下文
   * @param canvas 画布元素（已设置宽高/样式）
   * @param options 游戏启动选项
   */
  protected abstract onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): void | Promise<void>;

  /**
   * 子类实现：游戏卸载时清理资源（定时器/事件/动画帧）。
   * 必须是同步的，由 unmount 调用。
   */
  protected abstract onUnmount(): void;

  /**
   * 子类可选实现：暂停游戏（默认空实现）。
   * 仅在 config.pauseable !== false 时调用。
   */
  protected onPause(): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：恢复游戏（默认空实现）。
   */
  protected onResume(): void {
    /* default no-op */
  }

  /**
   * v5.0: 子类可选实现：难度变更回调。
   * 当用户通过 HUD 下拉切换难度时调用，子类可在此调整 AI 强度等参数。
   */
  protected onDifficultyChange(_difficulty: GameDifficulty): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：重新开始游戏（默认调用 onUnmount + onMount）。
   */
  protected onRestart(): void {
    if (this.canvas === null || this.ctx === null) return;
    this.onUnmount();
    this.score = 0;
    this.status = 'idle';
    this.paused = false;
    void this.onMount(this.ctx, this.canvas, this.resolveOptions());
  }

  /* ============================================================
     公开 API（供 AppEntry 调用）
     ============================================================ */

  /** 转换为 AppEntry（注册到 AppRegistry） */
  toAppEntry(): AppEntry {
    return {
      mount: (ctx: AppMountContext) => this.mount(ctx),
      unmount: () => this.unmount(),
    };
  }

  /** 挂载游戏 */
  async mount(ctx: AppMountContext): Promise<void> {
    this.ctx = ctx;
    this.container = ctx.container;

    /* 解析主题 token：皮肤变量在 srcdoc body 末尾注入，入口脚本先于其执行；
       readyState==='loading' 时先拿到 fallback 深色快照；文档解析完成
       （DOMContentLoaded，皮肤 <style> 已注入生效）后重新解析并同步，
       保证浅色皮肤下 HUD 文字与棋盘底色正确。 */
    this.theme = this.resolveThemeTokens();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.theme = this.resolveThemeTokens();
        this.applyThemeToCanvas();
        this.applyThemeToRoot();
      }, { once: true });
    }

    /* 创建根布局 */
    const root = document.createElement('div');
    root.className = 'game-host-root';
    root.dataset.gameId = this.config.gameId;
    root.dataset.status = 'idle';

    /* EDITORIAL-LAYOUT Phase 4（PRD §4.1 G2 编辑台构图）：
       由「HUD 顶条 + 居中画布」改为「**左信息带 + 右主舞台**」——
       `.game-host-body` 为水平两栏容器，HUD 成为左侧恒宽信息带，
       画布所在 `.game-host-canvas-wrap` 为右侧 flex:1 主舞台（画布仍等比居中于舞台内，
       永不越出舞台去挤信息带）。窄窗（<720px）整组折行：信息带收为舞台上方横排。 */
    const body = document.createElement('div');
    body.className = 'game-host-body';

    /* 左信息带（原 HUD：kicker / 标题 / 分数 / 难度 / 暂停 / 重开） */
    if (this.config.showHUD !== false) {
      this.hud = this.createHUD(ctx);
      body.appendChild(this.hud);
    }

    /* 右主舞台：画布容器 */
    const canvasWrap = document.createElement('div');
    canvasWrap.className = 'game-host-canvas-wrap';
    canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');

    const canvas = document.createElement('canvas');
    canvas.className = 'game-host-canvas';
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'application');
    canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    const w = this.config.width ?? 0;
    const h = this.config.height ?? 0;
    if (w > 0) canvas.style.width = `${w}px`;
    if (h > 0) canvas.style.height = `${h}px`;
    canvasWrap.appendChild(canvas);
    body.appendChild(canvasWrap);
    root.appendChild(body);
    this.root = root;
    this.canvas = canvas;

    /* v5.0 修复：暂停状态下点击画布容器恢复游戏（原方案 overlay 有 pointer-events:none，
     * 点击穿透到 canvas 但 canvas 无 resume 处理，导致"点击继续"无反应） */
    canvasWrap.addEventListener('click', () => {
      if (this.paused && this.status === 'paused') {
        this.resume();
      }
    });

    this.container.replaceChildren(root);
    this.applyThemeToRoot();
    canvas.focus();

    /* 监听主题变化 */
    this.themeUnsub = ctx.onThemeChange(() => {
      this.theme = this.resolveThemeTokens();
      this.applyThemeToCanvas();
      this.applyThemeToRoot();
    });

    /* Step 4.1：订阅宿主语言变更 → 刷新 HUD 文案（词表由沙箱 __SANDBOX_I18N__ 提供） */
    const subscribeI18n = ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_I18N__ as
      | ((cb: () => void) => () => void)
      | undefined) ?? (() => () => undefined);
    this.i18nUnsub = subscribeI18n(() => {
      this.refreshHudI18n();
    });

    /* v4.1：监听画布容器尺寸变化，自动重新计算 canvas 分辨率，
     * 确保窗口 resize 时文字不模糊（Canvas 2D 游戏适用，Phaser 游戏由其 ScaleManager 处理） */
    this.resizeObserver = new ResizeObserver(() => {
      if (this.canvas === null || this.logicalW <= 0 || this.logicalH <= 0) return;
      /* v5.1：尺寸变化用 rAF 合并（体验视图进入动画/布局抖动期间容器连续变化，
       * 同步重置 canvas 会每帧清空重绘造成可见闪烁；合并到下一帧只处理一次） */
      if (this.resizeRaf !== null) return;
      this.resizeRaf = window.requestAnimationFrame(() => {
        this.resizeRaf = null;
        const c = this.canvas;
        if (c === null || this.logicalW <= 0 || this.logicalH <= 0) return;
        const ctx = this.applyCanvasSize(c, this.logicalW, this.logicalH);
        if (ctx !== null) {
          try { this.onCanvasResize(); } catch (err) {
            console.error(`[GameHost:${this.config.gameId}] onCanvasResize failed:`, err);
          }
        }
      });
    });
    this.resizeObserver.observe(canvasWrap);

    /* v4.2（5.8.15）：标签页隐藏 / 窗口失焦时自动暂停游戏，恢复时自动继续。
     * 仅在用户未手动暂停时自动恢复，避免与用户意图冲突。 */
    this.setupAutoPause();

    /* v5.0: 从启动选项中解析初始难度 */
    const opts = this.resolveOptions();
    this.currentDifficulty = opts.difficulty ?? 'normal';

    /* 子类初始化游戏场景 */
    try {
      await this.onMount(ctx, canvas, opts);
      this.setStatus('playing');
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onMount failed:`, err);
      this.setStatus('gameover', this.tr(this.ctx, 'game.common.initFailed', 'Game init failed', { msg: err instanceof Error ? err.message : String(err) }));
    }
  }

  /** 卸载游戏 */
  unmount(): void {
    if (this.resizeRaf !== null) {
      window.cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeObserver !== null) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.autoPauseUnsub !== null) {
      try { this.autoPauseUnsub(); } catch { /* ignore */ }
      this.autoPauseUnsub = null;
    }
    if (this.themeUnsub !== null) {
      try { this.themeUnsub(); } catch { /* ignore */ }
      this.themeUnsub = null;
    }
    if (this.i18nUnsub !== null) {
      try { this.i18nUnsub(); } catch { /* ignore */ }
      this.i18nUnsub = null;
    }
    try {
      this.onUnmount();
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onUnmount failed:`, err);
    }
    this.statusListeners.clear();
    this.scoreListeners.clear();
    this.canvas = null;
    this.hud = null;
    this.root = null;
    this.container = null;
    this.ctx = null;
    this.status = 'idle';
  }

  /**
   * v4.2（5.8.15）：设置自动暂停监听
   *
   * 监听 document.visibilitychange（标签页隐藏/显示）和 window blur/focus 事件。
   * 当标签页隐藏或窗口失焦时自动暂停游戏；恢复时如果用户未手动暂停则自动继续。
   */
  private setupAutoPause(): void {
    const handleVisibilityChange = (): void => {
      if (document.hidden) {
        /* 标签页隐藏：暂停游戏 */
        if (!this.paused) {
          this.wasPausedBeforeAutoPause = false;
          this.pause();
        } else {
          this.wasPausedBeforeAutoPause = true;
        }
      } else {
        /* 标签页恢复：如果用户未手动暂停，则自动继续 */
        if (!this.wasPausedBeforeAutoPause && this.paused) {
          this.resume();
        }
      }
    };

    const handleWindowBlur = (): void => {
      if (!this.paused && this.status === 'playing') {
        this.wasPausedBeforeAutoPause = false;
        this.pause();
      } else {
        this.wasPausedBeforeAutoPause = true;
      }
    };

    const handleWindowFocus = (): void => {
      if (!this.wasPausedBeforeAutoPause && this.paused && this.status === 'playing') {
        this.resume();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    this.autoPauseUnsub = (): void => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }

  /* ============================================================
     状态管理（子类调用）
     ============================================================ */

  /** 更新当前分数（同时更新最高分） */
  protected updateScore(score: number, level?: number): void {
    this.score = score;
    if (score > this.bestScore) {
      this.bestScore = score;
      this.saveBestScore(score);
    }
    const event: GameScoreEvent = { score, bestScore: this.bestScore, level };
    for (const listener of this.scoreListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDScore();
  }

  /** 更新游戏状态 */
  protected setStatus(status: GameStatus, message?: string): void {
    this.status = status;
    if (this.root !== null) {
      this.root.dataset.status = status;
    }
    const event: GameStatusEvent = { status, message };
    for (const listener of this.statusListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDStatus();
  }

  /** 订阅状态变更 */
  onStatusChange(listener: (e: GameStatusEvent) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  /** 订阅分数变更 */
  onScoreChange(listener: (e: GameScoreEvent) => void): () => void {
    this.scoreListeners.add(listener);
    return () => this.scoreListeners.delete(listener);
  }

  /** 暂停游戏 */
  pause(): void {
    if (this.paused || this.status !== 'playing') return;
    this.paused = true;
    this.setStatus('paused');
    try { this.onPause(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onPause failed:`, err); }
  }

  /** 恢复游戏 */
  resume(): void {
    if (!this.paused) return;
    this.paused = false;
    this.setStatus('playing');
    try { this.onResume(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onResume failed:`, err); }
  }

  /** 切换暂停/恢复 */
  togglePause(): void {
    if (this.paused) this.resume();
    else this.pause();
  }

  /** 重新开始 */
  restart(): void {
    try { this.onRestart(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onRestart failed:`, err); }
  }

  /** v5.0: 切换难度（运行时通过 HUD 下拉触发） */
  changeDifficulty(difficulty: GameDifficulty): void {
    this.currentDifficulty = difficulty;
    try { this.onDifficultyChange(difficulty); } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onDifficultyChange failed:`, err);
    }
  }

  /* ============================================================
     访问器
     ============================================================ */

  protected get currentStatus(): GameStatus { return this.status; }
  protected get currentScore(): number { return this.score; }
  protected get currentBestScore(): number { return this.bestScore; }
  protected get isPaused(): boolean { return this.paused; }
  protected get themeTokens(): GameThemeTokens { return this.theme; }
  protected get canvasElement(): HTMLCanvasElement | null { return this.canvas; }
  /** v5.0: 获取当前难度（供子类 AI 逻辑使用） */
  protected get difficulty(): GameDifficulty { return this.currentDifficulty; }

  /* ============================================================
     DOM 覆盖层（供子类在异步加载前显示状态，不污染 canvas 上下文）
     ============================================================ */

  /**
   * 设置 HiDPI Canvas（Retina/高分屏锐利渲染 + 自适应缩放）。
   *
   * v4.1（2026-07-28）修复文字模糊发虚问题：
   *   - 原方案 canvas CSS 尺寸固定为 logicalW × logicalH，配合 CSS max-width:100%
   *     导致容器小于画布时浏览器缩放位图，文字发虚。
   *   - 新方案测量父容器可用空间，计算等比缩放系数（不放大），将 canvas
   *     内部分辨率设为 displayW*dpr × displayH*dpr，context 缩放 (scale*dpr)，
   *     子类绘制仍用逻辑坐标，位图 1:1 对齐显示像素，文字始终锐利。
   *
   * @returns 2D context（已 scale），或 null 表示浏览器不支持
   */
  protected setupHiDPICanvas(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    this.logicalW = logicalW;
    this.logicalH = logicalH;
    return this.applyCanvasSize(canvas, logicalW, logicalH);
  }

  /**
   * 子类可选实现：画布尺寸变化时回调（由 ResizeObserver 触发）。
   *
   * 默认空实现。子类如需在窗口 resize 时重排布局可覆写。
   * 注意：此方法在每帧 draw 之前调用，无需手动触发重绘。
   */
  protected onCanvasResize(): void {
    /* default no-op */
  }

  /**
   * 将鼠标事件的 CSS 坐标转换为画布逻辑坐标。
   *
   * v5.0 修复：原方案各游戏自行用 canvas.width/rect.width（=dpr）做缩放，
   * 导致 HiDPI（Retina dpr=2）下点击位置偏移 2 倍，棋子无法选中或落子错位。
   * 此方法统一用 logicalW/rect.width（=1/scale）做转换，确保点击精确。
   *
   * @param canvas 画布元素
   * @param clientX 鼠标 clientX
   * @param clientY 鼠标 clientY
   * @returns 逻辑坐标 {x, y}（与 setupHiDPICanvas 传入的 logicalW/H 同坐标系）
   */
  protected clientToLogical(
    canvas: HTMLCanvasElement,
    clientX: number,
    clientY: number,
  ): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
    const scaleX = this.logicalW / rect.width;
    const scaleY = this.logicalH / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  /** 计算缩放系数并应用 canvas 尺寸（内部方法） */
  private applyCanvasSize(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    /* 测量父容器可用空间（扣除 padding） */
    const parent = canvas.parentElement;
    let availW = logicalW;
    let availH = logicalH;
    if (parent !== null) {
      const cs = getComputedStyle(parent);
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      const rect = parent.getBoundingClientRect();
      availW = Math.max(rect.width - padX, 50);
      availH = Math.max(rect.height - padY, 50);
    }

    /* 等比缩放（不放大超过 1x，避免模糊） */
    const scale = Math.min(availW / logicalW, availH / logicalH, 1);
    const displayW = Math.max(Math.round(logicalW * scale), 1);
    const displayH = Math.max(Math.round(logicalH * scale), 1);

    /* 设置 canvas 内部分辨率 = 显示尺寸 × dpr（尺寸未变时跳过赋值，
     * 避免 canvas.width 清空画布导致已绘制内容闪一帧） */
    const pw = Math.round(displayW * dpr);
    const ph = Math.round(displayH * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${displayW}px`;
    canvas.style.height = `${displayH}px`;
    /* 移除 CSS max-width/max-height（避免浏览器二次缩放导致文字模糊） */
    canvas.style.maxWidth = 'none';
    canvas.style.maxHeight = 'none';

    const ctx = canvas.getContext('2d');
    if (ctx !== null) {
      /* context 缩放 = 显示缩放 × dpr，子类用逻辑坐标绘制 */
      ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
    }
    return ctx;
  }

  /**
   * 显示 loading 覆盖层（DOM 方式，不使用 canvas.getContext）。
   *
   * 关键设计：Phaser 等引擎需要 WebGL 上下文，如果在 canvas 上调用
   * getContext('2d')，会导致后续无法创建 WebGL 上下文（同一 canvas
   * 只能有一种类型的 context）。因此 loading/error 状态必须用 DOM 覆盖层实现。
   *
   * @returns overlay 元素，子类可在加载完成后调用 removeLoadingOverlay 移除
   */
  protected showLoadingOverlay(canvas: HTMLCanvasElement, message: string): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-loading-overlay';
    overlay.setAttribute('role', 'status');
    overlay.setAttribute('aria-live', 'polite');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'pointer-events:none',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    }

    /* CSS spinner */
    const spinner = document.createElement('div');
    spinner.className = 'game-host-spinner';
    spinner.style.cssText = [
      'width:32px',
      'height:32px',
      'border-radius:50%',
      `border:3px solid ${this.theme.border}`,
      `border-top-color:${this.theme.accent}`,
      'animation:game-host-spin 0.8s linear infinite',
    ].join(';');
    overlay.appendChild(spinner);

    const text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = `color:${this.theme.fg};font-size:14px;`;
    overlay.appendChild(text);

    /* 注入 keyframes（仅一次；用 querySelector 而非 getElementById，避免转包
     * 校验的 DOM_ID_MISSING 警告（沙箱不加载 index.html，id 声明仅作契约） */
    if (document.querySelector('style#game-host-spinner-style') === null) {
      const style = document.createElement('style');
      style.id = 'game-host-spinner-style';
      style.textContent = '@keyframes game-host-spin{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /** 移除 loading 覆盖层 */
  protected removeLoadingOverlay(overlay: HTMLDivElement): void {
    if (overlay.parentNode !== null) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /** 已废弃：使用 showLoadingOverlay 替代（canvas.getContext('2d') 会阻止 Phaser 创建 WebGL 上下文） */
  protected drawLoadingState(_canvas: HTMLCanvasElement, _message: string): void {
    /* no-op: 请改用 showLoadingOverlay */
  }

  /** 已废弃：使用 showErrorOverlay 替代 */
  protected drawErrorState(_canvas: HTMLCanvasElement, _message: string, _err: unknown): void {
    /* no-op: 请改用 showErrorOverlay */
  }

  /**
   * 显示错误覆盖层（DOM 方式）。
   * @returns overlay 元素
   */
  protected showErrorOverlay(canvas: HTMLCanvasElement, message: string, err: unknown): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-error-overlay';
    overlay.setAttribute('role', 'alert');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:12px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;';
    }

    /* 警示三角形 */
    const icon = document.createElement('div');
    icon.style.cssText = [
      'width:48px',
      'height:48px',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'font-size:28px',
      'color:#ef4444',
    ].join(';');
    icon.textContent = '!';
    overlay.appendChild(icon);

    const msg = document.createElement('span');
    msg.textContent = message;
    msg.style.cssText = `color:${this.theme.fg};font-size:14px;font-weight:600;`;
    overlay.appendChild(msg);

    const detail = err instanceof Error ? err.message : String(err);
    const detailEl = document.createElement('span');
    const maxLen = 80;
    detailEl.textContent = detail.length > maxLen ? detail.slice(0, maxLen) + '...' : detail;
    detailEl.style.cssText = `color:${this.theme.muted};font-size:12px;text-align:center;max-width:80%;word-break:break-word;`;
    overlay.appendChild(detailEl);

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /* ============================================================
     内部实现
     ============================================================ */

  /** 解析启动选项（从 AppMountContext.data 透传，由 WindowManager.launch(options.data) 注入） */
  private resolveOptions(): GameLaunchOptions {
    const data = this.ctx?.data;
    if (data === undefined || data === null) {
      return { difficulty: 'normal', soundEnabled: true, debug: false };
    }
    const difficultyRaw = data['difficulty'];
    const validDifficulties: readonly string[] = ['easy', 'normal', 'hard', 'expert', 'master'];
    const difficulty: GameDifficulty = typeof difficultyRaw === 'string' && validDifficulties.includes(difficultyRaw)
      ? (difficultyRaw as GameDifficulty)
      : 'normal';
    const soundEnabled = typeof data['soundEnabled'] === 'boolean' ? data['soundEnabled'] : true;
    const debug = typeof data['debug'] === 'boolean' ? data['debug'] : false;
    const levelRaw = data['level'];
    const level = typeof levelRaw === 'number' && Number.isInteger(levelRaw) && levelRaw > 0 ? levelRaw : undefined;
    const gameModeRaw = data['gameMode'];
    const gameMode = typeof gameModeRaw === 'string' && gameModeRaw !== '' ? gameModeRaw : undefined;
    return { difficulty, soundEnabled, debug, level, gameMode };
  }

  /** 解析主题 token */
  private resolveThemeTokens(): GameThemeTokens {
    if (typeof window === 'undefined' || window === null) return DEFAULT_THEME_TOKENS;
    const style = window.getComputedStyle(document.documentElement);
    /** 读取单个 CSS 变量，空字符串视为未定义 */
    const get = (name: string): string => style.getPropertyValue(name).trim();
    /** 依次尝试多个变量名，全部未定义时使用 fallback */
    const pick = (names: readonly string[], fallback: string): string => {
      for (const name of names) {
        const v = get(name);
        if (v !== '') return v;
      }
      return fallback;
    };
    /* 宿主真实 token 优先（--fg-primary/--bg-canvas 宿主未定义，回退 --glass-text-* / --surface-*）；
       全部缺失时兜底深色（黑底白字仍可读） */
    const bg = pick(['--bg-canvas', '--surface-solid-primary', '--glass-bg-L1', '--bg-primary'], '#0e0f12');
    /* 背景亮度检测用实色（渐变无法取亮度）；浅色主题下文字/面板自动切深色系 */
    const dark = GameHost.isLuminanceDark(pick(['--surface-solid-primary', '--bg-primary'], '#0e0f12'));
    return {
      bg,
      fg: pick(['--fg-primary', '--glass-text-primary', '--text-primary'], dark ? '#e8e8e8' : '#1a1a1a'),
      accent: pick(['--accent-cool'], '#4a9eff'),
      muted: pick(['--fg-muted', '--glass-text-secondary', '--text-secondary'], dark ? '#888888' : '#5f6670'),
      border: pick(['--border-subtle', '--glass-divider', '--glass-border-L3'], '#333333'),
    } as GameThemeTokens;
  }

  /** 亮度判断（--bg-primary 为实色可解析；渐变等非 hex 一律视为深色） */
  private static isLuminanceDark(color: string): boolean {
    const m = /^#([0-9a-f]{6})$/i.exec(color);
    if (m === null) return true;
    const hex = m[1]!;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  }

  /** 同步主题 token 到根元素 CSS 变量（styles.css 的 var() 消费；浅色皮肤下文字/面板切深色系） */
  private applyThemeToRoot(): void {
    if (this.root === null) return;
    const t = this.theme;
    const s = this.root.style;
    s.setProperty('--fg-primary', t.fg);
    s.setProperty('--fg-muted', t.muted);
    s.setProperty('--bg-active', t.dark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)');
    s.setProperty('--bg-hover', t.dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)');
    s.setProperty('--bg-elevated', t.dark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)');
  }

  /** 应用主题到画布：canvas 内容由游戏引擎自绘（Phaser backgroundColor / 棋盘底色），
   *  CSS 背景不透明色会在引擎首帧前露出白/黑块（坊市体验层泛白根因之一），故置透明 */
  private applyThemeToCanvas(): void {
    if (this.canvas === null) return;
    this.canvas.style.background = 'transparent';
  }

  /** 创建 HUD */
  private createHUD(ctx: AppMountContext): HTMLElement {
    const hud = document.createElement('div');
    hud.className = 'game-host-hud';

    /* 身份块 = 宿主页头语言：mono kicker + 衬线大标题（--type-title 三件套）。
     * EDITORIAL Phase 4 收口：信息带从「HUD 顶条残余」升级为「大标题 + 小标题分区」编辑台。 */
    const left = document.createElement('div');
    left.className = 'game-host-hud-left';

    /* G2 F 头：mono kicker（游戏 id 大写；@2 F 语言 kicker/衬线标题双件套） */
    const kicker = document.createElement('span');
    kicker.className = 'game-host-hud-kicker';
    kicker.setAttribute('aria-hidden', 'true');
    kicker.textContent = String(ctx.manifest.id ?? 'GAME').toUpperCase();
    left.appendChild(kicker);

    const title = document.createElement('span');
    title.className = 'game-host-hud-title';
    title.textContent = this.resolveGameName(ctx);
    left.appendChild(title);

    hud.appendChild(left);

    /* 战况分区：小标题 + 渐细横线 + 计分行（分数 / 最高分各占一行——
       2026-09-15 用户反馈：左信息带宽度有限，同行合并文案窄屏时截断显示不全） */
    const scoreSec = this.createHudSection(ctx, 'game.hud.sectionScore', 'SCORE');
    const score = document.createElement('div');
    score.className = 'game-host-hud-score';
    score.dataset.role = 'score';
    score.appendChild(this.createScoreLine(ctx, 'game.hud.score', 'Score', 'score-value', String(0)));
    score.appendChild(this.createScoreLine(ctx, 'game.hud.best', 'Best', 'best-value', String(this.bestScore)));
    scoreSec.appendChild(score);
    hud.appendChild(scoreSec);

    /* 操作分区：难度 / 暂停 / 重开（按钮基座 .btn 变体不变） */
    const ctrlSec = this.createHudSection(ctx, 'game.hud.sectionControls', 'CONTROLS');
    const right = document.createElement('div');
    right.className = 'game-host-hud-right';

    /* v5.0: 难度选择器（下拉菜单，支持 5 档难度） */
    const diffWrap = document.createElement('div');
    diffWrap.className = 'game-host-hud-difficulty-wrap';
    const diffSelect = document.createElement('select');
    /* P4.7：按钮基座化（铁律 9）——消费 .btn 基座变体（次按钮 + 小尺寸），
     * 保留 game-host-hud-btn 类名用于模板内定位/复刻样式桥接 */
    diffSelect.className = 'game-host-hud-btn btn btn--secondary btn--sm game-host-hud-difficulty-select';
    diffSelect.dataset.role = 'difficulty';
    diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
    const diffOptions: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
      { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
      { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
      { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
      { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
      { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
    ];
    for (const opt of diffOptions) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = this.tr(ctx, opt.labelKey, opt.fallback);
      diffSelect.appendChild(o);
    }
    diffSelect.value = this.currentDifficulty;
    diffSelect.addEventListener('change', () => {
      const val = diffSelect.value as GameDifficulty;
      this.changeDifficulty(val);
    });
    diffWrap.appendChild(diffSelect);
    right.appendChild(diffWrap);

    if (this.config.pauseable !== false) {
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
      pauseBtn.dataset.role = 'pause';
      pauseBtn.textContent = this.tr(ctx, 'game.hud.pause', 'Pause');
      pauseBtn.addEventListener('click', () => this.togglePause());
      right.appendChild(pauseBtn);
    }

    const restartBtn = document.createElement('button');
    restartBtn.type = 'button';
    restartBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
    restartBtn.dataset.role = 'restart';
    restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    restartBtn.addEventListener('click', () => this.restart());
    right.appendChild(restartBtn);

    ctrlSec.appendChild(right);
    hud.appendChild(ctrlSec);
    return hud;
  }

  /** 小标题分区（宿主 .zby-sec-title 同配方）：i18n 中文 + 固定 EN mono 小注（装饰，aria-hidden）
   *  + 渐细皮肤色横线（::after，见 css-hud 末段）。dataset 双载 key 与英文兜底供 i18n 刷新。 */
  private createHudSection(ctx: AppMountContext, titleKey: string, enTag: string): HTMLElement {
    const sec = document.createElement('section');
    sec.className = 'game-host-sec';
    const head = document.createElement('div');
    head.className = 'game-host-sec-head';
    head.dataset.titleKey = titleKey;
    head.dataset.titleFallback = enTag;
    const name = document.createElement('span');
    name.textContent = this.tr(ctx, titleKey, enTag);
    head.appendChild(name);
    const sub = document.createElement('span');
    sub.className = 'game-host-sec-sub';
    sub.setAttribute('aria-hidden', 'true');
    sub.textContent = enTag;
    head.appendChild(sub);
    sec.appendChild(head);
    return sec;
  }

  /** 更新 HUD 分数显示（分数 / 最高分两行分别更新） */
  private updateHUDScore(): void {
    if (this.hud === null) return;
    const scoreEl = this.hud.querySelector<HTMLElement>('[data-role="score-value"]');
    if (scoreEl !== null) scoreEl.textContent = String(this.score);
    const bestEl = this.hud.querySelector<HTMLElement>('[data-role="best-value"]');
    if (bestEl !== null) bestEl.textContent = String(this.bestScore);
  }

  /** 计分行：标签（mono 小字）+ 数值（tabular-nums）；行内 nowrap、行间堆叠 */
  private createScoreLine(ctx: AppMountContext | null, labelKey: string, labelFallback: string, valueRole: string, initialValue: string): HTMLElement {
    const line = document.createElement('span');
    line.className = 'game-host-hud-score-line';
    const label = document.createElement('span');
    label.className = 'game-host-hud-score-label';
    label.textContent = this.tr(ctx, labelKey, labelFallback);
    const value = document.createElement('span');
    value.className = 'game-host-hud-score-value';
    value.dataset.role = valueRole;
    value.textContent = initialValue;
    line.appendChild(label);
    line.appendChild(value);
    return line;
  }

  /** i18n 刷新（Step 4.1）：宿主语言切换后重设 HUD 文案（data-role 查询 + 子类 hook） */
  protected refreshHudI18n(): void {
    if (this.hud === null) return;
    const ctx = this.ctx;
    if (ctx === null) return;
    const diffSelect = this.hud.querySelector<HTMLSelectElement>('[data-role="difficulty"]');
    if (diffSelect !== null) {
      diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
      const labels: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
        { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
        { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
        { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
        { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
        { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
      ];
      const options = diffSelect.querySelectorAll('option');
      options.forEach((o) => {
        const label = labels.find((l) => l.value === o.value);
        if (label !== undefined) o.textContent = this.tr(ctx, label.labelKey, label.fallback);
      });
    }
    /* 暂停遮罩文案（CSS ::after content 消费 dataset.pausedText） */
    const canvasWrap = this.root !== null ? this.root.querySelector<HTMLElement>('.game-host-canvas-wrap') : null;
    if (canvasWrap !== null) {
      canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');
    }
    if (this.canvas !== null) this.canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    /* HUD 标题（游戏名）+ 重新开始按钮（2026-08-27 P4.1f 运行时验证补齐） */
    const titleEl = this.hud.querySelector<HTMLElement>('.game-host-hud-title');
    if (titleEl !== null) titleEl.textContent = this.resolveGameName(ctx);
    const restartBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="restart"]');
    if (restartBtn !== null) restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    /* 分区小标题（EDITORIAL Phase 4 收口）：dataset.titleKey 记录 key，刷新时重查词表 */
    const secHeads = this.hud.querySelectorAll<HTMLElement>('.game-host-sec-head');
    secHeads.forEach((head) => {
      const key = head.dataset.titleKey;
      if (key === undefined || key === '') return;
      const name = head.firstElementChild;
      if (name !== null) name.textContent = this.tr(ctx, key, head.dataset.titleFallback ?? key);
    });
    this.updateHUDStatus();
    this.updateHUDScore();
    if (this.onI18nRefresh !== undefined) {
      try { this.onI18nRefresh(); } catch { /* ignore */ }
    }
  }

  /** i18n 刷新子类 hook（如 tank 的 Phaser 场景 overlays 重建） */
  protected onI18nRefresh?: () => void;

  /** 更新 HUD 状态显示 */
  private updateHUDStatus(): void {
    if (this.hud === null) return;
    const pauseBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="pause"]');
    if (pauseBtn !== null) {
      pauseBtn.textContent = this.paused
        ? this.tr(this.ctx, 'game.hud.resume', 'Resume')
        : this.tr(this.ctx, 'game.hud.pause', 'Pause');
    }
  }

  /** 格式化分数显示 */
  /** 解析游戏名称（从 manifest.nameFallback） */
  private resolveGameName(ctx: AppMountContext): string {
    const nameKey = ctx.manifest.nameKey;
    if (nameKey !== undefined && nameKey !== '') {
      const tr = this.tr(ctx, nameKey, ctx.manifest.nameFallback);
      if (tr !== nameKey) return tr;
    }
    return ctx.manifest.nameFallback;
  }

  /** i18n 翻译（带兜底） */
  private tr(ctx: AppMountContext | null, key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string {
    if (ctx === null) return fallback;
    try {
      const result = ctx.t(key, params);
      if (result !== key) return result;
    } catch {
      /* ignore */
    }
    return params === undefined ? fallback : fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
      const value = params[name];
      return value !== undefined ? String(value) : '';
    });
  }

  /* ============================================================
     最高分持久化（P4.3：sandboxStorage 代理，键 game:best:game-chess）
     ============================================================ */

  private async loadBestScore(): Promise<number> {
    const storage = getSandboxStorage();
    if (storage === null) return 0;
    try {
      const raw = await storage.get(BEST_SCORE_KEY_PREFIX + this.config.gameId);
      if (raw === null || raw === undefined) return 0;
      const n = Number.parseInt(String(raw), 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch {
      return 0;
    }
  }

  private saveBestScore(score: number): void {
    const storage = getSandboxStorage();
    if (storage === null) return;
    void storage.set(BEST_SCORE_KEY_PREFIX + this.config.gameId, String(score)).catch(() => {
      /* ignore quota */
    });
  }
}


  /* =========================================================
     5. ChessHost 内联（原 src/shared/apps/games/builtin/chess/ChessHost.ts）
     ========================================================= */

/**
 * ChessHost — 中国象棋游戏实现
 *
 * Phase 5.8.2 交付物：5 款内置小游戏之一。
 *
 * 引擎：Canvas 2D（主引擎，零依赖）
 * 类型：board（双人对弈，支持 AI 对手）
 * 操作：鼠标点击选子、再点击目标位置走子；P 暂停
 * 规则：红方先手，玩家执红，AI 执黑；将死/困毙对方者胜
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.4
 */






/* ============================================================
   常量
   ============================================================ */

/** 列数（9 列，col 0..8） */
const COLS = 9;
/** 行数（10 行，row 0..9；row 0 = 黑方底线，row 9 = 红方底线） */
const ROWS = 10;
/** 交叉点间距（CSS 像素） */
const CELL = 56;
/** 左右内边距 */
const PAD_X = 46;
/** 上下内边距 */
const PAD_Y = 48;
/** 棋盘区域宽度：2*PAD_X + (COLS-1)*CELL = 92 + 448 = 540 */
const BOARD_W = 2 * PAD_X + (COLS - 1) * CELL;
/** 棋盘区域高度：2*PAD_Y + (ROWS-1)*CELL = 96 + 504 = 600 */
const BOARD_H = 2 * PAD_Y + (ROWS - 1) * CELL;
/** 左侧吃子面板宽度（显示红方被吃的棋子） */
const LEFT_PANEL_W = 84;
/** 右侧走棋历史面板宽度（含黑方被吃棋子区域） */
const RIGHT_PANEL_W = 184;
/** 画布总宽度：左面板 + 棋盘 + 右面板 = 84 + 540 + 184 = 808 */
const W = LEFT_PANEL_W + BOARD_W + RIGHT_PANEL_W;
/** 画布总高度（与棋盘等高） */
const H = BOARD_H;
/** 棋盘在画布中的 X 偏移（= 左面板宽度） */
const BOARD_OFFSET_X = LEFT_PANEL_W;

/** 楚河汉界位于 row 4 与 row 5 之间 */

type Side = 'red' | 'black';
/** 棋子类型：K 将/帅、A 士/仕、B 象/相、N 马、R 车、C 炮、P 兵/卒 */
type PieceKind = 'K' | 'A' | 'B' | 'N' | 'R' | 'C' | 'P';

interface Piece {
  readonly kind: PieceKind;
  readonly side: Side;
}

type Cell = Piece | null;
/** 棋盘：board[row][col]，10 行 × 9 列 */
type Board = Cell[][];

interface Move {
  readonly fromR: number;
  readonly fromC: number;
  readonly toR: number;
  readonly toC: number;
}

/** 正交方向（上下左右） */
const ORTHO_DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1]] as const;
/** 斜向方向 */
const DIAG_DIRS = [[-1, -1], [-1, 1], [1, -1], [1, 1]] as const;
/** 马的 8 个走法：[dr, dc, 蹩马腿 dr, 蹩马腿 dc] */
const KNIGHT_MOVES = [
  [-2, -1, -1, 0], [-2, 1, -1, 0],
  [2, -1, 1, 0], [2, 1, 1, 0],
  [-1, -2, 0, -1], [1, -2, 0, -1],
  [-1, 2, 0, 1], [1, 2, 0, 1],
] as const;

/** 棋子基础价值 */
const PIECE_VALUE: Record<PieceKind, number> = {
  K: 10000,
  R: 900,
  C: 450,
  N: 400,
  B: 200,
  A: 200,
  P: 100,
};

/** 棋子文字（红/黑双方分别使用传统字，缺词表时的英文兜底） */
const PIECE_CHAR: Record<PieceKind, { readonly red: string; readonly black: string }> = {
  K: { red: '帥', black: '將' },
  A: { red: '仕', black: '士' },
  B: { red: '相', black: '象' },
  N: { red: '馬', black: '馬' },
  R: { red: '車', black: '車' },
  C: { red: '炮', black: '砲' },
  P: { red: '兵', black: '卒' },
};

/** 棋子文字 i18n key（5 语词表，PRD Step 4.1） */
const PIECE_KEY: Record<PieceKind, { readonly red: string; readonly black: string }> = {
  K: { red: 'game.chess.piece.kRed', black: 'game.chess.piece.kBlack' },
  A: { red: 'game.chess.piece.aRed', black: 'game.chess.piece.aBlack' },
  B: { red: 'game.chess.piece.bRed', black: 'game.chess.piece.bBlack' },
  N: { red: 'game.chess.piece.nRed', black: 'game.chess.piece.nBlack' },
  R: { red: 'game.chess.piece.rRed', black: 'game.chess.piece.rBlack' },
  C: { red: 'game.chess.piece.cRed', black: 'game.chess.piece.cBlack' },
  P: { red: 'game.chess.piece.pRed', black: 'game.chess.piece.pBlack' },
};

/**
 * 红兵位置加分表（row 0 = 敌方底线 = 深入；row 9 = 己方底线）。
 * 过河（row <= 4）后逐步加分，中路更高。
 */
const RED_PAWN_BONUS: readonly (readonly number[])[] = [
  [0, 0, 0, 0, 0, 0, 0, 0, 0],   /* row 0 */
  [20, 20, 25, 30, 35, 30, 25, 20, 20], /* row 1 */
  [18, 20, 22, 28, 30, 28, 22, 20, 18], /* row 2 */
  [15, 18, 20, 25, 26, 25, 20, 18, 15], /* row 3 */
  [12, 15, 18, 22, 24, 22, 18, 15, 12], /* row 4（刚过河） */
  [4, 0, 8, 0, 10, 0, 8, 0, 4],         /* row 5（未过河） */
  [4, 0, 4, 0, 8, 0, 4, 0, 4],          /* row 6（起始） */
  [0, 0, 0, 0, 0, 0, 0, 0, 0],          /* row 7 */
  [0, 0, 0, 0, 0, 0, 0, 0, 0],          /* row 8 */
  [0, 0, 0, 0, 0, 0, 0, 0, 0],          /* row 9 */
];

/** 黑卒位置加分表（红兵表上下镜像） */
const BLACK_PAWN_BONUS: readonly (readonly number[])[] = Array.from(
  { length: ROWS },
  (_v, r) => RED_PAWN_BONUS[ROWS - 1 - r]!.slice(),
);

/** 搜索常数 */
const INF = 1e9;
const MATE = 100000;

/* ============================================================
   纯函数：棋盘 / 走法生成 / 检测
   ============================================================ */

function inBoard(r: number, c: number): boolean {
  return r >= 0 && r < ROWS && c >= 0 && c < COLS;
}

/** 是否在九宫格内 */
function inPalace(r: number, c: number, side: Side): boolean {
  if (c < 3 || c > 5) return false;
  if (side === 'red') return r >= 7 && r <= 9;
  return r >= 0 && r <= 2;
}

function opp(side: Side): Side {
  return side === 'red' ? 'black' : 'red';
}

/** 安全读取格子（noUncheckedIndexedAccess 友好） */
function pieceAt(board: Board, r: number, c: number): Cell {
  const row = board[r];
  if (row === undefined) return null;
  const v = row[c];
  return v === undefined ? null : v;
}

/** 该位置是否可落子（在棋盘内 && 不是己方棋子） */
function canLand(board: Board, r: number, c: number, side: Side): boolean {
  if (!inBoard(r, c)) return false;
  const t = pieceAt(board, r, c);
  return t === null || t.side !== side;
}

/** 查找指定方将/帅位置 */
function kingSquare(board: Board, side: Side): { r: number; c: number } | null {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const p = pieceAt(board, r, c);
      if (p !== null && p.kind === 'K' && p.side === side) return { r, c };
    }
  }
  return null;
}

/** 两将是否在同列且中间无子（飞将） */
function kingsFacing(board: Board): boolean {
  const rk = kingSquare(board, 'red');
  const bk = kingSquare(board, 'black');
  if (rk === null || bk === null) return false;
  if (rk.c !== bk.c) return false;
  const lo = Math.min(rk.r, bk.r) + 1;
  const hi = Math.max(rk.r, bk.r);
  for (let r = lo; r < hi; r++) {
    if (pieceAt(board, r, rk.c) !== null) return false;
  }
  return true;
}

/** 初始棋盘 */
function initialBoard(): Board {
  const b: Board = Array.from({ length: ROWS }, () => new Array<Cell>(COLS).fill(null));
  const place = (r: number, c: number, kind: PieceKind, side: Side): void => {
    const row = b[r];
    if (row !== undefined) row[c] = { kind, side };
  };
  /* 黑方（上方，row 0..3） */
  const back: readonly PieceKind[] = ['R', 'N', 'B', 'A', 'K', 'A', 'B', 'N', 'R'];
  for (let c = 0; c < COLS; c++) {
    const k = back[c];
    if (k !== undefined) place(0, c, k, 'black');
  }
  place(2, 1, 'C', 'black');
  place(2, 7, 'C', 'black');
  for (const c of [0, 2, 4, 6, 8]) place(3, c, 'P', 'black');
  /* 红方（下方，row 6..9） */
  for (let c = 0; c < COLS; c++) {
    const k = back[c];
    if (k !== undefined) place(9, c, k, 'red');
  }
  place(7, 1, 'C', 'red');
  place(7, 7, 'C', 'red');
  for (const c of [0, 2, 4, 6, 8]) place(6, c, 'P', 'red');
  return b;
}

/** 生成单枚棋子的走法（不含飞将吃帅） */
function genPieceMovesAt(board: Board, r: number, c: number, piece: Piece, out: Move[]): void {
  const side = piece.side;
  switch (piece.kind) {
    case 'K': {
      for (const [dr, dc] of ORTHO_DIRS) {
        const nr = r + dr;
        const nc = c + dc;
        if (!inPalace(nr, nc, side)) continue;
        if (canLand(board, nr, nc, side)) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
      }
      break;
    }
    case 'A': {
      for (const [dr, dc] of DIAG_DIRS) {
        const nr = r + dr;
        const nc = c + dc;
        if (!inPalace(nr, nc, side)) continue;
        if (canLand(board, nr, nc, side)) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
      }
      break;
    }
    case 'B': {
      for (const [dr, dc] of DIAG_DIRS) {
        const nr = r + dr * 2;
        const nc = c + dc * 2;
        const mr = r + dr;
        const mc = c + dc;
        if (!inBoard(nr, nc)) continue;
        /* 象不过河 */
        if (side === 'red' && nr < 5) continue;
        if (side === 'black' && nr > 4) continue;
        /* 塞象眼 */
        if (pieceAt(board, mr, mc) !== null) continue;
        if (canLand(board, nr, nc, side)) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
      }
      break;
    }
    case 'N': {
      for (const [dr, dc, ldr, ldc] of KNIGHT_MOVES) {
        const nr = r + dr;
        const nc = c + dc;
        if (!inBoard(nr, nc)) continue;
        /* 蹩马腿 */
        if (pieceAt(board, r + ldr, c + ldc) !== null) continue;
        if (canLand(board, nr, nc, side)) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
      }
      break;
    }
    case 'R': {
      for (const [dr, dc] of ORTHO_DIRS) {
        let nr = r + dr;
        let nc = c + dc;
        while (inBoard(nr, nc)) {
          const t = pieceAt(board, nr, nc);
          if (t === null) {
            out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
          } else {
            if (t.side !== side) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
            break;
          }
          nr += dr;
          nc += dc;
        }
      }
      break;
    }
    case 'C': {
      for (const [dr, dc] of ORTHO_DIRS) {
        let nr = r + dr;
        let nc = c + dc;
        /* 阶段一：直行到空位（非吃子） */
        while (inBoard(nr, nc) && pieceAt(board, nr, nc) === null) {
          out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
          nr += dr;
          nc += dc;
        }
        /* 阶段二：翻山吃子（必须隔一个炮架） */
        if (!inBoard(nr, nc)) continue;
        nr += dr;
        nc += dc;
        while (inBoard(nr, nc)) {
          const t = pieceAt(board, nr, nc);
          if (t !== null) {
            if (t.side !== side) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
            break;
          }
          nr += dr;
          nc += dc;
        }
      }
      break;
    }
    case 'P': {
      const forward = side === 'red' ? -1 : 1;
      const crossed = side === 'red' ? r <= 4 : r >= 5;
      /* 前进 */
      {
        const nr = r + forward;
        const nc = c;
        if (canLand(board, nr, nc, side)) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
      }
      /* 过河后可左右走 */
      if (crossed) {
        for (const dc of [-1, 1] as const) {
          const nr = r;
          const nc = c + dc;
          if (canLand(board, nr, nc, side)) out.push({ fromR: r, fromC: c, toR: nr, toC: nc });
        }
      }
      break;
    }
    default:
      break;
  }
}

/** 生成一方所有"正常"走法（不含飞将吃帅） */
function genPieceMoves(board: Board, side: Side): Move[] {
  const moves: Move[] = [];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const p = pieceAt(board, r, c);
      if (p === null || p.side !== side) continue;
      genPieceMovesAt(board, r, c, p, moves);
    }
  }
  return moves;
}

/**
 * 生成一方所有伪合法走法（含飞将吃帅），用于搜索。
 * 飞将吃帅作为一着"吃对方将"，使搜索能正确识别飞将非法局面。
 */
function pseudoMoves(board: Board, side: Side): Move[] {
  const moves = genPieceMoves(board, side);
  const myKing = kingSquare(board, side);
  const enemyKing = kingSquare(board, opp(side));
  if (myKing !== null && enemyKing !== null && myKing.c === enemyKing.c) {
    const lo = Math.min(myKing.r, enemyKing.r) + 1;
    const hi = Math.max(myKing.r, enemyKing.r);
    let blocked = false;
    for (let r = lo; r < hi; r++) {
      if (pieceAt(board, r, myKing.c) !== null) { blocked = true; break; }
    }
    if (!blocked) {
      moves.push({ fromR: myKing.r, fromC: myKing.c, toR: enemyKing.r, toC: enemyKing.c });
    }
  }
  return moves;
}

/** side 的将/帅是否被将军（含飞将） */
function isInCheck(board: Board, side: Side): boolean {
  const k = kingSquare(board, side);
  if (k === null) return true; /* 无将 = 已败 */
  /* 飞将 */
  if (kingsFacing(board)) return true;
  /* 敌方正常走法能否吃到将 */
  const enemy = opp(side);
  const enemyMoves = genPieceMoves(board, enemy);
  for (const m of enemyMoves) {
    if (m.toR === k.r && m.toC === k.c) return true;
  }
  return false;
}

/** 合法走法：过滤掉走完后己方仍被将军的走法 */
function legalMoves(board: Board, side: Side): Move[] {
  const out: Move[] = [];
  const ms = genPieceMoves(board, side);
  for (const m of ms) {
    const nb = applyMove(board, m);
    if (!isInCheck(nb, side)) out.push(m);
  }
  return out;
}

/** 应用走法，返回新棋盘（不可变，用于搜索） */
function applyMove(board: Board, move: Move): Board {
  const nb: Board = board.map((row) => row.slice());
  const piece = pieceAt(board, move.fromR, move.fromC);
  if (piece === null) return nb;
  const fr = nb[move.fromR];
  if (fr !== undefined) fr[move.fromC] = null;
  const tr = nb[move.toR];
  if (tr !== undefined) tr[move.toC] = piece;
  return nb;
}

/* ============================================================
   记谱法（中国象棋记谱）
   ============================================================ */

/** 红方列号汉字（从红方右起：col 8 = 一，col 0 = 九） */
/** 记谱翻译器（boot() 注入，供模块级记谱函数使用，PRD Step 4.1） */
let notationT: Translator = (key: string): string => key;

/** 记谱翻译：缺词表时回退传统汉字 */
function tN(key: string, fallback: string): string {
  try {
    const v = notationT(key);
    if (v !== key && v !== '') return v;
  } catch {
    /* ignore */
  }
  return fallback;
}

const RED_NUMS = ['一', '二', '三', '四', '五', '六', '七', '八', '九'] as const;

/** 列号转记谱字符：红方用汉字（从右到左），黑方用阿拉伯数字（从左到右） */
function colChar(c: number, side: Side): string {
  if (side === 'red') return tN('game.chess.num.' + (9 - c), RED_NUMS[8 - c] ?? '?');
  return String(c + 1);
}

/**
 * 将走法转为中国象棋记谱法字符串。
 * 规则：
 *   - 红方列号从己方右侧起用汉字"一二三四五六七八九"
 *   - 黑方列号从己方左侧起用阿拉伯数字"1".."9"
 *   - 动作：平（横移）/ 进（向前）/ 退（向后）
 *   - 直行棋子（车/炮/兵/将）跟步数，斜走棋子（马/象/士）跟目标列号
 *   - 同列同型棋子用"前/后"消歧义
 */
function moveToNotation(board: Board, move: Move): string {
  const piece = pieceAt(board, move.fromR, move.fromC);
  if (piece === null) return '?';
  const side = piece.side;
  const char = tN(PIECE_KEY[piece.kind][side], PIECE_CHAR[piece.kind][side]);

  /* 检查同列同型棋子（用于前/后消歧义） */
  let sameCount = 0;
  let otherR = -1;
  for (let r = 0; r < ROWS; r++) {
    const p = pieceAt(board, r, move.fromC);
    if (p !== null && p.kind === piece.kind && p.side === side) {
      sameCount++;
      if (r !== move.fromR) otherR = r;
    }
  }

  let prefix: string;
  if (sameCount > 1 && piece.kind !== 'K') {
    /* 前/后消歧义：红方"前"= 行号更小（更靠近敌方），黑方"前"= 行号更大 */
    const isFront = side === 'red' ? move.fromR < otherR : move.fromR > otherR;
    prefix = tN(isFront ? 'game.chess.move.front' : 'game.chess.move.back', isFront ? '前' : '后') + char;
  } else {
    prefix = char + colChar(move.fromC, side);
  }

  /* 动作：平 / 进 / 退 */
  if (move.fromR === move.toR) {
    return `${prefix}${tN('game.chess.move.level', '平')}${colChar(move.toC, side)}`;
  }
  const forward = side === 'red' ? move.toR < move.fromR : move.toR > move.fromR;
  const action = tN(forward ? 'game.chess.move.advance' : 'game.chess.move.retreat', forward ? '进' : '退');

  /* 斜走棋子（马/象/士）跟目标列号；直走棋子跟步数 */
  const isDiagonal = piece.kind === 'N' || piece.kind === 'B' || piece.kind === 'A';
  if (isDiagonal) {
    return `${prefix}${action}${colChar(move.toC, side)}`;
  }
  const dist = Math.abs(move.toR - move.fromR);
  const distChar = side === 'red' ? (RED_NUMS[dist - 1] ?? '?') : String(dist);
  return `${prefix}${action}${distChar}`;
}

/* ============================================================
   AI：启发式评分 + minimax + alpha-beta
   ============================================================ */

/** 位置加分 */
function positionBonus(piece: Piece, r: number, c: number): number {
  switch (piece.kind) {
    case 'P': {
      const table = piece.side === 'red' ? RED_PAWN_BONUS : BLACK_PAWN_BONUS;
      return table[r]?.[c] ?? 0;
    }
    case 'N': {
      /* 马居中央更灵活 */
      const d = Math.max(Math.abs(c - 4), Math.abs(r - 4));
      return Math.max(0, 12 - d * 3);
    }
    case 'C': {
      if (c >= 3 && c <= 5) return 10;
      if (c === 1 || c === 7) return 5;
      return 0;
    }
    case 'R': {
      if (c >= 3 && c <= 5) return 6;
      return 0;
    }
    default:
      return 0;
  }
}

/** 局面评估（从黑方视角：正数利于黑/AI） */
function evaluate(board: Board): number {
  let score = 0;
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const p = pieceAt(board, r, c);
      if (p === null) continue;
      const v = PIECE_VALUE[p.kind] + positionBonus(p, r, c);
      score += p.side === 'black' ? v : -v;
    }
  }
  return score;
}

/** minimax + alpha-beta（maximizing = 黑方走，黑方最大化） */
function minimax(
  board: Board,
  depth: number,
  alpha: number,
  beta: number,
  maximizing: boolean,
): number {
  const blackKing = kingSquare(board, 'black');
  const redKing = kingSquare(board, 'red');
  if (blackKing === null) return -MATE;
  if (redKing === null) return MATE;
  if (depth === 0) return evaluate(board);

  const side: Side = maximizing ? 'black' : 'red';
  const moves = pseudoMoves(board, side);
  if (moves.length === 0) {
    /* 无棋可走 = 被将死或困毙，走子方负 */
    return maximizing ? -MATE : MATE;
  }

  if (maximizing) {
    let best = -INF;
    for (const m of moves) {
      const child = applyMove(board, m);
      const v = minimax(child, depth - 1, alpha, beta, false);
      if (v > best) best = v;
      if (best > alpha) alpha = best;
      if (beta <= alpha) break;
    }
    return best;
  }
  let best = INF;
  for (const m of moves) {
    const child = applyMove(board, m);
    const v = minimax(child, depth - 1, alpha, beta, true);
    if (v < best) best = v;
    if (best < beta) beta = best;
    if (beta <= alpha) break;
  }
  return best;
}

/** 选择 AI（黑方）走法 */
function chooseAIMove(board: Board, difficulty: GameDifficulty): Move | null {
  const moves = legalMoves(board, 'black');
  if (moves.length === 0) return null;

  /* v5.0: 5 档难度搜索深度
   * easy=1（随机 top3）/ normal=2 / hard=3 / expert=4 / master=5
   * alpha-beta 剪枝下 5 层搜索通常 < 3s，可接受 */
  const depthMap: Record<GameDifficulty, number> = {
    easy: 1, normal: 2, hard: 3, expert: 4, master: 5,
  };
  const depth = depthMap[difficulty];

  /* easy: 从评分前 3 中随机选一，制造偶然性 */
  if (difficulty === 'easy') {
    const scored = moves.map((m) => {
      const child = applyMove(board, m);
      return { move: m, score: minimax(child, 1, -INF, INF, false) };
    });
    scored.sort((a, b) => b.score - a.score);
    const topN = Math.min(3, scored.length);
    const idx = Math.floor(Math.random() * topN);
    return scored[idx]?.move ?? null;
  }

  let best = -INF;
  let bestMove: Move | null = null;
  const randomChance = difficulty === 'normal' ? 0.15 : 0;
  for (const m of moves) {
    const child = applyMove(board, m);
    const v = minimax(child, depth - 1, -INF, INF, false);
    if (v > best) {
      best = v;
      bestMove = m;
    } else if (v === best && bestMove !== null && Math.random() < randomChance) {
      bestMove = m;
    }
  }
  return bestMove;
}

/* ============================================================
   ChessHost
   ============================================================ */

/** 走棋历史记录条目 */
interface HistoryEntry {
  readonly notation: string;
  readonly side: Side;
}

class ChessHost extends GameHost {
  private ctx2d: CanvasRenderingContext2D | null = null;
  private board: Board = [];
  private turn: Side = 'red';
  private selected: { r: number; c: number } | null = null;
  private legalForSelected: Move[] = [];
  private lastMove: Move | null = null;
  private checkSide: Side | null = null;
  private aiThinking = false;
  private aiTimeout: ReturnType<typeof setTimeout> | null = null;
  private rafId: number | null = null;
  private clickHandler: ((e: MouseEvent) => void) | null = null;
  private keyHandler: ((e: KeyboardEvent) => void) | null = null;
  private redCaptureValue = 0;
  /** 走棋历史（记谱法字符串 + 走子方） */
  private history: HistoryEntry[] = [];
  /** 红方吃掉的棋子（黑方棋子） */
  private capturedByRed: Piece[] = [];
  /** 黑方吃掉的棋子（红方棋子） */
  private capturedByBlack: Piece[] = [];
  /** "将军！"提示消失时间戳（performance.now 基准），0 = 无提示 */
  private checkMessageUntil = 0;

  protected onMount(
    _ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    _options: GameLaunchOptions,
  ): void {
    const ctx2d = this.setupHiDPICanvas(canvas, W, H);
    if (ctx2d === null) return;
    this.ctx2d = ctx2d;
    this.reset();

    this.clickHandler = (e: MouseEvent) => this.onClick(e, canvas);
    canvas.addEventListener('click', this.clickHandler);
    this.keyHandler = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P') this.togglePause();
    };
    window.addEventListener('keydown', this.keyHandler);

    const loop = (): void => {
      this.draw();
      this.rafId = window.requestAnimationFrame(loop);
    };
    this.rafId = window.requestAnimationFrame(loop);
  }

  protected onUnmount(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    if (this.clickHandler !== null) {
      const c = this.canvasElement;
      if (c !== null) c.removeEventListener('click', this.clickHandler);
      this.clickHandler = null;
    }
    if (this.keyHandler !== null) {
      window.removeEventListener('keydown', this.keyHandler);
      this.keyHandler = null;
    }
    this.aiThinking = false;
    this.ctx2d = null;
  }

  protected override onPause(): void {
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.aiThinking = false;
  }

  protected override onResume(): void {
    if (this.turn === 'black' && !this.aiThinking && this.currentStatus === 'playing') {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 200);
    }
  }

  protected override onRestart(): void {
    /* Phase 5.10.2：restart 前清理可能挂起的 AI 定时器 */
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.reset();
  }

  /* ============================================================
     游戏逻辑
     ============================================================ */

  private reset(): void {
    this.board = initialBoard();
    this.turn = 'red';
    this.selected = null;
    this.legalForSelected = [];
    this.lastMove = null;
    this.checkSide = null;
    this.aiThinking = false;
    this.redCaptureValue = 0;
    this.history = [];
    this.capturedByRed = [];
    this.capturedByBlack = [];
    this.checkMessageUntil = 0;
    this.updateScore(0);
    this.setStatus('playing');
  }

  private selectPiece(r: number, c: number): void {
    this.selected = { r, c };
    const all = legalMoves(this.board, 'red');
    this.legalForSelected = all.filter((m) => m.fromR === r && m.fromC === c);
  }

  private clearSelection(): void {
    this.selected = null;
    this.legalForSelected = [];
  }

  private onClick(e: MouseEvent, canvas: HTMLCanvasElement): void {
    if (this.currentStatus !== 'playing') return;
    if (this.turn !== 'red' || this.aiThinking) return;

    /* v5.0 修复：使用 clientToLogical 统一转换坐标，修复 HiDPI 下点击偏移 */
    const { x: cx, y: cy } = this.clientToLogical(canvas, e.clientX, e.clientY);
    /* 棋盘在画布中偏移 LEFT_PANEL_W，需减去偏移量再计算行列 */
    const bx = cx - BOARD_OFFSET_X;
    const c = Math.round((bx - PAD_X) / CELL);
    const r = Math.round((cy - PAD_Y) / CELL);
    if (!inBoard(r, c)) {
      this.clearSelection();
      return;
    }

    const target = pieceAt(this.board, r, c);
    if (this.selected !== null) {
      const move = this.legalForSelected.find((m) => m.toR === r && m.toC === c);
      if (move !== undefined) {
        this.clearSelection();
        this.doMove(move);
        return;
      }
      /* 点选己方其它子：换选 */
      if (target !== null && target.side === 'red') {
        this.selectPiece(r, c);
        return;
      }
      this.clearSelection();
      return;
    }

    if (target !== null && target.side === 'red') {
      this.selectPiece(r, c);
    }
  }

  private doMove(move: Move): void {
    const piece = pieceAt(this.board, move.fromR, move.fromC);
    if (piece === null) return;
    const captured = pieceAt(this.board, move.toR, move.toC);

    /* 生成记谱（在 applyMove 之前，需要原始棋盘判断消歧义） */
    const notation = moveToNotation(this.board, move);
    this.history.push({ notation, side: piece.side });

    /* 记录吃子 */
    if (captured !== null) {
      if (piece.side === 'red') this.capturedByRed.push(captured);
      else this.capturedByBlack.push(captured);
    }

    this.board = applyMove(this.board, move);
    this.lastMove = move;

    if (captured !== null && piece.side === 'red') {
      this.redCaptureValue += PIECE_VALUE[captured.kind];
      this.updateScore(this.redCaptureValue);
    }

    const oppSide = opp(piece.side);
    const oppMoves = legalMoves(this.board, oppSide);
    this.checkSide = isInCheck(this.board, oppSide) ? oppSide : null;
    if (this.checkSide !== null) {
      /* 将军提示持续 2 秒 */
      this.checkMessageUntil = performance.now() + 2000;
    }

    if (oppMoves.length === 0) {
      /* 将死或困毙：走子方胜 */
      if (piece.side === 'red') this.setStatus('victory', this.tr(this.ctx, 'game.chess.result.redWin', 'Red wins!'));
      else this.setStatus('gameover', this.tr(this.ctx, 'game.chess.result.blackWin', 'Black wins'));
      return;
    }

    this.turn = oppSide;
    if (oppSide === 'black') {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 200);
    }
  }

  private aiMove(): void {
    this.aiTimeout = null;
    this.aiThinking = false;
    if (this.currentStatus !== 'playing') return;
    const move = chooseAIMove(this.board, this.difficulty);
    if (move === null) {
      /* AI 无棋可走：红方胜 */
      this.setStatus('victory', this.tr(this.ctx, 'game.chess.result.redWin', 'Red wins!'));
      return;
    }
    this.doMove(move);
  }

  /* ============================================================
     渲染
     ============================================================ */

  /** 判断当前是否为深色主题（用于选择棋盘配色） */
  private isDarkTheme(): boolean {
    return this.themeTokens.dark;
  }

  private draw(): void {
    const ctx = this.ctx2d;
    if (ctx === null) return;
    const theme = this.themeTokens;

    /* 背景 */
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, W, H);

    /* 左侧吃子面板（红方被吃的棋子） */
    this.drawCapturedPanel(ctx, 0, 0, LEFT_PANEL_W, H, 'red');

    /* 右侧面板（走棋历史 + 黑方被吃的棋子） */
    this.drawRightPanel(ctx, LEFT_PANEL_W + BOARD_W, 0, RIGHT_PANEL_W, H);

    /* 棋盘（平移到左侧面板之后，使棋盘内部坐标保持不变） */
    ctx.save();
    ctx.translate(BOARD_OFFSET_X, 0);
    this.drawBoard(ctx);
    ctx.restore();

    /* 将军提示文字（画布顶部，居中于棋盘区域） */
    this.drawCheckMessage(ctx);

    /* 胜负遮罩（仅覆盖棋盘区域） */
    if (this.currentStatus === 'victory' || this.currentStatus === 'gameover') {
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(BOARD_OFFSET_X, 0, BOARD_W, H);
      ctx.fillStyle = theme.fg;
      ctx.font = 'bold 24px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const text = this.tr(this.ctx, this.currentStatus === 'victory' ? 'game.chess.result.redWin' : 'game.chess.result.blackWin', this.currentStatus === 'victory' ? 'Red wins!' : 'Black wins');
      ctx.fillText(text, BOARD_OFFSET_X + BOARD_W / 2, H / 2 - 12);
      ctx.font = '13px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.fillStyle = theme.muted;
      ctx.fillText(this.tr(this.ctx, 'game.chess.restartHint', 'Click "Restart" to play again'), BOARD_OFFSET_X + BOARD_W / 2, H / 2 + 18);
    }
  }

  /** 绘制棋盘（在已平移的上下文中调用，坐标从 PAD_X/PAD_Y 起） */
  private drawBoard(ctx: CanvasRenderingContext2D): void {
    const dark = this.isDarkTheme();
  /* EDITORIAL-LAYOUT Phase 4 豁免：以下为**玩法画布内容色**（棋盘木纹 / 方块配色等），
     属于游戏可识别的玩法身份，不随皮肤变化 —— 按 PRD §9.2 非目标「不动玩法画布内部视觉」保留。
     与之相对，UI 面（页头 / 信息带 / 按钮 / 面板）一律消费 Token。 */
    /* EDITORIAL-LAYOUT 豁免：以下为玩法画布内容色（棋盘木纹），属游戏玩法身份，
       不随皮肤变化（PRD §9.2 非目标）；UI 面一律消费 Token。 */
    const woodStart = dark ? '#7c6f5e' : '#f0d6a0';
    const woodEnd = dark ? '#5e5346' : '#e8c880';
    const woodEdge = dark ? '#3e3528' : '#b08d57';
    const lineCol = dark ? '#3a3328' : '#5c4a35';
    const goldCol = '#c9a961';
    const riverCol = dark ? '#d4c8b0' : '#5c4a35';

    /* 木纹棋盘底（渐变） + 加粗边框 */
    const bx = PAD_X - 18;
    const by = PAD_Y - 18;
    const bw = (COLS - 1) * CELL + 36;
    const bh = (ROWS - 1) * CELL + 36;
    const grad = ctx.createLinearGradient(bx, by, bx + bw, by + bh);
    grad.addColorStop(0, woodStart);
    grad.addColorStop(1, woodEnd);
    ctx.fillStyle = grad;
    ctx.fillRect(bx, by, bw, bh);
    ctx.strokeStyle = woodEdge;
    ctx.lineWidth = 3;
    ctx.strokeRect(bx + 1.5, by + 1.5, bw - 3, bh - 3);

    /* 楚河汉界区域加深背景色 */
    ctx.fillStyle = dark ? 'rgba(0,0,0,0.18)' : 'rgba(120,80,30,0.12)';
    ctx.fillRect(PAD_X, PAD_Y + 4 * CELL, (COLS - 1) * CELL, CELL);

    /* 网格线 */
    ctx.strokeStyle = lineCol;
    ctx.lineWidth = 1;
    for (let c = 0; c < COLS; c++) {
      const x = PAD_X + c * CELL;
      if (c === 0 || c === COLS - 1) {
        ctx.beginPath();
        ctx.moveTo(x, PAD_Y);
        ctx.lineTo(x, PAD_Y + (ROWS - 1) * CELL);
        ctx.stroke();
      } else {
        /* 内部列在楚河汉界处断开 */
        ctx.beginPath();
        ctx.moveTo(x, PAD_Y);
        ctx.lineTo(x, PAD_Y + 4 * CELL);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, PAD_Y + 5 * CELL);
        ctx.lineTo(x, PAD_Y + (ROWS - 1) * CELL);
        ctx.stroke();
      }
    }
    for (let r = 0; r < ROWS; r++) {
      const y = PAD_Y + r * CELL;
      ctx.beginPath();
      ctx.moveTo(PAD_X, y);
      ctx.lineTo(PAD_X + (COLS - 1) * CELL, y);
      ctx.stroke();
    }

    /* 九宫格斜线（金色） */
    ctx.strokeStyle = goldCol;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(PAD_X + 3 * CELL, PAD_Y);
    ctx.lineTo(PAD_X + 5 * CELL, PAD_Y + 2 * CELL);
    ctx.moveTo(PAD_X + 5 * CELL, PAD_Y);
    ctx.lineTo(PAD_X + 3 * CELL, PAD_Y + 2 * CELL);
    ctx.moveTo(PAD_X + 3 * CELL, PAD_Y + 7 * CELL);
    ctx.lineTo(PAD_X + 5 * CELL, PAD_Y + 9 * CELL);
    ctx.moveTo(PAD_X + 5 * CELL, PAD_Y + 7 * CELL);
    ctx.lineTo(PAD_X + 3 * CELL, PAD_Y + 9 * CELL);
    ctx.stroke();

    /* 兵卒 / 炮位置十字标记 */
    ctx.strokeStyle = lineCol;
    ctx.lineWidth = 1;
    const pawnMarks: readonly (readonly [number, number])[] = [
      [3, 0], [3, 2], [3, 4], [3, 6], [3, 8], /* 黑卒 */
      [6, 0], [6, 2], [6, 4], [6, 6], [6, 8], /* 红兵 */
      [2, 1], [2, 7], /* 黑炮 */
      [7, 1], [7, 7], /* 红炮 */
    ];
    for (const [mr, mc] of pawnMarks) {
      this.drawPawnMark(ctx, PAD_X + mc * CELL, PAD_Y + mr * CELL, mc === 0, mc === COLS - 1);
    }

    /* 楚河汉界文字（楷体，加阴影，更醒目） */
    ctx.save();
    ctx.fillStyle = riverCol;
    ctx.font = 'bold 26px "STKaiti","KaiTi","PingFang SC",serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = dark ? 'rgba(0,0,0,0.5)' : 'rgba(255,255,255,0.6)';
    ctx.shadowBlur = 3;
    ctx.shadowOffsetY = 1;
    ctx.globalAlpha = 0.7;
    const riverY = PAD_Y + 4.5 * CELL;
    ctx.fillText(this.tr(this.ctx, 'game.common.river.chu', 'Chu River'), PAD_X + 2 * CELL, riverY);
    ctx.fillText(this.tr(this.ctx, 'game.common.river.han', 'Han Border'), PAD_X + 6 * CELL, riverY);
    ctx.restore();

    /* 上一步落子标记：起点方形边框 + 终点圆形边框（淡黄色） */
    if (this.lastMove !== null) {
      ctx.strokeStyle = 'rgba(255, 235, 130, 0.85)';
      ctx.lineWidth = 2.5;
      /* 起点：方形边框 */
      const fx = PAD_X + this.lastMove.fromC * CELL;
      const fy = PAD_Y + this.lastMove.fromR * CELL;
      const sq = CELL * 0.36;
      ctx.beginPath();
      ctx.rect(fx - sq, fy - sq, sq * 2, sq * 2);
      ctx.stroke();
      /* 终点：圆形边框 */
      const tx = PAD_X + this.lastMove.toC * CELL;
      const ty = PAD_Y + this.lastMove.toR * CELL;
      ctx.beginPath();
      ctx.arc(tx, ty, CELL * 0.42, 0, Math.PI * 2);
      ctx.stroke();
    }

    /* 选中棋子（金色发光描边） + 合法走点 */
    if (this.selected !== null) {
      const sx = PAD_X + this.selected.c * CELL;
      const sy = PAD_Y + this.selected.r * CELL;
      ctx.save();
      ctx.strokeStyle = '#d4a838';
      ctx.shadowColor = 'rgba(212, 168, 56, 0.8)';
      ctx.shadowBlur = 12;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(sx, sy, CELL * 0.46, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      for (const m of this.legalForSelected) {
        const tx = PAD_X + m.toC * CELL;
        const ty = PAD_Y + m.toR * CELL;
        const tgt = pieceAt(this.board, m.toR, m.toC);
        if (tgt === null) {
          /* 可移动位置：绿色半透明圆点 */
          ctx.fillStyle = 'rgba(76, 175, 80, 0.55)';
          ctx.beginPath();
          ctx.arc(tx, ty, 7, 0, Math.PI * 2);
          ctx.fill();
        } else {
          /* 可吃子位置：红色环框 */
          ctx.strokeStyle = '#f44336';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(tx, ty, CELL * 0.46, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
    }

    /* 棋子 */
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const p = pieceAt(this.board, r, c);
        if (p === null) continue;
        this.drawPiece(ctx, r, c, p);
      }
    }

    /* 将军时将/帅闪烁红环 */
    if (this.checkSide !== null) {
      const k = kingSquare(this.board, this.checkSide);
      if (k !== null) {
        const t = performance.now();
        const alpha = 0.4 + 0.4 * Math.sin(t / 120);
        ctx.strokeStyle = '#ff3b30';
        ctx.globalAlpha = alpha;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(PAD_X + k.c * CELL, PAD_Y + k.r * CELL, CELL * 0.5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
  }

  /** 绘制兵卒/炮位置的 L 形十字标记 */
  private drawPawnMark(ctx: CanvasRenderingContext2D, x: number, y: number, atLeftEdge: boolean, atRightEdge: boolean): void {
    const gap = 5;
    const len = 7;
    ctx.beginPath();
    if (!atLeftEdge) {
      /* 左上 */
      ctx.moveTo(x - gap - len, y - gap);
      ctx.lineTo(x - gap, y - gap);
      ctx.lineTo(x - gap, y - gap - len);
      /* 左下 */
      ctx.moveTo(x - gap - len, y + gap);
      ctx.lineTo(x - gap, y + gap);
      ctx.lineTo(x - gap, y + gap + len);
    }
    if (!atRightEdge) {
      /* 右上 */
      ctx.moveTo(x + gap + len, y - gap);
      ctx.lineTo(x + gap, y - gap);
      ctx.lineTo(x + gap, y - gap - len);
      /* 右下 */
      ctx.moveTo(x + gap + len, y + gap);
      ctx.lineTo(x + gap, y + gap);
      ctx.lineTo(x + gap, y + gap + len);
    }
    ctx.stroke();
  }

  /** 绘制左侧吃子面板（显示指定方被吃的棋子） */
  private drawCapturedPanel(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, side: Side): void {
    const theme = this.themeTokens;
    const dark = this.isDarkTheme();

    /* 面板背景 */
    ctx.fillStyle = dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.05)';
    ctx.fillRect(x + 4, y + 8, w - 8, h - 16);

    /* 标题 */
    ctx.fillStyle = theme.muted;
    ctx.font = '11px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const title = this.tr(this.ctx, side === 'red' ? 'game.chess.loss.red' : 'game.chess.loss.black', side === 'red' ? 'Red losses' : 'Black losses');
    ctx.fillText(title, x + w / 2, y + 14);

    /* 被吃的棋子（按价值降序排列） */
    const captured = side === 'red' ? this.capturedByBlack : this.capturedByRed;
    const sorted = captured.slice().sort((a, b) => PIECE_VALUE[b.kind] - PIECE_VALUE[a.kind]);

    const cols = 2;
    const cellSize = (w - 16) / cols;
    const startY = y + 36;
    for (let i = 0; i < sorted.length; i++) {
      const p = sorted[i]!;
      const col = i % cols;
      const row = Math.floor(i / cols);
      const px = x + 8 + col * cellSize + cellSize / 2;
      const py = startY + row * cellSize + cellSize / 2;
      this.drawMiniPiece(ctx, px, py, cellSize * 0.36, p);
    }
  }

  /** 绘制右侧面板（走棋历史 + 黑方被吃的棋子） */
  private drawRightPanel(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number): void {
    const theme = this.themeTokens;
    const dark = this.isDarkTheme();

    /* 面板背景 */
    ctx.fillStyle = dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.05)';
    ctx.fillRect(x + 4, y + 8, w - 8, h - 16);

    /* 上半部分：走棋历史 */
    const histH = Math.floor(h * 0.62);

    /* 标题 */
    ctx.fillStyle = theme.muted;
    ctx.font = '11px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(this.tr(this.ctx, 'game.common.records', 'Move records'), x + w / 2, y + 14);

    /* 历史记录区域（裁剪 + 滚动，最新走法在底部） */
    const histX = x + 10;
    const histY = y + 34;
    const histW = w - 20;
    const histAreaH = histH - 40;

    ctx.save();
    ctx.beginPath();
    ctx.rect(histX, histY, histW, histAreaH);
    ctx.clip();

    ctx.font = '12px -apple-system, BlinkMacSystemFont, "PingFang SC", monospace';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const lineH = 18;
    const totalLines = Math.ceil(this.history.length / 2);
    const maxVisibleLines = Math.floor(histAreaH / lineH);
    /* 起始行号：使最新走法始终在底部可见 */
    const startLine = Math.max(0, totalLines - maxVisibleLines);

    for (let i = startLine; i < totalLines; i++) {
      const redMove = this.history[i * 2];
      const blackMove = this.history[i * 2 + 1];
      const ly = histY + (i - startLine) * lineH;
      /* 行号 */
      ctx.fillStyle = theme.muted;
      ctx.fillText(`${i + 1}.`, histX, ly);
      /* 红方走法 */
      if (redMove !== undefined) {
        ctx.fillStyle = '#e8554a';
        ctx.fillText(redMove.notation, histX + 22, ly);
      }
      /* 黑方走法 */
      if (blackMove !== undefined) {
        ctx.fillStyle = '#c8c8c8';
        ctx.fillText(blackMove.notation, histX + 82, ly);
      }
    }
    ctx.restore();

    /* 下半部分：黑方被吃的棋子 */
    const capY = y + histH;
    ctx.fillStyle = theme.muted;
    ctx.font = '11px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(this.tr(this.ctx, 'game.chess.loss.black', 'Black losses'), x + w / 2, capY + 6);

    const captured = this.capturedByRed;
    const sorted = captured.slice().sort((a, b) => PIECE_VALUE[b.kind] - PIECE_VALUE[a.kind]);
    const cols = 4;
    const cellSize = (w - 16) / cols;
    const capStartY = capY + 28;
    for (let i = 0; i < sorted.length; i++) {
      const p = sorted[i]!;
      const col = i % cols;
      const row = Math.floor(i / cols);
      const px = x + 8 + col * cellSize + cellSize / 2;
      const py = capStartY + row * cellSize + cellSize / 2;
      this.drawMiniPiece(ctx, px, py, cellSize * 0.36, p);
    }
  }

  /** 绘制"将军！"提示文字（顶部居中，2 秒后淡出消失） */
  private drawCheckMessage(ctx: CanvasRenderingContext2D): void {
    if (this.checkMessageUntil === 0) return;
    const now = performance.now();
    if (now >= this.checkMessageUntil) return;
    /* 最后 500ms 淡出 */
    const remaining = this.checkMessageUntil - now;
    const alpha = remaining > 500 ? 1 : remaining / 500;

    const cx = BOARD_OFFSET_X + BOARD_W / 2;
    const cy = 24;

    ctx.save();
    ctx.globalAlpha = alpha;
    /* 红底白字，更醒目 */
    ctx.fillStyle = 'rgba(255, 59, 48, 0.92)';
    ctx.fillRect(cx - 52, cy - 14, 104, 28);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 18px "STKaiti","KaiTi","PingFang SC",serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.tr(this.ctx, 'game.chess.check', 'Check!'), cx, cy);
    ctx.restore();
  }

  /** 绘制小尺寸棋子（用于吃子面板） */
  private drawMiniPiece(ctx: CanvasRenderingContext2D, x: number, y: number, rad: number, piece: Piece): void {
    const isRed = piece.side === 'red';
    /* 底色渐变 */
    const g = ctx.createRadialGradient(x - rad * 0.3, y - rad * 0.3, rad * 0.1, x, y, rad);
    if (isRed) {
      g.addColorStop(0, '#e8554a');
      g.addColorStop(1, '#8b1a1a');
    } else {
      g.addColorStop(0, '#4a4a4a');
      g.addColorStop(1, '#141414');
    }
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fill();
    /* 边框 */
    ctx.strokeStyle = isRed ? '#5e1a1a' : '#000';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.stroke();
    /* 文字（红方金色 / 黑方银色） */
    ctx.fillStyle = isRed ? '#f0c040' : '#d8d8d8';
    ctx.font = `bold ${Math.floor(rad * 1.2)}px "STKaiti","KaiTi","PingFang SC",serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(PIECE_CHAR[piece.kind][piece.side], x, y + 1);
  }

  private drawPiece(ctx: CanvasRenderingContext2D, r: number, c: number, piece: Piece): void {
    const x = PAD_X + c * CELL;
    const y = PAD_Y + r * CELL;
    const rad = CELL * 0.42;
    const isRed = piece.side === 'red';

    /* 投影（圆形底座阴影） */
    ctx.fillStyle = 'rgba(0,0,0,0.32)';
    ctx.beginPath();
    ctx.arc(x + 2, y + 3, rad, 0, Math.PI * 2);
    ctx.fill();

    /* 棋子盘（红方红色渐变 / 黑方深色渐变） */
    const g = ctx.createRadialGradient(x - rad * 0.3, y - rad * 0.3, rad * 0.1, x, y, rad);
    if (isRed) {
      g.addColorStop(0, '#e8554a');
      g.addColorStop(0.7, '#c62828');
      g.addColorStop(1, '#8b1a1a');
    } else {
      g.addColorStop(0, '#4a4a4a');
      g.addColorStop(0.7, '#2a2a2a');
      g.addColorStop(1, '#141414');
    }
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fill();

    /* 外圈描边（红方深红 / 黑方黑色） */
    ctx.strokeStyle = isRed ? '#5e1a1a' : '#000000';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.stroke();

    /* 内圈细线 */
    ctx.strokeStyle = isRed ? 'rgba(255, 200, 120, 0.4)' : 'rgba(200, 200, 200, 0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(x, y, rad * 0.82, 0, Math.PI * 2);
    ctx.stroke();

    /* 文字（红方金色 / 黑方银色，楷体） */
    ctx.fillStyle = isRed ? '#f0c040' : '#d8d8d8';
    ctx.font = `bold ${Math.floor(rad * 1.1)}px "STKaiti","KaiTi","PingFang SC",serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const ch = this.tr(this.ctx, PIECE_KEY[piece.kind][piece.side], PIECE_CHAR[piece.kind][piece.side]);
    ctx.fillText(ch, x, y + 1);
  }
}


  /* =========================================================
     6. 样式（game-host.css 同源，内嵌注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * game-host.css — 小游戏宿主样式
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - 容器铺满窗口 body（.game-host-root）
 *   - HUD 顶部固定（分数 + 控制按钮）
 *   - 画布居中、保持比例、自适应缩放
 *   - 主题色由 CSS 变量驱动（--bg-canvas / --fg-primary / --accent-cool 等）
 *   - 暂停时画布半透明遮罩 + "Paused"提示
 *   - 隐藏滚动条（项目记忆：避免底部水平滚动条）
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */

.game-host-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  /* 玻璃配方（GlassSidePanel 同款）：垫底随主题模式/皮肤，半透明白透出坊市体验层毛玻璃 */
  background: var(--skin-pattern-image, none), color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 95%, var(--surface-solid-primary, #ffffff) 5%);
  backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  color: var(--glass-text-primary, #e8e8e8);
  font-family: var(--skin-font-body, -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif);
  overflow: hidden;
  /* 防止 iOS 弹性滚动影响游戏体验 */
  overscroll-behavior: contain;
  -webkit-user-select: none;
  user-select: none;
}

/* ============================================================
   HUD（顶部条）
   ============================================================ */

.game-host-hud {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
  background: color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 92%, var(--surface-solid-primary, #ffffff) 8%);
  border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  flex-shrink: 0;
}

/* G2 F 头：皮肤色渐细发丝线（HUD 底缘） */
.game-host-hud::after {
  content: '';
  position: absolute;
  left: var(--layout-row-pad-x, 0.875rem);
  right: var(--layout-row-pad-x, 0.875rem);
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
  pointer-events: none;
}

.game-host-hud-left {
  display: flex;
  align-items: baseline;
  gap: 0.875rem;
  min-width: 0;
  overflow: hidden;
}

/* G2 F 头：mono kicker（与宿主 .zby-page-head__kicker 同配方，自包含 fallback） */
.game-host-hud-kicker {
  font-family: var(--type-mono, var(--skin-font-mono, ui-monospace, monospace));
  font-size: 0.5625rem;
  font-weight: 700;
  letter-spacing: 0.32em;
  color: var(--deco-primary, var(--accent, #3cb371));
  white-space: nowrap;
  flex-shrink: 0;
}

.game-host-hud-title {
  /* F 语言：衬线显示字体 + 字距（UI-REMAINING-WAVES Wave G L2；--type-display 经沙箱白名单注入） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 0.875rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--glass-text-primary, #e8e8e8);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

/* 计分区（2026-09-15 改双行）：分数 / 最高分各占一行——左信息带宽度有限，
   同行合并文案窄屏时截断显示不全；行内 nowrap（单值不会溢出），行间堆叠 */
.game-host-hud-score {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.game-host-hud-score-line {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 0.5rem;
  min-width: 0;
}

.game-host-hud-score-label {
  font-family: var(--type-mono, monospace);
  font-size: 0.6875rem;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--glass-text-tertiary, #999);
  flex-shrink: 0;
}

.game-host-hud-score-value {
  font-size: 0.8125rem;
  font-variant-numeric: tabular-nums;
  color: var(--glass-text-secondary, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.game-host-hud-right {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

/* P4.7：按钮基座化（铁律 9）——ui-kit btn 片段内嵌快照（assets/ui-kit/btn.css），
 * 选择器扩列桥接 .game-host-hud-btn（HUD 暂停/重开/难度控件），
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：次按钮 + 小尺寸变体。 */

.btn, .game-host-hud-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .game-host-hud-btn:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .game-host-hud-btn:disabled,
.btn[disabled], .game-host-hud-btn[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 次按钮：卡片玻璃底（HUD 暂停/重开/难度选择） */
.btn--secondary, .game-host-hud-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .game-host-hud-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 尺寸变体：小尺寸（HUD 紧凑布局） */
.btn--sm, .game-host-hud-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .game-host-hud-btn{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}

/* =========================================================
   P4.7b：皮肤按钮形状钩子表（皮肤形状语言内嵌快照）
   ---------------------------------------------------------
   宿主端按钮形状 = tokens.css data-interaction-model 通用规则
   （src/shared/design-tokens/tokens.css）+ 各皮肤 Manifest extraCSS
   （src/domains/themes/skins/*.ts）；iframe 无法继承宿主样式表，
   此处内嵌按钮形状语言子集，由 MultiFileSandbox 同步的
   data-skin / data-interaction-model / data-theme-mode 属性驱动，
   使游戏按钮获得与宿主同款手绘边框/糖果胶囊 3D/像素厚度/粗描边
   错位/油墨细线/浮雕等形状语言。
   约定：
   - 顺序与宿主一致：交互模型通用规则在前，皮肤 extraCSS 在后
     （同特异性后注入者胜，island 默认态即依赖此顺序让位 toy hover）
   - 深色变体选择器用 [data-theme-mode="dark"]（iframe 同步属性，
     非宿主的 data-theme-mode-effective）
   - 皮肤自定义变量（--is-ink/--is-cream/--toy-shadow/--ra-ink/
     --neumo-dark/--neumo-light）不在沙箱注入白名单
     （sandbox-skin-var-names.ts），一律 var(..., fallback)
   - iframe 内按钮必挂 .btn 类（core.tpl 受控），钩子表只写 .btn
   - 修改需同步宿主真相源（tokens.css + skins/*.ts extraCSS）
   ========================================================= */

/* —— 1. 交互模型通用规则子集（tokens.css data-interaction-model 快照） —— */

/* 交互类统一过渡节奏 */
[data-interaction-model] .btn{
  transition:
    background var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    color var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1));
}

/* lightweight：轻反馈 — 按下微缩放 */
[data-interaction-model="lightweight"] .btn:active{
  transform: scale(var(--motion-travel-press, 0.98));
}

/* responsive：标准反馈 — hover 上浮 + 按下微缩放 */
[data-interaction-model="responsive"] .btn:hover{
  transform: translateY(var(--motion-travel-hover, -1px));
}
[data-interaction-model="responsive"] .btn:active{
  transform: translateY(0) scale(var(--motion-travel-press, 0.98));
}

/* terminal：命令行式反馈 — hover 品红下划线、按下反白、focus 品红描边
   （硬编码色 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="terminal"] .btn:hover{
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(255, 46, 136, 0.55);
}
[data-interaction-model="terminal"] .btn:active{
  color: rgba(232, 237, 246, 1);
  background: rgba(255, 46, 136, 1);
  text-decoration: none;
}
[data-interaction-model="terminal"] .btn:focus-visible{
  outline: 1px solid rgba(255, 46, 136, 1);
  outline-offset: 2px;
}

/* print：印刷批注式反馈 — hover 印刷红下划线、按下墨底反白、focus 红细描边（深色反白）。
   硬编码色一律 rgba 等价书写（皮肤契约 forbidHardcodedColors 不认裸 hex） */
[data-interaction-model="print"] .btn:hover{
  color: rgba(192, 57, 43, 1);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(192, 57, 43, 0.55);
}
[data-interaction-model="print"] .btn:active{
  color: rgba(240, 231, 211, 1);
  background: rgba(26, 26, 24, 1);
  text-decoration: none;
}
[data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(192, 57, 43, 0.5);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:hover{
  color: rgba(226, 112, 90, 1);
  text-decoration-color: rgba(226, 112, 90, 0.6);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:active{
  color: rgba(32, 31, 27, 1);
  background: rgba(240, 231, 211, 1);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(226, 112, 90, 0.6);
}

/* snap：瞬时反馈 — hover 黑白互换、按下黑底黄字、focus 2px 黑描边（深色对称反转；
   硬编码色一律 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="snap"] .btn:hover{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 255, 255, 1);
  transition-duration: 0ms;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:hover{
  background: rgba(255, 255, 255, 1);
  color: rgba(17, 17, 17, 1);
}
[data-interaction-model="snap"] .btn:active{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 195, 0, 1);
  transition-duration: 0ms;
}
[data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(17, 17, 17, 1);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(255, 255, 255, 1);
  outline-offset: 2px;
}

/* doodle：手绘反馈 — hover 蜡笔红波浪下划线 + 微旋转、按下反向回弹、focus 蜡笔虚线 */
[data-interaction-model="doodle"] .btn:hover{
  transform: rotate(-0.5deg);
  text-decoration: underline;
  text-underline-offset: 4px;
  text-decoration-style: wavy;
  text-decoration-color: rgba(232, 96, 76, 0.75);
  text-decoration-thickness: 1.5px;
}
[data-theme-mode="dark"][data-interaction-model="doodle"] .btn:hover{
  text-decoration-color: rgba(91, 168, 201, 0.8);
}
[data-interaction-model="doodle"] .btn:active{
  transform: rotate(0.5deg) scale(0.97);
  text-decoration: none;
}
[data-interaction-model="doodle"] .btn:focus-visible{
  outline: 2px dashed rgba(232, 96, 76, 0.8);
  outline-offset: 2px;
}

/* hygge：柔和暖色反馈 — hover 暖色高亮、按下轻微缩放、focus 暖色细描边 */
[data-interaction-model="hygge"] .btn:hover{
  background: color-mix(in srgb, var(--accent-warm, #C08552) 10%, transparent);
}
[data-interaction-model="hygge"] .btn:active{
  transform: scale(0.99);
}
[data-interaction-model="hygge"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-warm, #C08552) 65%, transparent);
  outline-offset: 2px;
}

/* neumorphic：同色浮雕反馈 — hover 外凸、按下内凹、focus 柔和高亮 */
[data-interaction-model="neumorphic"] .btn:hover{
  box-shadow:
    4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:active{
  box-shadow:
    inset 4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    inset -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-cool, #7A8BA6) 50%, transparent);
  outline-offset: 2px;
}

/* toy：玩具 3D 按压 — hover 抬升（底沿加深）、按下塌陷（下沉 + 底沿归零） */
[data-interaction-model="toy"] .btn:hover:not(:disabled){
  transform: translateY(-2px);
  box-shadow: 0 5px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:active:not(:disabled){
  transform: translateY(2px) scale(0.96);
  box-shadow: 0 1px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:focus-visible{
  outline: 2px solid color-mix(in srgb, var(--deco-primary, #14B8A6) 65%, transparent);
  outline-offset: 2px;
}

/* —— 2. 皮肤形状规则子集（各皮肤 Manifest extraCSS 快照，最后注入覆盖交互模型） —— */

/* doodle：手绘边框 — 不规则圆角 + 微旋转 + 蜡笔 2px 边框（hover 换蜡笔红/深色湖水蓝） */
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect){
  border-radius: 15px 8px 17px 7px / 8px 16px 7px 18px; /* 皮肤形状快照：手绘不规则圆角，无 token 语义，同 skins.css 豁免决策 */
  transform: rotate(-0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect):nth-child(even of .btn){
  transform: rotate(0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary{
  border: 2px solid rgba(43, 43, 43, 0.62);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary{
  border-color: rgba(242, 237, 227, 0.55);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(232, 96, 76, 0.85);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(91, 168, 201, 0.85);
}

/* island：糖果胶囊 + 3D 底沿（默认态让位 toy hover/active；次按钮奶油卡纸） */
[data-skin="xy-skin-official-island"] .btn:not(:hover):not(:active){
  border: 1px solid var(--is-ink, rgba(92, 74, 50, 0.55));
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}
[data-skin="xy-skin-official-island"] .btn:not(.btn--rect){
  border-radius: 999px;
}
[data-skin="xy-skin-official-island"] .btn--secondary:not(:hover):not(:active){
  background: var(--is-cream, rgba(255, 253, 245, 0.92));
  border-color: var(--is-ink, rgba(92, 74, 50, 0.55));
  color: var(--text-primary, #5C4A32);
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}

/* pixel：块状厚度 — 无描线 + 底部 3px 厚度（NES 街机按键），按压塌陷
   （皮肤自定义变量不在沙箱白名单，改引注入变量 --bg-elevated/--text-primary） */
[data-skin="xy-skin-official-pixel"] .btn{
  border: none;
  border-radius: 0;
  background: var(--bg-elevated, #FFFDF6);
  box-shadow: 0 3px 0 var(--text-primary, #1A1C2C);
  transition: none;
}
[data-skin="xy-skin-official-pixel"] .btn:active{
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--text-primary, #1A1C2C);
}

/* popart：漫画粗描边 + CMYK 三色错位叠印投影（丝网印刷注册错位，波普签名） */
[data-skin="xy-skin-official-popart"] .btn{
  border: 3px solid var(--text-primary, #1A1A1A);
  box-shadow:
    2.5px 2.5px 0 rgba(230, 57, 70, 0.5),
    -2px 2.5px 0 rgba(0, 119, 182, 0.45),
    4px 4px 0 rgba(26, 26, 26, 0.28);
}

/* red-age：油墨细线（印刷品边线） */
[data-skin="xy-skin-official-red-age"] .btn{
  border: 1px solid var(--ra-ink, rgba(31, 26, 18, 0.75));
}

/* neumorphism：无描边浮雕（外凸双阴影） */
[data-skin="xy-skin-official-neumorphism"] .btn{
  border: none;
  box-shadow:
    3px 3px 6px var(--neumo-dark, rgba(163, 177, 198, 0.55)),
    -3px -3px 6px var(--neumo-light, rgba(255, 255, 255, 0.9));
}

/* cyber-city：glitch 重影 — hover RGB 通道错位（静态 text-shadow，零动画开销） */
[data-skin="xy-skin-official-cyber-city"] .btn:hover{
  text-shadow:
    1px 0 rgba(0, 229, 255, 0.75),
    -1px 0 rgba(255, 46, 136, 0.75);
}

/* 动效偏好降级：形状钩子表的位移/旋转一律禁用（保留形状与描边） */
[data-reduce-motion="true"] .btn:hover,
[data-reduce-motion="true"] .btn:active{
  transform: none;
}

/* v5.0: 难度选择器 */
.game-host-hud-difficulty-wrap {
  display: flex;
  align-items: center;
}

.game-host-hud-difficulty-select {
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23888' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  padding-right: 1.375rem !important;
  cursor: pointer;
}

.game-host-hud-difficulty-select option {
  background: var(--bg-elevated, #1a1a1a);
  color: var(--glass-text-primary, #e8e8e8);
}


/* ============================================================
   Phase 4（EDITORIAL-LAYOUT PRD §4.1 G2）：左信息带 + 右主舞台
   ------------------------------------------------------------
   放在 css-hud.tpl 末尾是有意的：注入顺序为 HUD → CANVAS → OVERLAY →
   RESPONSIVE，同特异性下后出现者胜，故本段安全覆写上面的顶条配方。
   ============================================================ */

.game-host-body {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  flex-direction: row;
  align-items: stretch;
}

/* HUD 由「顶条」改为「左侧信息带」：竖向堆叠 */
.game-host-hud {
  flex: 0 0 208px;
  width: 208px;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-4, 1rem) var(--space-3, 0.875rem);
  border-bottom: none;
  border-right: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  overflow-y: auto;
  overscroll-behavior: contain;
}
/* 发丝线由「底缘」转为「右缘」（信息带与舞台的分界） */
.game-host-hud::after {
  left: auto;
  right: 0;
  top: var(--space-4, 1rem);
  bottom: var(--space-4, 1rem);
  width: 1px;
  height: auto;
  background: linear-gradient(
    to bottom,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}

/* 信息带内三段纵排：身份（kicker + 标题） / 分数 / 控制 */
.game-host-hud-left {
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1, 0.25rem);
  overflow: visible;
}
.game-host-hud-right {
  flex-direction: column;
  align-items: stretch;
  width: 100%;
  gap: var(--space-2, 0.5rem);
}
.game-host-hud-right > * { width: 100%; }
.game-host-hud-difficulty-wrap { width: 100%; }
.game-host-hud-difficulty-select { width: 100%; }

.game-host-hud-kicker {
  font-size: 0.5625rem;
  letter-spacing: 0.24em;
}
.game-host-hud-title {
  font-size: 1.0625rem;
  letter-spacing: 0.1em;
  line-height: 1.2;
}
.game-host-hud-score {
  margin-top: var(--space-2, 0.5rem);
  gap: 0.25rem;
}
.game-host-hud-score-value {
  font-size: 0.75rem;
}

/* 右主舞台：画布在其中等比居中，永不挤占信息带 */
.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-width: 0;
}

/* ============================================================
   Phase 4 收口（EDITORIAL §16 定版）：信息带升级「统一大标题 + 小标题分区」
   ------------------------------------------------------------
   与宿主 .zby-page-head / .zby-sec-title 同配方（自包含 fallback，
   Token 经沙箱白名单注入 computed 值）。注入序在 css-responsive 之前，
   <720 折行态的覆写见 css-responsive.tpl 末段。
   ============================================================ */

/* 信息带纵向节奏单源：分区 margin-top 走 --layout-section-gap（与宿主分区间隔同源）。
 * box-sizing 收敛为 border-box：flex-basis 208px 从此含内距（恒宽名副其实），
 * 窄窗折行态不再因 content-box 的 28px 水平内距溢出视口。 */
.game-host-hud {
  gap: 0;
  box-sizing: border-box;
}

/* 身份块 = 页头语言：mono kicker + 衬线大标题 + 标题下发丝线 */
.game-host-hud-left {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1, 0.25rem);
  width: 100%;
  min-width: 0;
  padding-bottom: var(--space-3, 0.875rem);
  position: relative;
}
/* 大标题下发丝线（宿主 .zby-page-head::after 同配方：--deco-primary 55% → 12% → 透明） */
.game-host-hud-left::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}
/* 大标题三件套：字号/字距/字族全部走布局维度 Token（与宿主内页大标题同构）。
 * 白名单注入的是宿主 root computed 值，方案切换（刊物/经典/紧凑）随广播生效。 */
.game-host-hud-title {
  font-family: var(--type-title-font, var(--font-serif-cn, var(--type-display, inherit)));
  font-size: var(--type-title, var(--layout-display, 2rem));
  font-weight: 700;
  letter-spacing: var(--tracking-title, 0.04em);
  line-height: 1.16;
  color: var(--glass-text-primary, #e8e8e8);
  /* 窄带允许自然换行（杂志标题语言），不再省略号截断 */
  white-space: normal;
  overflow: visible;
  text-overflow: clip;
  min-width: 0;
}

/* 分区容器：分区间距 = --layout-section-gap（宿主分区节奏同源，非自造间隔） */
.game-host-sec {
  display: flex;
  flex-direction: column;
  gap: var(--space-2, 0.5rem);
  margin-top: var(--layout-section-gap, var(--space-5, 1.5rem));
  min-width: 0;
}

/* 分区小标题（宿主 .zby-sec-title 同配方）：中文 12px/0.2em + EN mono 小注 + 渐细横线 */
.game-host-sec-head {
  display: flex;
  align-items: baseline;
  gap: var(--space-2, 8px);
  font-size: var(--type-scale-1, 0.75rem);
  font-weight: 650;
  letter-spacing: 0.2em;
  color: var(--glass-text-secondary, #666);
  white-space: nowrap;
}
.game-host-sec-head::after {
  content: '';
  flex: 1;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}
.game-host-sec-sub {
  font-family: var(--type-mono, ui-monospace, 'JetBrains Mono', monospace);
  font-size: calc(var(--type-scale-1, 0.75rem) * 0.71);
  font-weight: 600;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--glass-text-tertiary, #707070);
  opacity: 0.85;
}

/* 计分行归入战况分区：分区间距由 .game-host-sec 承担，行内不再带顶距 */
.game-host-hud-score {
  margin-top: 0;
  font-size: 0.8125rem;
}
/* ============================================================
   画布容器
   ============================================================ */

.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  position: relative;
  overflow: hidden;
}

.game-host-canvas {
  display: block;
  max-width: 100%;
  max-height: 100%;
  /* canvas 由游戏引擎自绘背景（棋盘/Phaser backgroundColor），CSS 背景置透明防泛白 */
  background: transparent;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.06));
  border-radius: 0.5rem;
  box-shadow: var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
  outline: none;
  cursor: default;
  touch-action: none;
}

.game-host-canvas:focus-visible {
  border-color: var(--accent-cool, #4a9eff);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent-cool, #4a9eff) 25%, transparent), var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
}

/* ============================================================
   暂停遮罩（由 GameHost 在 paused 状态下注入）
   ============================================================ */

.game-host-root[data-status="paused"] .game-host-canvas-wrap::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.55));
  backdrop-filter: blur(4px);
  pointer-events: none;
}

.game-host-root[data-status="paused"] .game-host-canvas-wrap::before {
  content: attr(data-paused-text);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 遮罩底为皮肤感知玻璃（--glass-overlay-bg：浅色皮肤浅底 / 深色皮肤深底），
     文字跟随皮肤明暗取 --glass-text-primary，任意皮肤 × 明暗下恒可读 */
  color: var(--glass-text-primary, #f1f5f9);
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 1.125rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.6));
  padding: 0.625rem 1.25rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.1));
  z-index: 1;
  pointer-events: none;
}

/* ============================================================
   游戏结束 / 胜利覆盖层
   ============================================================ */

.game-host-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4, 0.875rem);
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.7));
  backdrop-filter: blur(6px);
  z-index: 5;
  pointer-events: auto;
}

.game-host-overlay-title {
  /* F 语言：衬线显示字体 + 页面显示档字号 + 编辑头同款字距（Wave G L2） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: calc(var(--layout-display, 2.125rem) * 0.7);
  font-weight: 700;
  color: var(--glass-text-primary, #e8e8e8);
  letter-spacing: 0.14em;
}

.game-host-overlay-title--win {
  color: var(--accent-warm, #ffb04a);
}

.game-host-overlay-title--lose {
  color: var(--danger, #ff6b8a);
}

.game-host-overlay-msg {
  font-size: 0.875rem;
  color: var(--glass-text-secondary, #888);
  text-align: center;
  max-width: 80%;
}

.game-host-overlay-actions {
  display: flex;
  gap: 0.625rem;
}

/* P4.7：.game-host-overlay-btn 系列已删除（无 JS 创建者，历史死样式）；
 * 覆盖层操作统一走 HUD 重新开始按钮（game-host-hud-btn，已基座化）。 */

/* ============================================================
   响应式（窄窗口时缩小 HUD）
   ============================================================ */

@media (max-width: 480px) {
  .game-host-hud {
    padding: 0.375rem 0.625rem;
    gap: 0.5rem;
  }
  .game-host-hud-title {
    font-size: 1.0625rem;
  }
  .game-host-hud-score {
    font-size: 0.75rem;
  }
  .game-host-hud-btn {
    font-size: 0.6875rem;
    padding: 0.3125rem 0.5rem;
  }
  .game-host-canvas-wrap {
    padding: 0.375rem;
  }
}



/* Phase 4：窄窗（<720px）整组折行 —— 信息带收为舞台上方横排，
   画布仍占主区居中。信息带靠「折」保持可见，不靠挤。 */
@media (max-width: 720px) {
  .game-host-body {
    flex-direction: column;
  }
  .game-host-hud {
    flex: 0 0 auto;
    width: 100%;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-2, 0.5rem);
    padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
    border-right: none;
    border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
    overflow: visible;
  }
  .game-host-hud::after { display: none; }
  .game-host-hud-left {
    flex-direction: row;
    align-items: baseline;
    gap: var(--space-2, 0.5rem);
  }
  .game-host-hud-right {
    flex-direction: row;
    align-items: center;
    width: auto;
    gap: var(--space-2, 0.5rem);
  }
  .game-host-hud-right > * { width: auto; }
  .game-host-hud-difficulty-wrap { width: auto; }
  .game-host-hud-difficulty-select { width: auto; }
  .game-host-hud-score { margin-top: 0; font-size: 0.6875rem; }
  /* 分区折行态收为横排：小标题隐藏、内容内联（身份 | 战况 | 操作 三段一行）；
     身份块的下发丝线与底部内距同步移除（横条内无线）。 */
  .game-host-sec {
    flex-direction: row;
    align-items: center;
    margin-top: 0;
    gap: var(--space-2, 0.5rem);
    min-width: 0;
  }
  .game-host-sec-head { display: none; }
  /* 宽窗块的 width:100% / padding 在折行态复位（否则左段撑满整行、右段溢出视口） */
  .game-host-hud-left { padding-bottom: 0; width: auto; flex: 0 1 auto; min-width: 0; }
  .game-host-hud-left::after { display: none; }
  .game-host-hud { flex-wrap: wrap; }
  /* 折行态标题降档（横条内不撑高）：衬线 20px，保留层级 */
  .game-host-hud-title { font-size: 1.25rem; line-height: 1.1; }
}
/* ============================================================
   无障碍：减少动效
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  .game-host-hud-btn {
    transition: none;
  }
}
/* 动态创建元素类名锚点（CSS_CLASS_MISSING 校验 + 结构契约）
   EDITORIAL-LAYOUT Phase 4：.game-host-body 是 GameHost 模板在运行时创建的
   「左信息带 + 右主舞台」两栏容器，真实规则在模板 css-hud.tpl 内（构建期注入），
   此处仅放空规则供打包校验识别，勿删。 */
.game-host-body {}
.game-host-loading-overlay {}
.game-host-spinner {}
.game-host-error-overlay {}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'chess-game-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  let host: ChessHost | null = null;

  /** 挂载游戏：创建 Host 并启动（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    injectAppStyle(ctx.container);
    host = new ChessHost({
      gameId: 'game-chess',
      width: 808,
      height: 600,
    });
    void host.mount(ctx).catch((e: unknown) => {
      console.error('[chess] mount failed:', e);
    });
  }

  /** 卸载游戏：清理监听 / 定时器 / DOM */
  function unmount(): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: { nameKey: 'game.chessName', nameFallback: 'Chinese Chess' },
      t: createTranslator(),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    notationT = ctx.t;
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__chessApp = {
    unmount,
  };
})();
