/**
 * gomoku — 五子棋（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：src/shared/apps/games/（GameHost 基类 + builtin/gomoku/GomokuHost）。
 * 转包改造点（对齐 PRD §4.2 / hex-color 模板）：
 *   1. 模块内联：沙箱 classic script 无模块系统，GameTypes + GameHost + GomokuHost
 *      三段源平铺进本文件（原 import 全部为 type-only 或本地模块，编译后零残留）
 *   2. i18n：宿主 5 语包 → 内嵌 game.* 最小词表（HUD/难度/名称），零语言包依赖
 *   3. 皮肤：game-host.css → APP_CSS 内嵌注入（变量已带 fallback，沙箱可独立渲染）
 *   4. 入口签名：toAppEntry() → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. manifest 透传：boot 构造 { nameKey, nameFallback }（GameHost.resolveGameName 依赖）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅、manifest={nameKey,nameFallback}）并调用；样式同源内容
 *   以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. i18n：沙箱词表（宿主注入 window.__SANDBOX_I18N__，PRD Step 4.1）
     ========================================================= */

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 沙箱 i18n 快照（宿主 MultiFileSandbox 注入，与 SandboxI18nSnapshot 一致） */
  interface SandboxI18nState {
    readonly lang: string;
    readonly dict: Readonly<Record<string, string>>;
    readonly dictEn: Readonly<Record<string, string>>;
  }

  /** 读取沙箱 i18n 快照（宿主未注入时 undefined，t 回退 key 本身） */
  function getSandboxI18n(): SandboxI18nState | undefined {
    return (window as unknown as Record<string, unknown>).__SANDBOX_I18N__ as SandboxI18nState | undefined;
  }

  /** 翻译器：当前语言词表 → 英文兜底表 → key 本身（缺 key 走英文，不出现中文硬编码） */
  function createTranslator(): Translator {
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const i18n = getSandboxI18n();
      let template = key;
      if (i18n !== undefined) {
        template = i18n.dict[key] ?? i18n.dictEn[key] ?? key;
      }
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. GameTypes 内联（原 src/shared/apps/games/GameTypes.ts）
     ========================================================= */

/**
 * GameTypes — 小游戏共享类型定义
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - GameRenderEngine：游戏渲染引擎标识（canvas2d 主引擎 / phaser 辅引擎）
 *   - GameManifestDescriptor：游戏描述元数据（用于 AI 创造 prompt 隔离）
 *   - GameLaunchOptions：游戏启动参数（难度/音效/初始状态等）
 *
 * 引擎选型依据（详见 prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.2）：
 *   - Canvas 2D：零依赖、AI 友好度最高、适合棋类/俄罗斯方块等逻辑型游戏
 *   - Phaser 4：原生 TS 支持、适合动作类（坦克大战/打砖块）等需要物理引擎/精灵动画的游戏
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24
 */


/** 游戏渲染引擎 */
type GameRenderEngine = 'canvas2d' | 'phaser';

/** 游戏难度（v5.0: 扩展为 5 档） */
type GameDifficulty = 'easy' | 'normal' | 'hard' | 'expert' | 'master';

/** 游戏启动选项（由 AppMountContext.data 透传） */
interface GameLaunchOptions {
  /** 初始难度（默认 'normal'） */
  readonly difficulty?: GameDifficulty | undefined;
  /** 是否启用音效（默认 true） */
  readonly soundEnabled?: boolean | undefined;
  /** 是否启用调试模式（默认 false，开启后显示 FPS/碰撞框等） */
  readonly debug?: boolean | undefined;
  /** 初始关卡/级别（部分游戏支持，从 1 开始） */
  readonly level?: number | undefined;
  /** 游戏模式（部分游戏支持，如军棋 'open' 明棋 / 'dark' 暗棋） */
  readonly gameMode?: string | undefined;
}

/** 游戏状态（用于 UI 显示/Dock 角标） */
type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover' | 'victory';

/** 游戏分数变更事件 */
interface GameScoreEvent {
  /** 当前分数 */
  readonly score: number;
  /** 历史最高分 */
  readonly bestScore: number;
  /** 关卡/级别 */
  readonly level?: number | undefined;
}

/** 游戏状态变更事件 */
interface GameStatusEvent {
  readonly status: GameStatus;
  readonly message?: string | undefined;
}

/** 游戏元数据（用于 AI 创造 prompt 隔离，与 AppManifest 解耦） */
interface GameManifestDescriptor {
  /** 游戏唯一标识（与 AppManifest.id 一致） */
  readonly id: string;
  /** 游戏名称（与 AppManifest.nameFallback 一致） */
  readonly name: string;
  /** 渲染引擎 */
  readonly engine: GameRenderEngine;
  /** 游戏类型分类（用于 AI 创造 prompt） */
  readonly genre: 'puzzle' | 'board' | 'action' | 'arcade' | 'strategy';
  /** 玩家数 */
  readonly players: 1 | 2;
  /** 是否支持 AI 对手 */
  readonly supportsAI?: boolean | undefined;
  /** 默认难度 */
  readonly defaultDifficulty?: GameDifficulty | undefined;
  /** 简短描述（用于 AI prompt 上下文） */
  readonly summary: string;
}


  /* =========================================================
     3. 沙箱存储访问器（PRD ZBY-PORTABLE-APP-CONTRACT-ROADMAP P4.3：
        最高分经宿主 sandboxStorage 代理持久化，键 game:best:game-<id>
        已逐键声明于 manifest.dataKeys；离线预览无宿主时降级 null，
        行为同旧空实现）
     ========================================================= */

/** 沙箱 KV 存储三方法（ZbyAPI.sandboxStorage 无 appId 签名，宿主侧补全命名空间） */
interface SandboxStorageLike {
  readonly get: (key: string) => Promise<unknown>;
  readonly set: (key: string, value: unknown) => Promise<unknown>;
  readonly remove: (key: string) => Promise<unknown>;
}

/** 取宿主注入的沙箱存储代理；无宿主（离线预览模板）返回 null */
function getSandboxStorage(): SandboxStorageLike | null {
  const api = (window as unknown as Record<string, unknown>).ZbyAPI as
    | Record<string, unknown>
    | undefined;
  const storage =
    api === undefined || api === null
      ? undefined
      : (api['sandboxStorage'] as Record<string, unknown> | undefined);
  if (storage === null || storage === undefined) return null;
  if (typeof storage['get'] !== 'function' || typeof storage['set'] !== 'function') return null;
  return storage as unknown as SandboxStorageLike;
}

  /* =========================================================
     4. GameHost 基类内联（原 src/shared/apps/games/GameHost.ts）
     ========================================================= */

/**
 * GameHost — 小游戏宿主基类
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 职责：
 *   - 提供统一的 mount/unmount 生命周期
 *   - 创建游戏画布容器 + HUD（分数/暂停/重新开始按钮）
 *   - 解析 GameLaunchOptions（从 AppMountContext.data 透传）
 *   - 派发 GameStatusEvent / GameScoreEvent 事件
 *   - 持久化最高分（宿主 sandboxStorage 代理，按 gameId 隔离）
 *   - 适配深浅主题（CSS 变量驱动）
 *
 * 子类需实现：
 *   - onMount(ctx, canvas, options)：初始化游戏场景
 *   - onUnmount()：清理资源/定时器/事件
 *   - onPause()/onResume()：可选，处理暂停恢复
 *   - onRestart()：可选，处理重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */






/** GameHost 配置（子类构造时传入） */
interface GameHostConfig {
  /** 游戏 ID（与 AppManifest.id 一致，用于最高分持久化 key） */
  readonly gameId: string;
  /** 是否显示 HUD（默认 true） */
  readonly showHUD?: boolean;
  /** 是否支持暂停（默认 true） */
  readonly pauseable?: boolean;
  /** 画布宽度（CSS 像素，0 表示自适应容器宽度） */
  readonly width?: number;
  /** 画布高度（CSS 像素，0 表示自适应容器高度） */
  readonly height?: number;
}

/** 主题色 token（与 CSS 变量一一对应） */
interface GameThemeTokens {
  readonly bg: string;
  readonly fg: string;
  readonly accent: string;
  readonly muted: string;
  readonly border: string;
  readonly dark: boolean;
}

/** 默认主题 token（从 CSS 变量读取，失败时兜底） */
const DEFAULT_THEME_TOKENS: GameThemeTokens = {
  bg: '#1a1a1a',
  fg: '#e8e8e8',
  accent: '#4a9eff',
  muted: '#888888',
  border: '#333333',
  dark: true,
};

/** 最高分 LocalStorage key 前缀 */
const BEST_SCORE_KEY_PREFIX = 'game:best:';

/**
 * GameHost — 游戏宿主基类。
 *
 * 子类通过 extends GameHost 并实现 onMount/onUnmount 等抽象方法，
 * 即可获得统一的 HUD/主题适配/最高分持久化能力。
 *
 * 典型用法：
 * ```ts
 * class TetrisHost extends GameHost {
 *   protected onMount(ctx, canvas, options) {
 *     // 初始化 Tetris 渲染循环
 *   }
 *   protected onUnmount() {
 *     // 清理定时器
 *   }
 * }
 *
 * export function createTetrisEntry(): AppEntry {
 *   const host = new TetrisHost({ gameId: 'game-tetris' });
 *   return host.toAppEntry();
 * }
 * ```
 */
abstract class GameHost {
  protected readonly config: Readonly<GameHostConfig>;

  /** 挂载容器（由 mount 注入） */
  private container: HTMLElement | null = null;
  /** 根元素（.game-host-root） */
  private root: HTMLElement | null = null;
  /** 画布元素（由 mount 创建） */
  private canvas: HTMLCanvasElement | null = null;
  /** HUD 容器（分数/按钮） */
  private hud: HTMLElement | null = null;
  /** 当前应用上下文（用于 i18n / API 调用） */
  protected ctx: AppMountContext | null = null;
  /** 当前游戏状态 */
  private status: GameStatus = 'idle';
  /** 当前分数 */
  private score = 0;
  /** 历史最高分 */
  private bestScore = 0;
  /** 主题 token */
  private theme: GameThemeTokens = DEFAULT_THEME_TOKENS;
  /** 主题变化订阅解绑函数 */
  private themeUnsub: (() => void) | null = null;
  /** i18n 变更订阅解绑函数（宿主语言切换 → 刷新 HUD 文案，Step 4.1） */
  private i18nUnsub: (() => void) | null = null;
  /** 暂停状态锁（防止重复暂停/恢复） */
  private paused = false;
  /** HUD 状态监听器集合 */
  private readonly statusListeners = new Set<(e: GameStatusEvent) => void>();
  /** HUD 分数监听器集合 */
  private readonly scoreListeners = new Set<(e: GameScoreEvent) => void>();
  /** 画布逻辑宽度（子类调用 setupHiDPICanvas 时传入） */
  private logicalW = 0;
  /** 画布逻辑高度 */
  private logicalH = 0;
  /** ResizeObserver 实例（窗口尺寸变化时重新适配画布） */
  private resizeObserver: ResizeObserver | null = null;
  /** rAF 合并句柄（ResizeObserver 防抖，避免连续清空画布闪烁） */
  private resizeRaf: number | null = null;
  /** v4.2：自动暂停监听解绑函数（标签页隐藏 / 窗口失焦时自动暂停游戏） */
  private autoPauseUnsub: (() => void) | null = null;
  /** v4.2：自动暂停前的用户手动暂停状态（恢复时保留用户意图） */
  private wasPausedBeforeAutoPause: boolean = false;
  /** v5.0：当前游戏难度（由 resolveOptions 初始化，可运行时通过 HUD 下拉切换） */
  private currentDifficulty: GameDifficulty = 'normal';

  constructor(config: GameHostConfig) {
    this.config = config;
    this.bestScore = 0;
    /* P4.3：最高分经 sandboxStorage 异步加载（postMessage 往返），构造期无法
       同步取值；加载完成后取大者回填（防玩家抢先破纪录被旧值覆盖） */
    void this.loadBestScore().then((loaded) => {
      if (loaded > this.bestScore) {
        this.bestScore = loaded;
        this.updateHUDScore();
      }
    });
  }

  /* ============================================================
     生命周期（子类实现）
     ============================================================ */

  /**
   * 子类实现：游戏挂载时初始化场景。
   *
   * @param ctx 应用挂载上下文
   * @param canvas 画布元素（已设置宽高/样式）
   * @param options 游戏启动选项
   */
  protected abstract onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): void | Promise<void>;

  /**
   * 子类实现：游戏卸载时清理资源（定时器/事件/动画帧）。
   * 必须是同步的，由 unmount 调用。
   */
  protected abstract onUnmount(): void;

  /**
   * 子类可选实现：暂停游戏（默认空实现）。
   * 仅在 config.pauseable !== false 时调用。
   */
  protected onPause(): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：恢复游戏（默认空实现）。
   */
  protected onResume(): void {
    /* default no-op */
  }

  /**
   * v5.0: 子类可选实现：难度变更回调。
   * 当用户通过 HUD 下拉切换难度时调用，子类可在此调整 AI 强度等参数。
   */
  protected onDifficultyChange(_difficulty: GameDifficulty): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：重新开始游戏（默认调用 onUnmount + onMount）。
   */
  protected onRestart(): void {
    if (this.canvas === null || this.ctx === null) return;
    this.onUnmount();
    this.score = 0;
    this.status = 'idle';
    this.paused = false;
    void this.onMount(this.ctx, this.canvas, this.resolveOptions());
  }

  /* ============================================================
     公开 API（供 AppEntry 调用）
     ============================================================ */

  /** 转换为 AppEntry（注册到 AppRegistry） */
  toAppEntry(): AppEntry {
    return {
      mount: (ctx: AppMountContext) => this.mount(ctx),
      unmount: () => this.unmount(),
    };
  }

  /** 挂载游戏 */
  async mount(ctx: AppMountContext): Promise<void> {
    this.ctx = ctx;
    this.container = ctx.container;

    /* 解析主题 token：皮肤变量在 srcdoc body 末尾注入，入口脚本先于其执行；
       readyState==='loading' 时先拿到 fallback 深色快照；文档解析完成
       （DOMContentLoaded，皮肤 <style> 已注入生效）后重新解析并同步，
       保证浅色皮肤下 HUD 文字与棋盘底色正确。 */
    this.theme = this.resolveThemeTokens();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.theme = this.resolveThemeTokens();
        this.applyThemeToCanvas();
        this.applyThemeToRoot();
      }, { once: true });
    }

    /* 创建根布局 */
    const root = document.createElement('div');
    root.className = 'game-host-root';
    root.dataset.gameId = this.config.gameId;
    root.dataset.status = 'idle';

    /* HUD（顶部条） */
    if (this.config.showHUD !== false) {
      this.hud = this.createHUD(ctx);
      root.appendChild(this.hud);
    }

    /* 画布容器 */
    const canvasWrap = document.createElement('div');
    canvasWrap.className = 'game-host-canvas-wrap';
    canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');

    const canvas = document.createElement('canvas');
    canvas.className = 'game-host-canvas';
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'application');
    canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    const w = this.config.width ?? 0;
    const h = this.config.height ?? 0;
    if (w > 0) canvas.style.width = `${w}px`;
    if (h > 0) canvas.style.height = `${h}px`;
    canvasWrap.appendChild(canvas);
    root.appendChild(canvasWrap);
    this.root = root;
    this.canvas = canvas;

    /* v5.0 修复：暂停状态下点击画布容器恢复游戏（原方案 overlay 有 pointer-events:none，
     * 点击穿透到 canvas 但 canvas 无 resume 处理，导致"点击继续"无反应） */
    canvasWrap.addEventListener('click', () => {
      if (this.paused && this.status === 'paused') {
        this.resume();
      }
    });

    this.container.replaceChildren(root);
    this.applyThemeToRoot();
    canvas.focus();

    /* 监听主题变化 */
    this.themeUnsub = ctx.onThemeChange(() => {
      this.theme = this.resolveThemeTokens();
      this.applyThemeToCanvas();
      this.applyThemeToRoot();
    });

    /* Step 4.1：订阅宿主语言变更 → 刷新 HUD 文案（词表由沙箱 __SANDBOX_I18N__ 提供） */
    const subscribeI18n = ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_I18N__ as
      | ((cb: () => void) => () => void)
      | undefined) ?? (() => () => undefined);
    this.i18nUnsub = subscribeI18n(() => {
      this.refreshHudI18n();
    });

    /* v4.1：监听画布容器尺寸变化，自动重新计算 canvas 分辨率，
     * 确保窗口 resize 时文字不模糊（Canvas 2D 游戏适用，Phaser 游戏由其 ScaleManager 处理） */
    this.resizeObserver = new ResizeObserver(() => {
      if (this.canvas === null || this.logicalW <= 0 || this.logicalH <= 0) return;
      /* v5.1：尺寸变化用 rAF 合并（体验视图进入动画/布局抖动期间容器连续变化，
       * 同步重置 canvas 会每帧清空重绘造成可见闪烁；合并到下一帧只处理一次） */
      if (this.resizeRaf !== null) return;
      this.resizeRaf = window.requestAnimationFrame(() => {
        this.resizeRaf = null;
        const c = this.canvas;
        if (c === null || this.logicalW <= 0 || this.logicalH <= 0) return;
        const ctx = this.applyCanvasSize(c, this.logicalW, this.logicalH);
        if (ctx !== null) {
          try { this.onCanvasResize(); } catch (err) {
            console.error(`[GameHost:${this.config.gameId}] onCanvasResize failed:`, err);
          }
        }
      });
    });
    this.resizeObserver.observe(canvasWrap);

    /* v4.2（5.8.15）：标签页隐藏 / 窗口失焦时自动暂停游戏，恢复时自动继续。
     * 仅在用户未手动暂停时自动恢复，避免与用户意图冲突。 */
    this.setupAutoPause();

    /* v5.0: 从启动选项中解析初始难度 */
    const opts = this.resolveOptions();
    this.currentDifficulty = opts.difficulty ?? 'normal';

    /* 子类初始化游戏场景 */
    try {
      await this.onMount(ctx, canvas, opts);
      this.setStatus('playing');
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onMount failed:`, err);
      this.setStatus('gameover', this.tr(this.ctx, 'game.common.initFailed', 'Game init failed', { msg: err instanceof Error ? err.message : String(err) }));
    }
  }

  /** 卸载游戏 */
  unmount(): void {
    if (this.resizeRaf !== null) {
      window.cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeObserver !== null) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.autoPauseUnsub !== null) {
      try { this.autoPauseUnsub(); } catch { /* ignore */ }
      this.autoPauseUnsub = null;
    }
    if (this.themeUnsub !== null) {
      try { this.themeUnsub(); } catch { /* ignore */ }
      this.themeUnsub = null;
    }
    if (this.i18nUnsub !== null) {
      try { this.i18nUnsub(); } catch { /* ignore */ }
      this.i18nUnsub = null;
    }
    try {
      this.onUnmount();
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onUnmount failed:`, err);
    }
    this.statusListeners.clear();
    this.scoreListeners.clear();
    this.canvas = null;
    this.hud = null;
    this.root = null;
    this.container = null;
    this.ctx = null;
    this.status = 'idle';
  }

  /**
   * v4.2（5.8.15）：设置自动暂停监听
   *
   * 监听 document.visibilitychange（标签页隐藏/显示）和 window blur/focus 事件。
   * 当标签页隐藏或窗口失焦时自动暂停游戏；恢复时如果用户未手动暂停则自动继续。
   */
  private setupAutoPause(): void {
    const handleVisibilityChange = (): void => {
      if (document.hidden) {
        /* 标签页隐藏：暂停游戏 */
        if (!this.paused) {
          this.wasPausedBeforeAutoPause = false;
          this.pause();
        } else {
          this.wasPausedBeforeAutoPause = true;
        }
      } else {
        /* 标签页恢复：如果用户未手动暂停，则自动继续 */
        if (!this.wasPausedBeforeAutoPause && this.paused) {
          this.resume();
        }
      }
    };

    const handleWindowBlur = (): void => {
      if (!this.paused && this.status === 'playing') {
        this.wasPausedBeforeAutoPause = false;
        this.pause();
      } else {
        this.wasPausedBeforeAutoPause = true;
      }
    };

    const handleWindowFocus = (): void => {
      if (!this.wasPausedBeforeAutoPause && this.paused && this.status === 'playing') {
        this.resume();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    this.autoPauseUnsub = (): void => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }

  /* ============================================================
     状态管理（子类调用）
     ============================================================ */

  /** 更新当前分数（同时更新最高分） */
  protected updateScore(score: number, level?: number): void {
    this.score = score;
    if (score > this.bestScore) {
      this.bestScore = score;
      this.saveBestScore(score);
    }
    const event: GameScoreEvent = { score, bestScore: this.bestScore, level };
    for (const listener of this.scoreListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDScore();
  }

  /** 更新游戏状态 */
  protected setStatus(status: GameStatus, message?: string): void {
    this.status = status;
    if (this.root !== null) {
      this.root.dataset.status = status;
    }
    const event: GameStatusEvent = { status, message };
    for (const listener of this.statusListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDStatus();
  }

  /** 订阅状态变更 */
  onStatusChange(listener: (e: GameStatusEvent) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  /** 订阅分数变更 */
  onScoreChange(listener: (e: GameScoreEvent) => void): () => void {
    this.scoreListeners.add(listener);
    return () => this.scoreListeners.delete(listener);
  }

  /** 暂停游戏 */
  pause(): void {
    if (this.paused || this.status !== 'playing') return;
    this.paused = true;
    this.setStatus('paused');
    try { this.onPause(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onPause failed:`, err); }
  }

  /** 恢复游戏 */
  resume(): void {
    if (!this.paused) return;
    this.paused = false;
    this.setStatus('playing');
    try { this.onResume(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onResume failed:`, err); }
  }

  /** 切换暂停/恢复 */
  togglePause(): void {
    if (this.paused) this.resume();
    else this.pause();
  }

  /** 重新开始 */
  restart(): void {
    try { this.onRestart(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onRestart failed:`, err); }
  }

  /** v5.0: 切换难度（运行时通过 HUD 下拉触发） */
  changeDifficulty(difficulty: GameDifficulty): void {
    this.currentDifficulty = difficulty;
    try { this.onDifficultyChange(difficulty); } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onDifficultyChange failed:`, err);
    }
  }

  /* ============================================================
     访问器
     ============================================================ */

  protected get currentStatus(): GameStatus { return this.status; }
  protected get currentScore(): number { return this.score; }
  protected get currentBestScore(): number { return this.bestScore; }
  protected get isPaused(): boolean { return this.paused; }
  protected get themeTokens(): GameThemeTokens { return this.theme; }
  protected get canvasElement(): HTMLCanvasElement | null { return this.canvas; }
  /** v5.0: 获取当前难度（供子类 AI 逻辑使用） */
  protected get difficulty(): GameDifficulty { return this.currentDifficulty; }

  /* ============================================================
     DOM 覆盖层（供子类在异步加载前显示状态，不污染 canvas 上下文）
     ============================================================ */

  /**
   * 设置 HiDPI Canvas（Retina/高分屏锐利渲染 + 自适应缩放）。
   *
   * v4.1（2026-07-28）修复文字模糊发虚问题：
   *   - 原方案 canvas CSS 尺寸固定为 logicalW × logicalH，配合 CSS max-width:100%
   *     导致容器小于画布时浏览器缩放位图，文字发虚。
   *   - 新方案测量父容器可用空间，计算等比缩放系数（不放大），将 canvas
   *     内部分辨率设为 displayW*dpr × displayH*dpr，context 缩放 (scale*dpr)，
   *     子类绘制仍用逻辑坐标，位图 1:1 对齐显示像素，文字始终锐利。
   *
   * @returns 2D context（已 scale），或 null 表示浏览器不支持
   */
  protected setupHiDPICanvas(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    this.logicalW = logicalW;
    this.logicalH = logicalH;
    return this.applyCanvasSize(canvas, logicalW, logicalH);
  }

  /**
   * 子类可选实现：画布尺寸变化时回调（由 ResizeObserver 触发）。
   *
   * 默认空实现。子类如需在窗口 resize 时重排布局可覆写。
   * 注意：此方法在每帧 draw 之前调用，无需手动触发重绘。
   */
  protected onCanvasResize(): void {
    /* default no-op */
  }

  /**
   * 将鼠标事件的 CSS 坐标转换为画布逻辑坐标。
   *
   * v5.0 修复：原方案各游戏自行用 canvas.width/rect.width（=dpr）做缩放，
   * 导致 HiDPI（Retina dpr=2）下点击位置偏移 2 倍，棋子无法选中或落子错位。
   * 此方法统一用 logicalW/rect.width（=1/scale）做转换，确保点击精确。
   *
   * @param canvas 画布元素
   * @param clientX 鼠标 clientX
   * @param clientY 鼠标 clientY
   * @returns 逻辑坐标 {x, y}（与 setupHiDPICanvas 传入的 logicalW/H 同坐标系）
   */
  protected clientToLogical(
    canvas: HTMLCanvasElement,
    clientX: number,
    clientY: number,
  ): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
    const scaleX = this.logicalW / rect.width;
    const scaleY = this.logicalH / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  /** 计算缩放系数并应用 canvas 尺寸（内部方法） */
  private applyCanvasSize(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    /* 测量父容器可用空间（扣除 padding） */
    const parent = canvas.parentElement;
    let availW = logicalW;
    let availH = logicalH;
    if (parent !== null) {
      const cs = getComputedStyle(parent);
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      const rect = parent.getBoundingClientRect();
      availW = Math.max(rect.width - padX, 50);
      availH = Math.max(rect.height - padY, 50);
    }

    /* 等比缩放（不放大超过 1x，避免模糊） */
    const scale = Math.min(availW / logicalW, availH / logicalH, 1);
    const displayW = Math.max(Math.round(logicalW * scale), 1);
    const displayH = Math.max(Math.round(logicalH * scale), 1);

    /* 设置 canvas 内部分辨率 = 显示尺寸 × dpr（尺寸未变时跳过赋值，
     * 避免 canvas.width 清空画布导致已绘制内容闪一帧） */
    const pw = Math.round(displayW * dpr);
    const ph = Math.round(displayH * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${displayW}px`;
    canvas.style.height = `${displayH}px`;
    /* 移除 CSS max-width/max-height（避免浏览器二次缩放导致文字模糊） */
    canvas.style.maxWidth = 'none';
    canvas.style.maxHeight = 'none';

    const ctx = canvas.getContext('2d');
    if (ctx !== null) {
      /* context 缩放 = 显示缩放 × dpr，子类用逻辑坐标绘制 */
      ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
    }
    return ctx;
  }

  /**
   * 显示 loading 覆盖层（DOM 方式，不使用 canvas.getContext）。
   *
   * 关键设计：Phaser 等引擎需要 WebGL 上下文，如果在 canvas 上调用
   * getContext('2d')，会导致后续无法创建 WebGL 上下文（同一 canvas
   * 只能有一种类型的 context）。因此 loading/error 状态必须用 DOM 覆盖层实现。
   *
   * @returns overlay 元素，子类可在加载完成后调用 removeLoadingOverlay 移除
   */
  protected showLoadingOverlay(canvas: HTMLCanvasElement, message: string): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-loading-overlay';
    overlay.setAttribute('role', 'status');
    overlay.setAttribute('aria-live', 'polite');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'pointer-events:none',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    }

    /* CSS spinner */
    const spinner = document.createElement('div');
    spinner.className = 'game-host-spinner';
    spinner.style.cssText = [
      'width:32px',
      'height:32px',
      'border-radius:50%',
      `border:3px solid ${this.theme.border}`,
      `border-top-color:${this.theme.accent}`,
      'animation:game-host-spin 0.8s linear infinite',
    ].join(';');
    overlay.appendChild(spinner);

    const text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = `color:${this.theme.fg};font-size:14px;`;
    overlay.appendChild(text);

    /* 注入 keyframes（仅一次；用 querySelector 而非 getElementById，避免转包
     * 校验的 DOM_ID_MISSING 警告（沙箱不加载 index.html，id 声明仅作契约） */
    if (document.querySelector('style#game-host-spinner-style') === null) {
      const style = document.createElement('style');
      style.id = 'game-host-spinner-style';
      style.textContent = '@keyframes game-host-spin{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /** 移除 loading 覆盖层 */
  protected removeLoadingOverlay(overlay: HTMLDivElement): void {
    if (overlay.parentNode !== null) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /** 已废弃：使用 showLoadingOverlay 替代（canvas.getContext('2d') 会阻止 Phaser 创建 WebGL 上下文） */
  protected drawLoadingState(_canvas: HTMLCanvasElement, _message: string): void {
    /* no-op: 请改用 showLoadingOverlay */
  }

  /** 已废弃：使用 showErrorOverlay 替代 */
  protected drawErrorState(_canvas: HTMLCanvasElement, _message: string, _err: unknown): void {
    /* no-op: 请改用 showErrorOverlay */
  }

  /**
   * 显示错误覆盖层（DOM 方式）。
   * @returns overlay 元素
   */
  protected showErrorOverlay(canvas: HTMLCanvasElement, message: string, err: unknown): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-error-overlay';
    overlay.setAttribute('role', 'alert');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:12px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;';
    }

    /* 警示三角形 */
    const icon = document.createElement('div');
    icon.style.cssText = [
      'width:48px',
      'height:48px',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'font-size:28px',
      'color:#ef4444',
    ].join(';');
    icon.textContent = '!';
    overlay.appendChild(icon);

    const msg = document.createElement('span');
    msg.textContent = message;
    msg.style.cssText = `color:${this.theme.fg};font-size:14px;font-weight:600;`;
    overlay.appendChild(msg);

    const detail = err instanceof Error ? err.message : String(err);
    const detailEl = document.createElement('span');
    const maxLen = 80;
    detailEl.textContent = detail.length > maxLen ? detail.slice(0, maxLen) + '...' : detail;
    detailEl.style.cssText = `color:${this.theme.muted};font-size:12px;text-align:center;max-width:80%;word-break:break-word;`;
    overlay.appendChild(detailEl);

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /* ============================================================
     内部实现
     ============================================================ */

  /** 解析启动选项（从 AppMountContext.data 透传，由 WindowManager.launch(options.data) 注入） */
  private resolveOptions(): GameLaunchOptions {
    const data = this.ctx?.data;
    if (data === undefined || data === null) {
      return { difficulty: 'normal', soundEnabled: true, debug: false };
    }
    const difficultyRaw = data['difficulty'];
    const validDifficulties: readonly string[] = ['easy', 'normal', 'hard', 'expert', 'master'];
    const difficulty: GameDifficulty = typeof difficultyRaw === 'string' && validDifficulties.includes(difficultyRaw)
      ? (difficultyRaw as GameDifficulty)
      : 'normal';
    const soundEnabled = typeof data['soundEnabled'] === 'boolean' ? data['soundEnabled'] : true;
    const debug = typeof data['debug'] === 'boolean' ? data['debug'] : false;
    const levelRaw = data['level'];
    const level = typeof levelRaw === 'number' && Number.isInteger(levelRaw) && levelRaw > 0 ? levelRaw : undefined;
    const gameModeRaw = data['gameMode'];
    const gameMode = typeof gameModeRaw === 'string' && gameModeRaw !== '' ? gameModeRaw : undefined;
    return { difficulty, soundEnabled, debug, level, gameMode };
  }

  /** 解析主题 token */
  private resolveThemeTokens(): GameThemeTokens {
    if (typeof window === 'undefined' || window === null) return DEFAULT_THEME_TOKENS;
    const style = window.getComputedStyle(document.documentElement);
    /** 读取单个 CSS 变量，空字符串视为未定义 */
    const get = (name: string): string => style.getPropertyValue(name).trim();
    /** 依次尝试多个变量名，全部未定义时使用 fallback */
    const pick = (names: readonly string[], fallback: string): string => {
      for (const name of names) {
        const v = get(name);
        if (v !== '') return v;
      }
      return fallback;
    };
    /* 宿主真实 token 优先（--fg-primary/--bg-canvas 宿主未定义，回退 --glass-text-* / --surface-*）；
       全部缺失时兜底深色（黑底白字仍可读） */
    const bg = pick(['--bg-canvas', '--surface-solid-primary', '--glass-bg-L1', '--bg-primary'], '#0e0f12');
    /* 背景亮度检测用实色（渐变无法取亮度）；浅色主题下文字/面板自动切深色系 */
    const dark = GameHost.isLuminanceDark(pick(['--surface-solid-primary', '--bg-primary'], '#0e0f12'));
    return {
      bg,
      fg: pick(['--fg-primary', '--glass-text-primary', '--text-primary'], dark ? '#e8e8e8' : '#1a1a1a'),
      accent: pick(['--accent-cool'], '#4a9eff'),
      muted: pick(['--fg-muted', '--glass-text-secondary', '--text-secondary'], dark ? '#888888' : '#5f6670'),
      border: pick(['--border-subtle', '--glass-divider', '--glass-border-L3'], '#333333'),
    } as GameThemeTokens;
  }

  /** 亮度判断（--bg-primary 为实色可解析；渐变等非 hex 一律视为深色） */
  private static isLuminanceDark(color: string): boolean {
    const m = /^#([0-9a-f]{6})$/i.exec(color);
    if (m === null) return true;
    const hex = m[1]!;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  }

  /** 同步主题 token 到根元素 CSS 变量（styles.css 的 var() 消费；浅色皮肤下文字/面板切深色系） */
  private applyThemeToRoot(): void {
    if (this.root === null) return;
    const t = this.theme;
    const s = this.root.style;
    s.setProperty('--fg-primary', t.fg);
    s.setProperty('--fg-muted', t.muted);
    s.setProperty('--bg-active', t.dark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)');
    s.setProperty('--bg-hover', t.dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)');
    s.setProperty('--bg-elevated', t.dark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)');
  }

  /** 应用主题到画布：canvas 内容由游戏引擎自绘（Phaser backgroundColor / 棋盘底色），
   *  CSS 背景不透明色会在引擎首帧前露出白/黑块（坊市体验层泛白根因之一），故置透明 */
  private applyThemeToCanvas(): void {
    if (this.canvas === null) return;
    this.canvas.style.background = 'transparent';
  }

  /** 创建 HUD */
  private createHUD(ctx: AppMountContext): HTMLElement {
    const hud = document.createElement('div');
    hud.className = 'game-host-hud';

    const left = document.createElement('div');
    left.className = 'game-host-hud-left';

    /* G2 F 头：mono kicker（游戏 id 大写；@2 F 语言 kicker/衬线标题双件套） */
    const kicker = document.createElement('span');
    kicker.className = 'game-host-hud-kicker';
    kicker.setAttribute('aria-hidden', 'true');
    kicker.textContent = String(ctx.manifest.id ?? 'GAME').toUpperCase();
    left.appendChild(kicker);

    const title = document.createElement('span');
    title.className = 'game-host-hud-title';
    title.textContent = this.resolveGameName(ctx);
    left.appendChild(title);

    const score = document.createElement('span');
    score.className = 'game-host-hud-score';
    score.dataset.role = 'score';
    score.textContent = this.formatScoreText(0, this.bestScore);
    left.appendChild(score);

    hud.appendChild(left);

    const right = document.createElement('div');
    right.className = 'game-host-hud-right';

    /* v5.0: 难度选择器（下拉菜单，支持 5 档难度） */
    const diffWrap = document.createElement('div');
    diffWrap.className = 'game-host-hud-difficulty-wrap';
    const diffSelect = document.createElement('select');
    /* P4.7：按钮基座化（铁律 9）——消费 .btn 基座变体（次按钮 + 小尺寸），
     * 保留 game-host-hud-btn 类名用于模板内定位/复刻样式桥接 */
    diffSelect.className = 'game-host-hud-btn btn btn--secondary btn--sm game-host-hud-difficulty-select';
    diffSelect.dataset.role = 'difficulty';
    diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
    const diffOptions: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
      { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
      { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
      { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
      { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
      { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
    ];
    for (const opt of diffOptions) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = this.tr(ctx, opt.labelKey, opt.fallback);
      diffSelect.appendChild(o);
    }
    diffSelect.value = this.currentDifficulty;
    diffSelect.addEventListener('change', () => {
      const val = diffSelect.value as GameDifficulty;
      this.changeDifficulty(val);
    });
    diffWrap.appendChild(diffSelect);
    right.appendChild(diffWrap);

    if (this.config.pauseable !== false) {
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
      pauseBtn.dataset.role = 'pause';
      pauseBtn.textContent = this.tr(ctx, 'game.hud.pause', 'Pause');
      pauseBtn.addEventListener('click', () => this.togglePause());
      right.appendChild(pauseBtn);
    }

    const restartBtn = document.createElement('button');
    restartBtn.type = 'button';
    restartBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
    restartBtn.dataset.role = 'restart';
    restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    restartBtn.addEventListener('click', () => this.restart());
    right.appendChild(restartBtn);

    hud.appendChild(right);
    return hud;
  }

  /** 更新 HUD 分数显示 */
  private updateHUDScore(): void {
    if (this.hud === null) return;
    const scoreEl = this.hud.querySelector<HTMLElement>('[data-role="score"]');
    if (scoreEl !== null) {
      scoreEl.textContent = this.formatScoreText(this.score, this.bestScore);
    }
  }

  /** i18n 刷新（Step 4.1）：宿主语言切换后重设 HUD 文案（data-role 查询 + 子类 hook） */
  protected refreshHudI18n(): void {
    if (this.hud === null) return;
    const ctx = this.ctx;
    if (ctx === null) return;
    const diffSelect = this.hud.querySelector<HTMLSelectElement>('[data-role="difficulty"]');
    if (diffSelect !== null) {
      diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
      const labels: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
        { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
        { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
        { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
        { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
        { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
      ];
      const options = diffSelect.querySelectorAll('option');
      options.forEach((o) => {
        const label = labels.find((l) => l.value === o.value);
        if (label !== undefined) o.textContent = this.tr(ctx, label.labelKey, label.fallback);
      });
    }
    /* 暂停遮罩文案（CSS ::after content 消费 dataset.pausedText） */
    const canvasWrap = this.root !== null ? this.root.querySelector<HTMLElement>('.game-host-canvas-wrap') : null;
    if (canvasWrap !== null) {
      canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');
    }
    if (this.canvas !== null) this.canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    /* HUD 标题（游戏名）+ 重新开始按钮（2026-08-27 P4.1f 运行时验证补齐） */
    const titleEl = this.hud.querySelector<HTMLElement>('.game-host-hud-title');
    if (titleEl !== null) titleEl.textContent = this.resolveGameName(ctx);
    const restartBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="restart"]');
    if (restartBtn !== null) restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    this.updateHUDStatus();
    this.updateHUDScore();
    if (this.onI18nRefresh !== undefined) {
      try { this.onI18nRefresh(); } catch { /* ignore */ }
    }
  }

  /** i18n 刷新子类 hook（如 tank 的 Phaser 场景 overlays 重建） */
  protected onI18nRefresh?: () => void;

  /** 更新 HUD 状态显示 */
  private updateHUDStatus(): void {
    if (this.hud === null) return;
    const pauseBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="pause"]');
    if (pauseBtn !== null) {
      pauseBtn.textContent = this.paused
        ? this.tr(this.ctx, 'game.hud.resume', 'Resume')
        : this.tr(this.ctx, 'game.hud.pause', 'Pause');
    }
  }

  /** 格式化分数显示 */
  private formatScoreText(score: number, best: number): string {
    const scoreStr = this.tr(this.ctx, 'game.hud.score', 'Score');
    const bestStr = this.tr(this.ctx, 'game.hud.best', 'Best');
    return `${scoreStr} ${score}  ·  ${bestStr} ${best}`;
  }

  /** 解析游戏名称（从 manifest.nameFallback） */
  private resolveGameName(ctx: AppMountContext): string {
    const nameKey = ctx.manifest.nameKey;
    if (nameKey !== undefined && nameKey !== '') {
      const tr = this.tr(ctx, nameKey, ctx.manifest.nameFallback);
      if (tr !== nameKey) return tr;
    }
    return ctx.manifest.nameFallback;
  }

  /** i18n 翻译（带兜底） */
  private tr(ctx: AppMountContext | null, key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string {
    if (ctx === null) return fallback;
    try {
      const result = ctx.t(key, params);
      if (result !== key) return result;
    } catch {
      /* ignore */
    }
    return params === undefined ? fallback : fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
      const value = params[name];
      return value !== undefined ? String(value) : '';
    });
  }

  /* ============================================================
     最高分持久化（P4.3：sandboxStorage 代理，键 game:best:game-gomoku）
     ============================================================ */

  private async loadBestScore(): Promise<number> {
    const storage = getSandboxStorage();
    if (storage === null) return 0;
    try {
      const raw = await storage.get(BEST_SCORE_KEY_PREFIX + this.config.gameId);
      if (raw === null || raw === undefined) return 0;
      const n = Number.parseInt(String(raw), 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch {
      return 0;
    }
  }

  private saveBestScore(score: number): void {
    const storage = getSandboxStorage();
    if (storage === null) return;
    void storage.set(BEST_SCORE_KEY_PREFIX + this.config.gameId, String(score)).catch(() => {
      /* ignore quota */
    });
  }
}


  /* =========================================================
     5. GomokuHost 内联（原 src/shared/apps/games/builtin/gomoku/GomokuHost.ts）
     ========================================================= */

/**
 * GomokuHost — 五子棋游戏实现
 *
 * Phase 5.8.2 交付物：5 款内置小游戏之一。
 *
 * 引擎：Canvas 2D
 * 操作：鼠标点击落子；P 暂停；R 重新开始；U 悔棋
 * 模式：单人对 AI（easy / normal / hard 三档难度）
 *
 * 增强功能：
 *   - 最后一手红色三角标记
 *   - 走棋历史面板（棋盘坐标 A-O + 1-15），自动滚动到最新
 *   - U 键悔棋（撤销玩家 + AI 各一步，退回玩家回合）
 *   - 三档难度（easy 随机 top3 / normal 最佳 / hard 加权防守）
 *   - 棋子径向渐变 + 高光 + 落子缩放动画
 *   - 胜利金色连线 + 棋子发光边框 + 大字提示
 *   - 木纹棋盘 + 星位 + 坐标标注
 *   - AI 思考中动画省略号提示
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.4
 */






const SIZE = 15;
const CELL = 36;
/** v5.0: 24 → 32，确保坐标标注不与棋盘边框重叠
 * v5.1: 32 → 42，坐标标注与边框保留更舒适的间距
 * v5.2: 42 → 48，参考围棋(Go PAD=44)的间距，坐标标注与边框保留更充分的间隔 */
const PADDING = 48;
/** 顶部状态条高度（用于显示 AI 思考提示 / 难度标签） */
const HEADER_H = 32;
/** 走棋历史面板宽度 */
const HISTORY_W = 140;
/** 棋盘与历史面板之间的间距 */
const HISTORY_GAP = 12;
/** 棋盘区域宽高（含内边距） */
const BOARD_W = (SIZE - 1) * CELL + PADDING * 2;
/** 棋盘在画布中的纵向起始位置（顶部留 HEADER_H 给状态条） */
const BOARD_Y = HEADER_H;
/** 画布总宽（棋盘 + 间距 + 历史面板） */
const W = BOARD_W + HISTORY_GAP + HISTORY_W;
/** 画布总高（顶部状态条 + 棋盘） */
const H = HEADER_H + BOARD_W;
/** 历史面板在画布中的横向起始位置 */
const HISTORY_X = BOARD_W + HISTORY_GAP;

const EMPTY = 0;
const BLACK = 1;
const WHITE = 2;

/** 落子缩放动画时长（毫秒，1.2x → 1.0x） */
const STONE_ANIM_MS = 220;
/** AI 思考动画省略号周期（毫秒） */
const AI_DOT_MS = 350;
/** 字体栈 */
const FONT_STACK = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif';

/** 历史走子记录条目 */
interface MoveRecord {
  readonly x: number;
  readonly y: number;
  readonly who: 1 | 2;
}

/** 历史面板中的回合记录（黑方必走，白方可能尚未走） */
interface RoundRecord {
  black: MoveRecord;
  white?: MoveRecord;
}

class GomokuHost extends GameHost {
  private ctx2d: CanvasRenderingContext2D | null = null;
  private board: number[][] = [];
  private turn: 1 | 2 = BLACK;
  private winner: 0 | 1 | 2 = 0;
  private lastMove: { x: number; y: number } | null = null;
  private winLine: { x: number; y: number }[] | null = null;
  private rafId: number | null = null;
  private clickHandler: ((e: MouseEvent) => void) | null = null;
  private keyHandler: ((e: KeyboardEvent) => void) | null = null;
  private aiEnabled = true;
  /** AI 走子定时器（必须在 onUnmount 中清理，避免幽灵调用） */
  private aiTimeout: ReturnType<typeof setTimeout> | null = null;
  /** AI 是否正在思考（用于显示提示并阻止玩家落子） */
  private aiThinking = false;
  /** 走棋历史（用于显示面板与悔棋） */
  private moveHistory: MoveRecord[] = [];
  /** 棋子落子时间戳（key: "x,y"，用于落子缩放动画） */
  private readonly stoneAnims = new Map<string, number>();

  protected onMount(_ctx: AppMountContext, canvas: HTMLCanvasElement, _options: GameLaunchOptions): void {
    const ctx2d = this.setupHiDPICanvas(canvas, W, H);
    if (ctx2d === null) return;
    this.ctx2d = ctx2d;
    this.reset();

    this.clickHandler = (e: MouseEvent) => this.onClick(e, canvas);
    canvas.addEventListener('click', this.clickHandler);
    this.keyHandler = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P') this.togglePause();
      else if (e.key === 'r' || e.key === 'R') this.restart();
      else if (e.key === 'u' || e.key === 'U') this.undo();
    };
    window.addEventListener('keydown', this.keyHandler);

    const loop = (): void => {
      this.draw();
      this.rafId = window.requestAnimationFrame(loop);
    };
    this.rafId = window.requestAnimationFrame(loop);
  }

  protected onUnmount(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    /* Phase 5.10.2：清理 AI 走子定时器，避免卸载后幽灵调用 */
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    if (this.clickHandler !== null) {
      const c = this.canvasElement;
      if (c !== null) c.removeEventListener('click', this.clickHandler);
      this.clickHandler = null;
    }
    if (this.keyHandler !== null) {
      window.removeEventListener('keydown', this.keyHandler);
      this.keyHandler = null;
    }
    this.ctx2d = null;
  }

  protected override onPause(): void {
    /* 暂停时取消正在等待的 AI 走子，恢复时由 onResume 重新调度 */
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.aiThinking = false;
  }

  protected override onResume(): void {
    /* 若暂停时轮到 AI，恢复后重新调度 */
    if (this.aiEnabled && this.turn === WHITE && this.winner === 0 && this.aiTimeout === null) {
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 200);
    }
  }

  protected override onRestart(): void {
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.reset();
  }

  private reset(): void {
    this.board = Array.from({ length: SIZE }, () => new Array<number>(SIZE).fill(EMPTY));
    this.turn = BLACK;
    this.winner = 0;
    this.lastMove = null;
    this.winLine = null;
    this.aiThinking = false;
    this.moveHistory = [];
    this.stoneAnims.clear();
    this.updateScore(0);
    this.setStatus('playing');
  }

  private onClick(e: MouseEvent, canvas: HTMLCanvasElement): void {
    if (this.currentStatus !== 'playing' || this.winner !== 0) return;
    if (this.aiEnabled && this.turn === WHITE) return; /* AI 思考中 */

    /* v5.0 修复：使用 clientToLogical 统一转换坐标，修复 HiDPI 下点击偏移 */
    const { x: cssX, y: cssY } = this.clientToLogical(canvas, e.clientX, e.clientY);
    const x = Math.round((cssX - PADDING) / CELL);
    const y = Math.round((cssY - BOARD_Y - PADDING) / CELL);
    if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return;
    if (this.board[y]![x] !== EMPTY) return;

    this.place(x, y);
    if (this.winner === 0 && this.aiEnabled && this.turn === WHITE) {
      /* AI 走子：评分选最佳点（难度决定策略） */
      this.aiThinking = true;
      this.aiTimeout = setTimeout(() => this.aiMove(), 220);
    }
  }

  private place(x: number, y: number): boolean {
    if (this.board[y]![x] !== EMPTY) return false;
    const who = this.turn;
    this.board[y]![x] = who;
    this.lastMove = { x, y };
    this.moveHistory.push({ x, y, who });
    this.stoneAnims.set(`${x},${y}`, performance.now());
    const line = this.checkWin(x, y, who);
    if (line !== null) {
      this.winner = who;
      this.winLine = line;
      this.setStatus('victory');
      this.updateScore(who === BLACK ? 1 : 2);
    } else if (this.isFull()) {
      this.setStatus('gameover', this.tr(this.ctx, 'game.gomoku.result.draw', 'Draw'));
    } else {
      this.turn = this.turn === BLACK ? WHITE : BLACK;
    }
    return true;
  }

  /** 悔棋：撤销玩家最后一步 + AI 最后一步，退回玩家回合 */
  private undo(): void {
    if (this.currentStatus === 'paused') return;
    if (this.moveHistory.length === 0) return;
    /* 取消正在等待的 AI 走子 */
    if (this.aiTimeout !== null) {
      clearTimeout(this.aiTimeout);
      this.aiTimeout = null;
    }
    this.aiThinking = false;

    /* 弹出最后一步；若为 AI（白），则继续弹出玩家（黑） */
    const popOne = (): void => {
      const last = this.moveHistory.pop();
      if (last === undefined) return;
      this.board[last.y]![last.x] = EMPTY;
      this.stoneAnims.delete(`${last.x},${last.y}`);
    };
    popOne();
    const top = this.moveHistory[this.moveHistory.length - 1];
    if (top !== undefined && top.who === WHITE) {
      popOne();
    }

    /* 重置胜负状态，回到玩家回合 */
    this.winner = 0;
    this.winLine = null;
    this.turn = BLACK;
    const newTop = this.moveHistory[this.moveHistory.length - 1];
    this.lastMove = newTop !== undefined ? { x: newTop.x, y: newTop.y } : null;
    this.updateScore(0);
    if (this.currentStatus !== 'playing') {
      this.setStatus('playing');
    }
  }

  private isFull(): boolean {
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        if (this.board[y]![x] === EMPTY) return false;
      }
    }
    return true;
  }

  private checkWin(x: number, y: number, who: number): { x: number; y: number }[] | null {
    const dirs: readonly (readonly [number, number])[] = [[1, 0], [0, 1], [1, 1], [1, -1]];
    for (const [dx, dy] of dirs) {
      const line: { x: number; y: number }[] = [{ x, y }];
      /* 正向 */
      for (let i = 1; i < 5; i++) {
        const nx = x + dx * i;
        const ny = y + dy * i;
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
        if (this.board[ny]![nx] !== who) break;
        line.push({ x: nx, y: ny });
      }
      /* 反向 */
      for (let i = 1; i < 5; i++) {
        const nx = x - dx * i;
        const ny = y - dy * i;
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
        if (this.board[ny]![nx] !== who) break;
        line.unshift({ x: nx, y: ny });
      }
      if (line.length >= 5) return line.slice(0, 5);
    }
    return null;
  }

  /* ============================================================
     AI（启发式评分 + 难度策略）
     ============================================================ */

  private aiMove(): void {
    /* Phase 5.10.2：进入回调时立即清空定时器句柄 */
    this.aiTimeout = null;
    this.aiThinking = false;
    /* 暂停/已结束/非 AI 回合均不应执行走子 */
    if (this.currentStatus !== 'playing') return;
    if (this.winner !== 0) return;

    const candidates: Array<{ x: number; y: number; score: number }> = [];
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        if (this.board[y]![x] !== EMPTY) continue;
        const off = this.scorePoint(x, y, WHITE);
        const def = this.scorePoint(x, y, BLACK);
        /* v5.0: 5 档难度防守权重递增 */
        const defWeight: Record<GameDifficulty, number> = {
          easy: 0.6, normal: 0.85, hard: 1.0, expert: 1.2, master: 1.4,
        };
        const score = off + def * defWeight[this.difficulty];
        candidates.push({ x, y, score });
      }
    }

    if (candidates.length === 0) return;
    candidates.sort((a, b) => b.score - a.score);

    let chosen: { x: number; y: number };
    /* v5.0: 5 档难度选点策略 */
    if (this.difficulty === 'easy') {
      /* easy：从评分前 5 中随机选一 */
      const topN = Math.min(5, candidates.length);
      const idx = Math.floor(Math.random() * topN);
      chosen = candidates[idx] !== undefined ? { x: candidates[idx].x, y: candidates[idx].y } : { x: 7, y: 7 };
    } else if (this.difficulty === 'normal') {
      /* normal：从评分前 3 中随机选一 */
      const topN = Math.min(3, candidates.length);
      const idx = Math.floor(Math.random() * topN);
      chosen = candidates[idx] !== undefined ? { x: candidates[idx].x, y: candidates[idx].y } : { x: 7, y: 7 };
    } else {
      /* hard / expert / master：选评分最高点 */
      const c = candidates[0];
      chosen = c !== undefined ? { x: c.x, y: c.y } : { x: 7, y: 7 };
    }

    this.place(chosen.x, chosen.y);
  }

  /** 评估在 (x,y) 落子为 who 的得分（连子模式） */
  private scorePoint(x: number, y: number, who: number): number {
    const dirs: readonly (readonly [number, number])[] = [[1, 0], [0, 1], [1, 1], [1, -1]];
    let total = 0;
    for (const [dx, dy] of dirs) {
      let cnt = 1;
      let openEnds = 0;
      for (let i = 1; i < 5; i++) {
        const nx = x + dx * i;
        const ny = y + dy * i;
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
        if (this.board[ny]![nx] === who) cnt++;
        else { if (this.board[ny]![nx] === EMPTY) openEnds++; break; }
      }
      for (let i = 1; i < 5; i++) {
        const nx = x - dx * i;
        const ny = y - dy * i;
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
        if (this.board[ny]![nx] === who) cnt++;
        else { if (this.board[ny]![nx] === EMPTY) openEnds++; break; }
      }
      if (cnt >= 5) total += 100000;
      else if (cnt === 4 && openEnds === 2) total += 10000;
      else if (cnt === 4 && openEnds === 1) total += 1000;
      else if (cnt === 3 && openEnds === 2) total += 500;
      else if (cnt === 3 && openEnds === 1) total += 100;
      else if (cnt === 2 && openEnds === 2) total += 50;
      else total += cnt;
    }
    return total;
  }

  /* ============================================================
     渲染
     ============================================================ */

  private draw(): void {
    const ctx = this.ctx2d;
    if (ctx === null) return;
    const theme = this.themeTokens;

    /* 主背景 */
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, W, H);

    /* 顶部状态条背景 */
    ctx.fillStyle = theme.border;
    ctx.fillRect(0, 0, W, HEADER_H);

    /* AI 思考提示 / 难度标签 */
    this.drawAIStatus(ctx);

    /* 棋盘（木纹 + 网格 + 星位） */
    this.drawBoard(ctx);

    /* 坐标标注 */
    this.drawCoordinates(ctx);

    /* 棋子 */
    this.drawStones(ctx);

    /* 最后一手标记 */
    this.drawLastMoveMarker(ctx);

    /* 胜利连线 + 发光棋子 */
    this.drawWinLine(ctx);

    /* 走棋历史面板 */
    this.drawHistoryPanel(ctx);

    /* 胜利/结束遮罩 */
    this.drawOverlay(ctx);
  }

  /** 绘制顶部 AI 思考状态 / 操作提示 */
  private drawAIStatus(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    ctx.font = `13px ${FONT_STACK}`;
    if (this.aiThinking) {
      const dots = Math.floor(Date.now() / AI_DOT_MS) % 4;
      const dotStr = '.'.repeat(dots);
      ctx.fillStyle = theme.accent;
      ctx.fillText(this.tr(this.ctx, 'game.common.aiThinking', 'AI thinking') + dotStr, 12, HEADER_H / 2);
    } else {
      ctx.fillStyle = theme.muted;
      ctx.fillText(this.tr(this.ctx, 'game.gomoku.hud.keys', 'U Undo · R Restart · P Pause'), 12, HEADER_H / 2);
    }
  }

  /** 绘制棋盘（木纹背景 + 网格 + 星位） */
  private drawBoard(ctx: CanvasRenderingContext2D): void {
    const boardX = PADDING - 14;
    const boardY = BOARD_Y + PADDING - 14;
    const boardW = (SIZE - 1) * CELL + 28;
    const boardH = (SIZE - 1) * CELL + 28;

    /* 棋盘外框（深色木纹） */
    ctx.fillStyle = '#7c6f5e';
    ctx.fillRect(boardX, boardY, boardW, boardH);

    /* 棋盘表面（木纹线性渐变 #f0d6a0 → #e8c880） */
    const grad = ctx.createLinearGradient(boardX, boardY, boardX + boardW, boardY + boardH);
    grad.addColorStop(0, '#f0d6a0');
    grad.addColorStop(1, '#e8c880');
    ctx.fillStyle = grad;
    ctx.fillRect(boardX + 4, boardY + 4, boardW - 8, boardH - 8);

    /* 木纹细线（贝塞尔曲线增加质感） */
    ctx.strokeStyle = 'rgba(124, 111, 94, 0.18)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 8; i++) {
      ctx.beginPath();
      const y = boardY + 4 + (boardH - 8) * (i / 8);
      ctx.moveTo(boardX + 4, y);
      ctx.bezierCurveTo(
        boardX + boardW / 3, y + 3,
        boardX + (2 * boardW) / 3, y - 3,
        boardX + boardW - 4, y,
      );
      ctx.stroke();
    }

    /* 网格线（深棕色） */
    ctx.strokeStyle = '#8b6914';
    ctx.lineWidth = 1;
    for (let i = 0; i < SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(PADDING, BOARD_Y + PADDING + i * CELL);
      ctx.lineTo(PADDING + (SIZE - 1) * CELL, BOARD_Y + PADDING + i * CELL);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(PADDING + i * CELL, BOARD_Y + PADDING);
      ctx.lineTo(PADDING + i * CELL, BOARD_Y + PADDING + (SIZE - 1) * CELL);
      ctx.stroke();
    }

    /* 棋盘内边框（加粗，深棕） */
    ctx.strokeStyle = '#5a4a35';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(
      PADDING - 1,
      BOARD_Y + PADDING - 1,
      (SIZE - 1) * CELL + 2,
      (SIZE - 1) * CELL + 2,
    );

    /* 星位（天元 + 4 个角星位，共 5 个） */
    const stars: readonly (readonly [number, number])[] = [[3, 3], [3, 11], [11, 3], [11, 11], [7, 7]];
    ctx.fillStyle = '#8b6914';
    for (const [sx, sy] of stars) {
      ctx.beginPath();
      ctx.arc(PADDING + sx * CELL, BOARD_Y + PADDING + sy * CELL, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  /** 绘制坐标标注（列 A-O，行 1-15） */
  private drawCoordinates(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    ctx.fillStyle = theme.muted;
    ctx.font = `10px ${FONT_STACK}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (let i = 0; i < SIZE; i++) {
      const col = String.fromCharCode(65 + i); /* A-O */
      const row = String(i + 1); /* 1-15 */
      const cx = PADDING + i * CELL;
      const cy = BOARD_Y + PADDING + i * CELL;
      /* 顶部 / 底部 列标注（v5.2: -18 → -22，参考围棋间距） */
      ctx.fillText(col, cx, BOARD_Y + PADDING - 22);
      ctx.fillText(col, cx, BOARD_Y + PADDING + (SIZE - 1) * CELL + 22);
      /* 左侧 / 右侧 行标注 */
      ctx.fillText(row, PADDING - 22, cy);
      ctx.fillText(row, PADDING + (SIZE - 1) * CELL + 22, cy);
    }
  }

  /** 绘制所有棋子 */
  private drawStones(ctx: CanvasRenderingContext2D): void {
    for (let y = 0; y < SIZE; y++) {
      const row = this.board[y];
      if (row === undefined) continue;
      for (let x = 0; x < SIZE; x++) {
        const v = row[x];
        if (v === undefined || v === EMPTY) continue;
        this.drawStone(ctx, x, y, v);
      }
    }
  }

  /** 绘制单枚棋子（径向渐变 + 高光 + 阴影 + 落子缩放动画） */
  private drawStone(ctx: CanvasRenderingContext2D, x: number, y: number, who: number): void {
    const px = PADDING + x * CELL;
    const py = BOARD_Y + PADDING + y * CELL;
    /* 落子缩放动画：1.2x → 1.0x */
    let scale = 1.0;
    const placed = this.stoneAnims.get(`${x},${y}`);
    if (placed !== undefined) {
      const elapsed = performance.now() - placed;
      if (elapsed < STONE_ANIM_MS) {
        const t = elapsed / STONE_ANIM_MS;
        scale = 1.2 - 0.2 * t;
      }
    }
    const r = CELL * 0.42 * scale;

    /* 投影（向右下偏移） */
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    ctx.arc(px + 1.5, py + 2, r, 0, Math.PI * 2);
    ctx.fill();

    if (who === BLACK) {
      /* 黑子：深黑色径向渐变（#222 → #000） */
      const g = ctx.createRadialGradient(px - r * 0.4, py - r * 0.4, r * 0.1, px, py, r);
      g.addColorStop(0, '#444444');
      g.addColorStop(0.5, '#222222');
      g.addColorStop(1, '#000000');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      /* 顶部高光 */
      const hg = ctx.createRadialGradient(
        px - r * 0.35, py - r * 0.35, 0,
        px - r * 0.35, py - r * 0.35, r * 0.45,
      );
      hg.addColorStop(0, 'rgba(255,255,255,0.55)');
      hg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      /* 棋子轮廓 */
      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      /* 白子：白色径向渐变（#fff → #ddd） */
      const g = ctx.createRadialGradient(px - r * 0.3, py - r * 0.3, r * 0.1, px, py, r);
      g.addColorStop(0, '#ffffff');
      g.addColorStop(0.7, '#f0f0f0');
      g.addColorStop(1, '#dddddd');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      /* 顶部高光 */
      const hg = ctx.createRadialGradient(
        px - r * 0.3, py - r * 0.3, 0,
        px - r * 0.3, py - r * 0.3, r * 0.4,
      );
      hg.addColorStop(0, 'rgba(255,255,255,0.8)');
      hg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();

      /* 棋子轮廓 */
      ctx.strokeStyle = 'rgba(80,80,80,0.5)';
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  /** 绘制最后一手红色三角标记 */
  private drawLastMoveMarker(ctx: CanvasRenderingContext2D): void {
    if (this.lastMove === null) return;
    /* 胜利时不显示三角，改由金色发光边框标识 */
    if (this.winLine !== null) return;
    const lx = PADDING + this.lastMove.x * CELL;
    const ly = BOARD_Y + PADDING + this.lastMove.y * CELL;
    const r = CELL * 0.18;
    ctx.fillStyle = '#ef4444';
    ctx.strokeStyle = 'rgba(0,0,0,0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(lx, ly - r);
    ctx.lineTo(lx + r * 0.866, ly + r * 0.5);
    ctx.lineTo(lx - r * 0.866, ly + r * 0.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  /** 绘制胜利金色连线 + 棋子发光边框 */
  private drawWinLine(ctx: CanvasRenderingContext2D): void {
    if (this.winLine === null) return;

    /* 连线棋子的金色发光边框 */
    ctx.save();
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 12;
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 2.5;
    for (const p of this.winLine) {
      const px = PADDING + p.x * CELL;
      const py = BOARD_Y + PADDING + p.y * CELL;
      const r = CELL * 0.42 + 2;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();

    /* 金色连线贯穿五子 */
    const f = this.winLine[0];
    const l = this.winLine[this.winLine.length - 1];
    if (f === undefined || l === undefined) return;
    ctx.save();
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 10;
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(PADDING + f.x * CELL, BOARD_Y + PADDING + f.y * CELL);
    ctx.lineTo(PADDING + l.x * CELL, BOARD_Y + PADDING + l.y * CELL);
    ctx.stroke();
    ctx.restore();
  }

  /** 绘制走棋历史面板 */
  private drawHistoryPanel(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;

    /* 面板外框 */
    ctx.fillStyle = theme.border;
    ctx.fillRect(HISTORY_X, 0, HISTORY_W, H);
    /* 面板内部 */
    ctx.fillStyle = theme.bg;
    ctx.fillRect(HISTORY_X + 1, 1, HISTORY_W - 2, H - 2);

    const padX = 8;
    const innerX = HISTORY_X + padX;

    /* 标题 */
    ctx.fillStyle = theme.fg;
    ctx.font = `bold 12px ${FONT_STACK}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.tr(this.ctx, 'game.common.records', 'Move records'), innerX, 16);

    /* 分隔线 */
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(HISTORY_X + 6, 30);
    ctx.lineTo(HISTORY_X + HISTORY_W - 6, 30);
    ctx.stroke();

    /* 将历史按回合配对（黑 + 白） */
    const rounds: RoundRecord[] = [];
    for (let i = 0; i < this.moveHistory.length; i++) {
      const m = this.moveHistory[i];
      if (m === undefined) continue;
      if (i % 2 === 0) {
        rounds.push({ black: m });
      } else {
        const r = rounds[rounds.length - 1];
        if (r !== undefined) r.white = m;
      }
    }

    /* 计算可见行数，滚动到最新 */
    ctx.font = `11px ${FONT_STACK}`;
    const lineH = 18;
    const startY = 44;
    const totalLines = Math.floor((H - startY - 8) / lineH);
    const visibleCount = Math.max(1, totalLines);
    const startIdx = Math.max(0, rounds.length - visibleCount);

    for (let i = 0; i < visibleCount && startIdx + i < rounds.length; i++) {
      const r = rounds[startIdx + i];
      if (r === undefined) continue;
      const roundNum = startIdx + i + 1;
      const ly = startY + i * lineH + lineH / 2;
      /* 回合号 */
      ctx.fillStyle = theme.muted;
      ctx.textAlign = 'left';
      ctx.fillText(`${roundNum}.`, innerX, ly);
      /* 黑方走子 */
      ctx.fillStyle = '#e8e8e8';
      ctx.fillText(this.tr(this.ctx, 'game.gomoku.record.black', 'B {pos}', { pos: this.coordLabel(r.black) }), innerX + 20, ly);
      /* 白方走子（若已走） */
      if (r.white !== undefined) {
        ctx.fillStyle = '#bbbbbb';
        ctx.fillText(this.tr(this.ctx, 'game.gomoku.record.white', 'W {pos}', { pos: this.coordLabel(r.white) }), innerX + 64, ly);
      }
    }
  }

  /** 将棋盘坐标转为标签（列 A-O + 行 1-15） */
  private coordLabel(m: MoveRecord): string {
    return `${String.fromCharCode(65 + m.x)}${m.y + 1}`;
  }

  /** 绘制胜利/结束遮罩 */
  private drawOverlay(ctx: CanvasRenderingContext2D): void {
    if (this.currentStatus !== 'victory' && this.currentStatus !== 'gameover') return;
    const theme = this.themeTokens;
    ctx.fillStyle = 'rgba(0,0,0,0.65)';
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    /* 大字标题 */
    const title = this.tr(this.ctx, this.winner === BLACK
      ? 'game.gomoku.result.blackWin'
      : this.winner === WHITE
        ? 'game.gomoku.result.whiteWin'
        : 'game.gomoku.result.draw', this.winner === BLACK
      ? 'Black wins!'
      : this.winner === WHITE
        ? 'White wins!'
        : 'Draw');
    ctx.fillStyle = this.winner !== 0 ? '#fbbf24' : theme.fg;
    ctx.font = `bold 36px ${FONT_STACK}`;
    ctx.fillText(title, W / 2, H / 2 - 16);
    /* 提示 */
    ctx.fillStyle = theme.muted;
    ctx.font = `14px ${FONT_STACK}`;
    ctx.fillText(this.tr(this.ctx, 'game.common.restartKey', 'Press R to restart'), W / 2, H / 2 + 28);
  }
}


  /* =========================================================
     6. 样式（game-host.css 同源，内嵌注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * game-host.css — 小游戏宿主样式
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - 容器铺满窗口 body（.game-host-root）
 *   - HUD 顶部固定（分数 + 控制按钮）
 *   - 画布居中、保持比例、自适应缩放
 *   - 主题色由 CSS 变量驱动（--bg-canvas / --fg-primary / --accent-cool 等）
 *   - 暂停时画布半透明遮罩 + "Paused"提示
 *   - 隐藏滚动条（项目记忆：避免底部水平滚动条）
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */

.game-host-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  /* 玻璃配方（GlassSidePanel 同款）：垫底随主题模式/皮肤，半透明白透出坊市体验层毛玻璃 */
  background: var(--skin-pattern-image, none), color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 95%, var(--surface-solid-primary, #ffffff) 5%);
  backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  color: var(--glass-text-primary, #e8e8e8);
  font-family: var(--skin-font-body, -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif);
  overflow: hidden;
  /* 防止 iOS 弹性滚动影响游戏体验 */
  overscroll-behavior: contain;
  -webkit-user-select: none;
  user-select: none;
}

/* ============================================================
   HUD（顶部条）
   ============================================================ */

.game-host-hud {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
  background: color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 92%, var(--surface-solid-primary, #ffffff) 8%);
  border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  flex-shrink: 0;
}

/* G2 F 头：皮肤色渐细发丝线（HUD 底缘） */
.game-host-hud::after {
  content: '';
  position: absolute;
  left: var(--layout-row-pad-x, 0.875rem);
  right: var(--layout-row-pad-x, 0.875rem);
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
  pointer-events: none;
}

.game-host-hud-left {
  display: flex;
  align-items: baseline;
  gap: 0.875rem;
  min-width: 0;
  overflow: hidden;
}

/* G2 F 头：mono kicker（与宿主 .zby-page-head__kicker 同配方，自包含 fallback） */
.game-host-hud-kicker {
  font-family: var(--type-mono, var(--skin-font-mono, ui-monospace, monospace));
  font-size: 0.5625rem;
  font-weight: 700;
  letter-spacing: 0.32em;
  color: var(--deco-primary, var(--accent, #3cb371));
  white-space: nowrap;
  flex-shrink: 0;
}

.game-host-hud-title {
  /* F 语言：衬线显示字体 + 字距（UI-REMAINING-WAVES Wave G L2；--type-display 经沙箱白名单注入） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 0.875rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--glass-text-primary, #e8e8e8);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

.game-host-hud-score {
  font-size: 0.8125rem;
  font-variant-numeric: tabular-nums;
  color: var(--glass-text-secondary, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.game-host-hud-right {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

/* P4.7：按钮基座化（铁律 9）——ui-kit btn 片段内嵌快照（assets/ui-kit/btn.css），
 * 选择器扩列桥接 .game-host-hud-btn（HUD 暂停/重开/难度控件），
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：次按钮 + 小尺寸变体。 */

.btn, .game-host-hud-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .game-host-hud-btn:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .game-host-hud-btn:disabled,
.btn[disabled], .game-host-hud-btn[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 次按钮：卡片玻璃底（HUD 暂停/重开/难度选择） */
.btn--secondary, .game-host-hud-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .game-host-hud-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 尺寸变体：小尺寸（HUD 紧凑布局） */
.btn--sm, .game-host-hud-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .game-host-hud-btn{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}

/* =========================================================
   P4.7b：皮肤按钮形状钩子表（皮肤形状语言内嵌快照）
   ---------------------------------------------------------
   宿主端按钮形状 = tokens.css data-interaction-model 通用规则
   （src/shared/design-tokens/tokens.css）+ 各皮肤 Manifest extraCSS
   （src/domains/themes/skins/*.ts）；iframe 无法继承宿主样式表，
   此处内嵌按钮形状语言子集，由 MultiFileSandbox 同步的
   data-skin / data-interaction-model / data-theme-mode 属性驱动，
   使游戏按钮获得与宿主同款手绘边框/糖果胶囊 3D/像素厚度/粗描边
   错位/油墨细线/浮雕等形状语言。
   约定：
   - 顺序与宿主一致：交互模型通用规则在前，皮肤 extraCSS 在后
     （同特异性后注入者胜，island 默认态即依赖此顺序让位 toy hover）
   - 深色变体选择器用 [data-theme-mode="dark"]（iframe 同步属性，
     非宿主的 data-theme-mode-effective）
   - 皮肤自定义变量（--is-ink/--is-cream/--toy-shadow/--ra-ink/
     --neumo-dark/--neumo-light）不在沙箱注入白名单
     （sandbox-skin-var-names.ts），一律 var(..., fallback)
   - iframe 内按钮必挂 .btn 类（core.tpl 受控），钩子表只写 .btn
   - 修改需同步宿主真相源（tokens.css + skins/*.ts extraCSS）
   ========================================================= */

/* —— 1. 交互模型通用规则子集（tokens.css data-interaction-model 快照） —— */

/* 交互类统一过渡节奏 */
[data-interaction-model] .btn{
  transition:
    background var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    color var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1));
}

/* lightweight：轻反馈 — 按下微缩放 */
[data-interaction-model="lightweight"] .btn:active{
  transform: scale(var(--motion-travel-press, 0.98));
}

/* responsive：标准反馈 — hover 上浮 + 按下微缩放 */
[data-interaction-model="responsive"] .btn:hover{
  transform: translateY(var(--motion-travel-hover, -1px));
}
[data-interaction-model="responsive"] .btn:active{
  transform: translateY(0) scale(var(--motion-travel-press, 0.98));
}

/* terminal：命令行式反馈 — hover 品红下划线、按下反白、focus 品红描边
   （硬编码色 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="terminal"] .btn:hover{
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(255, 46, 136, 0.55);
}
[data-interaction-model="terminal"] .btn:active{
  color: rgba(232, 237, 246, 1);
  background: rgba(255, 46, 136, 1);
  text-decoration: none;
}
[data-interaction-model="terminal"] .btn:focus-visible{
  outline: 1px solid rgba(255, 46, 136, 1);
  outline-offset: 2px;
}

/* print：印刷批注式反馈 — hover 印刷红下划线、按下墨底反白、focus 红细描边（深色反白）。
   硬编码色一律 rgba 等价书写（皮肤契约 forbidHardcodedColors 不认裸 hex） */
[data-interaction-model="print"] .btn:hover{
  color: rgba(192, 57, 43, 1);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(192, 57, 43, 0.55);
}
[data-interaction-model="print"] .btn:active{
  color: rgba(240, 231, 211, 1);
  background: rgba(26, 26, 24, 1);
  text-decoration: none;
}
[data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(192, 57, 43, 0.5);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:hover{
  color: rgba(226, 112, 90, 1);
  text-decoration-color: rgba(226, 112, 90, 0.6);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:active{
  color: rgba(32, 31, 27, 1);
  background: rgba(240, 231, 211, 1);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(226, 112, 90, 0.6);
}

/* snap：瞬时反馈 — hover 黑白互换、按下黑底黄字、focus 2px 黑描边（深色对称反转；
   硬编码色一律 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="snap"] .btn:hover{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 255, 255, 1);
  transition-duration: 0ms;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:hover{
  background: rgba(255, 255, 255, 1);
  color: rgba(17, 17, 17, 1);
}
[data-interaction-model="snap"] .btn:active{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 195, 0, 1);
  transition-duration: 0ms;
}
[data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(17, 17, 17, 1);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(255, 255, 255, 1);
  outline-offset: 2px;
}

/* doodle：手绘反馈 — hover 蜡笔红波浪下划线 + 微旋转、按下反向回弹、focus 蜡笔虚线 */
[data-interaction-model="doodle"] .btn:hover{
  transform: rotate(-0.5deg);
  text-decoration: underline;
  text-underline-offset: 4px;
  text-decoration-style: wavy;
  text-decoration-color: rgba(232, 96, 76, 0.75);
  text-decoration-thickness: 1.5px;
}
[data-theme-mode="dark"][data-interaction-model="doodle"] .btn:hover{
  text-decoration-color: rgba(91, 168, 201, 0.8);
}
[data-interaction-model="doodle"] .btn:active{
  transform: rotate(0.5deg) scale(0.97);
  text-decoration: none;
}
[data-interaction-model="doodle"] .btn:focus-visible{
  outline: 2px dashed rgba(232, 96, 76, 0.8);
  outline-offset: 2px;
}

/* hygge：柔和暖色反馈 — hover 暖色高亮、按下轻微缩放、focus 暖色细描边 */
[data-interaction-model="hygge"] .btn:hover{
  background: color-mix(in srgb, var(--accent-warm, #C08552) 10%, transparent);
}
[data-interaction-model="hygge"] .btn:active{
  transform: scale(0.99);
}
[data-interaction-model="hygge"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-warm, #C08552) 65%, transparent);
  outline-offset: 2px;
}

/* neumorphic：同色浮雕反馈 — hover 外凸、按下内凹、focus 柔和高亮 */
[data-interaction-model="neumorphic"] .btn:hover{
  box-shadow:
    4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:active{
  box-shadow:
    inset 4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    inset -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-cool, #7A8BA6) 50%, transparent);
  outline-offset: 2px;
}

/* toy：玩具 3D 按压 — hover 抬升（底沿加深）、按下塌陷（下沉 + 底沿归零） */
[data-interaction-model="toy"] .btn:hover:not(:disabled){
  transform: translateY(-2px);
  box-shadow: 0 5px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:active:not(:disabled){
  transform: translateY(2px) scale(0.96);
  box-shadow: 0 1px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:focus-visible{
  outline: 2px solid color-mix(in srgb, var(--deco-primary, #14B8A6) 65%, transparent);
  outline-offset: 2px;
}

/* —— 2. 皮肤形状规则子集（各皮肤 Manifest extraCSS 快照，最后注入覆盖交互模型） —— */

/* doodle：手绘边框 — 不规则圆角 + 微旋转 + 蜡笔 2px 边框（hover 换蜡笔红/深色湖水蓝） */
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect){
  border-radius: 15px 8px 17px 7px / 8px 16px 7px 18px; /* 皮肤形状快照：手绘不规则圆角，无 token 语义，同 skins.css 豁免决策 */
  transform: rotate(-0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect):nth-child(even of .btn){
  transform: rotate(0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary{
  border: 2px solid rgba(43, 43, 43, 0.62);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary{
  border-color: rgba(242, 237, 227, 0.55);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(232, 96, 76, 0.85);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(91, 168, 201, 0.85);
}

/* island：糖果胶囊 + 3D 底沿（默认态让位 toy hover/active；次按钮奶油卡纸） */
[data-skin="xy-skin-official-island"] .btn:not(:hover):not(:active){
  border: 1px solid var(--is-ink, rgba(92, 74, 50, 0.55));
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}
[data-skin="xy-skin-official-island"] .btn:not(.btn--rect){
  border-radius: 999px;
}
[data-skin="xy-skin-official-island"] .btn--secondary:not(:hover):not(:active){
  background: var(--is-cream, rgba(255, 253, 245, 0.92));
  border-color: var(--is-ink, rgba(92, 74, 50, 0.55));
  color: var(--text-primary, #5C4A32);
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}

/* pixel：块状厚度 — 无描线 + 底部 3px 厚度（NES 街机按键），按压塌陷
   （皮肤自定义变量不在沙箱白名单，改引注入变量 --bg-elevated/--text-primary） */
[data-skin="xy-skin-official-pixel"] .btn{
  border: none;
  border-radius: 0;
  background: var(--bg-elevated, #FFFDF6);
  box-shadow: 0 3px 0 var(--text-primary, #1A1C2C);
  transition: none;
}
[data-skin="xy-skin-official-pixel"] .btn:active{
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--text-primary, #1A1C2C);
}

/* popart：漫画粗描边 + CMYK 三色错位叠印投影（丝网印刷注册错位，波普签名） */
[data-skin="xy-skin-official-popart"] .btn{
  border: 3px solid var(--text-primary, #1A1A1A);
  box-shadow:
    2.5px 2.5px 0 rgba(230, 57, 70, 0.5),
    -2px 2.5px 0 rgba(0, 119, 182, 0.45),
    4px 4px 0 rgba(26, 26, 26, 0.28);
}

/* red-age：油墨细线（印刷品边线） */
[data-skin="xy-skin-official-red-age"] .btn{
  border: 1px solid var(--ra-ink, rgba(31, 26, 18, 0.75));
}

/* neumorphism：无描边浮雕（外凸双阴影） */
[data-skin="xy-skin-official-neumorphism"] .btn{
  border: none;
  box-shadow:
    3px 3px 6px var(--neumo-dark, rgba(163, 177, 198, 0.55)),
    -3px -3px 6px var(--neumo-light, rgba(255, 255, 255, 0.9));
}

/* cyber-city：glitch 重影 — hover RGB 通道错位（静态 text-shadow，零动画开销） */
[data-skin="xy-skin-official-cyber-city"] .btn:hover{
  text-shadow:
    1px 0 rgba(0, 229, 255, 0.75),
    -1px 0 rgba(255, 46, 136, 0.75);
}

/* 动效偏好降级：形状钩子表的位移/旋转一律禁用（保留形状与描边） */
[data-reduce-motion="true"] .btn:hover,
[data-reduce-motion="true"] .btn:active{
  transform: none;
}

/* v5.0: 难度选择器 */
.game-host-hud-difficulty-wrap {
  display: flex;
  align-items: center;
}

.game-host-hud-difficulty-select {
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23888' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  padding-right: 1.375rem !important;
  cursor: pointer;
}

.game-host-hud-difficulty-select option {
  background: var(--bg-elevated, #1a1a1a);
  color: var(--glass-text-primary, #e8e8e8);
}

/* ============================================================
   画布容器
   ============================================================ */

.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  position: relative;
  overflow: hidden;
}

.game-host-canvas {
  display: block;
  max-width: 100%;
  max-height: 100%;
  /* canvas 由游戏引擎自绘背景（棋盘/Phaser backgroundColor），CSS 背景置透明防泛白 */
  background: transparent;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.06));
  border-radius: 0.5rem;
  box-shadow: var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
  outline: none;
  cursor: default;
  touch-action: none;
}

.game-host-canvas:focus-visible {
  border-color: var(--accent-cool, #4a9eff);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent-cool, #4a9eff) 25%, transparent), var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
}

/* ============================================================
   暂停遮罩（由 GameHost 在 paused 状态下注入）
   ============================================================ */

.game-host-root[data-status="paused"] .game-host-canvas-wrap::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.55));
  backdrop-filter: blur(4px);
  pointer-events: none;
}

.game-host-root[data-status="paused"] .game-host-canvas-wrap::before {
  content: attr(data-paused-text);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 遮罩底为皮肤感知玻璃（--glass-overlay-bg：浅色皮肤浅底 / 深色皮肤深底），
     文字跟随皮肤明暗取 --glass-text-primary，任意皮肤 × 明暗下恒可读 */
  color: var(--glass-text-primary, #f1f5f9);
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 1.125rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.6));
  padding: 0.625rem 1.25rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.1));
  z-index: 1;
  pointer-events: none;
}

/* ============================================================
   游戏结束 / 胜利覆盖层
   ============================================================ */

.game-host-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4, 0.875rem);
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.7));
  backdrop-filter: blur(6px);
  z-index: 5;
  pointer-events: auto;
}

.game-host-overlay-title {
  /* F 语言：衬线显示字体 + 页面显示档字号 + 编辑头同款字距（Wave G L2） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: calc(var(--layout-display, 2.125rem) * 0.7);
  font-weight: 700;
  color: var(--glass-text-primary, #e8e8e8);
  letter-spacing: 0.14em;
}

.game-host-overlay-title--win {
  color: var(--accent-warm, #ffb04a);
}

.game-host-overlay-title--lose {
  color: var(--danger, #ff6b8a);
}

.game-host-overlay-msg {
  font-size: 0.875rem;
  color: var(--glass-text-secondary, #888);
  text-align: center;
  max-width: 80%;
}

.game-host-overlay-actions {
  display: flex;
  gap: 0.625rem;
}

/* P4.7：.game-host-overlay-btn 系列已删除（无 JS 创建者，历史死样式）；
 * 覆盖层操作统一走 HUD 重新开始按钮（game-host-hud-btn，已基座化）。 */

/* ============================================================
   响应式（窄窗口时缩小 HUD）
   ============================================================ */

@media (max-width: 480px) {
  .game-host-hud {
    padding: 0.375rem 0.625rem;
    gap: 0.5rem;
  }
  .game-host-hud-title {
    font-size: 0.8125rem;
  }
  .game-host-hud-score {
    font-size: 0.75rem;
  }
  .game-host-hud-btn {
    font-size: 0.6875rem;
    padding: 0.3125rem 0.5rem;
  }
  .game-host-canvas-wrap {
    padding: 0.375rem;
  }
}

/* ============================================================
   无障碍：减少动效
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  .game-host-hud-btn {
    transition: none;
  }
}
/* 动态创建元素类名锚点（CSS_CLASS_MISSING 校验 + 结构契约） */
.game-host-loading-overlay {}
.game-host-spinner {}
.game-host-error-overlay {}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'gomoku-game-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  let host: GomokuHost | null = null;

  /** 挂载游戏：创建 Host 并启动（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    injectAppStyle(ctx.container);
    host = new GomokuHost({
      gameId: 'game-gomoku',
      width: 704,
      height: 584,
    });
    void host.mount(ctx).catch((e: unknown) => {
      console.error('[gomoku] mount failed:', e);
    });
  }

  /** 卸载游戏：清理监听 / 定时器 / DOM */
  function unmount(): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: { nameKey: 'game.gomokuName', nameFallback: 'Gomoku' },
      t: createTranslator(),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__gomokuApp = {
    unmount,
  };
})();
