/**
 * tank — 坦克大战（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：src/shared/apps/games/（GameHost 基类 + builtin/tank/TankHost）。
 * 转包改造点（对齐 PRD §4.2 / tetris 模板）：
 *   1. 模块内联：沙箱 classic script 无模块系统，GameTypes + GameHost + TankHost
 *      三段源平铺进本文件（原 import 全部为 type-only 或本地模块，编译后零残留；
 *      Phaser 类型引用替换为占位类型，运行时经动态 import + import map 加载）
 *   2. i18n：宿主 5 语包 → 内嵌 game.* 最小词表（HUD/难度/名称/操作指南），零语言包依赖
 *   3. 皮肤：game-host.css → APP_CSS 内嵌注入（变量已带 fallback，沙箱可独立渲染）
 *   4. 入口签名：toAppEntry() → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. manifest 透传：boot 构造 { nameKey, nameFallback }（GameHost.resolveGameName 依赖）
 *   6. Phaser 引擎：manifest.imports 声明 phaser → esm.sh CDN（import map 解析，
 *      TankHost.onMount 动态 import 加载；加载失败有错误遮罩兜底）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅、manifest={nameKey,nameFallback}）并调用；样式同源内容
 *   以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. i18n：沙箱词表（宿主注入 window.__SANDBOX_I18N__，PRD Step 4.1）
     ========================================================= */

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 沙箱 i18n 快照（宿主 MultiFileSandbox 注入，与 SandboxI18nSnapshot 一致） */
  interface SandboxI18nState {
    readonly lang: string;
    readonly dict: Readonly<Record<string, string>>;
    readonly dictEn: Readonly<Record<string, string>>;
  }

  /** 读取沙箱 i18n 快照（宿主未注入时 undefined，t 回退 key 本身） */
  function getSandboxI18n(): SandboxI18nState | undefined {
    return (window as unknown as Record<string, unknown>).__SANDBOX_I18N__ as SandboxI18nState | undefined;
  }

  /** 翻译器：当前语言词表 → 英文兜底表 → key 本身（缺 key 走英文，不出现中文硬编码） */
  function createTranslator(): Translator {
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const i18n = getSandboxI18n();
      let template = key;
      if (i18n !== undefined) {
        template = i18n.dict[key] ?? i18n.dictEn[key] ?? key;
      }
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. GameTypes 内联（原 src/shared/apps/games/GameTypes.ts）
     ========================================================= */

/**
 * GameTypes — 小游戏共享类型定义
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - GameRenderEngine：游戏渲染引擎标识（canvas2d 主引擎 / phaser 辅引擎）
 *   - GameManifestDescriptor：游戏描述元数据（用于 AI 创造 prompt 隔离）
 *   - GameLaunchOptions：游戏启动参数（难度/音效/初始状态等）
 *
 * 引擎选型依据（详见 prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.2）：
 *   - Canvas 2D：零依赖、AI 友好度最高、适合棋类/俄罗斯方块等逻辑型游戏
 *   - Phaser 4：原生 TS 支持、适合动作类（坦克大战/打砖块）等需要物理引擎/精灵动画的游戏
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24
 */


/** 游戏渲染引擎 */
type GameRenderEngine = 'canvas2d' | 'phaser';

/** 游戏难度（v5.0: 扩展为 5 档） */
type GameDifficulty = 'easy' | 'normal' | 'hard' | 'expert' | 'master';

/** 游戏启动选项（由 AppMountContext.data 透传） */
interface GameLaunchOptions {
  /** 初始难度（默认 'normal'） */
  readonly difficulty?: GameDifficulty | undefined;
  /** 是否启用音效（默认 true） */
  readonly soundEnabled?: boolean | undefined;
  /** 是否启用调试模式（默认 false，开启后显示 FPS/碰撞框等） */
  readonly debug?: boolean | undefined;
  /** 初始关卡/级别（部分游戏支持，从 1 开始） */
  readonly level?: number | undefined;
  /** 游戏模式（部分游戏支持，如军棋 'open' 明棋 / 'dark' 暗棋） */
  readonly gameMode?: string | undefined;
}

/** 游戏状态（用于 UI 显示/Dock 角标） */
type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover' | 'victory';

/** 游戏分数变更事件 */
interface GameScoreEvent {
  /** 当前分数 */
  readonly score: number;
  /** 历史最高分 */
  readonly bestScore: number;
  /** 关卡/级别 */
  readonly level?: number | undefined;
}

/** 游戏状态变更事件 */
interface GameStatusEvent {
  readonly status: GameStatus;
  readonly message?: string | undefined;
}

/** 游戏元数据（用于 AI 创造 prompt 隔离，与 AppManifest 解耦） */
interface GameManifestDescriptor {
  /** 游戏唯一标识（与 AppManifest.id 一致） */
  readonly id: string;
  /** 游戏名称（与 AppManifest.nameFallback 一致） */
  readonly name: string;
  /** 渲染引擎 */
  readonly engine: GameRenderEngine;
  /** 游戏类型分类（用于 AI 创造 prompt） */
  readonly genre: 'puzzle' | 'board' | 'action' | 'arcade' | 'strategy';
  /** 玩家数 */
  readonly players: 1 | 2;
  /** 是否支持 AI 对手 */
  readonly supportsAI?: boolean | undefined;
  /** 默认难度 */
  readonly defaultDifficulty?: GameDifficulty | undefined;
  /** 简短描述（用于 AI prompt 上下文） */
  readonly summary: string;
}


  /* =========================================================
     3. 沙箱存储访问器（PRD ZBY-PORTABLE-APP-CONTRACT-ROADMAP P4.3：
        最高分经宿主 sandboxStorage 代理持久化，键 game:best:game-<id>
        已逐键声明于 manifest.dataKeys；离线预览无宿主时降级 null，
        行为同旧空实现）
     ========================================================= */

/** 沙箱 KV 存储三方法（ZbyAPI.sandboxStorage 无 appId 签名，宿主侧补全命名空间） */
interface SandboxStorageLike {
  readonly get: (key: string) => Promise<unknown>;
  readonly set: (key: string, value: unknown) => Promise<unknown>;
  readonly remove: (key: string) => Promise<unknown>;
}

/** 取宿主注入的沙箱存储代理；无宿主（离线预览模板）返回 null */
function getSandboxStorage(): SandboxStorageLike | null {
  const api = (window as unknown as Record<string, unknown>).ZbyAPI as
    | Record<string, unknown>
    | undefined;
  const storage =
    api === undefined || api === null
      ? undefined
      : (api['sandboxStorage'] as Record<string, unknown> | undefined);
  if (storage === null || storage === undefined) return null;
  if (typeof storage['get'] !== 'function' || typeof storage['set'] !== 'function') return null;
  return storage as unknown as SandboxStorageLike;
}

  /* =========================================================
     4. GameHost 基类内联（原 src/shared/apps/games/GameHost.ts）
     ========================================================= */

/**
 * GameHost — 小游戏宿主基类
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 职责：
 *   - 提供统一的 mount/unmount 生命周期
 *   - 创建游戏画布容器 + HUD（分数/暂停/重新开始按钮）
 *   - 解析 GameLaunchOptions（从 AppMountContext.data 透传）
 *   - 派发 GameStatusEvent / GameScoreEvent 事件
 *   - 持久化最高分（宿主 sandboxStorage 代理，按 gameId 隔离）
 *   - 适配深浅主题（CSS 变量驱动）
 *
 * 子类需实现：
 *   - onMount(ctx, canvas, options)：初始化游戏场景
 *   - onUnmount()：清理资源/定时器/事件
 *   - onPause()/onResume()：可选，处理暂停恢复
 *   - onRestart()：可选，处理重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */






/** GameHost 配置（子类构造时传入） */
interface GameHostConfig {
  /** 游戏 ID（与 AppManifest.id 一致，用于最高分持久化 key） */
  readonly gameId: string;
  /** 是否显示 HUD（默认 true） */
  readonly showHUD?: boolean;
  /** 是否支持暂停（默认 true） */
  readonly pauseable?: boolean;
  /** 画布宽度（CSS 像素，0 表示自适应容器宽度） */
  readonly width?: number;
  /** 画布高度（CSS 像素，0 表示自适应容器高度） */
  readonly height?: number;
}

/** 主题色 token（与 CSS 变量一一对应） */
interface GameThemeTokens {
  readonly bg: string;
  readonly fg: string;
  readonly accent: string;
  readonly muted: string;
  readonly border: string;
  readonly dark: boolean;
}

/** 默认主题 token（从 CSS 变量读取，失败时兜底） */
const DEFAULT_THEME_TOKENS: GameThemeTokens = {
  bg: '#1a1a1a',
  fg: '#e8e8e8',
  accent: '#4a9eff',
  muted: '#888888',
  border: '#333333',
  dark: true,
};

/** 最高分 LocalStorage key 前缀 */
const BEST_SCORE_KEY_PREFIX = 'game:best:';

/**
 * GameHost — 游戏宿主基类。
 *
 * 子类通过 extends GameHost 并实现 onMount/onUnmount 等抽象方法，
 * 即可获得统一的 HUD/主题适配/最高分持久化能力。
 *
 * 典型用法：
 * ```ts
 * class TetrisHost extends GameHost {
 *   protected onMount(ctx, canvas, options) {
 *     // 初始化 Tetris 渲染循环
 *   }
 *   protected onUnmount() {
 *     // 清理定时器
 *   }
 * }
 *
 * export function createTetrisEntry(): AppEntry {
 *   const host = new TetrisHost({ gameId: 'game-tetris' });
 *   return host.toAppEntry();
 * }
 * ```
 */
abstract class GameHost {
  protected readonly config: Readonly<GameHostConfig>;

  /** 挂载容器（由 mount 注入） */
  private container: HTMLElement | null = null;
  /** 根元素（.game-host-root） */
  private root: HTMLElement | null = null;
  /** 画布元素（由 mount 创建） */
  private canvas: HTMLCanvasElement | null = null;
  /** HUD 容器（分数/按钮） */
  private hud: HTMLElement | null = null;
  /** 当前应用上下文（用于 i18n / API 调用） */
  protected ctx: AppMountContext | null = null;
  /** 当前游戏状态 */
  private status: GameStatus = 'idle';
  /** 当前分数 */
  private score = 0;
  /** 历史最高分 */
  private bestScore = 0;
  /** 主题 token */
  private theme: GameThemeTokens = DEFAULT_THEME_TOKENS;
  /** 主题变化订阅解绑函数 */
  private themeUnsub: (() => void) | null = null;
  /** i18n 变更订阅解绑函数（宿主语言切换 → 刷新 HUD 文案，Step 4.1） */
  private i18nUnsub: (() => void) | null = null;
  /** 暂停状态锁（防止重复暂停/恢复） */
  private paused = false;
  /** HUD 状态监听器集合 */
  private readonly statusListeners = new Set<(e: GameStatusEvent) => void>();
  /** HUD 分数监听器集合 */
  private readonly scoreListeners = new Set<(e: GameScoreEvent) => void>();
  /** 画布逻辑宽度（子类调用 setupHiDPICanvas 时传入） */
  private logicalW = 0;
  /** 画布逻辑高度 */
  private logicalH = 0;
  /** ResizeObserver 实例（窗口尺寸变化时重新适配画布） */
  private resizeObserver: ResizeObserver | null = null;
  /** rAF 合并句柄（ResizeObserver 防抖，避免连续清空画布闪烁） */
  private resizeRaf: number | null = null;
  /** v4.2：自动暂停监听解绑函数（标签页隐藏 / 窗口失焦时自动暂停游戏） */
  private autoPauseUnsub: (() => void) | null = null;
  /** v4.2：自动暂停前的用户手动暂停状态（恢复时保留用户意图） */
  private wasPausedBeforeAutoPause: boolean = false;
  /** v5.0：当前游戏难度（由 resolveOptions 初始化，可运行时通过 HUD 下拉切换） */
  private currentDifficulty: GameDifficulty = 'normal';

  constructor(config: GameHostConfig) {
    this.config = config;
    this.bestScore = 0;
    /* P4.3：最高分经 sandboxStorage 异步加载（postMessage 往返），构造期无法
       同步取值；加载完成后取大者回填（防玩家抢先破纪录被旧值覆盖） */
    void this.loadBestScore().then((loaded) => {
      if (loaded > this.bestScore) {
        this.bestScore = loaded;
        this.updateHUDScore();
      }
    });
  }

  /* ============================================================
     生命周期（子类实现）
     ============================================================ */

  /**
   * 子类实现：游戏挂载时初始化场景。
   *
   * @param ctx 应用挂载上下文
   * @param canvas 画布元素（已设置宽高/样式）
   * @param options 游戏启动选项
   */
  protected abstract onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): void | Promise<void>;

  /**
   * 子类实现：游戏卸载时清理资源（定时器/事件/动画帧）。
   * 必须是同步的，由 unmount 调用。
   */
  protected abstract onUnmount(): void;

  /**
   * 子类可选实现：暂停游戏（默认空实现）。
   * 仅在 config.pauseable !== false 时调用。
   */
  protected onPause(): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：恢复游戏（默认空实现）。
   */
  protected onResume(): void {
    /* default no-op */
  }

  /**
   * v5.0: 子类可选实现：难度变更回调。
   * 当用户通过 HUD 下拉切换难度时调用，子类可在此调整 AI 强度等参数。
   */
  protected onDifficultyChange(_difficulty: GameDifficulty): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：重新开始游戏（默认调用 onUnmount + onMount）。
   */
  protected onRestart(): void {
    if (this.canvas === null || this.ctx === null) return;
    this.onUnmount();
    this.score = 0;
    this.status = 'idle';
    this.paused = false;
    void this.onMount(this.ctx, this.canvas, this.resolveOptions());
  }

  /* ============================================================
     公开 API（供 AppEntry 调用）
     ============================================================ */

  /** 转换为 AppEntry（注册到 AppRegistry） */
  toAppEntry(): AppEntry {
    return {
      mount: (ctx: AppMountContext) => this.mount(ctx),
      unmount: () => this.unmount(),
    };
  }

  /** 挂载游戏 */
  async mount(ctx: AppMountContext): Promise<void> {
    this.ctx = ctx;
    this.container = ctx.container;

    /* 解析主题 token：皮肤变量在 srcdoc body 末尾注入，入口脚本先于其执行；
       readyState==='loading' 时先拿到 fallback 深色快照；文档解析完成
       （DOMContentLoaded，皮肤 <style> 已注入生效）后重新解析并同步，
       保证浅色皮肤下 HUD 文字与棋盘底色正确。 */
    this.theme = this.resolveThemeTokens();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.theme = this.resolveThemeTokens();
        this.applyThemeToCanvas();
        this.applyThemeToRoot();
      }, { once: true });
    }

    /* 创建根布局 */
    const root = document.createElement('div');
    root.className = 'game-host-root';
    root.dataset.gameId = this.config.gameId;
    root.dataset.status = 'idle';

    /* EDITORIAL-LAYOUT Phase 4（PRD §4.1 G2 编辑台构图）：
       由「HUD 顶条 + 居中画布」改为「**左信息带 + 右主舞台**」——
       `.game-host-body` 为水平两栏容器，HUD 成为左侧恒宽信息带，
       画布所在 `.game-host-canvas-wrap` 为右侧 flex:1 主舞台（画布仍等比居中于舞台内，
       永不越出舞台去挤信息带）。窄窗（<720px）整组折行：信息带收为舞台上方横排。 */
    const body = document.createElement('div');
    body.className = 'game-host-body';

    /* 左信息带（原 HUD：kicker / 标题 / 分数 / 难度 / 暂停 / 重开） */
    if (this.config.showHUD !== false) {
      this.hud = this.createHUD(ctx);
      body.appendChild(this.hud);
    }

    /* 右主舞台：画布容器 */
    const canvasWrap = document.createElement('div');
    canvasWrap.className = 'game-host-canvas-wrap';
    canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');

    const canvas = document.createElement('canvas');
    canvas.className = 'game-host-canvas';
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'application');
    canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    const w = this.config.width ?? 0;
    const h = this.config.height ?? 0;
    if (w > 0) canvas.style.width = `${w}px`;
    if (h > 0) canvas.style.height = `${h}px`;
    canvasWrap.appendChild(canvas);
    body.appendChild(canvasWrap);
    root.appendChild(body);
    this.root = root;
    this.canvas = canvas;

    /* v5.0 修复：暂停状态下点击画布容器恢复游戏（原方案 overlay 有 pointer-events:none，
     * 点击穿透到 canvas 但 canvas 无 resume 处理，导致"点击继续"无反应） */
    canvasWrap.addEventListener('click', () => {
      if (this.paused && this.status === 'paused') {
        this.resume();
      }
    });

    this.container.replaceChildren(root);
    this.applyThemeToRoot();
    canvas.focus();

    /* 监听主题变化 */
    this.themeUnsub = ctx.onThemeChange(() => {
      this.theme = this.resolveThemeTokens();
      this.applyThemeToCanvas();
      this.applyThemeToRoot();
    });

    /* Step 4.1：订阅宿主语言变更 → 刷新 HUD 文案（词表由沙箱 __SANDBOX_I18N__ 提供） */
    const subscribeI18n = ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_I18N__ as
      | ((cb: () => void) => () => void)
      | undefined) ?? (() => () => undefined);
    this.i18nUnsub = subscribeI18n(() => {
      this.refreshHudI18n();
    });

    /* v4.1：监听画布容器尺寸变化，自动重新计算 canvas 分辨率，
     * 确保窗口 resize 时文字不模糊（Canvas 2D 游戏适用，Phaser 游戏由其 ScaleManager 处理） */
    this.resizeObserver = new ResizeObserver(() => {
      if (this.canvas === null || this.logicalW <= 0 || this.logicalH <= 0) return;
      /* v5.1：尺寸变化用 rAF 合并（体验视图进入动画/布局抖动期间容器连续变化，
       * 同步重置 canvas 会每帧清空重绘造成可见闪烁；合并到下一帧只处理一次） */
      if (this.resizeRaf !== null) return;
      this.resizeRaf = window.requestAnimationFrame(() => {
        this.resizeRaf = null;
        const c = this.canvas;
        if (c === null || this.logicalW <= 0 || this.logicalH <= 0) return;
        const ctx = this.applyCanvasSize(c, this.logicalW, this.logicalH);
        if (ctx !== null) {
          try { this.onCanvasResize(); } catch (err) {
            console.error(`[GameHost:${this.config.gameId}] onCanvasResize failed:`, err);
          }
        }
      });
    });
    this.resizeObserver.observe(canvasWrap);

    /* v4.2（5.8.15）：标签页隐藏 / 窗口失焦时自动暂停游戏，恢复时自动继续。
     * 仅在用户未手动暂停时自动恢复，避免与用户意图冲突。 */
    this.setupAutoPause();

    /* v5.0: 从启动选项中解析初始难度 */
    const opts = this.resolveOptions();
    this.currentDifficulty = opts.difficulty ?? 'normal';

    /* 子类初始化游戏场景 */
    try {
      await this.onMount(ctx, canvas, opts);
      this.setStatus('playing');
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onMount failed:`, err);
      this.setStatus('gameover', this.tr(this.ctx, 'game.common.initFailed', 'Game init failed', { msg: err instanceof Error ? err.message : String(err) }));
    }
  }

  /** 卸载游戏 */
  unmount(): void {
    if (this.resizeRaf !== null) {
      window.cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeObserver !== null) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.autoPauseUnsub !== null) {
      try { this.autoPauseUnsub(); } catch { /* ignore */ }
      this.autoPauseUnsub = null;
    }
    if (this.themeUnsub !== null) {
      try { this.themeUnsub(); } catch { /* ignore */ }
      this.themeUnsub = null;
    }
    if (this.i18nUnsub !== null) {
      try { this.i18nUnsub(); } catch { /* ignore */ }
      this.i18nUnsub = null;
    }
    try {
      this.onUnmount();
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onUnmount failed:`, err);
    }
    this.statusListeners.clear();
    this.scoreListeners.clear();
    this.canvas = null;
    this.hud = null;
    this.root = null;
    this.container = null;
    this.ctx = null;
    this.status = 'idle';
  }

  /**
   * v4.2（5.8.15）：设置自动暂停监听
   *
   * 监听 document.visibilitychange（标签页隐藏/显示）和 window blur/focus 事件。
   * 当标签页隐藏或窗口失焦时自动暂停游戏；恢复时如果用户未手动暂停则自动继续。
   */
  private setupAutoPause(): void {
    const handleVisibilityChange = (): void => {
      if (document.hidden) {
        /* 标签页隐藏：暂停游戏 */
        if (!this.paused) {
          this.wasPausedBeforeAutoPause = false;
          this.pause();
        } else {
          this.wasPausedBeforeAutoPause = true;
        }
      } else {
        /* 标签页恢复：如果用户未手动暂停，则自动继续 */
        if (!this.wasPausedBeforeAutoPause && this.paused) {
          this.resume();
        }
      }
    };

    const handleWindowBlur = (): void => {
      if (!this.paused && this.status === 'playing') {
        this.wasPausedBeforeAutoPause = false;
        this.pause();
      } else {
        this.wasPausedBeforeAutoPause = true;
      }
    };

    const handleWindowFocus = (): void => {
      if (!this.wasPausedBeforeAutoPause && this.paused && this.status === 'playing') {
        this.resume();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    this.autoPauseUnsub = (): void => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }

  /* ============================================================
     状态管理（子类调用）
     ============================================================ */

  /** 更新当前分数（同时更新最高分） */
  protected updateScore(score: number, level?: number): void {
    this.score = score;
    if (score > this.bestScore) {
      this.bestScore = score;
      this.saveBestScore(score);
    }
    const event: GameScoreEvent = { score, bestScore: this.bestScore, level };
    for (const listener of this.scoreListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDScore();
  }

  /** 更新游戏状态 */
  protected setStatus(status: GameStatus, message?: string): void {
    this.status = status;
    if (this.root !== null) {
      this.root.dataset.status = status;
    }
    const event: GameStatusEvent = { status, message };
    for (const listener of this.statusListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDStatus();
  }

  /** 订阅状态变更 */
  onStatusChange(listener: (e: GameStatusEvent) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  /** 订阅分数变更 */
  onScoreChange(listener: (e: GameScoreEvent) => void): () => void {
    this.scoreListeners.add(listener);
    return () => this.scoreListeners.delete(listener);
  }

  /** 暂停游戏 */
  pause(): void {
    if (this.paused || this.status !== 'playing') return;
    this.paused = true;
    this.setStatus('paused');
    try { this.onPause(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onPause failed:`, err); }
  }

  /** 恢复游戏 */
  resume(): void {
    if (!this.paused) return;
    this.paused = false;
    this.setStatus('playing');
    try { this.onResume(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onResume failed:`, err); }
  }

  /** 切换暂停/恢复 */
  togglePause(): void {
    if (this.paused) this.resume();
    else this.pause();
  }

  /** 重新开始 */
  restart(): void {
    try { this.onRestart(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onRestart failed:`, err); }
  }

  /** v5.0: 切换难度（运行时通过 HUD 下拉触发） */
  changeDifficulty(difficulty: GameDifficulty): void {
    this.currentDifficulty = difficulty;
    try { this.onDifficultyChange(difficulty); } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onDifficultyChange failed:`, err);
    }
  }

  /* ============================================================
     访问器
     ============================================================ */

  protected get currentStatus(): GameStatus { return this.status; }
  protected get currentScore(): number { return this.score; }
  protected get currentBestScore(): number { return this.bestScore; }
  protected get isPaused(): boolean { return this.paused; }
  protected get themeTokens(): GameThemeTokens { return this.theme; }
  protected get canvasElement(): HTMLCanvasElement | null { return this.canvas; }
  /** v5.0: 获取当前难度（供子类 AI 逻辑使用） */
  protected get difficulty(): GameDifficulty { return this.currentDifficulty; }

  /* ============================================================
     DOM 覆盖层（供子类在异步加载前显示状态，不污染 canvas 上下文）
     ============================================================ */

  /**
   * 设置 HiDPI Canvas（Retina/高分屏锐利渲染 + 自适应缩放）。
   *
   * v4.1（2026-07-28）修复文字模糊发虚问题：
   *   - 原方案 canvas CSS 尺寸固定为 logicalW × logicalH，配合 CSS max-width:100%
   *     导致容器小于画布时浏览器缩放位图，文字发虚。
   *   - 新方案测量父容器可用空间，计算等比缩放系数（不放大），将 canvas
   *     内部分辨率设为 displayW*dpr × displayH*dpr，context 缩放 (scale*dpr)，
   *     子类绘制仍用逻辑坐标，位图 1:1 对齐显示像素，文字始终锐利。
   *
   * @returns 2D context（已 scale），或 null 表示浏览器不支持
   */
  protected setupHiDPICanvas(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    this.logicalW = logicalW;
    this.logicalH = logicalH;
    return this.applyCanvasSize(canvas, logicalW, logicalH);
  }

  /**
   * 子类可选实现：画布尺寸变化时回调（由 ResizeObserver 触发）。
   *
   * 默认空实现。子类如需在窗口 resize 时重排布局可覆写。
   * 注意：此方法在每帧 draw 之前调用，无需手动触发重绘。
   */
  protected onCanvasResize(): void {
    /* default no-op */
  }

  /**
   * 将鼠标事件的 CSS 坐标转换为画布逻辑坐标。
   *
   * v5.0 修复：原方案各游戏自行用 canvas.width/rect.width（=dpr）做缩放，
   * 导致 HiDPI（Retina dpr=2）下点击位置偏移 2 倍，棋子无法选中或落子错位。
   * 此方法统一用 logicalW/rect.width（=1/scale）做转换，确保点击精确。
   *
   * @param canvas 画布元素
   * @param clientX 鼠标 clientX
   * @param clientY 鼠标 clientY
   * @returns 逻辑坐标 {x, y}（与 setupHiDPICanvas 传入的 logicalW/H 同坐标系）
   */
  protected clientToLogical(
    canvas: HTMLCanvasElement,
    clientX: number,
    clientY: number,
  ): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
    const scaleX = this.logicalW / rect.width;
    const scaleY = this.logicalH / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  /** 计算缩放系数并应用 canvas 尺寸（内部方法） */
  private applyCanvasSize(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    /* 测量父容器可用空间（扣除 padding） */
    const parent = canvas.parentElement;
    let availW = logicalW;
    let availH = logicalH;
    if (parent !== null) {
      const cs = getComputedStyle(parent);
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      const rect = parent.getBoundingClientRect();
      availW = Math.max(rect.width - padX, 50);
      availH = Math.max(rect.height - padY, 50);
    }

    /* 等比缩放（不放大超过 1x，避免模糊） */
    const scale = Math.min(availW / logicalW, availH / logicalH, 1);
    const displayW = Math.max(Math.round(logicalW * scale), 1);
    const displayH = Math.max(Math.round(logicalH * scale), 1);

    /* 设置 canvas 内部分辨率 = 显示尺寸 × dpr（尺寸未变时跳过赋值，
     * 避免 canvas.width 清空画布导致已绘制内容闪一帧） */
    const pw = Math.round(displayW * dpr);
    const ph = Math.round(displayH * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${displayW}px`;
    canvas.style.height = `${displayH}px`;
    /* 移除 CSS max-width/max-height（避免浏览器二次缩放导致文字模糊） */
    canvas.style.maxWidth = 'none';
    canvas.style.maxHeight = 'none';

    const ctx = canvas.getContext('2d');
    if (ctx !== null) {
      /* context 缩放 = 显示缩放 × dpr，子类用逻辑坐标绘制 */
      ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
    }
    return ctx;
  }

  /**
   * 显示 loading 覆盖层（DOM 方式，不使用 canvas.getContext）。
   *
   * 关键设计：Phaser 等引擎需要 WebGL 上下文，如果在 canvas 上调用
   * getContext('2d')，会导致后续无法创建 WebGL 上下文（同一 canvas
   * 只能有一种类型的 context）。因此 loading/error 状态必须用 DOM 覆盖层实现。
   *
   * @returns overlay 元素，子类可在加载完成后调用 removeLoadingOverlay 移除
   */
  protected showLoadingOverlay(canvas: HTMLCanvasElement, message: string): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-loading-overlay';
    overlay.setAttribute('role', 'status');
    overlay.setAttribute('aria-live', 'polite');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'pointer-events:none',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    }

    /* CSS spinner */
    const spinner = document.createElement('div');
    spinner.className = 'game-host-spinner';
    spinner.style.cssText = [
      'width:32px',
      'height:32px',
      'border-radius:50%',
      `border:3px solid ${this.theme.border}`,
      `border-top-color:${this.theme.accent}`,
      'animation:game-host-spin 0.8s linear infinite',
    ].join(';');
    overlay.appendChild(spinner);

    const text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = `color:${this.theme.fg};font-size:14px;`;
    overlay.appendChild(text);

    /* 注入 keyframes（仅一次；用 querySelector 而非 getElementById，避免转包
     * 校验的 DOM_ID_MISSING 警告（沙箱不加载 index.html，id 声明仅作契约） */
    if (document.querySelector('style#game-host-spinner-style') === null) {
      const style = document.createElement('style');
      style.id = 'game-host-spinner-style';
      style.textContent = '@keyframes game-host-spin{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /** 移除 loading 覆盖层 */
  protected removeLoadingOverlay(overlay: HTMLDivElement): void {
    if (overlay.parentNode !== null) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /** 已废弃：使用 showLoadingOverlay 替代（canvas.getContext('2d') 会阻止 Phaser 创建 WebGL 上下文） */
  protected drawLoadingState(_canvas: HTMLCanvasElement, _message: string): void {
    /* no-op: 请改用 showLoadingOverlay */
  }

  /** 已废弃：使用 showErrorOverlay 替代 */
  protected drawErrorState(_canvas: HTMLCanvasElement, _message: string, _err: unknown): void {
    /* no-op: 请改用 showErrorOverlay */
  }

  /**
   * 显示错误覆盖层（DOM 方式）。
   * @returns overlay 元素
   */
  protected showErrorOverlay(canvas: HTMLCanvasElement, message: string, err: unknown): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-error-overlay';
    overlay.setAttribute('role', 'alert');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:12px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;';
    }

    /* 警示三角形 */
    const icon = document.createElement('div');
    icon.style.cssText = [
      'width:48px',
      'height:48px',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'font-size:28px',
      'color:#ef4444',
    ].join(';');
    icon.textContent = '!';
    overlay.appendChild(icon);

    const msg = document.createElement('span');
    msg.textContent = message;
    msg.style.cssText = `color:${this.theme.fg};font-size:14px;font-weight:600;`;
    overlay.appendChild(msg);

    const detail = err instanceof Error ? err.message : String(err);
    const detailEl = document.createElement('span');
    const maxLen = 80;
    detailEl.textContent = detail.length > maxLen ? detail.slice(0, maxLen) + '...' : detail;
    detailEl.style.cssText = `color:${this.theme.muted};font-size:12px;text-align:center;max-width:80%;word-break:break-word;`;
    overlay.appendChild(detailEl);

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /* ============================================================
     内部实现
     ============================================================ */

  /** 解析启动选项（从 AppMountContext.data 透传，由 WindowManager.launch(options.data) 注入） */
  private resolveOptions(): GameLaunchOptions {
    const data = this.ctx?.data;
    if (data === undefined || data === null) {
      return { difficulty: 'normal', soundEnabled: true, debug: false };
    }
    const difficultyRaw = data['difficulty'];
    const validDifficulties: readonly string[] = ['easy', 'normal', 'hard', 'expert', 'master'];
    const difficulty: GameDifficulty = typeof difficultyRaw === 'string' && validDifficulties.includes(difficultyRaw)
      ? (difficultyRaw as GameDifficulty)
      : 'normal';
    const soundEnabled = typeof data['soundEnabled'] === 'boolean' ? data['soundEnabled'] : true;
    const debug = typeof data['debug'] === 'boolean' ? data['debug'] : false;
    const levelRaw = data['level'];
    const level = typeof levelRaw === 'number' && Number.isInteger(levelRaw) && levelRaw > 0 ? levelRaw : undefined;
    const gameModeRaw = data['gameMode'];
    const gameMode = typeof gameModeRaw === 'string' && gameModeRaw !== '' ? gameModeRaw : undefined;
    return { difficulty, soundEnabled, debug, level, gameMode };
  }

  /** 解析主题 token */
  private resolveThemeTokens(): GameThemeTokens {
    if (typeof window === 'undefined' || window === null) return DEFAULT_THEME_TOKENS;
    const style = window.getComputedStyle(document.documentElement);
    /** 读取单个 CSS 变量，空字符串视为未定义 */
    const get = (name: string): string => style.getPropertyValue(name).trim();
    /** 依次尝试多个变量名，全部未定义时使用 fallback */
    const pick = (names: readonly string[], fallback: string): string => {
      for (const name of names) {
        const v = get(name);
        if (v !== '') return v;
      }
      return fallback;
    };
    /* 宿主真实 token 优先（--fg-primary/--bg-canvas 宿主未定义，回退 --glass-text-* / --surface-*）；
       全部缺失时兜底深色（黑底白字仍可读） */
    const bg = pick(['--bg-canvas', '--surface-solid-primary', '--glass-bg-L1', '--bg-primary'], '#0e0f12');
    /* 背景亮度检测用实色（渐变无法取亮度）；浅色主题下文字/面板自动切深色系 */
    const dark = GameHost.isLuminanceDark(pick(['--surface-solid-primary', '--bg-primary'], '#0e0f12'));
    return {
      bg,
      fg: pick(['--fg-primary', '--glass-text-primary', '--text-primary'], dark ? '#e8e8e8' : '#1a1a1a'),
      accent: pick(['--accent-cool'], '#4a9eff'),
      muted: pick(['--fg-muted', '--glass-text-secondary', '--text-secondary'], dark ? '#888888' : '#5f6670'),
      border: pick(['--border-subtle', '--glass-divider', '--glass-border-L3'], '#333333'),
    } as GameThemeTokens;
  }

  /** 亮度判断（--bg-primary 为实色可解析；渐变等非 hex 一律视为深色） */
  private static isLuminanceDark(color: string): boolean {
    const m = /^#([0-9a-f]{6})$/i.exec(color);
    if (m === null) return true;
    const hex = m[1]!;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  }

  /** 同步主题 token 到根元素 CSS 变量（styles.css 的 var() 消费；浅色皮肤下文字/面板切深色系） */
  private applyThemeToRoot(): void {
    if (this.root === null) return;
    const t = this.theme;
    const s = this.root.style;
    s.setProperty('--fg-primary', t.fg);
    s.setProperty('--fg-muted', t.muted);
    s.setProperty('--bg-active', t.dark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)');
    s.setProperty('--bg-hover', t.dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)');
    s.setProperty('--bg-elevated', t.dark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)');
  }

  /** 应用主题到画布：canvas 内容由游戏引擎自绘（Phaser backgroundColor / 棋盘底色），
   *  CSS 背景不透明色会在引擎首帧前露出白/黑块（坊市体验层泛白根因之一），故置透明 */
  private applyThemeToCanvas(): void {
    if (this.canvas === null) return;
    this.canvas.style.background = 'transparent';
  }

  /** 创建 HUD */
  private createHUD(ctx: AppMountContext): HTMLElement {
    const hud = document.createElement('div');
    hud.className = 'game-host-hud';

    /* 身份块 = 宿主页头语言：mono kicker + 衬线大标题（--type-title 三件套）。
     * EDITORIAL Phase 4 收口：信息带从「HUD 顶条残余」升级为「大标题 + 小标题分区」编辑台。 */
    const left = document.createElement('div');
    left.className = 'game-host-hud-left';

    /* G2 F 头：mono kicker（游戏 id 大写；@2 F 语言 kicker/衬线标题双件套） */
    const kicker = document.createElement('span');
    kicker.className = 'game-host-hud-kicker';
    kicker.setAttribute('aria-hidden', 'true');
    kicker.textContent = String(ctx.manifest.id ?? 'GAME').toUpperCase();
    left.appendChild(kicker);

    const title = document.createElement('span');
    title.className = 'game-host-hud-title';
    title.textContent = this.resolveGameName(ctx);
    left.appendChild(title);

    hud.appendChild(left);

    /* 战况分区：小标题 + 渐细横线 + 计分行（分数 / 最高分各占一行——
       2026-09-15 用户反馈：左信息带宽度有限，同行合并文案窄屏时截断显示不全） */
    const scoreSec = this.createHudSection(ctx, 'game.hud.sectionScore', 'SCORE');
    const score = document.createElement('div');
    score.className = 'game-host-hud-score';
    score.dataset.role = 'score';
    score.appendChild(this.createScoreLine(ctx, 'game.hud.score', 'Score', 'score-value', String(0)));
    score.appendChild(this.createScoreLine(ctx, 'game.hud.best', 'Best', 'best-value', String(this.bestScore)));
    scoreSec.appendChild(score);
    hud.appendChild(scoreSec);

    /* 操作分区：难度 / 暂停 / 重开（按钮基座 .btn 变体不变） */
    const ctrlSec = this.createHudSection(ctx, 'game.hud.sectionControls', 'CONTROLS');
    const right = document.createElement('div');
    right.className = 'game-host-hud-right';

    /* v5.0: 难度选择器（下拉菜单，支持 5 档难度） */
    const diffWrap = document.createElement('div');
    diffWrap.className = 'game-host-hud-difficulty-wrap';
    const diffSelect = document.createElement('select');
    /* P4.7：按钮基座化（铁律 9）——消费 .btn 基座变体（次按钮 + 小尺寸），
     * 保留 game-host-hud-btn 类名用于模板内定位/复刻样式桥接 */
    diffSelect.className = 'game-host-hud-btn btn btn--secondary btn--sm game-host-hud-difficulty-select';
    diffSelect.dataset.role = 'difficulty';
    diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
    const diffOptions: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
      { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
      { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
      { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
      { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
      { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
    ];
    for (const opt of diffOptions) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = this.tr(ctx, opt.labelKey, opt.fallback);
      diffSelect.appendChild(o);
    }
    diffSelect.value = this.currentDifficulty;
    diffSelect.addEventListener('change', () => {
      const val = diffSelect.value as GameDifficulty;
      this.changeDifficulty(val);
    });
    diffWrap.appendChild(diffSelect);
    right.appendChild(diffWrap);

    if (this.config.pauseable !== false) {
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
      pauseBtn.dataset.role = 'pause';
      pauseBtn.textContent = this.tr(ctx, 'game.hud.pause', 'Pause');
      pauseBtn.addEventListener('click', () => this.togglePause());
      right.appendChild(pauseBtn);
    }

    const restartBtn = document.createElement('button');
    restartBtn.type = 'button';
    restartBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
    restartBtn.dataset.role = 'restart';
    restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    restartBtn.addEventListener('click', () => this.restart());
    right.appendChild(restartBtn);

    ctrlSec.appendChild(right);
    hud.appendChild(ctrlSec);
    return hud;
  }

  /** 小标题分区（宿主 .zby-sec-title 同配方）：i18n 中文 + 固定 EN mono 小注（装饰，aria-hidden）
   *  + 渐细皮肤色横线（::after，见 css-hud 末段）。dataset 双载 key 与英文兜底供 i18n 刷新。 */
  private createHudSection(ctx: AppMountContext, titleKey: string, enTag: string): HTMLElement {
    const sec = document.createElement('section');
    sec.className = 'game-host-sec';
    const head = document.createElement('div');
    head.className = 'game-host-sec-head';
    head.dataset.titleKey = titleKey;
    head.dataset.titleFallback = enTag;
    const name = document.createElement('span');
    name.textContent = this.tr(ctx, titleKey, enTag);
    head.appendChild(name);
    const sub = document.createElement('span');
    sub.className = 'game-host-sec-sub';
    sub.setAttribute('aria-hidden', 'true');
    sub.textContent = enTag;
    head.appendChild(sub);
    sec.appendChild(head);
    return sec;
  }

  /** 更新 HUD 分数显示（分数 / 最高分两行分别更新） */
  private updateHUDScore(): void {
    if (this.hud === null) return;
    const scoreEl = this.hud.querySelector<HTMLElement>('[data-role="score-value"]');
    if (scoreEl !== null) scoreEl.textContent = String(this.score);
    const bestEl = this.hud.querySelector<HTMLElement>('[data-role="best-value"]');
    if (bestEl !== null) bestEl.textContent = String(this.bestScore);
  }

  /** 计分行：标签（mono 小字）+ 数值（tabular-nums）；行内 nowrap、行间堆叠 */
  private createScoreLine(ctx: AppMountContext | null, labelKey: string, labelFallback: string, valueRole: string, initialValue: string): HTMLElement {
    const line = document.createElement('span');
    line.className = 'game-host-hud-score-line';
    const label = document.createElement('span');
    label.className = 'game-host-hud-score-label';
    label.textContent = this.tr(ctx, labelKey, labelFallback);
    const value = document.createElement('span');
    value.className = 'game-host-hud-score-value';
    value.dataset.role = valueRole;
    value.textContent = initialValue;
    line.appendChild(label);
    line.appendChild(value);
    return line;
  }

  /** i18n 刷新（Step 4.1）：宿主语言切换后重设 HUD 文案（data-role 查询 + 子类 hook） */
  protected refreshHudI18n(): void {
    if (this.hud === null) return;
    const ctx = this.ctx;
    if (ctx === null) return;
    const diffSelect = this.hud.querySelector<HTMLSelectElement>('[data-role="difficulty"]');
    if (diffSelect !== null) {
      diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
      const labels: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
        { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
        { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
        { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
        { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
        { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
      ];
      const options = diffSelect.querySelectorAll('option');
      options.forEach((o) => {
        const label = labels.find((l) => l.value === o.value);
        if (label !== undefined) o.textContent = this.tr(ctx, label.labelKey, label.fallback);
      });
    }
    /* 暂停遮罩文案（CSS ::after content 消费 dataset.pausedText） */
    const canvasWrap = this.root !== null ? this.root.querySelector<HTMLElement>('.game-host-canvas-wrap') : null;
    if (canvasWrap !== null) {
      canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');
    }
    if (this.canvas !== null) this.canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    /* HUD 标题（游戏名）+ 重新开始按钮（2026-08-27 P4.1f 运行时验证补齐） */
    const titleEl = this.hud.querySelector<HTMLElement>('.game-host-hud-title');
    if (titleEl !== null) titleEl.textContent = this.resolveGameName(ctx);
    const restartBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="restart"]');
    if (restartBtn !== null) restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    /* 分区小标题（EDITORIAL Phase 4 收口）：dataset.titleKey 记录 key，刷新时重查词表 */
    const secHeads = this.hud.querySelectorAll<HTMLElement>('.game-host-sec-head');
    secHeads.forEach((head) => {
      const key = head.dataset.titleKey;
      if (key === undefined || key === '') return;
      const name = head.firstElementChild;
      if (name !== null) name.textContent = this.tr(ctx, key, head.dataset.titleFallback ?? key);
    });
    this.updateHUDStatus();
    this.updateHUDScore();
    if (this.onI18nRefresh !== undefined) {
      try { this.onI18nRefresh(); } catch { /* ignore */ }
    }
  }

  /** i18n 刷新子类 hook（如 tank 的 Phaser 场景 overlays 重建） */
  protected onI18nRefresh?: () => void;

  /** 更新 HUD 状态显示 */
  private updateHUDStatus(): void {
    if (this.hud === null) return;
    const pauseBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="pause"]');
    if (pauseBtn !== null) {
      pauseBtn.textContent = this.paused
        ? this.tr(this.ctx, 'game.hud.resume', 'Resume')
        : this.tr(this.ctx, 'game.hud.pause', 'Pause');
    }
  }

  /** 格式化分数显示 */
  /** 解析游戏名称（从 manifest.nameFallback） */
  private resolveGameName(ctx: AppMountContext): string {
    const nameKey = ctx.manifest.nameKey;
    if (nameKey !== undefined && nameKey !== '') {
      const tr = this.tr(ctx, nameKey, ctx.manifest.nameFallback);
      if (tr !== nameKey) return tr;
    }
    return ctx.manifest.nameFallback;
  }

  /** i18n 翻译（带兜底） */
  private tr(ctx: AppMountContext | null, key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string {
    if (ctx === null) return fallback;
    try {
      const result = ctx.t(key, params);
      if (result !== key) return result;
    } catch {
      /* ignore */
    }
    return params === undefined ? fallback : fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
      const value = params[name];
      return value !== undefined ? String(value) : '';
    });
  }

  /* ============================================================
     最高分持久化（P4.3：sandboxStorage 代理，键 game:best:game-tank）
     ============================================================ */

  private async loadBestScore(): Promise<number> {
    const storage = getSandboxStorage();
    if (storage === null) return 0;
    try {
      const raw = await storage.get(BEST_SCORE_KEY_PREFIX + this.config.gameId);
      if (raw === null || raw === undefined) return 0;
      const n = Number.parseInt(String(raw), 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch {
      return 0;
    }
  }

  private saveBestScore(score: number): void {
    const storage = getSandboxStorage();
    if (storage === null) return;
    void storage.set(BEST_SCORE_KEY_PREFIX + this.config.gameId, String(score)).catch(() => {
      /* ignore quota */
    });
  }
}


  /* =========================================================
     5. TankHost 内联（原 src/shared/apps/games/builtin/tank/TankHost.ts）
     ========================================================= */

/**
 * TankHost — 坦克大战游戏实现
 *
 * Phase 5.8.2 交付物：5 款内置小游戏之一。
 *
 * 引擎：Phaser 4（lazy import，首屏不加载）
 * 操作：方向键移动 / 空格发射子弹 / P 暂停 / R 重新开始
 * 玩法：保护基地（老鹰），消灭敌方坦克，关卡递进
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.4
 */



/* ============================================================
   常量
   ============================================================ */

/** 瓦片像素大小 */
const TILE = 32;
/** 地图列数 */
const MAP_W = 16;
/** 地图行数 */
const MAP_H = 16;
/** 游戏区域宽度 */
const GAME_W = MAP_W * TILE;
/** 游戏区域高度 */
const GAME_H = MAP_H * TILE;
/** HUD 条高度（像素） */
const HUD_H = 36;
/** 画布总高度（含 HUD 条） */
const CANVAS_H = GAME_H + HUD_H;

/** 瓦片类型：红砖（可破坏） */
const TILE_BRICK = 1;
/** 瓦片类型：钢墙（不可破坏） */
const TILE_STEEL = 2;
/** 瓦片类型：基地 */
const TILE_BASE = 3;

/** 玩家出生点（列、行） */
const PLAYER_SPAWN_COL = 4;
const PLAYER_SPAWN_ROW = 15;
/** 敌方出生点列 */
const ENEMY_SPAWN_COLS: readonly number[] = [0, 7, 14];
/** 敌方出生点行 */
const ENEMY_SPAWN_ROW = 0;

/** 玩家移动速度（像素/秒） */
const PLAYER_SPEED = 120;
/** 子弹速度（像素/秒） */
const BULLET_SPEED = 300;
/** 玩家射击冷却（ms） */
const PLAYER_FIRE_COOLDOWN = 300;
/** 玩家初始生命数 */
const PLAYER_LIVES = 3;
/** 同时存在的最大敌方坦克数 */
const MAX_ACTIVE_ENEMIES = 4;
/** 玩家复活无敌时间（ms） */
const INVINCIBLE_DURATION = 2000;
/** 每次击杀得分 */
const SCORE_PER_KILL = 100;
/** 场景 key */
const SCENE_KEY = 'tank';

/** 精英敌方出现概率 */
const ELITE_ENEMY_CHANCE = 0.25;
/** 精英敌方速度倍率 */
const ELITE_ENEMY_SPEED_MULT = 1.6;
/** 最大关卡数（通关后显示胜利） */
const MAX_LEVEL = 3;

/* ============================================================
   方向
   ============================================================ */

type Direction = 'up' | 'down' | 'left' | 'right';

interface DirectionVector {
  readonly dx: number;
  readonly dy: number;
}

const DIR_VECTORS: Record<Direction, DirectionVector> = {
  up:    { dx: 0,  dy: -1 },
  down:  { dx: 0,  dy: 1 },
  left:  { dx: -1, dy: 0 },
  right: { dx: 1,  dy: 0 },
};

const DIR_ROTATIONS: Record<Direction, number> = {
  up:    0,
  right: Math.PI / 2,
  down:  Math.PI,
  left:  -Math.PI / 2,
};

const ALL_DIRECTIONS: readonly Direction[] = ['up', 'down', 'left', 'right'];

/* ============================================================
   关卡地图
   0=空地  1=红砖  2=钢墙  3=基地
   ============================================================ */

const LEVEL_1: readonly (readonly number[])[] = [
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,0],
  [0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0],
  [0,1,1,0,0,2,2,0,0,2,2,0,0,1,1,0],
  [0,0,0,0,0,2,2,0,0,2,2,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0],
  [0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0],
  [0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0],
  [0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0],
  [0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,1,3,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];

const LEVEL_2: readonly (readonly number[])[] = [
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,2,0,1,1,0,0,1,1,0,0,1,1,0,2,0],
  [0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0],
  [0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0],
  [0,1,1,0,0,2,2,0,0,2,2,0,0,1,1,0],
  [0,1,1,0,0,2,2,0,0,2,2,0,0,1,1,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,2,2,0,0,1,1,1,1,0,0,2,2,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,1,1,0,0,2,2,0,0,2,2,0,0,1,1,0],
  [0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0],
  [0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0],
  [0,0,0,0,0,2,1,1,1,1,2,0,0,0,0,0],
  [0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,1,3,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];

const LEVEL_3: readonly (readonly number[])[] = [
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,2,2,0,0,1,1,0,0,1,1,0,0,2,2,0],
  [0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0],
  [0,0,0,2,2,0,0,0,0,0,0,2,2,0,0,0],
  [0,1,1,0,0,0,0,2,2,0,0,0,0,1,1,0],
  [0,1,1,0,0,2,2,0,0,2,2,0,0,1,1,0],
  [0,0,0,0,0,2,2,0,0,2,2,0,0,0,0,0],
  [0,0,2,0,0,0,0,0,0,0,0,0,2,0,0,0],
  [0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0],
  [0,2,2,0,0,0,0,0,0,0,0,0,2,2,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,1,1,0,0,2,1,0,0,1,2,0,0,1,1,0],
  [0,0,0,0,0,2,1,1,1,1,2,0,0,0,0,0],
  [0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,1,3,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];

const LEVEL_MAPS: readonly (readonly (readonly number[])[])[] = [LEVEL_1, LEVEL_2, LEVEL_3];

/** 获取指定关卡的地图（循环使用 3 张地图） */
function getLevelMap(level: number): readonly (readonly number[])[] {
  const idx = (level - 1) % LEVEL_MAPS.length;
  const map = LEVEL_MAPS[idx];
  return map ?? LEVEL_1;
}

/* ============================================================
   难度配置
   ============================================================ */

interface DifficultyConfig {
  /** 敌方坦克移动速度 */
  readonly enemySpeed: number;
  /** 敌方射击间隔（ms） */
  readonly enemyFireInterval: number;
  /** 敌方 AI 状态切换间隔（ms） */
  readonly enemyAiInterval: number;
  /** 敌方生成间隔（ms） */
  readonly enemySpawnInterval: number;
  /** 每关敌方坦克总数 */
  readonly enemiesPerLevel: number;
}

function getDifficultyConfig(difficulty: GameDifficulty): DifficultyConfig {
  switch (difficulty) {
    case 'easy':
      return {
        enemySpeed: 50,
        enemyFireInterval: 2000,
        enemyAiInterval: 2500,
        enemySpawnInterval: 4000,
        enemiesPerLevel: 8,
      };
    case 'hard':
      return {
        enemySpeed: 100,
        enemyFireInterval: 900,
        enemyAiInterval: 1000,
        enemySpawnInterval: 2000,
        enemiesPerLevel: 12,
      };
    default:
      return {
        enemySpeed: 70,
        enemyFireInterval: 1500,
        enemyAiInterval: 1800,
        enemySpawnInterval: 3000,
        enemiesPerLevel: 10,
      };
  }
}

/* ============================================================
   敌方 AI 状态
   ============================================================ */

type EnemyState = 'patrol' | 'chase';

interface EnemyAiData {
  state: EnemyState;
  direction: Direction;
  lastStateChange: number;
  lastFireTime: number;
  nextAiUpdate: number;
}

/** AI 数据存储在 sprite 上的 key */
const AI_DATA_KEY = 'ai';

/** 碰撞回调参数类型（与 Phaser ArcadePhysicsCallback 一致） */
type CollisionObject =
  | PhaserType.Types.Physics.Arcade.GameObjectWithBody
  | PhaserType.Physics.Arcade.Body
  | PhaserType.Physics.Arcade.StaticBody
  | PhaserType.Tilemaps.Tile;

/* ============================================================
   TankScene 控制接口（供 TankHost 调用场景方法）
   ============================================================ */

interface TankSceneControl {
  /** 设置暂停状态（显示/隐藏遮罩） */
  setPaused(paused: boolean): void;
  /** Step 4.1：宿主语言切换后重建 Phaser 文本 overlays（词表已随 __SANDBOX_I18N__ 更新） */
  refreshOverlayTexts(): void;
}

/* ============================================================
   TankHost
   ============================================================ */

class TankHost extends GameHost {
  private phaserGame: PhaserType.Game | null = null;
  private sceneControl: TankSceneControl | null = null;
  private readonly sceneKey = SCENE_KEY;

  protected async onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): Promise<void> {
    /** i18n 翻译（带兜底，供 TankScene 内部使用）
     * v5.2 修复：定义必须置于 loadingOverlay 之前，否则 const TDZ 抛
     * ReferenceError（Cannot access 'tr' before initialization），
     * onMount 直接失败导致游戏区空白。 */
    const tr = (key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string => {
      try {
        const result = ctx.t(key, params);
        if (result !== key) return result;
      } catch {
        /* ignore */
      }
      if (params === undefined) return fallback;
      return fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };

    /* v2.6：使用 DOM overlay 显示 loading，避免在 canvas 上调用 getContext('2d')
     * 导致 Phaser 无法创建 WebGL 上下文（同一 canvas 只能有一种 context 类型） */
    const loadingOverlay = this.showLoadingOverlay(canvas, tr('game.tank.loading', 'Loading Battle City...'));

    let Phaser: typeof PhaserType;
    try {
      /* Vite ESM/CJS interop：import('phaser') 返回 { default: PhaserCJSExport }。
       * 直接赋值会导致 Phaser.Game / Phaser.CANVAS 等属性在 module namespace 上找不到。
       * 解包 default 导出，确保 Phaser.Game / Phaser.CANVAS 等可直接访问。 */
      const mod = await import('phaser');
      Phaser = (mod as typeof PhaserType & { default?: typeof PhaserType }).default ?? mod as typeof PhaserType;
    } catch (err) {
      this.removeLoadingOverlay(loadingOverlay);
      this.showErrorOverlay(canvas, tr('game.tank.error.engine', 'Phaser engine failed to load'), err);
      throw err;
    }

    /* Phaser 加载成功后移除 loading overlay */
    this.removeLoadingOverlay(loadingOverlay);

    const difficulty = options.difficulty ?? 'normal';
    const initialLevel = options.level ?? 1;
    const diffConfig = getDifficultyConfig(difficulty);

    /* 回调桥接：让 TankScene 能调用 GameHost 的 protected 方法。
     * 箭头函数捕获词法 this，无需 `const host = this` 别名（避免 no-this-alias 警告）。 */
    const notifyScore = (score: number, level: number): void => {
      this.updateScorePublic(score, level);
    };
    const notifyStatus = (status: GameStatus, message?: string): void => {
      this.updateStatusPublic(status, message);
    };
    const registerSceneControl = (ctrl: TankSceneControl): void => {
      this.sceneControl = ctrl;
    };
    /* Step 4.1：宿主语言切换 → 场景 Phaser 文本 overlays 重建（sceneControl 由场景 create 时异步注册） */
    this.onI18nRefresh = () => {
      this.sceneControl?.refreshOverlayTexts();
    };
    const requestTogglePause = (): void => {
      this.togglePause();
    };
    const requestRestart = (): void => {
      this.restart();
    };
    /* ============================================================
       TankScene — 主场景
       ============================================================ */

    class TankScene extends Phaser.Scene {
      /* 游戏对象 */
      private player!: PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody;
      private enemies!: PhaserType.Physics.Arcade.Group;
      private playerBullets!: PhaserType.Physics.Arcade.Group;
      private enemyBullets!: PhaserType.Physics.Arcade.Group;
      private bricks!: PhaserType.Physics.Arcade.StaticGroup;
      private steels!: PhaserType.Physics.Arcade.StaticGroup;
      private base!: PhaserType.Types.Physics.Arcade.SpriteWithStaticBody;

      /* HUD 文本 */
      private hudScoreText!: PhaserType.GameObjects.Text;
      private hudLivesText!: PhaserType.GameObjects.Text;
      private hudLevelText!: PhaserType.GameObjects.Text;
      private hudEnemiesText!: PhaserType.GameObjects.Text;

      /* 暂停遮罩 */
      private pauseOverlay!: PhaserType.GameObjects.Container;

      /* 操作指南遮罩（H 键切换） */
      private helpOverlay!: PhaserType.GameObjects.Container;
      private helpVisible = false;

      /* 关卡过渡 / 游戏结束文本 */
      private stageText!: PhaserType.GameObjects.Text;
      private gameOverOverlay!: PhaserType.GameObjects.Container;

      /* 输入 */
      private cursors!: PhaserType.Types.Input.Keyboard.CursorKeys;
      private fireKey!: PhaserType.Input.Keyboard.Key;
      private pauseKey!: PhaserType.Input.Keyboard.Key;
      private restartKey!: PhaserType.Input.Keyboard.Key;
      private helpKey!: PhaserType.Input.Keyboard.Key;

      /* 游戏状态 */
      private direction: Direction = 'up';
      private level = initialLevel;
      private lives = PLAYER_LIVES;
      private score = 0;
      private enemiesRemaining = 0;
      private lastEnemySpawn = 0;
      private lastFireTime = 0;
      private gameOver = false;
      private invincibleUntil = 0;
      private levelTransitioning = false;
      private paused = false;
      private wasMoving = false;

      constructor() {
        super({ key: SCENE_KEY });
      }

      /* --------------------------------------------------------
         生命周期
         -------------------------------------------------------- */

      create(): void {
        /* 重置游戏状态（重要：重启时字段不会通过构造函数重置） */
        this.direction = 'up';
        this.level = initialLevel;
        this.lives = PLAYER_LIVES;
        this.score = 0;
        this.enemiesRemaining = 0;
        this.lastEnemySpawn = 0;
        this.lastFireTime = 0;
        this.gameOver = false;
        this.invincibleUntil = 0;
        this.levelTransitioning = false;
        this.paused = false;
        this.wasMoving = false;
        this.helpVisible = false;

        this.createTextures();
        this.physics.world.setBounds(0, 0, GAME_W, GAME_H);

        /* 相机：游戏区域下方偏移 HUD_H，使 HUD 条显示在画面顶部 */
        this.cameras.main.setBounds(0, -HUD_H, GAME_W, CANVAS_H);
        this.cameras.main.setScroll(0, -HUD_H);

        /* 创建静态组 */
        this.bricks = this.physics.add.staticGroup();
        this.steels = this.physics.add.staticGroup();

        /* 创建动态组 */
        this.enemies = this.physics.add.group();
        this.playerBullets = this.physics.add.group();
        this.enemyBullets = this.physics.add.group();

        /* 构建第一关地图 */
        this.buildMap(this.level);

        /* 创建玩家 */
        this.createPlayer();

        /* 输入 */
        const keyboard = this.input.keyboard;
        if (keyboard !== null) {
          this.cursors = keyboard.createCursorKeys();
          this.fireKey = keyboard.addKey('SPACE');
          this.pauseKey = keyboard.addKey('P');
          this.restartKey = keyboard.addKey('R');
          this.helpKey = keyboard.addKey('H');
        }

        /* 碰撞 */
        this.setupCollisions();

        /* HUD */
        this.createHUD();
        this.createPauseOverlay();
        this.createHelpOverlay();

        /* 关卡过渡文本（大字居中） */
        this.stageText = this.add.text(GAME_W / 2, GAME_H / 2, '', {
          fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif',
          fontSize: '36px',
          color: '#fde047',
          fontStyle: 'bold',
          stroke: '#000000',
          strokeThickness: 4,
        });
        this.stageText.setOrigin(0.5, 0.5);
        this.stageText.setDepth(100);
        this.stageText.setVisible(false);

        /* 游戏结束遮罩（初始隐藏） */
        this.createGameOverOverlay();

        /* 注册场景控制接口 */
        registerSceneControl({
          setPaused: (p: boolean): void => this.setPaused(p),
        });

        /* 启动第一关 */
        this.startLevel(this.level);

        /* 通知 GameHost 状态 */
        notifyScore(this.score, this.level);
        notifyStatus('playing');
      }

      override update(time: number, _delta: number): void {
        /* 帮助键检测（始终活跃，切换操作指南面板） */
        if (this.helpKey !== undefined && Phaser.Input.Keyboard.JustDown(this.helpKey)) {
          this.toggleHelpOverlay();
          return;
        }

        /* 暂停键检测（始终活跃） */
        if (this.pauseKey !== undefined && Phaser.Input.Keyboard.JustDown(this.pauseKey)) {
          requestTogglePause();
          return;
        }

        /* 重启键检测（仅在游戏结束时活跃） */
        if (this.gameOver && this.restartKey !== undefined && Phaser.Input.Keyboard.JustDown(this.restartKey)) {
          requestRestart();
          return;
        }

        /* 操作指南显示时跳过游戏逻辑（类似暂停） */
        if (this.helpVisible || this.paused || this.gameOver || this.levelTransitioning) return;

        this.updatePlayer(time);
        this.updateEnemies(time);
        this.cleanupBullets();
        this.trySpawnEnemy(time);
        this.updateBulletTrails(time);
      }

      /* --------------------------------------------------------
         纹理生成
         -------------------------------------------------------- */

      private createTextures(): void {
        /* 玩家坦克（朝上）：亮黄主体 + 橙黄轮廓 + 深棕履带 */
        this.generateTankTexture('tank-player', 0xfbbf24, 0xf59e0b, 0x78350f);
        /* 敌方坦克-普通（朝上）：深灰绿主体 + 暗灰轮廓 + 深岩履带 */
        this.generateTankTexture('tank-enemy', 0x475569, 0x334155, 0x1e293b);
        /* 敌方坦克-精英（朝上）：红色主体 + 暗红轮廓 + 深红履带 */
        this.generateTankTexture('tank-enemy-elite', 0xef4444, 0xdc2626, 0x7f1d1d);

        /* 红砖：每行 4 块，上下行错缝，每块带高光与阴影 */
        const brickGfx = this.make.graphics();
        const brickMain = 0xb91c1c;
        const brickGap = 0x7f1d1d;
        const brickHi = 0xef4444;
        const brickLo = 0x450a0a;
        /* 缝隙底色 */
        brickGfx.fillStyle(brickGap, 1);
        brickGfx.fillRect(0, 0, TILE, TILE);
        const brickW = TILE / 4;
        const brickH = TILE / 4;
        for (let row = 0; row < 4; row++) {
          const y = row * brickH;
          const isOdd = row % 2 === 1;
          const startX = isOdd ? -brickW / 2 : 0;
          const count = isOdd ? 5 : 4;
          for (let i = 0; i < count; i++) {
            const x = startX + i * brickW;
            /* 砖块主体 */
            brickGfx.fillStyle(brickMain, 1);
            brickGfx.fillRect(x + 1, y + 1, brickW - 2, brickH - 2);
            /* 顶部高光 */
            brickGfx.fillStyle(brickHi, 1);
            brickGfx.fillRect(x + 1, y + 1, brickW - 2, 1);
            /* 底部阴影 */
            brickGfx.fillStyle(brickLo, 1);
            brickGfx.fillRect(x + 1, y + brickH - 2, brickW - 2, 1);
          }
        }
        brickGfx.generateTexture('brick', TILE, TILE);
        brickGfx.destroy();

        /* 钢墙：金属拉丝纹理 */
        const steelGfx = this.make.graphics();
        /* 主色底 */
        steelGfx.fillStyle(0x94a3b8, 1);
        steelGfx.fillRect(0, 0, TILE, TILE);
        /* 顶部/左侧高光斜面 */
        steelGfx.fillStyle(0xcbd5e1, 1);
        steelGfx.fillRect(2, 2, TILE - 4, 3);
        steelGfx.fillRect(2, 2, 3, TILE - 4);
        /* 底部/右侧阴影斜面 */
        steelGfx.fillStyle(0x475569, 1);
        steelGfx.fillRect(2, TILE - 5, TILE - 4, 3);
        steelGfx.fillRect(TILE - 5, 2, 3, TILE - 4);
        /* 内层主面板 */
        steelGfx.fillStyle(0x94a3b8, 1);
        steelGfx.fillRect(6, 6, TILE - 12, TILE - 12);
        /* 金属拉丝纹理（细水平线，明暗交错） */
        steelGfx.fillStyle(0x475569, 0.4);
        for (let y = 8; y < TILE - 6; y += 2) {
          steelGfx.fillRect(6, y, TILE - 12, 1);
        }
        steelGfx.fillStyle(0xcbd5e1, 0.3);
        for (let y = 9; y < TILE - 6; y += 2) {
          steelGfx.fillRect(6, y, TILE - 12, 1);
        }
        /* 中心螺栓 */
        steelGfx.fillStyle(0x475569, 1);
        steelGfx.fillCircle(TILE / 2, TILE / 2, 2.5);
        steelGfx.fillStyle(0xcbd5e1, 1);
        steelGfx.fillCircle(TILE / 2 - 0.5, TILE / 2 - 0.5, 1.2);
        steelGfx.generateTexture('steel', TILE, TILE);
        steelGfx.destroy();

        /* 基地：精致老鹰纹理（金色鹰展翅 + 深色堡垒底） */
        this.createBaseTexture();

        /* 子弹 */
        const bulletGfx = this.make.graphics();
        bulletGfx.fillStyle(0xffffff, 1);
        bulletGfx.fillCircle(3, 3, 3);
        bulletGfx.generateTexture('bullet', 6, 6);
        bulletGfx.destroy();
      }

      /** 绘制基地老鹰纹理 */
      private createBaseTexture(): void {
        const gfx = this.make.graphics();
        const cx = TILE / 2;
        const cy = TILE / 2;

        /* 堡垒外框（石质底座） */
        gfx.fillStyle(0x44403c, 1);
        gfx.fillRoundedRect(1, 1, TILE - 2, TILE - 2, 2);
        gfx.fillStyle(0x57534e, 1);
        gfx.fillRoundedRect(2, 2, TILE - 4, TILE - 4, 2);

        /* 内层深色背景 */
        gfx.fillStyle(0x1c1917, 1);
        gfx.fillRoundedRect(4, 4, TILE - 8, TILE - 8, 1);

        /* 老鹰身体（白色椭圆） */
        gfx.fillStyle(0xe7e5e4, 1);
        gfx.fillEllipse(cx, cy + 1, 7, 11);

        /* 老鹰头部（圆形） */
        gfx.fillStyle(0xfafaf9, 1);
        gfx.fillCircle(cx, cy - 5, 3.5);

        /* 喙（橙黄三角） */
        gfx.fillStyle(0xf59e0b, 1);
        gfx.beginPath();
        gfx.moveTo(cx + 3, cy - 5);
        gfx.lineTo(cx + 7, cy - 4);
        gfx.lineTo(cx + 3, cy - 3);
        gfx.closePath();
        gfx.fillPath();

        /* 左翼（展开） */
        gfx.fillStyle(0xe7e5e4, 1);
        gfx.beginPath();
        gfx.moveTo(cx - 2, cy - 2);
        gfx.lineTo(cx - 13, cy);
        gfx.lineTo(cx - 11, cy + 5);
        gfx.lineTo(cx - 2, cy + 3);
        gfx.closePath();
        gfx.fillPath();

        /* 右翼（展开） */
        gfx.beginPath();
        gfx.moveTo(cx + 2, cy - 2);
        gfx.lineTo(cx + 13, cy);
        gfx.lineTo(cx + 11, cy + 5);
        gfx.lineTo(cx + 2, cy + 3);
        gfx.closePath();
        gfx.fillPath();

        /* 翼尖阴影 */
        gfx.fillStyle(0xa8a29e, 0.7);
        gfx.fillRect(cx - 11, cy + 1, 3, 2);
        gfx.fillRect(cx + 8, cy + 1, 3, 2);

        /* 尾羽 */
        gfx.fillStyle(0xe7e5e4, 1);
        gfx.beginPath();
        gfx.moveTo(cx - 2, cy + 5);
        gfx.lineTo(cx + 2, cy + 5);
        gfx.lineTo(cx, cy + 11);
        gfx.closePath();
        gfx.fillPath();

        /* 眼睛 */
        gfx.fillStyle(0x000000, 1);
        gfx.fillCircle(cx + 1, cy - 5, 0.8);

        /* 胸部高光 */
        gfx.fillStyle(0xfafaf9, 0.5);
        gfx.fillEllipse(cx - 1, cy, 3, 5);

        gfx.generateTexture('base', TILE, TILE);
        gfx.destroy();
      }

      /** 生成坦克纹理（朝上） */
      private generateTankTexture(
        key: string,
        bodyColor: number,
        turretColor: number,
        treadColor: number,
      ): void {
        const gfx = this.make.graphics();
        const size = TILE;
        const cx = size / 2;

        /* === 履带（左右两条，圆角，带横纹模拟链节） === */
        gfx.fillStyle(treadColor, 1);
        gfx.fillRoundedRect(1, 5, 6, 24, 2);
        gfx.fillRoundedRect(size - 7, 5, 6, 24, 2);
        /* 履带横纹（链节） */
        gfx.fillStyle(0x000000, 0.4);
        for (let i = 0; i < 6; i++) {
          const y = 7 + i * 4;
          gfx.fillRect(1, y, 6, 1);
          gfx.fillRect(size - 7, y, 6, 1);
        }
        /* 履带顶部高光 */
        gfx.fillStyle(0xffffff, 0.18);
        gfx.fillRect(1, 6, 6, 1);
        gfx.fillRect(size - 7, 6, 6, 1);

        /* === 车体（圆角矩形 + 轮廓 + 顶部高光） === */
        /* 车体阴影（向下偏移 1px） */
        gfx.fillStyle(0x000000, 0.35);
        gfx.fillRoundedRect(8, 9, size - 16, 19, 3);
        /* 车体主体 */
        gfx.fillStyle(bodyColor, 1);
        gfx.fillRoundedRect(8, 8, size - 16, 18, 3);
        /* 车体顶部高光 */
        gfx.fillStyle(0xffffff, 0.28);
        gfx.fillRect(10, 9, size - 20, 2);
        /* 车体轮廓 */
        gfx.lineStyle(1, turretColor, 1);
        gfx.strokeRoundedRect(8, 8, size - 16, 18, 3);

        /* === 炮塔（同心圆渐变，立体感） === */
        /* 外圈深色（轮廓阴影） */
        gfx.fillStyle(turretColor, 1);
        gfx.fillCircle(cx, 16, 8);
        /* 中圈主色（亮） */
        gfx.fillStyle(bodyColor, 1);
        gfx.fillCircle(cx, 16, 7);
        /* 高光圈（左上偏移） */
        gfx.fillStyle(0xffffff, 0.35);
        gfx.fillCircle(cx - 1, 15, 5);
        /* 中心深色（轴心） */
        gfx.fillStyle(treadColor, 1);
        gfx.fillCircle(cx, 16, 2);
        /* 中心高光点 */
        gfx.fillStyle(0xffffff, 0.6);
        gfx.fillCircle(cx - 0.5, 15.5, 1);

        /* === 炮管（朝上，更长更明显） === */
        /* 炮管阴影 */
        gfx.fillStyle(0x000000, 0.45);
        gfx.fillRect(cx - 1, 1, 4, 16);
        /* 炮管主体 */
        gfx.fillStyle(turretColor, 1);
        gfx.fillRect(cx - 2, 0, 4, 16);
        /* 炮管左侧高光 */
        gfx.fillStyle(0xffffff, 0.3);
        gfx.fillRect(cx - 2, 0, 1, 16);
        /* 炮口（深色环） */
        gfx.fillStyle(treadColor, 1);
        gfx.fillRect(cx - 2, 0, 4, 2);

        gfx.generateTexture(key, size, size);
        gfx.destroy();
      }

      /* --------------------------------------------------------
         HUD
         -------------------------------------------------------- */

      private createHUD(): void {
        /* HUD 背景条 */
        const hudBg = this.add.rectangle(GAME_W / 2, -HUD_H / 2, GAME_W, HUD_H, 0x0f172a);
        hudBg.setDepth(90);
        hudBg.setOrigin(0.5, 0.5);

        /* HUD 底部分隔线 */
        const hudBorder = this.add.rectangle(GAME_W / 2, 0, GAME_W, 1, 0x334155);
        hudBorder.setDepth(91);
        hudBorder.setOrigin(0.5, 0.5);

        const hudStyle: PhaserType.Types.GameObjects.Text.TextStyle = {
          fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif',
          fontSize: '14px',
          fontStyle: 'bold',
        };

        /* 分数（左） */
        this.hudScoreText = this.add.text(6, -HUD_H / 2, tr('game.tank.hud.score', 'Score {score}', { score: 0 }), {
          ...hudStyle,
          color: '#fde047',
        });
        this.hudScoreText.setOrigin(0, 0.5);
        this.hudScoreText.setDepth(92);

        /* 生命数 */
        this.hudLivesText = this.add.text(120, -HUD_H / 2, tr('game.tank.hud.lives', 'Lives {lives}', { lives: 3 }), {
          ...hudStyle,
          color: '#4ade80',
        });
        this.hudLivesText.setOrigin(0, 0.5);
        this.hudLivesText.setDepth(92);

        /* 关卡 */
        this.hudLevelText = this.add.text(210, -HUD_H / 2, 'Stage 1', {
          ...hudStyle,
          color: '#60a5fa',
        });
        this.hudLevelText.setOrigin(0, 0.5);
        this.hudLevelText.setDepth(92);

        /* 剩余敌人（右） */
        this.hudEnemiesText = this.add.text(GAME_W - 6, -HUD_H / 2, tr('game.tank.hud.enemies', 'Enemies {count}', { count: 0 }), {
          ...hudStyle,
          color: '#f87171',
        });
        this.hudEnemiesText.setOrigin(1, 0.5);
        this.hudEnemiesText.setDepth(92);

        /* 操作指南提示（居中偏右，小字 muted） */
        const helpHint = this.add.text(
          GAME_W / 2 + 70, -HUD_H / 2,
          tr('game.tank.guide.hint', 'Press H for help'),
          {
            fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif',
            fontSize: '10px',
            color: '#64748b',
          },
        );
        helpHint.setOrigin(0.5, 0.5);
        helpHint.setDepth(92);

        this.updateHUD();
      }

      private updateHUD(): void {
        this.hudScoreText.setText(tr('game.tank.hud.score', 'Score {score}', { score: this.score }));
        this.hudLivesText.setText(tr('game.tank.hud.lives', 'Lives {lives}', { lives: this.lives }));
        this.hudLevelText.setText(`Stage ${this.level}`);
        this.hudEnemiesText.setText(tr('game.tank.hud.enemies', 'Enemies {count}', { count: this.enemiesRemaining }));
      }

      /* --------------------------------------------------------
         暂停遮罩
         -------------------------------------------------------- */

      private createPauseOverlay(): void {
        this.pauseOverlay = this.add.container(0, 0);
        this.pauseOverlay.setDepth(150);
        this.pauseOverlay.setVisible(false);

        /* 半透明遮罩（覆盖整个可见区域） */
        const bg = this.add.rectangle(
          GAME_W / 2, (GAME_H - HUD_H) / 2,
          GAME_W, CANVAS_H,
          0x000000, 0.65,
        );
        this.pauseOverlay.add(bg);

        /* 暂停文本（词表随宿主语言切换，重建时重取） */
        const text = this.add.text(
          GAME_W / 2, GAME_H / 2,
          tr('game.hud.pausedHint', 'Paused'),
          {
            fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif',
            fontSize: '24px',
            color: '#fde047',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 3,
          },
        );
        text.setOrigin(0.5, 0.5);
        this.pauseOverlay.add(text);
      }

      /** 设置暂停状态（由 TankHost.onPause/onResume 调用） */
      private setPaused(paused: boolean): void {
        this.paused = paused;
        /* 检查 pauseOverlay 是否仍然有效（场景重启期间可能被销毁） */
        if (this.pauseOverlay !== undefined && this.pauseOverlay.scene !== null) {
          this.pauseOverlay.setVisible(paused);
        }
      }

      /** Step 4.1：宿主语言切换后重建帮助遮罩与暂停遮罩（Phaser 文本一次性创建，重建才生效） */
      refreshOverlayTexts(): void {
        if (this.helpOverlay !== undefined) {
          const wasVisible = this.helpOverlay.visible;
          this.helpOverlay.destroy(true);
          this.helpOverlay = undefined as unknown as PhaserType.GameObjects.Container;
          this.createHelpOverlay();
          if (!wasVisible) this.helpOverlay.setVisible(false);
        }
        if (this.pauseOverlay !== undefined) {
          const wasVisible = this.pauseOverlay.visible;
          this.pauseOverlay.destroy(true);
          this.pauseOverlay = undefined as unknown as PhaserType.GameObjects.Container;
          this.createPauseOverlay();
          this.pauseOverlay.setVisible(wasVisible);
        }
      }

      /* --------------------------------------------------------
         操作指南遮罩（H 键切换）
         -------------------------------------------------------- */

      private createHelpOverlay(): void {
        this.helpOverlay = this.add.container(0, 0);
        this.helpOverlay.setDepth(180);
        this.helpOverlay.setVisible(false);

        /* 半透明背景遮罩 */
        const bg = this.add.rectangle(
          GAME_W / 2, GAME_H / 2,
          GAME_W, GAME_H,
          0x000000, 0.72,
        );
        this.helpOverlay.add(bg);

        /* 面板背景（圆角矩形，居中）
         * v5.0: 高度根据条目数量动态计算，避免内容超出弹窗底部 */
        interface HelpEntry {
          readonly groupKey: string;
          readonly groupFallback: string;
          readonly keyKey: string;
          readonly keyFallback: string;
          readonly descKey: string;
          readonly descFallback: string;
        }
        const entries: readonly HelpEntry[] = [
          {
            groupKey: 'game.tank.guide.move',
            groupFallback: 'Move',
            keyKey: 'game.tank.guide.arrowKeys',
            keyFallback: 'Arrow keys',
            descKey: 'game.tank.guide.moveDesc',
            descFallback: 'Move your tank',
          },
          {
            groupKey: 'game.tank.guide.shoot',
            groupFallback: 'Shoot',
            keyKey: 'game.tank.guide.space',
            keyFallback: 'Space',
            descKey: 'game.tank.guide.shootDesc',
            descFallback: 'Fire bullets',
          },
          {
            groupKey: 'game.tank.guide.other',
            groupFallback: 'Other',
            keyKey: 'P',
            keyFallback: 'P',
            descKey: 'game.tank.guide.pauseDesc',
            descFallback: 'Pause/Resume',
          },
          {
            groupKey: 'game.tank.guide.other',
            groupFallback: 'Other',
            keyKey: 'R',
            keyFallback: 'R',
            descKey: 'game.tank.guide.restartDesc',
            descFallback: 'Restart',
          },
          {
            groupKey: 'game.tank.guide.other',
            groupFallback: 'Other',
            keyKey: 'H',
            keyFallback: 'H',
            descKey: 'game.tank.guide.helpDesc',
            descFallback: 'Toggle help',
          },
        ];
        const ENTRY_HEIGHT = 38;
        const TITLE_AREA_H = 70; /* 标题(24) + 关闭提示(24) + 分隔线间距(22) */
        const BOTTOM_PADDING = 24;
        const panelW = 280;
        const panelH = TITLE_AREA_H + entries.length * ENTRY_HEIGHT + BOTTOM_PADDING;
        const panelX = (GAME_W - panelW) / 2;
        const panelY = (GAME_H - panelH) / 2;
        const panel = this.add.rectangle(
          GAME_W / 2, GAME_H / 2,
          panelW, panelH,
          0x0f172a, 0.96,
        );
        panel.setStrokeStyle(1.5, 0x60a5fa, 0.8);
        this.helpOverlay.add(panel);

        const sansFont = '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
        const cx = GAME_W / 2;

        /* 标题 */
        const title = this.add.text(
          cx, panelY + 24,
          tr('game.tank.guide.title', 'Controls'),
          {
            fontFamily: sansFont,
            fontSize: '18px',
            color: '#fde047',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 2,
          },
        );
        title.setOrigin(0.5, 0.5);
        this.helpOverlay.add(title);

        /* 关闭提示（标题下方） */
        const closeHint = this.add.text(
          cx, panelY + 48,
          tr('game.tank.guide.close', 'Press H to close'),
          {
            fontFamily: sansFont,
            fontSize: '11px',
            color: '#94a3b8',
          },
        );
        closeHint.setOrigin(0.5, 0.5);
        this.helpOverlay.add(closeHint);

        /* 分组分隔线 */
        const dividerY = panelY + 70;
        const divider = this.add.rectangle(cx, dividerY, panelW - 32, 1, 0x334155);
        this.helpOverlay.add(divider);

        /* 按键条目：键位 + 描述（entries 已在上方定义，用于动态计算面板高度） */
        let entryY = dividerY + 18;
        const keyBoxW = 54;
        const keyBoxH = 22;
        const keyBoxX = panelX + 24;
        const descX = keyBoxX + keyBoxW + 12;

        for (const entry of entries) {
          /* 分组标签 */
          const groupText = this.add.text(
            keyBoxX, entryY,
            tr(entry.groupKey, entry.groupFallback),
            {
              fontFamily: sansFont,
              fontSize: '11px',
              color: '#60a5fa',
              fontStyle: 'bold',
            },
          );
          groupText.setOrigin(0, 0.5);
          this.helpOverlay.add(groupText);

          /* 键位方块 */
          const keyBox = this.add.rectangle(
            keyBoxX + keyBoxW / 2, entryY + 18,
            keyBoxW, keyBoxH,
            0x1e293b, 1,
          );
          keyBox.setStrokeStyle(1, 0x475569, 1);
          this.helpOverlay.add(keyBox);

          /* 键位文字 */
          const keyText = this.add.text(
            keyBoxX + keyBoxW / 2, entryY + 18,
            tr(entry.keyKey, entry.keyFallback),
            {
              fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
              fontSize: '13px',
              color: '#f1f5f9',
              fontStyle: 'bold',
            },
          );
          keyText.setOrigin(0.5, 0.5);
          this.helpOverlay.add(keyText);

          /* 描述文字 */
          const descText = this.add.text(
            descX, entryY + 18,
            tr(entry.descKey, entry.descFallback),
            {
              fontFamily: sansFont,
              fontSize: '12px',
              color: '#cbd5e1',
            },
          );
          descText.setOrigin(0, 0.5);
          this.helpOverlay.add(descText);

          entryY += 38;
        }
      }

      /** 切换操作指南面板显示 */
      private toggleHelpOverlay(): void {
        this.helpVisible = !this.helpVisible;
        if (this.helpOverlay !== undefined && this.helpOverlay.scene !== null) {
          this.helpOverlay.setVisible(this.helpVisible);
        }
      }

      /* --------------------------------------------------------
         游戏结束遮罩
         -------------------------------------------------------- */

      private createGameOverOverlay(): void {
        this.gameOverOverlay = this.add.container(0, 0);
        this.gameOverOverlay.setDepth(200);
        this.gameOverOverlay.setVisible(false);
      }

      /** 显示游戏结束 / 胜利画面 */
      private showGameOverScreen(message: string, isVictory: boolean): void {
        /* 半透明遮罩 */
        const bg = this.add.rectangle(
          GAME_W / 2, (GAME_H - HUD_H) / 2,
          GAME_W, CANVAS_H,
          0x000000, 0.75,
        );
        bg.setDepth(200);
        this.gameOverOverlay.add(bg);

        const fontFamily = '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';

        /* 主标题 */
        const title = this.add.text(
          GAME_W / 2, GAME_H / 2 - 50,
          message,
          {
            fontFamily,
            fontSize: '32px',
            color: isVictory ? '#fde047' : '#ef4444',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 4,
          },
        );
        title.setOrigin(0.5, 0.5);
        title.setDepth(201);
        title.setAlpha(0);
        this.gameOverOverlay.add(title);

        /* 最终分数 */
        const scoreLine = this.add.text(
          GAME_W / 2, GAME_H / 2 + 5,
          tr('game.tank.hud.finalScore', 'Final score: {score}', { score: this.score }),
          {
            fontFamily,
            fontSize: '20px',
            color: '#ffffff',
          },
        );
        scoreLine.setOrigin(0.5, 0.5);
        scoreLine.setDepth(201);
        scoreLine.setAlpha(0);
        this.gameOverOverlay.add(scoreLine);

        /* 重启提示 */
        const hint = this.add.text(
          GAME_W / 2, GAME_H / 2 + 45,
          tr('game.common.restartKey', 'Press R to restart'),
          {
            fontFamily,
            fontSize: '16px',
            color: '#94a3b8',
          },
        );
        hint.setOrigin(0.5, 0.5);
        hint.setDepth(201);
        hint.setAlpha(0);
        this.gameOverOverlay.add(hint);

        this.gameOverOverlay.setVisible(true);

        /* 淡入动画 */
        this.tweens.add({
          targets: title,
          alpha: 1,
          duration: 500,
          delay: 300,
        });
        this.tweens.add({
          targets: scoreLine,
          alpha: 1,
          duration: 500,
          delay: 600,
        });
        this.tweens.add({
          targets: hint,
          alpha: 1,
          duration: 500,
          delay: 900,
        });
      }

      /* --------------------------------------------------------
         爆炸 / 特效
         -------------------------------------------------------- */

      /** 创建爆炸效果 */
      private createExplosion(x: number, y: number, color: number, scale: number): void {
        this.playSound('explosion');

        /* 主爆炸圆 */
        const blast = this.add.circle(x, y, 6 * scale, color, 0.9);
        blast.setDepth(50);
        this.tweens.add({
          targets: blast,
          scale: { from: 0.5, to: 4 + scale },
          alpha: { from: 0.9, to: 0 },
          duration: 400,
          ease: 'Power2',
          onComplete: () => blast.destroy(),
        });

        /* 冲击波环 */
        const ring = this.add.circle(x, y, 8 * scale, 0xffffff, 0);
        ring.setStrokeStyle(2, 0xffffff, 0.8);
        ring.setDepth(49);
        this.tweens.add({
          targets: ring,
          scale: { from: 0.5, to: 5 + scale },
          alpha: { from: 0.8, to: 0 },
          duration: 500,
          ease: 'Power2',
          onComplete: () => ring.destroy(),
        });

        /* 碎片粒子（向外飞散） */
        const debrisCount = Math.floor(4 + scale * 2);
        for (let i = 0; i < debrisCount; i++) {
          const angle = (Math.PI * 2 * i) / debrisCount + Math.random() * 0.5;
          const dist = 20 + Math.random() * 20 * scale;
          const debris = this.add.rectangle(x, y, 3, 3, color, 1);
          debris.setDepth(51);
          this.tweens.add({
            targets: debris,
            x: x + Math.cos(angle) * dist,
            y: y + Math.sin(angle) * dist,
            alpha: 0,
            scale: 0,
            duration: 400 + Math.random() * 200,
            ease: 'Power1',
            onComplete: () => debris.destroy(),
          });
        }
      }

      /** 子弹击中墙体的小爆炸 */
      private createBulletImpact(x: number, y: number): void {
        this.playSound('hit');

        const impact = this.add.circle(x, y, 4, 0xffffff, 0.9);
        impact.setDepth(50);
        this.tweens.add({
          targets: impact,
          scale: { from: 0.5, to: 3 },
          alpha: { from: 0.9, to: 0 },
          duration: 200,
          ease: 'Power2',
          onComplete: () => impact.destroy(),
        });
      }

      /** 坦克被击中时的闪光 */
      private createHitFlash(x: number, y: number): void {
        const flash = this.add.circle(x, y, 16, 0xffffff, 0.8);
        flash.setDepth(55);
        this.tweens.add({
          targets: flash,
          alpha: 0,
          scale: 1.5,
          duration: 150,
          ease: 'Power1',
          onComplete: () => flash.destroy(),
        });
      }

      /* --------------------------------------------------------
         子弹拖尾
         -------------------------------------------------------- */

      private updateBulletTrails(time: number): void {
        this.updateGroupTrails(this.playerBullets, time, 0xfde047);
        this.updateGroupTrails(this.enemyBullets, time, 0xfb923c);
      }

      private updateGroupTrails(
        group: PhaserType.Physics.Arcade.Group,
        time: number,
        color: number,
      ): void {
        for (const child of group.getChildren()) {
          const bullet = child as PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody;
          const lastTrail = bullet.getData('lastTrail');
          if (typeof lastTrail === 'number' && time - lastTrail < 40) continue;

          const trail = this.add.circle(bullet.x, bullet.y, 3, color, 0.6);
          trail.setDepth(15);
          this.tweens.add({
            targets: trail,
            alpha: 0,
            scale: 0.2,
            duration: 200,
            ease: 'Power1',
            onComplete: () => trail.destroy(),
          });
          bullet.setData('lastTrail', time);
        }
      }

      /* --------------------------------------------------------
         音效占位
         -------------------------------------------------------- */

      /**
       * 音效占位（后续接入音频系统）。
       * @param name 音效名称：'shoot' | 'explosion' | 'hit' | 'move'
       */
      private playSound(_name: string): void {
        /* no-op: 音效占位，后续接入音频系统 */
      }

      /* --------------------------------------------------------
         地图构建
         -------------------------------------------------------- */

      private buildMap(level: number): void {
        /* 清除旧瓦片 */
        this.bricks.clear(true, true);
        this.steels.clear(true, true);

        const map = getLevelMap(level);
        for (let row = 0; row < MAP_H; row++) {
          const rowData = map[row];
          if (rowData === undefined) continue;
          for (let col = 0; col < MAP_W; col++) {
            const tile = rowData[col];
            if (tile === undefined) continue;
            const x = col * TILE + TILE / 2;
            const y = row * TILE + TILE / 2;
            if (tile === TILE_BRICK) {
              const brick = this.physics.add.staticSprite(x, y, 'brick');
              this.bricks.add(brick);
            } else if (tile === TILE_STEEL) {
              const steel = this.physics.add.staticSprite(x, y, 'steel');
              this.steels.add(steel);
            } else if (tile === TILE_BASE) {
              this.base = this.physics.add.staticSprite(x, y, 'base');
            }
          }
        }
      }

      /* --------------------------------------------------------
         玩家
         -------------------------------------------------------- */

      private createPlayer(): void {
        const x = PLAYER_SPAWN_COL * TILE + TILE / 2;
        const y = PLAYER_SPAWN_ROW * TILE + TILE / 2;
        this.player = this.physics.add.sprite(x, y, 'tank-player');
        this.player.setCollideWorldBounds(true);
        this.player.setSize(28, 28);
        this.player.setOffset(2, 2);
        this.direction = 'up';
        this.player.setRotation(DIR_ROTATIONS[this.direction]);
      }

      private updatePlayer(time: number): void {
        if (this.cursors === undefined) return;

        let moving = false;
        const prevDirection = this.direction;

        if (this.cursors.left?.isDown === true) {
          this.direction = 'left';
          moving = true;
        } else if (this.cursors.right?.isDown === true) {
          this.direction = 'right';
          moving = true;
        } else if (this.cursors.up?.isDown === true) {
          this.direction = 'up';
          moving = true;
        } else if (this.cursors.down?.isDown === true) {
          this.direction = 'down';
          moving = true;
        }

        if (moving) {
          const vec = DIR_VECTORS[this.direction];
          this.player.setVelocity(vec.dx * PLAYER_SPEED, vec.dy * PLAYER_SPEED);
          if (this.direction !== prevDirection) {
            this.player.setRotation(DIR_ROTATIONS[this.direction]);
          }
          /* 移动音效（仅在从静止到移动时触发） */
          if (!this.wasMoving) {
            this.playSound('move');
            this.wasMoving = true;
          }
        } else {
          this.player.setVelocity(0, 0);
          this.wasMoving = false;
        }

        /* 对齐到网格（便于在走廊中移动） */
        this.snapToGrid();

        /* 射击 */
        if (this.fireKey.isDown && time - this.lastFireTime >= PLAYER_FIRE_COOLDOWN) {
          this.fireBullet(this.player.x, this.player.y, this.direction, true);
          this.lastFireTime = time;
        }

        /* 无敌闪烁 */
        if (time < this.invincibleUntil) {
          this.player.setVisible(Math.floor(time / 120) % 2 === 0);
        } else if (!this.player.visible) {
          this.player.setVisible(true);
        }
      }

      /** 将坦克位置对齐到网格中心，避免卡墙 */
      private snapToGrid(): void {
        const threshold = 4;
        if (this.direction === 'up' || this.direction === 'down') {
          const col = Math.round((this.player.x - TILE / 2) / TILE);
          const targetX = col * TILE + TILE / 2;
          if (Math.abs(this.player.x - targetX) < threshold) {
            this.player.x = targetX;
          }
        } else {
          const row = Math.round((this.player.y - TILE / 2) / TILE);
          const targetY = row * TILE + TILE / 2;
          if (Math.abs(this.player.y - targetY) < threshold) {
            this.player.y = targetY;
          }
        }
      }

      /* --------------------------------------------------------
         敌方 AI
         -------------------------------------------------------- */

      private trySpawnEnemy(time: number): void {
        const activeCount = this.enemies.getChildren().length;
        if (this.enemiesRemaining <= 0 || activeCount >= MAX_ACTIVE_ENEMIES) return;
        if (time - this.lastEnemySpawn < diffConfig.enemySpawnInterval) return;

        /* 选择一个出生点 */
        const spawnIdx = activeCount % ENEMY_SPAWN_COLS.length;
        const col = ENEMY_SPAWN_COLS[spawnIdx];
        if (col === undefined) return;
        const x = col * TILE + TILE / 2;
        const y = ENEMY_SPAWN_ROW * TILE + TILE / 2;

        this.spawnEnemyAt(x, y, time);
        this.lastEnemySpawn = time;
      }

      private spawnEnemyAt(x: number, y: number, time: number): void {
        /* 随机决定是否为精英敌方 */
        const isElite = Math.random() < ELITE_ENEMY_CHANCE;
        const textureKey = isElite ? 'tank-enemy-elite' : 'tank-enemy';
        const enemy = this.physics.add.sprite(x, y, textureKey);
        enemy.setCollideWorldBounds(true);
        enemy.setSize(28, 28);
        enemy.setOffset(2, 2);

        /* 初始 AI 状态 */
        const initDir: Direction = 'down';
        const aiData: EnemyAiData = {
          state: 'patrol',
          direction: initDir,
          lastStateChange: time,
          lastFireTime: 0,
          nextAiUpdate: time + diffConfig.enemyAiInterval,
        };
        enemy.setData(AI_DATA_KEY, aiData);
        enemy.setData('elite', isElite);

        const speed = isElite
          ? diffConfig.enemySpeed * ELITE_ENEMY_SPEED_MULT
          : diffConfig.enemySpeed;
        enemy.setVelocity(0, speed);
        enemy.setRotation(DIR_ROTATIONS[initDir]);

        this.enemies.add(enemy);
      }

      private updateEnemies(time: number): void {
        const children = this.enemies.getChildren();
        for (const child of children) {
          const enemy = child as PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody;
          const ai = enemy.getData(AI_DATA_KEY) as EnemyAiData | null;
          if (ai === null) continue;

          /* AI 状态更新 */
          if (time >= ai.nextAiUpdate) {
            this.updateEnemyAi(enemy, ai, time);
          }

          /* 检查是否被阻挡，换向 */
          const body = enemy.body;
          if (body === null || body === undefined) continue;
          const blocked = body.blocked;
          if (blocked.up || blocked.down || blocked.left || blocked.right) {
            this.changeEnemyDirection(enemy, ai, time, true);
          }

          /* 射击 */
          if (time - ai.lastFireTime >= diffConfig.enemyFireInterval) {
            this.fireBullet(enemy.x, enemy.y, ai.direction, false);
            ai.lastFireTime = time;
          }
        }
      }

      /** 敌方 AI 状态机更新 */
      private updateEnemyAi(
        enemy: PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody,
        ai: EnemyAiData,
        time: number,
      ): void {
        const distToPlayer = Phaser.Math.Distance.Between(
          enemy.x, enemy.y,
          this.player.x, this.player.y,
        );

        /* 状态切换：hard 难度优先追击 */
        const chaseRange = difficulty === 'hard' ? 200 : difficulty === 'easy' ? 80 : 140;

        if (ai.state === 'patrol' && distToPlayer < chaseRange) {
          ai.state = 'chase';
        } else if (ai.state === 'chase' && distToPlayer > chaseRange * 1.5) {
          ai.state = 'patrol';
        }

        if (ai.state === 'chase') {
          /* 朝玩家方向移动 */
          const dx = this.player.x - enemy.x;
          const dy = this.player.y - enemy.y;
          if (Math.abs(dx) > Math.abs(dy)) {
            ai.direction = dx > 0 ? 'right' : 'left';
          } else {
            ai.direction = dy > 0 ? 'down' : 'up';
          }
        } else {
          /* 巡逻：随机换向 */
          const randomIdx = Math.floor(Math.random() * ALL_DIRECTIONS.length);
          const newDir = ALL_DIRECTIONS[randomIdx];
          if (newDir !== undefined) {
            ai.direction = newDir;
          }
        }

        this.applyEnemyVelocity(enemy, ai);
        ai.lastStateChange = time;
        ai.nextAiUpdate = time + diffConfig.enemyAiInterval;
      }

      /** 改变敌方方向（被阻挡时调用） */
      private changeEnemyDirection(
        enemy: PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody,
        ai: EnemyAiData,
        time: number,
        forced: boolean,
      ): void {
        /* 随机选择一个不同于当前方向的方向 */
        const choices = ALL_DIRECTIONS.filter((d) => d !== ai.direction);
        const randomIdx = Math.floor(Math.random() * choices.length);
        const newDir = choices[randomIdx];
        if (newDir !== undefined) {
          ai.direction = newDir;
        }
        this.applyEnemyVelocity(enemy, ai);
        if (forced) {
          ai.nextAiUpdate = time + diffConfig.enemyAiInterval;
        }
      }

      private applyEnemyVelocity(
        enemy: PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody,
        ai: EnemyAiData,
      ): void {
        const vec = DIR_VECTORS[ai.direction];
        const isElite = enemy.getData('elite') === true;
        const speed = isElite
          ? diffConfig.enemySpeed * ELITE_ENEMY_SPEED_MULT
          : diffConfig.enemySpeed;
        enemy.setVelocity(vec.dx * speed, vec.dy * speed);
        enemy.setRotation(DIR_ROTATIONS[ai.direction]);
      }

      /* --------------------------------------------------------
         子弹
         -------------------------------------------------------- */

      private fireBullet(x: number, y: number, direction: Direction, isPlayer: boolean): void {
        this.playSound('shoot');

        const vec = DIR_VECTORS[direction];
        const offsetX = vec.dx * 14;
        const offsetY = vec.dy * 14;

        const group = isPlayer ? this.playerBullets : this.enemyBullets;
        const bullet = group.create(x + offsetX, y + offsetY, 'bullet') as
          PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody;
        if (bullet === null) return;

        bullet.setCollideWorldBounds(false);
        bullet.setSize(6, 6);
        bullet.setVelocity(vec.dx * BULLET_SPEED, vec.dy * BULLET_SPEED);
        bullet.setData('owner', isPlayer ? 'player' : 'enemy');
      }

      /** 清理飞出边界的子弹 */
      private cleanupBullets(): void {
        this.cleanupGroupBullets(this.playerBullets);
        this.cleanupGroupBullets(this.enemyBullets);
      }

      private cleanupGroupBullets(group: PhaserType.Physics.Arcade.Group): void {
        const children = group.getChildren();
        for (const child of children) {
          const bullet = child as PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody;
          if (bullet.x < 0 || bullet.x > GAME_W || bullet.y < 0 || bullet.y > GAME_H) {
            bullet.destroy();
          }
        }
      }

      /* --------------------------------------------------------
         碰撞设置
         -------------------------------------------------------- */

      private setupCollisions(): void {
        /* 坦克 vs 墙体（物理阻挡） */
        this.physics.add.collider(this.player, this.bricks);
        this.physics.add.collider(this.player, this.steels);
        this.physics.add.collider(this.player, this.base);
        this.physics.add.collider(this.enemies, this.bricks);
        this.physics.add.collider(this.enemies, this.steels);
        this.physics.add.collider(this.enemies, this.base);
        this.physics.add.collider(this.player, this.enemies);
        this.physics.add.collider(this.enemies, this.enemies);

        /* 子弹重叠检测 */
        this.physics.add.overlap(
          this.playerBullets, this.enemies,
          (obj1, obj2) => this.onBulletHitEnemy(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.playerBullets, this.bricks,
          (obj1, obj2) => this.onBulletHitBrick(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.playerBullets, this.steels,
          (obj1, obj2) => this.onBulletHitSteel(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.playerBullets, this.base,
          (obj1, obj2) => this.onBulletHitBase(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.enemyBullets, this.player,
          (obj1, obj2) => this.onBulletHitPlayer(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.enemyBullets, this.bricks,
          (obj1, obj2) => this.onBulletHitBrick(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.enemyBullets, this.steels,
          (obj1, obj2) => this.onBulletHitSteel(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.enemyBullets, this.base,
          (obj1, obj2) => this.onBulletHitBase(obj1, obj2), undefined, this,
        );
        this.physics.add.overlap(
          this.playerBullets, this.enemyBullets,
          (obj1, obj2) => this.onBulletHitBullet(obj1, obj2), undefined, this,
        );
      }

      /* --------------------------------------------------------
         碰撞回调
         -------------------------------------------------------- */

      private onBulletHitEnemy(
        obj1: CollisionObject,
        obj2: CollisionObject,
      ): void {
        const bullet = this.asSprite(obj1);
        const enemy = this.asSprite(obj2);
        if (bullet === null || enemy === null) return;
        if (bullet.getData('owner') !== 'player') return;

        const enemyX = enemy.x;
        const enemyY = enemy.y;
        const isElite = enemy.getData('elite') === true;

        /* 击中闪光 */
        this.createHitFlash(enemyX, enemyY);

        bullet.destroy();
        enemy.destroy();

        /* 爆炸效果（精英敌方使用红色，普通敌方使用橙色） */
        const explosionColor = isElite ? 0xef4444 : 0xfb923c;
        this.createExplosion(enemyX, enemyY, explosionColor, 1.0);

        this.score += SCORE_PER_KILL;
        this.enemiesRemaining = Math.max(0, this.enemiesRemaining - 1);
        this.updateHUD();
        notifyScore(this.score, this.level);

        if (this.enemiesRemaining <= 0 && this.enemies.getChildren().length === 0) {
          this.advanceLevel();
        }
      }

      private onBulletHitPlayer(
        obj1: CollisionObject,
        obj2: CollisionObject,
      ): void {
        const bullet = this.asSprite(obj1);
        const player = this.asSprite(obj2);
        if (bullet === null || player === null) return;
        if (bullet.getData('owner') !== 'enemy') return;

        const bx = bullet.x;
        const by = bullet.y;
        bullet.destroy();

        /* 无敌时子弹反弹效果 */
        if (this.time.now < this.invincibleUntil) {
          this.createBulletImpact(bx, by);
          return;
        }

        this.hitPlayer();
      }

      private onBulletHitBrick(
        obj1: CollisionObject,
        obj2: CollisionObject,
      ): void {
        const bullet = this.asSprite(obj1);
        const brick = this.asStaticSprite(obj2);
        if (bullet === null || brick === null) return;
        const bx = bullet.x;
        const by = bullet.y;
        bullet.destroy();
        brick.destroy();
        this.createBulletImpact(bx, by);
      }

      private onBulletHitSteel(
        obj1: CollisionObject,
        _obj2: CollisionObject,
      ): void {
        const bullet = this.asSprite(obj1);
        if (bullet === null) return;
        const bx = bullet.x;
        const by = bullet.y;
        bullet.destroy();
        this.createBulletImpact(bx, by);
      }

      private onBulletHitBase(
        obj1: CollisionObject,
        _obj2: CollisionObject,
      ): void {
        const bullet = this.asSprite(obj1);
        if (bullet === null) return;
        bullet.destroy();

        /* 基地爆炸 */
        this.createExplosion(this.base.x, this.base.y, 0xf59e0b, 2.0);
        this.endGame('base');
      }

      private onBulletHitBullet(
        obj1: CollisionObject,
        obj2: CollisionObject,
      ): void {
        const b1 = this.asSprite(obj1);
        const b2 = this.asSprite(obj2);
        if (b1 === null || b2 === null) return;
        const mx = (b1.x + b2.x) / 2;
        const my = (b1.y + b2.y) / 2;
        b1.destroy();
        b2.destroy();
        this.createBulletImpact(mx, my);
      }

      /* --------------------------------------------------------
         玩家受击 / 关卡 / 游戏结束
         -------------------------------------------------------- */

      private hitPlayer(): void {
        const px = this.player.x;
        const py = this.player.y;

        this.lives -= 1;
        this.updateHUD();

        /* 玩家爆炸（更大的爆炸效果） */
        this.createExplosion(px, py, 0xfbbf24, 1.5);

        if (this.lives <= 0) {
          this.endGame('lives');
          return;
        }

        /* 重生 */
        const x = PLAYER_SPAWN_COL * TILE + TILE / 2;
        const y = PLAYER_SPAWN_ROW * TILE + TILE / 2;
        this.player.setPosition(x, y);
        this.direction = 'up';
        this.player.setRotation(DIR_ROTATIONS.up);
        this.player.setVelocity(0, 0);
        this.invincibleUntil = this.time.now + INVINCIBLE_DURATION;
      }

      private startLevel(level: number): void {
        this.buildMap(level);
        this.enemies.clear(true, true);
        this.playerBullets.clear(true, true);
        this.enemyBullets.clear(true, true);

        /* 重置玩家位置 */
        const x = PLAYER_SPAWN_COL * TILE + TILE / 2;
        const y = PLAYER_SPAWN_ROW * TILE + TILE / 2;
        this.player.setPosition(x, y);
        this.direction = 'up';
        this.player.setRotation(DIR_ROTATIONS.up);
        this.player.setVelocity(0, 0);

        /* 敌方数量随关卡递增 */
        this.enemiesRemaining = diffConfig.enemiesPerLevel + (level - 1) * 2;
        this.lastEnemySpawn = 0;
        this.gameOver = false;
        this.levelTransitioning = true;

        /* 更新 HUD */
        this.updateHUD();

        /* 显示关卡过渡文本 */
        this.showStageTransition(level);
      }

      /** 显示 "Stage N" 过渡文本，2 秒后淡出并开始游戏 */
      private showStageTransition(level: number): void {
        this.stageText.setText(`Stage ${level}`);
        this.stageText.setAlpha(0);
        this.stageText.setVisible(true);

        /* 淡入 */
        this.tweens.add({
          targets: this.stageText,
          alpha: 1,
          duration: 300,
          ease: 'Power2',
          onComplete: () => {
            /* 持续 1.4 秒后淡出 */
            this.time.delayedCall(1400, () => {
              this.tweens.add({
                targets: this.stageText,
                alpha: 0,
                duration: 300,
                ease: 'Power2',
                onComplete: () => {
                  this.stageText.setVisible(false);
                  this.levelTransitioning = false;
                },
              });
            });
          },
        });
      }

      private advanceLevel(): void {
        this.levelTransitioning = true;

        /* 通关检查 */
        if (this.level >= MAX_LEVEL) {
          this.endGame('victory');
          return;
        }

        this.level += 1;
        this.time.delayedCall(800, () => {
          this.startLevel(this.level);
          notifyScore(this.score, this.level);
        });
      }

      /** 结束游戏
       * @param reason 结束原因：'lives' 生命耗尽 | 'base' 基地被毁 | 'victory' 通关
       */
      private endGame(reason: 'lives' | 'base' | 'victory'): void {
        if (this.gameOver) return;
        this.gameOver = true;
        this.player.setVelocity(0, 0);
        this.enemies.setVelocity(0, 0);

        let message: string;
        let status: GameStatus;

        if (reason === 'victory') {
          message = tr('game.tank.result.victory', 'VICTORY!');
          status = 'victory';
        } else if (reason === 'base') {
          message = tr('game.tank.result.defeat', 'Base destroyed!');
          status = 'gameover';
        } else {
          message = 'GAME OVER';
          status = 'gameover';
        }

        notifyStatus(status);
        this.showGameOverScreen(message, reason === 'victory');
      }

      /* --------------------------------------------------------
         类型工具
         -------------------------------------------------------- */

      private asSprite(
        obj: CollisionObject,
      ): PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody | null {
        if (typeof obj === 'object' && obj !== null && 'texture' in obj) {
          return obj as PhaserType.Types.Physics.Arcade.SpriteWithDynamicBody;
        }
        return null;
      }

      private asStaticSprite(
        obj: CollisionObject,
      ): PhaserType.Types.Physics.Arcade.SpriteWithStaticBody | null {
        if (typeof obj === 'object' && obj !== null && 'texture' in obj) {
          return obj as PhaserType.Types.Physics.Arcade.SpriteWithStaticBody;
        }
        return null;
      }
    }

    /* ============================================================
       创建 Phaser 游戏
       ============================================================ */

    /* v5.0 修复：传入外部 canvas 时，Phaser 视为"自定义环境"，AUTO(0) 会抛出
     * "Must set explicit renderType in custom environment"。
     * 因此必须显式指定 WEBGL(2)（文字锐利）或 CANVAS(1)，并按设备能力回退；源码验证：
     *   WEBGL=2 (phaser/src/const.js)
     *   CANVAS=1 (phaser/src/const.js)
     *   Scale.FIT=3 (phaser/src/scale/const/SCALE_MODE_CONST.js)
     *   CENTER_OFF=0 (phaser/src/scale/const/CENTER_CONST.js) */
    const RENDER_WEBGL: number = 2;
    const RENDER_CANVAS: number = 1;
    const SCALE_FIT: number = 3;
    /* v5.1：居中改为 CENTER_OFF(0)——canvas-wrap 是 flex 居中容器（align-items/justify-content:
     * center），Phaser CENTER_BOTH 会设置固定 margin（如 margin-left:187px），与 flex 居中叠加
     * 产生双倍偏移（实测水平偏 margin/2 ≈ 90px+）。关闭 autoCenter 后 margin 为 0，由 CSS flex
     * 兜底居中，任何窗口尺寸下都严格居中。 */
    const SCALE_CENTER_OFF: number = 0;

    const isWebGLSupported = ((): boolean => {
      try {
        const testCanvas = document.createElement('canvas');
        return (
          testCanvas.getContext('webgl') !== null ||
          testCanvas.getContext('experimental-webgl') !== null
        );
      } catch {
        return false;
      }
    })();
    const renderType = isWebGLSupported ? RENDER_WEBGL : RENDER_CANVAS;

    const config: PhaserType.Types.Core.GameConfig = {
      type: renderType,
      canvas,
      width: GAME_W,
      height: CANVAS_H,
      backgroundColor: '#0a0e14',
      antialias: true,
      roundPixels: true,
      scale: {
        mode: SCALE_FIT,
        autoCenter: SCALE_CENTER_OFF,
        parent: canvas.parentElement ?? null,
        width: GAME_W,
        height: CANVAS_H,
      },
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { x: 0, y: 0 },
        },
      },
      scene: [TankScene],
    };
    this.phaserGame = new Phaser.Game(config);
  }

  protected onUnmount(): void {
    if (this.phaserGame !== null) {
      this.phaserGame.destroy(true);
      this.phaserGame = null;
    }
    this.sceneControl = null;
  }

  protected override onPause(): void {
    /* 不使用 scene.pause()，以保证 P 键仍可检测（update 循环持续运行） */
    this.sceneControl?.setPaused(true);
  }

  protected override onResume(): void {
    this.sceneControl?.setPaused(false);
  }

  protected override onRestart(): void {
    /* 重置 GameHost 状态 */
    this.updateScore(0, 1);
    this.setStatus('playing');
    /* 重启场景（create 会重置所有字段） */
    this.phaserGame?.scene.start(this.sceneKey);
  }

  /* 内部桥接方法（供 TankScene 回调） */
  private updateScorePublic(score: number, level: number): void {
    this.updateScore(score, level);
  }

  private updateStatusPublic(status: GameStatus, message?: string): void {
    this.setStatus(status, message);
  }
}


  /* =========================================================
     6. 样式内嵌（styles.css 同源；注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * 小游戏宿主样式（zby-creation 扁平包）
 *
 * 源：src/shared/apps/games/game-host.css 平移（与 tetris 转包同源）。
 * 依赖的 CSS 变量全部带 fallback：沙箱皮肤注入缺失时仍可渲染，不白屏。
 * 变量取值对齐宿主 design-tokens 默认（沙箱注入优先覆盖）。
 */

/**
 * game-host.css — 小游戏宿主样式
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - 容器铺满窗口 body（.game-host-root）
 *   - HUD 顶部固定（分数 + 控制按钮）
 *   - 画布居中、保持比例、自适应缩放
 *   - 主题色由 CSS 变量驱动（--bg-canvas / --fg-primary / --accent-cool 等）
 *   - 暂停时画布半透明遮罩 + "Paused"提示
 *   - 隐藏滚动条（项目记忆：避免底部水平滚动条）
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */

.game-host-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  /* 玻璃配方（GlassSidePanel 同款）：垫底随主题模式/皮肤，半透明白透出坊市体验层毛玻璃 */
  background: var(--skin-pattern-image, none), color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 95%, var(--surface-solid-primary, #ffffff) 5%);
  backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  color: var(--glass-text-primary, #e8e8e8);
  font-family: var(--skin-font-body, -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif);
  overflow: hidden;
  /* 防止 iOS 弹性滚动影响游戏体验 */
  overscroll-behavior: contain;
  -webkit-user-select: none;
  user-select: none;
}

/* ============================================================
   HUD（顶部条）
   ============================================================ */

.game-host-hud {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
  background: color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 92%, var(--surface-solid-primary, #ffffff) 8%);
  border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  flex-shrink: 0;
}

/* G2 F 头：皮肤色渐细发丝线（HUD 底缘） */
.game-host-hud::after {
  content: '';
  position: absolute;
  left: var(--layout-row-pad-x, 0.875rem);
  right: var(--layout-row-pad-x, 0.875rem);
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
  pointer-events: none;
}

.game-host-hud-left {
  display: flex;
  align-items: baseline;
  gap: 0.875rem;
  min-width: 0;
  overflow: hidden;
}

/* G2 F 头：mono kicker（与宿主 .zby-page-head__kicker 同配方，自包含 fallback） */
.game-host-hud-kicker {
  font-family: var(--type-mono, var(--skin-font-mono, ui-monospace, monospace));
  font-size: 0.5625rem;
  font-weight: 700;
  letter-spacing: 0.32em;
  color: var(--deco-primary, var(--accent, #3cb371));
  white-space: nowrap;
  flex-shrink: 0;
}

.game-host-hud-title {
  /* F 语言：衬线显示字体 + 字距（UI-REMAINING-WAVES Wave G L2；--type-display 经沙箱白名单注入） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 0.875rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--glass-text-primary, #e8e8e8);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

/* 计分区（2026-09-15 改双行）：分数 / 最高分各占一行——左信息带宽度有限，
   同行合并文案窄屏时截断显示不全；行内 nowrap（单值不会溢出），行间堆叠 */
.game-host-hud-score {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.game-host-hud-score-line {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 0.5rem;
  min-width: 0;
}

.game-host-hud-score-label {
  font-family: var(--type-mono, monospace);
  font-size: 0.6875rem;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--glass-text-tertiary, #999);
  flex-shrink: 0;
}

.game-host-hud-score-value {
  font-size: 0.8125rem;
  font-variant-numeric: tabular-nums;
  color: var(--glass-text-secondary, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.game-host-hud-right {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

/* P4.7：按钮基座化（铁律 9）——ui-kit btn 片段内嵌快照（assets/ui-kit/btn.css），
 * 选择器扩列桥接 .game-host-hud-btn（HUD 暂停/重开/难度控件），
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：次按钮 + 小尺寸变体。 */

.btn, .game-host-hud-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .game-host-hud-btn:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .game-host-hud-btn:disabled,
.btn[disabled], .game-host-hud-btn[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 次按钮：卡片玻璃底（HUD 暂停/重开/难度选择） */
.btn--secondary, .game-host-hud-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .game-host-hud-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 尺寸变体：小尺寸（HUD 紧凑布局） */
.btn--sm, .game-host-hud-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .game-host-hud-btn{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}

/* =========================================================
   P4.7b：皮肤按钮形状钩子表（皮肤形状语言内嵌快照）
   ---------------------------------------------------------
   宿主端按钮形状 = tokens.css data-interaction-model 通用规则
   （src/shared/design-tokens/tokens.css）+ 各皮肤 Manifest extraCSS
   （src/domains/themes/skins/*.ts）；iframe 无法继承宿主样式表，
   此处内嵌按钮形状语言子集，由 MultiFileSandbox 同步的
   data-skin / data-interaction-model / data-theme-mode 属性驱动，
   使游戏按钮获得与宿主同款手绘边框/糖果胶囊 3D/像素厚度/粗描边
   错位/油墨细线/浮雕等形状语言。
   约定：
   - 顺序与宿主一致：交互模型通用规则在前，皮肤 extraCSS 在后
     （同特异性后注入者胜，island 默认态即依赖此顺序让位 toy hover）
   - 深色变体选择器用 [data-theme-mode="dark"]（iframe 同步属性，
     非宿主的 data-theme-mode-effective）
   - 皮肤自定义变量（--is-ink/--is-cream/--toy-shadow/--ra-ink/
     --neumo-dark/--neumo-light）不在沙箱注入白名单
     （sandbox-skin-var-names.ts），一律 var(..., fallback)
   - iframe 内按钮必挂 .btn 类（core.tpl 受控），钩子表只写 .btn
   - 修改需同步宿主真相源（tokens.css + skins/*.ts extraCSS）
   ========================================================= */

/* —— 1. 交互模型通用规则子集（tokens.css data-interaction-model 快照） —— */

/* 交互类统一过渡节奏 */
[data-interaction-model] .btn{
  transition:
    background var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    color var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1));
}

/* lightweight：轻反馈 — 按下微缩放 */
[data-interaction-model="lightweight"] .btn:active{
  transform: scale(var(--motion-travel-press, 0.98));
}

/* responsive：标准反馈 — hover 上浮 + 按下微缩放 */
[data-interaction-model="responsive"] .btn:hover{
  transform: translateY(var(--motion-travel-hover, -1px));
}
[data-interaction-model="responsive"] .btn:active{
  transform: translateY(0) scale(var(--motion-travel-press, 0.98));
}

/* terminal：命令行式反馈 — hover 品红下划线、按下反白、focus 品红描边
   （硬编码色 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="terminal"] .btn:hover{
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(255, 46, 136, 0.55);
}
[data-interaction-model="terminal"] .btn:active{
  color: rgba(232, 237, 246, 1);
  background: rgba(255, 46, 136, 1);
  text-decoration: none;
}
[data-interaction-model="terminal"] .btn:focus-visible{
  outline: 1px solid rgba(255, 46, 136, 1);
  outline-offset: 2px;
}

/* print：印刷批注式反馈 — hover 印刷红下划线、按下墨底反白、focus 红细描边（深色反白）。
   硬编码色一律 rgba 等价书写（皮肤契约 forbidHardcodedColors 不认裸 hex） */
[data-interaction-model="print"] .btn:hover{
  color: rgba(192, 57, 43, 1);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(192, 57, 43, 0.55);
}
[data-interaction-model="print"] .btn:active{
  color: rgba(240, 231, 211, 1);
  background: rgba(26, 26, 24, 1);
  text-decoration: none;
}
[data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(192, 57, 43, 0.5);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:hover{
  color: rgba(226, 112, 90, 1);
  text-decoration-color: rgba(226, 112, 90, 0.6);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:active{
  color: rgba(32, 31, 27, 1);
  background: rgba(240, 231, 211, 1);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(226, 112, 90, 0.6);
}

/* snap：瞬时反馈 — hover 黑白互换、按下黑底黄字、focus 2px 黑描边（深色对称反转；
   硬编码色一律 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="snap"] .btn:hover{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 255, 255, 1);
  transition-duration: 0ms;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:hover{
  background: rgba(255, 255, 255, 1);
  color: rgba(17, 17, 17, 1);
}
[data-interaction-model="snap"] .btn:active{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 195, 0, 1);
  transition-duration: 0ms;
}
[data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(17, 17, 17, 1);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(255, 255, 255, 1);
  outline-offset: 2px;
}

/* doodle：手绘反馈 — hover 蜡笔红波浪下划线 + 微旋转、按下反向回弹、focus 蜡笔虚线 */
[data-interaction-model="doodle"] .btn:hover{
  transform: rotate(-0.5deg);
  text-decoration: underline;
  text-underline-offset: 4px;
  text-decoration-style: wavy;
  text-decoration-color: rgba(232, 96, 76, 0.75);
  text-decoration-thickness: 1.5px;
}
[data-theme-mode="dark"][data-interaction-model="doodle"] .btn:hover{
  text-decoration-color: rgba(91, 168, 201, 0.8);
}
[data-interaction-model="doodle"] .btn:active{
  transform: rotate(0.5deg) scale(0.97);
  text-decoration: none;
}
[data-interaction-model="doodle"] .btn:focus-visible{
  outline: 2px dashed rgba(232, 96, 76, 0.8);
  outline-offset: 2px;
}

/* hygge：柔和暖色反馈 — hover 暖色高亮、按下轻微缩放、focus 暖色细描边 */
[data-interaction-model="hygge"] .btn:hover{
  background: color-mix(in srgb, var(--accent-warm, #C08552) 10%, transparent);
}
[data-interaction-model="hygge"] .btn:active{
  transform: scale(0.99);
}
[data-interaction-model="hygge"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-warm, #C08552) 65%, transparent);
  outline-offset: 2px;
}

/* neumorphic：同色浮雕反馈 — hover 外凸、按下内凹、focus 柔和高亮 */
[data-interaction-model="neumorphic"] .btn:hover{
  box-shadow:
    4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:active{
  box-shadow:
    inset 4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    inset -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-cool, #7A8BA6) 50%, transparent);
  outline-offset: 2px;
}

/* toy：玩具 3D 按压 — hover 抬升（底沿加深）、按下塌陷（下沉 + 底沿归零） */
[data-interaction-model="toy"] .btn:hover:not(:disabled){
  transform: translateY(-2px);
  box-shadow: 0 5px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:active:not(:disabled){
  transform: translateY(2px) scale(0.96);
  box-shadow: 0 1px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:focus-visible{
  outline: 2px solid color-mix(in srgb, var(--deco-primary, #14B8A6) 65%, transparent);
  outline-offset: 2px;
}

/* —— 2. 皮肤形状规则子集（各皮肤 Manifest extraCSS 快照，最后注入覆盖交互模型） —— */

/* doodle：手绘边框 — 不规则圆角 + 微旋转 + 蜡笔 2px 边框（hover 换蜡笔红/深色湖水蓝） */
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect){
  border-radius: 15px 8px 17px 7px / 8px 16px 7px 18px; /* 皮肤形状快照：手绘不规则圆角，无 token 语义，同 skins.css 豁免决策 */
  transform: rotate(-0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect):nth-child(even of .btn){
  transform: rotate(0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary{
  border: 2px solid rgba(43, 43, 43, 0.62);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary{
  border-color: rgba(242, 237, 227, 0.55);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(232, 96, 76, 0.85);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(91, 168, 201, 0.85);
}

/* island：糖果胶囊 + 3D 底沿（默认态让位 toy hover/active；次按钮奶油卡纸） */
[data-skin="xy-skin-official-island"] .btn:not(:hover):not(:active){
  border: 1px solid var(--is-ink, rgba(92, 74, 50, 0.55));
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}
[data-skin="xy-skin-official-island"] .btn:not(.btn--rect){
  border-radius: 999px;
}
[data-skin="xy-skin-official-island"] .btn--secondary:not(:hover):not(:active){
  background: var(--is-cream, rgba(255, 253, 245, 0.92));
  border-color: var(--is-ink, rgba(92, 74, 50, 0.55));
  color: var(--text-primary, #5C4A32);
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}

/* pixel：块状厚度 — 无描线 + 底部 3px 厚度（NES 街机按键），按压塌陷
   （皮肤自定义变量不在沙箱白名单，改引注入变量 --bg-elevated/--text-primary） */
[data-skin="xy-skin-official-pixel"] .btn{
  border: none;
  border-radius: 0;
  background: var(--bg-elevated, #FFFDF6);
  box-shadow: 0 3px 0 var(--text-primary, #1A1C2C);
  transition: none;
}
[data-skin="xy-skin-official-pixel"] .btn:active{
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--text-primary, #1A1C2C);
}

/* popart：漫画粗描边 + CMYK 三色错位叠印投影（丝网印刷注册错位，波普签名） */
[data-skin="xy-skin-official-popart"] .btn{
  border: 3px solid var(--text-primary, #1A1A1A);
  box-shadow:
    2.5px 2.5px 0 rgba(230, 57, 70, 0.5),
    -2px 2.5px 0 rgba(0, 119, 182, 0.45),
    4px 4px 0 rgba(26, 26, 26, 0.28);
}

/* red-age：油墨细线（印刷品边线） */
[data-skin="xy-skin-official-red-age"] .btn{
  border: 1px solid var(--ra-ink, rgba(31, 26, 18, 0.75));
}

/* neumorphism：无描边浮雕（外凸双阴影） */
[data-skin="xy-skin-official-neumorphism"] .btn{
  border: none;
  box-shadow:
    3px 3px 6px var(--neumo-dark, rgba(163, 177, 198, 0.55)),
    -3px -3px 6px var(--neumo-light, rgba(255, 255, 255, 0.9));
}

/* cyber-city：glitch 重影 — hover RGB 通道错位（静态 text-shadow，零动画开销） */
[data-skin="xy-skin-official-cyber-city"] .btn:hover{
  text-shadow:
    1px 0 rgba(0, 229, 255, 0.75),
    -1px 0 rgba(255, 46, 136, 0.75);
}

/* 动效偏好降级：形状钩子表的位移/旋转一律禁用（保留形状与描边） */
[data-reduce-motion="true"] .btn:hover,
[data-reduce-motion="true"] .btn:active{
  transform: none;
}

/* v5.0: 难度选择器 */
.game-host-hud-difficulty-wrap {
  display: flex;
  align-items: center;
}

.game-host-hud-difficulty-select {
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23888' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  padding-right: 1.375rem !important;
  cursor: pointer;
}

.game-host-hud-difficulty-select option {
  background: var(--bg-elevated, #1a1a1a);
  color: var(--glass-text-primary, #e8e8e8);
}


/* ============================================================
   Phase 4（EDITORIAL-LAYOUT PRD §4.1 G2）：左信息带 + 右主舞台
   ------------------------------------------------------------
   放在 css-hud.tpl 末尾是有意的：注入顺序为 HUD → CANVAS → OVERLAY →
   RESPONSIVE，同特异性下后出现者胜，故本段安全覆写上面的顶条配方。
   ============================================================ */

.game-host-body {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  flex-direction: row;
  align-items: stretch;
}

/* HUD 由「顶条」改为「左侧信息带」：竖向堆叠 */
.game-host-hud {
  flex: 0 0 208px;
  width: 208px;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-4, 1rem) var(--space-3, 0.875rem);
  border-bottom: none;
  border-right: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  overflow-y: auto;
  overscroll-behavior: contain;
}
/* 发丝线由「底缘」转为「右缘」（信息带与舞台的分界） */
.game-host-hud::after {
  left: auto;
  right: 0;
  top: var(--space-4, 1rem);
  bottom: var(--space-4, 1rem);
  width: 1px;
  height: auto;
  background: linear-gradient(
    to bottom,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}

/* 信息带内三段纵排：身份（kicker + 标题） / 分数 / 控制 */
.game-host-hud-left {
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1, 0.25rem);
  overflow: visible;
}
.game-host-hud-right {
  flex-direction: column;
  align-items: stretch;
  width: 100%;
  gap: var(--space-2, 0.5rem);
}
.game-host-hud-right > * { width: 100%; }
.game-host-hud-difficulty-wrap { width: 100%; }
.game-host-hud-difficulty-select { width: 100%; }

.game-host-hud-kicker {
  font-size: 0.5625rem;
  letter-spacing: 0.24em;
}
.game-host-hud-title {
  font-size: 1.0625rem;
  letter-spacing: 0.1em;
  line-height: 1.2;
}
.game-host-hud-score {
  margin-top: var(--space-2, 0.5rem);
  gap: 0.25rem;
}
.game-host-hud-score-value {
  font-size: 0.75rem;
}

/* 右主舞台：画布在其中等比居中，永不挤占信息带 */
.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-width: 0;
}

/* ============================================================
   Phase 4 收口（EDITORIAL §16 定版）：信息带升级「统一大标题 + 小标题分区」
   ------------------------------------------------------------
   与宿主 .zby-page-head / .zby-sec-title 同配方（自包含 fallback，
   Token 经沙箱白名单注入 computed 值）。注入序在 css-responsive 之前，
   <720 折行态的覆写见 css-responsive.tpl 末段。
   ============================================================ */

/* 信息带纵向节奏单源：分区 margin-top 走 --layout-section-gap（与宿主分区间隔同源）。
 * box-sizing 收敛为 border-box：flex-basis 208px 从此含内距（恒宽名副其实），
 * 窄窗折行态不再因 content-box 的 28px 水平内距溢出视口。 */
.game-host-hud {
  gap: 0;
  box-sizing: border-box;
}

/* 身份块 = 页头语言：mono kicker + 衬线大标题 + 标题下发丝线 */
.game-host-hud-left {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1, 0.25rem);
  width: 100%;
  min-width: 0;
  padding-bottom: var(--space-3, 0.875rem);
  position: relative;
}
/* 大标题下发丝线（宿主 .zby-page-head::after 同配方：--deco-primary 55% → 12% → 透明） */
.game-host-hud-left::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}
/* 大标题三件套：字号/字距/字族全部走布局维度 Token（与宿主内页大标题同构）。
 * 白名单注入的是宿主 root computed 值，方案切换（刊物/经典/紧凑）随广播生效。 */
.game-host-hud-title {
  font-family: var(--type-title-font, var(--font-serif-cn, var(--type-display, inherit)));
  font-size: var(--type-title, var(--layout-display, 2rem));
  font-weight: 700;
  letter-spacing: var(--tracking-title, 0.04em);
  line-height: 1.16;
  color: var(--glass-text-primary, #e8e8e8);
  /* 窄带允许自然换行（杂志标题语言），不再省略号截断 */
  white-space: normal;
  overflow: visible;
  text-overflow: clip;
  min-width: 0;
}

/* 分区容器：分区间距 = --layout-section-gap（宿主分区节奏同源，非自造间隔） */
.game-host-sec {
  display: flex;
  flex-direction: column;
  gap: var(--space-2, 0.5rem);
  margin-top: var(--layout-section-gap, var(--space-5, 1.5rem));
  min-width: 0;
}

/* 分区小标题（宿主 .zby-sec-title 同配方）：中文 12px/0.2em + EN mono 小注 + 渐细横线 */
.game-host-sec-head {
  display: flex;
  align-items: baseline;
  gap: var(--space-2, 8px);
  font-size: var(--type-scale-1, 0.75rem);
  font-weight: 650;
  letter-spacing: 0.2em;
  color: var(--glass-text-secondary, #666);
  white-space: nowrap;
}
.game-host-sec-head::after {
  content: '';
  flex: 1;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}
.game-host-sec-sub {
  font-family: var(--type-mono, ui-monospace, 'JetBrains Mono', monospace);
  font-size: calc(var(--type-scale-1, 0.75rem) * 0.71);
  font-weight: 600;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--glass-text-tertiary, #707070);
  opacity: 0.85;
}

/* 计分行归入战况分区：分区间距由 .game-host-sec 承担，行内不再带顶距 */
.game-host-hud-score {
  margin-top: 0;
  font-size: 0.8125rem;
}
/* ============================================================
   画布容器
   ============================================================ */

.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  position: relative;
  overflow: hidden;
}

.game-host-canvas {
  display: block;
  max-width: 100%;
  max-height: 100%;
  /* canvas 由游戏引擎自绘背景（棋盘/Phaser backgroundColor），CSS 背景置透明防泛白 */
  background: transparent;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.06));
  border-radius: 0.5rem;
  box-shadow: var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
  outline: none;
  cursor: default;
  touch-action: none;
}

.game-host-canvas:focus-visible {
  border-color: var(--accent-cool, #4a9eff);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent-cool, #4a9eff) 25%, transparent), var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
}

/* ============================================================
   暂停遮罩（由 GameHost 在 paused 状态下注入）
   ============================================================ */

.game-host-root[data-status="paused"] .game-host-canvas-wrap::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.55));
  backdrop-filter: blur(4px);
  pointer-events: none;
}

.game-host-root[data-status="paused"] .game-host-canvas-wrap::before {
  content: attr(data-paused-text);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 遮罩底为皮肤感知玻璃（--glass-overlay-bg：浅色皮肤浅底 / 深色皮肤深底），
     文字跟随皮肤明暗取 --glass-text-primary，任意皮肤 × 明暗下恒可读 */
  color: var(--glass-text-primary, #f1f5f9);
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 1.125rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.6));
  padding: 0.625rem 1.25rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.1));
  z-index: 1;
  pointer-events: none;
}

/* ============================================================
   游戏结束 / 胜利覆盖层
   ============================================================ */

.game-host-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4, 0.875rem);
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.7));
  backdrop-filter: blur(6px);
  z-index: 5;
  pointer-events: auto;
}

.game-host-overlay-title {
  /* F 语言：衬线显示字体 + 页面显示档字号 + 编辑头同款字距（Wave G L2） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: calc(var(--layout-display, 2.125rem) * 0.7);
  font-weight: 700;
  color: var(--glass-text-primary, #e8e8e8);
  letter-spacing: 0.14em;
}

.game-host-overlay-title--win {
  color: var(--accent-warm, #ffb04a);
}

.game-host-overlay-title--lose {
  color: var(--danger, #ff6b8a);
}

.game-host-overlay-msg {
  font-size: 0.875rem;
  color: var(--glass-text-secondary, #888);
  text-align: center;
  max-width: 80%;
}

.game-host-overlay-actions {
  display: flex;
  gap: 0.625rem;
}

/* P4.7：.game-host-overlay-btn 系列已删除（无 JS 创建者，历史死样式）；
 * 覆盖层操作统一走 HUD 重新开始按钮（game-host-hud-btn，已基座化）。 */

/* ============================================================
   响应式（窄窗口时缩小 HUD）
   ============================================================ */

@media (max-width: 480px) {
  .game-host-hud {
    padding: 0.375rem 0.625rem;
    gap: 0.5rem;
  }
  .game-host-hud-title {
    font-size: 1.0625rem;
  }
  .game-host-hud-score {
    font-size: 0.75rem;
  }
  .game-host-hud-btn {
    font-size: 0.6875rem;
    padding: 0.3125rem 0.5rem;
  }
  .game-host-canvas-wrap {
    padding: 0.375rem;
  }
}



/* Phase 4：窄窗（<720px）整组折行 —— 信息带收为舞台上方横排，
   画布仍占主区居中。信息带靠「折」保持可见，不靠挤。 */
@media (max-width: 720px) {
  .game-host-body {
    flex-direction: column;
  }
  .game-host-hud {
    flex: 0 0 auto;
    width: 100%;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-2, 0.5rem);
    padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
    border-right: none;
    border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
    overflow: visible;
  }
  .game-host-hud::after { display: none; }
  .game-host-hud-left {
    flex-direction: row;
    align-items: baseline;
    gap: var(--space-2, 0.5rem);
  }
  .game-host-hud-right {
    flex-direction: row;
    align-items: center;
    width: auto;
    gap: var(--space-2, 0.5rem);
  }
  .game-host-hud-right > * { width: auto; }
  .game-host-hud-difficulty-wrap { width: auto; }
  .game-host-hud-difficulty-select { width: auto; }
  .game-host-hud-score { margin-top: 0; font-size: 0.6875rem; }
  /* 分区折行态收为横排：小标题隐藏、内容内联（身份 | 战况 | 操作 三段一行）；
     身份块的下发丝线与底部内距同步移除（横条内无线）。 */
  .game-host-sec {
    flex-direction: row;
    align-items: center;
    margin-top: 0;
    gap: var(--space-2, 0.5rem);
    min-width: 0;
  }
  .game-host-sec-head { display: none; }
  /* 宽窗块的 width:100% / padding 在折行态复位（否则左段撑满整行、右段溢出视口） */
  .game-host-hud-left { padding-bottom: 0; width: auto; flex: 0 1 auto; min-width: 0; }
  .game-host-hud-left::after { display: none; }
  .game-host-hud { flex-wrap: wrap; }
  /* 折行态标题降档（横条内不撑高）：衬线 20px，保留层级 */
  .game-host-hud-title { font-size: 1.25rem; line-height: 1.1; }
}
/* ============================================================
   无障碍：减少动效
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  .game-host-hud-btn {
    transition: none;
  }
}


/* 覆盖层语义类（GameHost showLoadingOverlay/showErrorOverlay 动态设置，
   样式为内联 cssText；保留空规则以通过包校验器 CSS_CLASS_MISSING 检查） */
.game-host-loading-overlay {}
.game-host-spinner {}
.game-host-error-overlay {}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'tank-game-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  let host: TankHost | null = null;

  /** 挂载游戏：创建 Host 并启动（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    injectAppStyle(ctx.container);
    host = new TankHost({
      gameId: 'game-tank',
      width: 512,
      height: 548,
    });
    void host.mount(ctx).catch((e: unknown) => {
      console.error('[tank] mount failed:', e);
    });
  }

  /** 卸载游戏：清理监听 / 定时器 / DOM */
  function unmount(): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: { nameKey: 'game.tankName', nameFallback: 'Battle City' },
      t: createTranslator(),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__tankApp = {
    unmount,
  };
})();
