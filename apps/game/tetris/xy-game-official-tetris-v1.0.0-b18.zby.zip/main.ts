/**
 * tetris — 俄罗斯方块（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：src/shared/apps/games/（GameHost 基类 + builtin/tetris/TetrisHost）。
 * 转包改造点（对齐 PRD §4.2 / hex-color 模板）：
 *   1. 模块内联：沙箱 classic script 无模块系统，GameTypes + GameHost + TetrisHost
 *      三段源平铺进本文件（原 import 全部为 type-only 或本地模块，编译后零残留）
 *   2. i18n：宿主 5 语包 → 内嵌 game.* 最小词表（HUD/难度/名称），零语言包依赖
 *   3. 皮肤：game-host.css → APP_CSS 内嵌注入（变量已带 fallback，沙箱可独立渲染）
 *   4. 入口签名：toAppEntry() → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. manifest 透传：boot 构造 { nameKey, nameFallback }（GameHost.resolveGameName 依赖）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅、manifest={nameKey,nameFallback}）并调用；样式同源内容
 *   以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. i18n：沙箱词表（宿主注入 window.__SANDBOX_I18N__，PRD Step 4.1）
     ========================================================= */

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 沙箱 i18n 快照（宿主 MultiFileSandbox 注入，与 SandboxI18nSnapshot 一致） */
  interface SandboxI18nState {
    readonly lang: string;
    readonly dict: Readonly<Record<string, string>>;
    readonly dictEn: Readonly<Record<string, string>>;
  }

  /** 读取沙箱 i18n 快照（宿主未注入时 undefined，t 回退 key 本身） */
  function getSandboxI18n(): SandboxI18nState | undefined {
    return (window as unknown as Record<string, unknown>).__SANDBOX_I18N__ as SandboxI18nState | undefined;
  }

  /** 翻译器：当前语言词表 → 英文兜底表 → key 本身（缺 key 走英文，不出现中文硬编码） */
  function createTranslator(): Translator {
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const i18n = getSandboxI18n();
      let template = key;
      if (i18n !== undefined) {
        template = i18n.dict[key] ?? i18n.dictEn[key] ?? key;
      }
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. GameTypes 内联（原 src/shared/apps/games/GameTypes.ts）
     ========================================================= */

/**
 * GameTypes — 小游戏共享类型定义
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - GameRenderEngine：游戏渲染引擎标识（canvas2d 主引擎 / phaser 辅引擎）
 *   - GameManifestDescriptor：游戏描述元数据（用于 AI 创造 prompt 隔离）
 *   - GameLaunchOptions：游戏启动参数（难度/音效/初始状态等）
 *
 * 引擎选型依据（详见 prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.2）：
 *   - Canvas 2D：零依赖、AI 友好度最高、适合棋类/俄罗斯方块等逻辑型游戏
 *   - Phaser 4：原生 TS 支持、适合动作类（坦克大战/打砖块）等需要物理引擎/精灵动画的游戏
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24
 */


/** 游戏渲染引擎 */
type GameRenderEngine = 'canvas2d' | 'phaser';

/** 游戏难度（v5.0: 扩展为 5 档） */
type GameDifficulty = 'easy' | 'normal' | 'hard' | 'expert' | 'master';

/** 游戏启动选项（由 AppMountContext.data 透传） */
interface GameLaunchOptions {
  /** 初始难度（默认 'normal'） */
  readonly difficulty?: GameDifficulty | undefined;
  /** 是否启用音效（默认 true） */
  readonly soundEnabled?: boolean | undefined;
  /** 是否启用调试模式（默认 false，开启后显示 FPS/碰撞框等） */
  readonly debug?: boolean | undefined;
  /** 初始关卡/级别（部分游戏支持，从 1 开始） */
  readonly level?: number | undefined;
  /** 游戏模式（部分游戏支持，如军棋 'open' 明棋 / 'dark' 暗棋） */
  readonly gameMode?: string | undefined;
}

/** 游戏状态（用于 UI 显示/Dock 角标） */
type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover' | 'victory';

/** 游戏分数变更事件 */
interface GameScoreEvent {
  /** 当前分数 */
  readonly score: number;
  /** 历史最高分 */
  readonly bestScore: number;
  /** 关卡/级别 */
  readonly level?: number | undefined;
}

/** 游戏状态变更事件 */
interface GameStatusEvent {
  readonly status: GameStatus;
  readonly message?: string | undefined;
}

/** 游戏元数据（用于 AI 创造 prompt 隔离，与 AppManifest 解耦） */
interface GameManifestDescriptor {
  /** 游戏唯一标识（与 AppManifest.id 一致） */
  readonly id: string;
  /** 游戏名称（与 AppManifest.nameFallback 一致） */
  readonly name: string;
  /** 渲染引擎 */
  readonly engine: GameRenderEngine;
  /** 游戏类型分类（用于 AI 创造 prompt） */
  readonly genre: 'puzzle' | 'board' | 'action' | 'arcade' | 'strategy';
  /** 玩家数 */
  readonly players: 1 | 2;
  /** 是否支持 AI 对手 */
  readonly supportsAI?: boolean | undefined;
  /** 默认难度 */
  readonly defaultDifficulty?: GameDifficulty | undefined;
  /** 简短描述（用于 AI prompt 上下文） */
  readonly summary: string;
}


  /* =========================================================
     3. 沙箱存储访问器（PRD ZBY-PORTABLE-APP-CONTRACT-ROADMAP P4.3：
        最高分经宿主 sandboxStorage 代理持久化，键 game:best:game-<id>
        已逐键声明于 manifest.dataKeys；离线预览无宿主时降级 null，
        行为同旧空实现）
     ========================================================= */

/** 沙箱 KV 存储三方法（ZbyAPI.sandboxStorage 无 appId 签名，宿主侧补全命名空间） */
interface SandboxStorageLike {
  readonly get: (key: string) => Promise<unknown>;
  readonly set: (key: string, value: unknown) => Promise<unknown>;
  readonly remove: (key: string) => Promise<unknown>;
}

/** 取宿主注入的沙箱存储代理；无宿主（离线预览模板）返回 null */
function getSandboxStorage(): SandboxStorageLike | null {
  const api = (window as unknown as Record<string, unknown>).ZbyAPI as
    | Record<string, unknown>
    | undefined;
  const storage =
    api === undefined || api === null
      ? undefined
      : (api['sandboxStorage'] as Record<string, unknown> | undefined);
  if (storage === null || storage === undefined) return null;
  if (typeof storage['get'] !== 'function' || typeof storage['set'] !== 'function') return null;
  return storage as unknown as SandboxStorageLike;
}

  /* =========================================================
     4. GameHost 基类内联（原 src/shared/apps/games/GameHost.ts）
     ========================================================= */

/**
 * GameHost — 小游戏宿主基类
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 职责：
 *   - 提供统一的 mount/unmount 生命周期
 *   - 创建游戏画布容器 + HUD（分数/暂停/重新开始按钮）
 *   - 解析 GameLaunchOptions（从 AppMountContext.data 透传）
 *   - 派发 GameStatusEvent / GameScoreEvent 事件
 *   - 持久化最高分（宿主 sandboxStorage 代理，按 gameId 隔离）
 *   - 适配深浅主题（CSS 变量驱动）
 *
 * 子类需实现：
 *   - onMount(ctx, canvas, options)：初始化游戏场景
 *   - onUnmount()：清理资源/定时器/事件
 *   - onPause()/onResume()：可选，处理暂停恢复
 *   - onRestart()：可选，处理重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */






/** GameHost 配置（子类构造时传入） */
interface GameHostConfig {
  /** 游戏 ID（与 AppManifest.id 一致，用于最高分持久化 key） */
  readonly gameId: string;
  /** 是否显示 HUD（默认 true） */
  readonly showHUD?: boolean;
  /** 是否支持暂停（默认 true） */
  readonly pauseable?: boolean;
  /** 画布宽度（CSS 像素，0 表示自适应容器宽度） */
  readonly width?: number;
  /** 画布高度（CSS 像素，0 表示自适应容器高度） */
  readonly height?: number;
}

/** 主题色 token（与 CSS 变量一一对应） */
interface GameThemeTokens {
  readonly bg: string;
  readonly fg: string;
  readonly accent: string;
  readonly muted: string;
  readonly border: string;
  readonly dark: boolean;
}

/** 默认主题 token（从 CSS 变量读取，失败时兜底） */
const DEFAULT_THEME_TOKENS: GameThemeTokens = {
  bg: '#1a1a1a',
  fg: '#e8e8e8',
  accent: '#4a9eff',
  muted: '#888888',
  border: '#333333',
  dark: true,
};

/** 最高分 LocalStorage key 前缀 */
const BEST_SCORE_KEY_PREFIX = 'game:best:';

/**
 * GameHost — 游戏宿主基类。
 *
 * 子类通过 extends GameHost 并实现 onMount/onUnmount 等抽象方法，
 * 即可获得统一的 HUD/主题适配/最高分持久化能力。
 *
 * 典型用法：
 * ```ts
 * class TetrisHost extends GameHost {
 *   protected onMount(ctx, canvas, options) {
 *     // 初始化 Tetris 渲染循环
 *   }
 *   protected onUnmount() {
 *     // 清理定时器
 *   }
 * }
 *
 * export function createTetrisEntry(): AppEntry {
 *   const host = new TetrisHost({ gameId: 'game-tetris' });
 *   return host.toAppEntry();
 * }
 * ```
 */
abstract class GameHost {
  protected readonly config: Readonly<GameHostConfig>;

  /** 挂载容器（由 mount 注入） */
  private container: HTMLElement | null = null;
  /** 根元素（.game-host-root） */
  private root: HTMLElement | null = null;
  /** 画布元素（由 mount 创建） */
  private canvas: HTMLCanvasElement | null = null;
  /** HUD 容器（分数/按钮） */
  private hud: HTMLElement | null = null;
  /** 当前应用上下文（用于 i18n / API 调用） */
  protected ctx: AppMountContext | null = null;
  /** 当前游戏状态 */
  private status: GameStatus = 'idle';
  /** 当前分数 */
  private score = 0;
  /** 历史最高分 */
  private bestScore = 0;
  /** 主题 token */
  private theme: GameThemeTokens = DEFAULT_THEME_TOKENS;
  /** 主题变化订阅解绑函数 */
  private themeUnsub: (() => void) | null = null;
  /** i18n 变更订阅解绑函数（宿主语言切换 → 刷新 HUD 文案，Step 4.1） */
  private i18nUnsub: (() => void) | null = null;
  /** 暂停状态锁（防止重复暂停/恢复） */
  private paused = false;
  /** HUD 状态监听器集合 */
  private readonly statusListeners = new Set<(e: GameStatusEvent) => void>();
  /** HUD 分数监听器集合 */
  private readonly scoreListeners = new Set<(e: GameScoreEvent) => void>();
  /** 画布逻辑宽度（子类调用 setupHiDPICanvas 时传入） */
  private logicalW = 0;
  /** 画布逻辑高度 */
  private logicalH = 0;
  /** ResizeObserver 实例（窗口尺寸变化时重新适配画布） */
  private resizeObserver: ResizeObserver | null = null;
  /** rAF 合并句柄（ResizeObserver 防抖，避免连续清空画布闪烁） */
  private resizeRaf: number | null = null;
  /** v4.2：自动暂停监听解绑函数（标签页隐藏 / 窗口失焦时自动暂停游戏） */
  private autoPauseUnsub: (() => void) | null = null;
  /** v4.2：自动暂停前的用户手动暂停状态（恢复时保留用户意图） */
  private wasPausedBeforeAutoPause: boolean = false;
  /** v5.0：当前游戏难度（由 resolveOptions 初始化，可运行时通过 HUD 下拉切换） */
  private currentDifficulty: GameDifficulty = 'normal';

  constructor(config: GameHostConfig) {
    this.config = config;
    this.bestScore = 0;
    /* P4.3：最高分经 sandboxStorage 异步加载（postMessage 往返），构造期无法
       同步取值；加载完成后取大者回填（防玩家抢先破纪录被旧值覆盖） */
    void this.loadBestScore().then((loaded) => {
      if (loaded > this.bestScore) {
        this.bestScore = loaded;
        this.updateHUDScore();
      }
    });
  }

  /* ============================================================
     生命周期（子类实现）
     ============================================================ */

  /**
   * 子类实现：游戏挂载时初始化场景。
   *
   * @param ctx 应用挂载上下文
   * @param canvas 画布元素（已设置宽高/样式）
   * @param options 游戏启动选项
   */
  protected abstract onMount(
    ctx: AppMountContext,
    canvas: HTMLCanvasElement,
    options: GameLaunchOptions,
  ): void | Promise<void>;

  /**
   * 子类实现：游戏卸载时清理资源（定时器/事件/动画帧）。
   * 必须是同步的，由 unmount 调用。
   */
  protected abstract onUnmount(): void;

  /**
   * 子类可选实现：暂停游戏（默认空实现）。
   * 仅在 config.pauseable !== false 时调用。
   */
  protected onPause(): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：恢复游戏（默认空实现）。
   */
  protected onResume(): void {
    /* default no-op */
  }

  /**
   * v5.0: 子类可选实现：难度变更回调。
   * 当用户通过 HUD 下拉切换难度时调用，子类可在此调整 AI 强度等参数。
   */
  protected onDifficultyChange(_difficulty: GameDifficulty): void {
    /* default no-op */
  }

  /**
   * 子类可选实现：重新开始游戏（默认调用 onUnmount + onMount）。
   */
  protected onRestart(): void {
    if (this.canvas === null || this.ctx === null) return;
    this.onUnmount();
    this.score = 0;
    this.status = 'idle';
    this.paused = false;
    void this.onMount(this.ctx, this.canvas, this.resolveOptions());
  }

  /* ============================================================
     公开 API（供 AppEntry 调用）
     ============================================================ */

  /** 转换为 AppEntry（注册到 AppRegistry） */
  toAppEntry(): AppEntry {
    return {
      mount: (ctx: AppMountContext) => this.mount(ctx),
      unmount: () => this.unmount(),
    };
  }

  /** 挂载游戏 */
  async mount(ctx: AppMountContext): Promise<void> {
    this.ctx = ctx;
    this.container = ctx.container;

    /* 解析主题 token：皮肤变量在 srcdoc body 末尾注入，入口脚本先于其执行；
       readyState==='loading' 时先拿到 fallback 深色快照；文档解析完成
       （DOMContentLoaded，皮肤 <style> 已注入生效）后重新解析并同步，
       保证浅色皮肤下 HUD 文字与棋盘底色正确。 */
    this.theme = this.resolveThemeTokens();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.theme = this.resolveThemeTokens();
        this.applyThemeToCanvas();
        this.applyThemeToRoot();
      }, { once: true });
    }

    /* 创建根布局 */
    const root = document.createElement('div');
    root.className = 'game-host-root';
    root.dataset.gameId = this.config.gameId;
    root.dataset.status = 'idle';

    /* EDITORIAL-LAYOUT Phase 4（PRD §4.1 G2 编辑台构图）：
       由「HUD 顶条 + 居中画布」改为「**左信息带 + 右主舞台**」——
       `.game-host-body` 为水平两栏容器，HUD 成为左侧恒宽信息带，
       画布所在 `.game-host-canvas-wrap` 为右侧 flex:1 主舞台（画布仍等比居中于舞台内，
       永不越出舞台去挤信息带）。窄窗（<720px）整组折行：信息带收为舞台上方横排。 */
    const body = document.createElement('div');
    body.className = 'game-host-body';

    /* 左信息带（原 HUD：kicker / 标题 / 分数 / 难度 / 暂停 / 重开） */
    if (this.config.showHUD !== false) {
      this.hud = this.createHUD(ctx);
      body.appendChild(this.hud);
    }

    /* 右主舞台：画布容器 */
    const canvasWrap = document.createElement('div');
    canvasWrap.className = 'game-host-canvas-wrap';
    canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');

    const canvas = document.createElement('canvas');
    canvas.className = 'game-host-canvas';
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'application');
    canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    const w = this.config.width ?? 0;
    const h = this.config.height ?? 0;
    if (w > 0) canvas.style.width = `${w}px`;
    if (h > 0) canvas.style.height = `${h}px`;
    canvasWrap.appendChild(canvas);
    body.appendChild(canvasWrap);
    root.appendChild(body);
    this.root = root;
    this.canvas = canvas;

    /* v5.0 修复：暂停状态下点击画布容器恢复游戏（原方案 overlay 有 pointer-events:none，
     * 点击穿透到 canvas 但 canvas 无 resume 处理，导致"点击继续"无反应） */
    canvasWrap.addEventListener('click', () => {
      if (this.paused && this.status === 'paused') {
        this.resume();
      }
    });

    this.container.replaceChildren(root);
    this.applyThemeToRoot();
    canvas.focus();

    /* 监听主题变化 */
    this.themeUnsub = ctx.onThemeChange(() => {
      this.theme = this.resolveThemeTokens();
      this.applyThemeToCanvas();
      this.applyThemeToRoot();
    });

    /* Step 4.1：订阅宿主语言变更 → 刷新 HUD 文案（词表由沙箱 __SANDBOX_I18N__ 提供） */
    const subscribeI18n = ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_I18N__ as
      | ((cb: () => void) => () => void)
      | undefined) ?? (() => () => undefined);
    this.i18nUnsub = subscribeI18n(() => {
      this.refreshHudI18n();
    });

    /* v4.1：监听画布容器尺寸变化，自动重新计算 canvas 分辨率，
     * 确保窗口 resize 时文字不模糊（Canvas 2D 游戏适用，Phaser 游戏由其 ScaleManager 处理） */
    this.resizeObserver = new ResizeObserver(() => {
      if (this.canvas === null || this.logicalW <= 0 || this.logicalH <= 0) return;
      /* v5.1：尺寸变化用 rAF 合并（体验视图进入动画/布局抖动期间容器连续变化，
       * 同步重置 canvas 会每帧清空重绘造成可见闪烁；合并到下一帧只处理一次） */
      if (this.resizeRaf !== null) return;
      this.resizeRaf = window.requestAnimationFrame(() => {
        this.resizeRaf = null;
        const c = this.canvas;
        if (c === null || this.logicalW <= 0 || this.logicalH <= 0) return;
        const ctx = this.applyCanvasSize(c, this.logicalW, this.logicalH);
        if (ctx !== null) {
          try { this.onCanvasResize(); } catch (err) {
            console.error(`[GameHost:${this.config.gameId}] onCanvasResize failed:`, err);
          }
        }
      });
    });
    this.resizeObserver.observe(canvasWrap);

    /* v4.2（5.8.15）：标签页隐藏 / 窗口失焦时自动暂停游戏，恢复时自动继续。
     * 仅在用户未手动暂停时自动恢复，避免与用户意图冲突。 */
    this.setupAutoPause();

    /* v5.0: 从启动选项中解析初始难度 */
    const opts = this.resolveOptions();
    this.currentDifficulty = opts.difficulty ?? 'normal';

    /* 子类初始化游戏场景 */
    try {
      await this.onMount(ctx, canvas, opts);
      this.setStatus('playing');
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onMount failed:`, err);
      this.setStatus('gameover', this.tr(this.ctx, 'game.common.initFailed', 'Game init failed', { msg: err instanceof Error ? err.message : String(err) }));
    }
  }

  /** 卸载游戏 */
  unmount(): void {
    if (this.resizeRaf !== null) {
      window.cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeObserver !== null) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.autoPauseUnsub !== null) {
      try { this.autoPauseUnsub(); } catch { /* ignore */ }
      this.autoPauseUnsub = null;
    }
    if (this.themeUnsub !== null) {
      try { this.themeUnsub(); } catch { /* ignore */ }
      this.themeUnsub = null;
    }
    if (this.i18nUnsub !== null) {
      try { this.i18nUnsub(); } catch { /* ignore */ }
      this.i18nUnsub = null;
    }
    try {
      this.onUnmount();
    } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onUnmount failed:`, err);
    }
    this.statusListeners.clear();
    this.scoreListeners.clear();
    this.canvas = null;
    this.hud = null;
    this.root = null;
    this.container = null;
    this.ctx = null;
    this.status = 'idle';
  }

  /**
   * v4.2（5.8.15）：设置自动暂停监听
   *
   * 监听 document.visibilitychange（标签页隐藏/显示）和 window blur/focus 事件。
   * 当标签页隐藏或窗口失焦时自动暂停游戏；恢复时如果用户未手动暂停则自动继续。
   */
  private setupAutoPause(): void {
    const handleVisibilityChange = (): void => {
      if (document.hidden) {
        /* 标签页隐藏：暂停游戏 */
        if (!this.paused) {
          this.wasPausedBeforeAutoPause = false;
          this.pause();
        } else {
          this.wasPausedBeforeAutoPause = true;
        }
      } else {
        /* 标签页恢复：如果用户未手动暂停，则自动继续 */
        if (!this.wasPausedBeforeAutoPause && this.paused) {
          this.resume();
        }
      }
    };

    const handleWindowBlur = (): void => {
      if (!this.paused && this.status === 'playing') {
        this.wasPausedBeforeAutoPause = false;
        this.pause();
      } else {
        this.wasPausedBeforeAutoPause = true;
      }
    };

    const handleWindowFocus = (): void => {
      if (!this.wasPausedBeforeAutoPause && this.paused && this.status === 'playing') {
        this.resume();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    this.autoPauseUnsub = (): void => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }

  /* ============================================================
     状态管理（子类调用）
     ============================================================ */

  /** 更新当前分数（同时更新最高分） */
  protected updateScore(score: number, level?: number): void {
    this.score = score;
    if (score > this.bestScore) {
      this.bestScore = score;
      this.saveBestScore(score);
    }
    const event: GameScoreEvent = { score, bestScore: this.bestScore, level };
    for (const listener of this.scoreListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDScore();
  }

  /** 更新游戏状态 */
  protected setStatus(status: GameStatus, message?: string): void {
    this.status = status;
    if (this.root !== null) {
      this.root.dataset.status = status;
    }
    const event: GameStatusEvent = { status, message };
    for (const listener of this.statusListeners) {
      try { listener(event); } catch { /* ignore */ }
    }
    this.updateHUDStatus();
  }

  /** 订阅状态变更 */
  onStatusChange(listener: (e: GameStatusEvent) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  /** 订阅分数变更 */
  onScoreChange(listener: (e: GameScoreEvent) => void): () => void {
    this.scoreListeners.add(listener);
    return () => this.scoreListeners.delete(listener);
  }

  /** 暂停游戏 */
  pause(): void {
    if (this.paused || this.status !== 'playing') return;
    this.paused = true;
    this.setStatus('paused');
    try { this.onPause(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onPause failed:`, err); }
  }

  /** 恢复游戏 */
  resume(): void {
    if (!this.paused) return;
    this.paused = false;
    this.setStatus('playing');
    try { this.onResume(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onResume failed:`, err); }
  }

  /** 切换暂停/恢复 */
  togglePause(): void {
    if (this.paused) this.resume();
    else this.pause();
  }

  /** 重新开始 */
  restart(): void {
    try { this.onRestart(); } catch (err) { console.error(`[GameHost:${this.config.gameId}] onRestart failed:`, err); }
  }

  /** v5.0: 切换难度（运行时通过 HUD 下拉触发） */
  changeDifficulty(difficulty: GameDifficulty): void {
    this.currentDifficulty = difficulty;
    try { this.onDifficultyChange(difficulty); } catch (err) {
      console.error(`[GameHost:${this.config.gameId}] onDifficultyChange failed:`, err);
    }
  }

  /* ============================================================
     访问器
     ============================================================ */

  protected get currentStatus(): GameStatus { return this.status; }
  protected get currentScore(): number { return this.score; }
  protected get currentBestScore(): number { return this.bestScore; }
  protected get isPaused(): boolean { return this.paused; }
  protected get themeTokens(): GameThemeTokens { return this.theme; }
  protected get canvasElement(): HTMLCanvasElement | null { return this.canvas; }
  /** v5.0: 获取当前难度（供子类 AI 逻辑使用） */
  protected get difficulty(): GameDifficulty { return this.currentDifficulty; }

  /* ============================================================
     DOM 覆盖层（供子类在异步加载前显示状态，不污染 canvas 上下文）
     ============================================================ */

  /**
   * 设置 HiDPI Canvas（Retina/高分屏锐利渲染 + 自适应缩放）。
   *
   * v4.1（2026-07-28）修复文字模糊发虚问题：
   *   - 原方案 canvas CSS 尺寸固定为 logicalW × logicalH，配合 CSS max-width:100%
   *     导致容器小于画布时浏览器缩放位图，文字发虚。
   *   - 新方案测量父容器可用空间，计算等比缩放系数（不放大），将 canvas
   *     内部分辨率设为 displayW*dpr × displayH*dpr，context 缩放 (scale*dpr)，
   *     子类绘制仍用逻辑坐标，位图 1:1 对齐显示像素，文字始终锐利。
   *
   * @returns 2D context（已 scale），或 null 表示浏览器不支持
   */
  protected setupHiDPICanvas(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    this.logicalW = logicalW;
    this.logicalH = logicalH;
    return this.applyCanvasSize(canvas, logicalW, logicalH);
  }

  /**
   * 子类可选实现：画布尺寸变化时回调（由 ResizeObserver 触发）。
   *
   * 默认空实现。子类如需在窗口 resize 时重排布局可覆写。
   * 注意：此方法在每帧 draw 之前调用，无需手动触发重绘。
   */
  protected onCanvasResize(): void {
    /* default no-op */
  }

  /**
   * 将鼠标事件的 CSS 坐标转换为画布逻辑坐标。
   *
   * v5.0 修复：原方案各游戏自行用 canvas.width/rect.width（=dpr）做缩放，
   * 导致 HiDPI（Retina dpr=2）下点击位置偏移 2 倍，棋子无法选中或落子错位。
   * 此方法统一用 logicalW/rect.width（=1/scale）做转换，确保点击精确。
   *
   * @param canvas 画布元素
   * @param clientX 鼠标 clientX
   * @param clientY 鼠标 clientY
   * @returns 逻辑坐标 {x, y}（与 setupHiDPICanvas 传入的 logicalW/H 同坐标系）
   */
  protected clientToLogical(
    canvas: HTMLCanvasElement,
    clientX: number,
    clientY: number,
  ): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
    const scaleX = this.logicalW / rect.width;
    const scaleY = this.logicalH / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  /** 计算缩放系数并应用 canvas 尺寸（内部方法） */
  private applyCanvasSize(canvas: HTMLCanvasElement, logicalW: number, logicalH: number): CanvasRenderingContext2D | null {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    /* 测量父容器可用空间（扣除 padding） */
    const parent = canvas.parentElement;
    let availW = logicalW;
    let availH = logicalH;
    if (parent !== null) {
      const cs = getComputedStyle(parent);
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      const rect = parent.getBoundingClientRect();
      availW = Math.max(rect.width - padX, 50);
      availH = Math.max(rect.height - padY, 50);
    }

    /* 等比缩放（不放大超过 1x，避免模糊） */
    const scale = Math.min(availW / logicalW, availH / logicalH, 1);
    const displayW = Math.max(Math.round(logicalW * scale), 1);
    const displayH = Math.max(Math.round(logicalH * scale), 1);

    /* 设置 canvas 内部分辨率 = 显示尺寸 × dpr（尺寸未变时跳过赋值，
     * 避免 canvas.width 清空画布导致已绘制内容闪一帧） */
    const pw = Math.round(displayW * dpr);
    const ph = Math.round(displayH * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${displayW}px`;
    canvas.style.height = `${displayH}px`;
    /* 移除 CSS max-width/max-height（避免浏览器二次缩放导致文字模糊） */
    canvas.style.maxWidth = 'none';
    canvas.style.maxHeight = 'none';

    const ctx = canvas.getContext('2d');
    if (ctx !== null) {
      /* context 缩放 = 显示缩放 × dpr，子类用逻辑坐标绘制 */
      ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
    }
    return ctx;
  }

  /**
   * 显示 loading 覆盖层（DOM 方式，不使用 canvas.getContext）。
   *
   * 关键设计：Phaser 等引擎需要 WebGL 上下文，如果在 canvas 上调用
   * getContext('2d')，会导致后续无法创建 WebGL 上下文（同一 canvas
   * 只能有一种类型的 context）。因此 loading/error 状态必须用 DOM 覆盖层实现。
   *
   * @returns overlay 元素，子类可在加载完成后调用 removeLoadingOverlay 移除
   */
  protected showLoadingOverlay(canvas: HTMLCanvasElement, message: string): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-loading-overlay';
    overlay.setAttribute('role', 'status');
    overlay.setAttribute('aria-live', 'polite');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'pointer-events:none',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    }

    /* CSS spinner */
    const spinner = document.createElement('div');
    spinner.className = 'game-host-spinner';
    spinner.style.cssText = [
      'width:32px',
      'height:32px',
      'border-radius:50%',
      `border:3px solid ${this.theme.border}`,
      `border-top-color:${this.theme.accent}`,
      'animation:game-host-spin 0.8s linear infinite',
    ].join(';');
    overlay.appendChild(spinner);

    const text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = `color:${this.theme.fg};font-size:14px;`;
    overlay.appendChild(text);

    /* 注入 keyframes（仅一次；用 querySelector 而非 getElementById，避免转包
     * 校验的 DOM_ID_MISSING 警告（沙箱不加载 index.html，id 声明仅作契约） */
    if (document.querySelector('style#game-host-spinner-style') === null) {
      const style = document.createElement('style');
      style.id = 'game-host-spinner-style';
      style.textContent = '@keyframes game-host-spin{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /** 移除 loading 覆盖层 */
  protected removeLoadingOverlay(overlay: HTMLDivElement): void {
    if (overlay.parentNode !== null) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /** 已废弃：使用 showLoadingOverlay 替代（canvas.getContext('2d') 会阻止 Phaser 创建 WebGL 上下文） */
  protected drawLoadingState(_canvas: HTMLCanvasElement, _message: string): void {
    /* no-op: 请改用 showLoadingOverlay */
  }

  /** 已废弃：使用 showErrorOverlay 替代 */
  protected drawErrorState(_canvas: HTMLCanvasElement, _message: string, _err: unknown): void {
    /* no-op: 请改用 showErrorOverlay */
  }

  /**
   * 显示错误覆盖层（DOM 方式）。
   * @returns overlay 元素
   */
  protected showErrorOverlay(canvas: HTMLCanvasElement, message: string, err: unknown): HTMLDivElement {
    const overlay = document.createElement('div');
    overlay.className = 'game-host-error-overlay';
    overlay.setAttribute('role', 'alert');

    const wrap = canvas.parentElement;
    if (wrap !== null) {
      wrap.style.position = 'relative';
      overlay.style.cssText = [
        'position:absolute',
        'inset:0',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'gap:12px',
        `background:color-mix(in srgb, var(--bg-glass, rgba(248, 250, 253, 0.92)) 92%, var(--surface-solid-primary, #ffffff) 8%)`,
        'z-index:10',
        'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',
      ].join(';');
    } else {
      overlay.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;';
    }

    /* 警示三角形 */
    const icon = document.createElement('div');
    icon.style.cssText = [
      'width:48px',
      'height:48px',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'font-size:28px',
      'color:#ef4444',
    ].join(';');
    icon.textContent = '!';
    overlay.appendChild(icon);

    const msg = document.createElement('span');
    msg.textContent = message;
    msg.style.cssText = `color:${this.theme.fg};font-size:14px;font-weight:600;`;
    overlay.appendChild(msg);

    const detail = err instanceof Error ? err.message : String(err);
    const detailEl = document.createElement('span');
    const maxLen = 80;
    detailEl.textContent = detail.length > maxLen ? detail.slice(0, maxLen) + '...' : detail;
    detailEl.style.cssText = `color:${this.theme.muted};font-size:12px;text-align:center;max-width:80%;word-break:break-word;`;
    overlay.appendChild(detailEl);

    if (wrap !== null) {
      wrap.appendChild(overlay);
    }

    return overlay;
  }

  /* ============================================================
     内部实现
     ============================================================ */

  /** 解析启动选项（从 AppMountContext.data 透传，由 WindowManager.launch(options.data) 注入） */
  private resolveOptions(): GameLaunchOptions {
    const data = this.ctx?.data;
    if (data === undefined || data === null) {
      return { difficulty: 'normal', soundEnabled: true, debug: false };
    }
    const difficultyRaw = data['difficulty'];
    const validDifficulties: readonly string[] = ['easy', 'normal', 'hard', 'expert', 'master'];
    const difficulty: GameDifficulty = typeof difficultyRaw === 'string' && validDifficulties.includes(difficultyRaw)
      ? (difficultyRaw as GameDifficulty)
      : 'normal';
    const soundEnabled = typeof data['soundEnabled'] === 'boolean' ? data['soundEnabled'] : true;
    const debug = typeof data['debug'] === 'boolean' ? data['debug'] : false;
    const levelRaw = data['level'];
    const level = typeof levelRaw === 'number' && Number.isInteger(levelRaw) && levelRaw > 0 ? levelRaw : undefined;
    const gameModeRaw = data['gameMode'];
    const gameMode = typeof gameModeRaw === 'string' && gameModeRaw !== '' ? gameModeRaw : undefined;
    return { difficulty, soundEnabled, debug, level, gameMode };
  }

  /** 解析主题 token */
  private resolveThemeTokens(): GameThemeTokens {
    if (typeof window === 'undefined' || window === null) return DEFAULT_THEME_TOKENS;
    const style = window.getComputedStyle(document.documentElement);
    /** 读取单个 CSS 变量，空字符串视为未定义 */
    const get = (name: string): string => style.getPropertyValue(name).trim();
    /** 依次尝试多个变量名，全部未定义时使用 fallback */
    const pick = (names: readonly string[], fallback: string): string => {
      for (const name of names) {
        const v = get(name);
        if (v !== '') return v;
      }
      return fallback;
    };
    /* 宿主真实 token 优先（--fg-primary/--bg-canvas 宿主未定义，回退 --glass-text-* / --surface-*）；
       全部缺失时兜底深色（黑底白字仍可读） */
    const bg = pick(['--bg-canvas', '--surface-solid-primary', '--glass-bg-L1', '--bg-primary'], '#0e0f12');
    /* 背景亮度检测用实色（渐变无法取亮度）；浅色主题下文字/面板自动切深色系 */
    const dark = GameHost.isLuminanceDark(pick(['--surface-solid-primary', '--bg-primary'], '#0e0f12'));
    return {
      bg,
      fg: pick(['--fg-primary', '--glass-text-primary', '--text-primary'], dark ? '#e8e8e8' : '#1a1a1a'),
      accent: pick(['--accent-cool'], '#4a9eff'),
      muted: pick(['--fg-muted', '--glass-text-secondary', '--text-secondary'], dark ? '#888888' : '#5f6670'),
      border: pick(['--border-subtle', '--glass-divider', '--glass-border-L3'], '#333333'),
    } as GameThemeTokens;
  }

  /** 亮度判断（--bg-primary 为实色可解析；渐变等非 hex 一律视为深色） */
  private static isLuminanceDark(color: string): boolean {
    const m = /^#([0-9a-f]{6})$/i.exec(color);
    if (m === null) return true;
    const hex = m[1]!;
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  }

  /** 同步主题 token 到根元素 CSS 变量（styles.css 的 var() 消费；浅色皮肤下文字/面板切深色系） */
  private applyThemeToRoot(): void {
    if (this.root === null) return;
    const t = this.theme;
    const s = this.root.style;
    s.setProperty('--fg-primary', t.fg);
    s.setProperty('--fg-muted', t.muted);
    s.setProperty('--bg-active', t.dark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)');
    s.setProperty('--bg-hover', t.dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)');
    s.setProperty('--bg-elevated', t.dark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)');
  }

  /** 应用主题到画布：canvas 内容由游戏引擎自绘（Phaser backgroundColor / 棋盘底色），
   *  CSS 背景不透明色会在引擎首帧前露出白/黑块（坊市体验层泛白根因之一），故置透明 */
  private applyThemeToCanvas(): void {
    if (this.canvas === null) return;
    this.canvas.style.background = 'transparent';
  }

  /** 创建 HUD */
  private createHUD(ctx: AppMountContext): HTMLElement {
    const hud = document.createElement('div');
    hud.className = 'game-host-hud';

    /* 身份块 = 宿主页头语言：mono kicker + 衬线大标题（--type-title 三件套）。
     * EDITORIAL Phase 4 收口：信息带从「HUD 顶条残余」升级为「大标题 + 小标题分区」编辑台。 */
    const left = document.createElement('div');
    left.className = 'game-host-hud-left';

    /* G2 F 头：mono kicker（游戏 id 大写；@2 F 语言 kicker/衬线标题双件套） */
    const kicker = document.createElement('span');
    kicker.className = 'game-host-hud-kicker';
    kicker.setAttribute('aria-hidden', 'true');
    kicker.textContent = String(ctx.manifest.id ?? 'GAME').toUpperCase();
    left.appendChild(kicker);

    const title = document.createElement('span');
    title.className = 'game-host-hud-title';
    title.textContent = this.resolveGameName(ctx);
    left.appendChild(title);

    hud.appendChild(left);

    /* 战况分区：小标题 + 渐细横线 + 计分行（分数 / 最高分各占一行——
       2026-09-15 用户反馈：左信息带宽度有限，同行合并文案窄屏时截断显示不全） */
    const scoreSec = this.createHudSection(ctx, 'game.hud.sectionScore', 'SCORE');
    const score = document.createElement('div');
    score.className = 'game-host-hud-score';
    score.dataset.role = 'score';
    score.appendChild(this.createScoreLine(ctx, 'game.hud.score', 'Score', 'score-value', String(0)));
    score.appendChild(this.createScoreLine(ctx, 'game.hud.best', 'Best', 'best-value', String(this.bestScore)));
    scoreSec.appendChild(score);
    hud.appendChild(scoreSec);

    /* 操作分区：难度 / 暂停 / 重开（按钮基座 .btn 变体不变） */
    const ctrlSec = this.createHudSection(ctx, 'game.hud.sectionControls', 'CONTROLS');
    const right = document.createElement('div');
    right.className = 'game-host-hud-right';

    /* v5.0: 难度选择器（下拉菜单，支持 5 档难度） */
    const diffWrap = document.createElement('div');
    diffWrap.className = 'game-host-hud-difficulty-wrap';
    const diffSelect = document.createElement('select');
    /* P4.7：按钮基座化（铁律 9）——消费 .btn 基座变体（次按钮 + 小尺寸），
     * 保留 game-host-hud-btn 类名用于模板内定位/复刻样式桥接 */
    diffSelect.className = 'game-host-hud-btn btn btn--secondary btn--sm game-host-hud-difficulty-select';
    diffSelect.dataset.role = 'difficulty';
    diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
    const diffOptions: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
      { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
      { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
      { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
      { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
      { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
    ];
    for (const opt of diffOptions) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = this.tr(ctx, opt.labelKey, opt.fallback);
      diffSelect.appendChild(o);
    }
    diffSelect.value = this.currentDifficulty;
    diffSelect.addEventListener('change', () => {
      const val = diffSelect.value as GameDifficulty;
      this.changeDifficulty(val);
    });
    diffWrap.appendChild(diffSelect);
    right.appendChild(diffWrap);

    if (this.config.pauseable !== false) {
      const pauseBtn = document.createElement('button');
      pauseBtn.type = 'button';
      pauseBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
      pauseBtn.dataset.role = 'pause';
      pauseBtn.textContent = this.tr(ctx, 'game.hud.pause', 'Pause');
      pauseBtn.addEventListener('click', () => this.togglePause());
      right.appendChild(pauseBtn);
    }

    const restartBtn = document.createElement('button');
    restartBtn.type = 'button';
    restartBtn.className = 'game-host-hud-btn btn btn--secondary btn--sm';
    restartBtn.dataset.role = 'restart';
    restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    restartBtn.addEventListener('click', () => this.restart());
    right.appendChild(restartBtn);

    ctrlSec.appendChild(right);
    hud.appendChild(ctrlSec);
    return hud;
  }

  /** 小标题分区（宿主 .zby-sec-title 同配方）：i18n 中文 + 固定 EN mono 小注（装饰，aria-hidden）
   *  + 渐细皮肤色横线（::after，见 css-hud 末段）。dataset 双载 key 与英文兜底供 i18n 刷新。 */
  private createHudSection(ctx: AppMountContext, titleKey: string, enTag: string): HTMLElement {
    const sec = document.createElement('section');
    sec.className = 'game-host-sec';
    const head = document.createElement('div');
    head.className = 'game-host-sec-head';
    head.dataset.titleKey = titleKey;
    head.dataset.titleFallback = enTag;
    const name = document.createElement('span');
    name.textContent = this.tr(ctx, titleKey, enTag);
    head.appendChild(name);
    const sub = document.createElement('span');
    sub.className = 'game-host-sec-sub';
    sub.setAttribute('aria-hidden', 'true');
    sub.textContent = enTag;
    head.appendChild(sub);
    sec.appendChild(head);
    return sec;
  }

  /** 更新 HUD 分数显示（分数 / 最高分两行分别更新） */
  private updateHUDScore(): void {
    if (this.hud === null) return;
    const scoreEl = this.hud.querySelector<HTMLElement>('[data-role="score-value"]');
    if (scoreEl !== null) scoreEl.textContent = String(this.score);
    const bestEl = this.hud.querySelector<HTMLElement>('[data-role="best-value"]');
    if (bestEl !== null) bestEl.textContent = String(this.bestScore);
  }

  /** 计分行：标签（mono 小字）+ 数值（tabular-nums）；行内 nowrap、行间堆叠 */
  private createScoreLine(ctx: AppMountContext | null, labelKey: string, labelFallback: string, valueRole: string, initialValue: string): HTMLElement {
    const line = document.createElement('span');
    line.className = 'game-host-hud-score-line';
    const label = document.createElement('span');
    label.className = 'game-host-hud-score-label';
    label.textContent = this.tr(ctx, labelKey, labelFallback);
    const value = document.createElement('span');
    value.className = 'game-host-hud-score-value';
    value.dataset.role = valueRole;
    value.textContent = initialValue;
    line.appendChild(label);
    line.appendChild(value);
    return line;
  }

  /** i18n 刷新（Step 4.1）：宿主语言切换后重设 HUD 文案（data-role 查询 + 子类 hook） */
  protected refreshHudI18n(): void {
    if (this.hud === null) return;
    const ctx = this.ctx;
    if (ctx === null) return;
    const diffSelect = this.hud.querySelector<HTMLSelectElement>('[data-role="difficulty"]');
    if (diffSelect !== null) {
      diffSelect.setAttribute('aria-label', this.tr(ctx, 'game.hud.difficulty', 'Difficulty'));
      const labels: ReadonlyArray<{ value: GameDifficulty; labelKey: string; fallback: string }> = [
        { value: 'easy', labelKey: 'game.difficulty.easy', fallback: 'Easy' },
        { value: 'normal', labelKey: 'game.difficulty.normal', fallback: 'Normal' },
        { value: 'hard', labelKey: 'game.difficulty.hard', fallback: 'Hard' },
        { value: 'expert', labelKey: 'game.difficulty.expert', fallback: 'Expert' },
        { value: 'master', labelKey: 'game.difficulty.master', fallback: 'Master' },
      ];
      const options = diffSelect.querySelectorAll('option');
      options.forEach((o) => {
        const label = labels.find((l) => l.value === o.value);
        if (label !== undefined) o.textContent = this.tr(ctx, label.labelKey, label.fallback);
      });
    }
    /* 暂停遮罩文案（CSS ::after content 消费 dataset.pausedText） */
    const canvasWrap = this.root !== null ? this.root.querySelector<HTMLElement>('.game-host-canvas-wrap') : null;
    if (canvasWrap !== null) {
      canvasWrap.dataset.pausedText = this.tr(ctx, 'game.hud.pausedHint', 'Paused');
    }
    if (this.canvas !== null) this.canvas.setAttribute('aria-label', this.resolveGameName(ctx));
    /* HUD 标题（游戏名）+ 重新开始按钮（2026-08-27 P4.1f 运行时验证补齐） */
    const titleEl = this.hud.querySelector<HTMLElement>('.game-host-hud-title');
    if (titleEl !== null) titleEl.textContent = this.resolveGameName(ctx);
    const restartBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="restart"]');
    if (restartBtn !== null) restartBtn.textContent = this.tr(ctx, 'game.hud.restart', 'Restart');
    /* 分区小标题（EDITORIAL Phase 4 收口）：dataset.titleKey 记录 key，刷新时重查词表 */
    const secHeads = this.hud.querySelectorAll<HTMLElement>('.game-host-sec-head');
    secHeads.forEach((head) => {
      const key = head.dataset.titleKey;
      if (key === undefined || key === '') return;
      const name = head.firstElementChild;
      if (name !== null) name.textContent = this.tr(ctx, key, head.dataset.titleFallback ?? key);
    });
    this.updateHUDStatus();
    this.updateHUDScore();
    if (this.onI18nRefresh !== undefined) {
      try { this.onI18nRefresh(); } catch { /* ignore */ }
    }
  }

  /** i18n 刷新子类 hook（如 tank 的 Phaser 场景 overlays 重建） */
  protected onI18nRefresh?: () => void;

  /** 更新 HUD 状态显示 */
  private updateHUDStatus(): void {
    if (this.hud === null) return;
    const pauseBtn = this.hud.querySelector<HTMLButtonElement>('[data-role="pause"]');
    if (pauseBtn !== null) {
      pauseBtn.textContent = this.paused
        ? this.tr(this.ctx, 'game.hud.resume', 'Resume')
        : this.tr(this.ctx, 'game.hud.pause', 'Pause');
    }
  }

  /** 格式化分数显示 */
  /** 解析游戏名称（从 manifest.nameFallback） */
  private resolveGameName(ctx: AppMountContext): string {
    const nameKey = ctx.manifest.nameKey;
    if (nameKey !== undefined && nameKey !== '') {
      const tr = this.tr(ctx, nameKey, ctx.manifest.nameFallback);
      if (tr !== nameKey) return tr;
    }
    return ctx.manifest.nameFallback;
  }

  /** i18n 翻译（带兜底） */
  private tr(ctx: AppMountContext | null, key: string, fallback: string, params?: Readonly<Record<string, string | number>>): string {
    if (ctx === null) return fallback;
    try {
      const result = ctx.t(key, params);
      if (result !== key) return result;
    } catch {
      /* ignore */
    }
    return params === undefined ? fallback : fallback.replace(/\{(\w+)\}/g, (_m: string, name: string): string => {
      const value = params[name];
      return value !== undefined ? String(value) : '';
    });
  }

  /* ============================================================
     最高分持久化（P4.3：sandboxStorage 代理，键 game:best:game-tetris）
     ============================================================ */

  private async loadBestScore(): Promise<number> {
    const storage = getSandboxStorage();
    if (storage === null) return 0;
    try {
      const raw = await storage.get(BEST_SCORE_KEY_PREFIX + this.config.gameId);
      if (raw === null || raw === undefined) return 0;
      const n = Number.parseInt(String(raw), 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch {
      return 0;
    }
  }

  private saveBestScore(score: number): void {
    const storage = getSandboxStorage();
    if (storage === null) return;
    void storage.set(BEST_SCORE_KEY_PREFIX + this.config.gameId, String(score)).catch(() => {
      /* ignore quota */
    });
  }
}


  /* =========================================================
     5. TetrisHost 内联（原 src/shared/apps/games/builtin/tetris/TetrisHost.ts）
     ========================================================= */

/**
 * TetrisHost — 俄罗斯方块游戏实现
 *
 * Phase 5.8.2 交付物：5 款内置小游戏之一。
 *
 * 引擎：Canvas 2D
 * 操作：
 *   ← → 移动；↑ 旋转；↓ 软降；空格 硬降；C 暂存(Hold)；P 暂停；R 重新开始
 *
 * 增强特性：
 *   - Hold（暂存）：C 键交换当前方块与暂存槽，每个方块仅可 Hold 一次（锁定后重置）
 *   - 7-bag 随机算法：每 7 个方块包含全部 7 种形状各一个，避免连续重复
 *   - 消行动画：满行白闪 220ms 后塌缩，配飘字效果（+分数 / LEVEL UP!）
 *   - 软降 +1 分/格；硬降 +2 分/格（累加进 SCORE）
 *   - 级别加速：dropInterval = max(100, 1000 - (level-1)*80) ms
 *   - 暂停毛玻璃遮罩（canvas filter blur 模拟 backdrop-filter）
 *   - 游戏结束画面：GAME OVER + 最终分数 + 按 R 重新开始
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.4
 */






/** 列数（标准 10 列） */
const COLS = 10;
/** 行数（标准 20 行） */
const ROWS = 20;
/** 单元格像素大小 */
const CELL = 28;
/** 侧边栏宽度（像素）：用于显示 HOLD/NEXT 预览 / 关卡 / 行数 / 操作提示 */
const SIDE_W = 140;
/** 画布宽度（含侧边栏） */
const W = COLS * CELL + SIDE_W;
/** 画布高度 */
const H = ROWS * CELL;
/** 游戏区域宽度 */
const BOARD_W = COLS * CELL;
/** 侧边栏 X 起点 */
const SIDE_X = BOARD_W;
/** 消行动画持续时长（毫秒）：满行白闪后塌缩 */
const CLEAR_ANIM_MS = 220;
/** 飘字效果持续时长（毫秒） */
const FLOAT_TEXT_MS = 900;
/** 飘字上升像素 */
const FLOAT_TEXT_RISE = 42;

/** 7 种 Tetromino 形状（用矩阵表示，便于旋转） */
const SHAPES: readonly (readonly (readonly number[])[])[] = [
  /* I */
  [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],
  /* O */
  [[1,1],[1,1]],
  /* T */
  [[0,1,0],[1,1,1],[0,0,0]],
  /* S */
  [[0,1,1],[1,1,0],[0,0,0]],
  /* Z */
  [[1,1,0],[0,1,1],[0,0,0]],
  /* L */
  [[0,0,1],[1,1,1],[0,0,0]],
  /* J */
  [[1,0,0],[1,1,1],[0,0,0]],
] as const;

/** 7 种 Tetromino 颜色（渐变：上浅下深，参考 chvin/react-tetris 配色） */
interface TetrominoColor {
  readonly light: string;
  readonly dark: string;
}
const COLORS: readonly TetrominoColor[] = [
  /* EDITORIAL-LAYOUT Phase 4 豁免：以下为**玩法画布内容色**（棋盘木纹 / 方块配色等），
     属于游戏可识别的玩法身份，不随皮肤变化 —— 按 PRD §9.2 非目标「不动玩法画布内部视觉」保留。
     与之相对，UI 面（页头 / 信息带 / 按钮 / 面板）一律消费 Token。 */
  { light: '#00f0f0', dark: '#00cccc' }, /* I 青 */
  { light: '#f0f000', dark: '#cccc00' }, /* O 黄 */
  { light: '#a000f0', dark: '#8000cc' }, /* T 紫 */
  { light: '#00f000', dark: '#00cc00' }, /* S 绿 */
  { light: '#f00000', dark: '#cc0000' }, /* Z 红 */
  { light: '#f0a000', dark: '#cc8800' }, /* L 橙 */
  { light: '#0000f0', dark: '#0000cc' }, /* J 蓝 */
];

/** 旋转矩阵 90°（顺时针） */
function rotate(matrix: readonly (readonly number[])[]): number[][] {
  const n = matrix.length;
  const m = matrix[0]?.length ?? 0;
  const result: number[][] = Array.from({ length: m }, () => new Array<number>(n).fill(0));
  for (let i = 0; i < n; i++) {
    const srcRow = matrix[i];
    if (srcRow === undefined) continue;
    for (let j = 0; j < m; j++) {
      const dstRow = result[j];
      if (dstRow === undefined) continue;
      const cell = srcRow[j];
      if (cell === undefined) continue;
      dstRow[n - 1 - i] = cell;
    }
  }
  return result;
}

/** Fisher-Yates 洗牌（原地打乱） */
function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = arr[i]!;
    const b = arr[j]!;
    arr[i] = b;
    arr[j] = a;
  }
  return arr;
}

/** 当前下落方块 */
interface Piece {
  shape: number[][];
  /** 颜色索引（对应 COLORS 数组） */
  color: number;
  x: number;
  y: number;
}

/** 飘字效果（消行得分 / 升级提示） */
interface FloatText {
  readonly text: string;
  readonly x: number;
  readonly y: number;
  readonly born: number;
  readonly ttl: number;
  readonly color: string;
}

class TetrisHost extends GameHost {
  private ctx2d: CanvasRenderingContext2D | null = null;
  private grid: number[][] = [];
  private current: Piece | null = null;
  private next: Piece | null = null;
  /** 7-bag：当前 bag 中剩余待取的形状索引序列 */
  private bag: number[] = [];
  /** 7-bag 读取位置（达到 bag.length 时自动重新洗牌） */
  private bagPos = 0;
  /** 暂存槽颜色索引（-1 表示空槽） */
  private holdColor = -1;
  /** 当前方块是否允许 Hold（锁定出新方块后重置为 true） */
  private canHold = true;
  /** 正在播放消行动画的行号集合（动画期间尚未塌缩） */
  private clearingRows: number[] = [];
  /** 消行动画截止时间戳（performance.now 基准） */
  private clearAnimEnd = 0;
  /** 活跃飘字列表 */
  private floatTexts: FloatText[] = [];
  private dropInterval = 1000;
  private lastDrop = 0;
  private rafId: number | null = null;
  private lines = 0;
  private level = 1;
  private keyHandler: ((e: KeyboardEvent) => void) | null = null;
  /** 本地暂停标记（与父类 isPaused 区分，避免 private 字段冲突） */
  private tetrisPaused = false;

  protected override onMount(_ctx: AppMountContext, canvas: HTMLCanvasElement, _options: GameLaunchOptions): void {
    const ctx2d = this.setupHiDPICanvas(canvas, W, H);
    if (ctx2d === null) return;
    this.ctx2d = ctx2d;
    this.reset();

    this.keyHandler = (e: KeyboardEvent) => this.onKey(e);
    window.addEventListener('keydown', this.keyHandler);

    const loop = (t: number): void => {
      this.tick(t);
      this.draw();
      this.rafId = window.requestAnimationFrame(loop);
    };
    this.rafId = window.requestAnimationFrame(loop);
  }

  protected onUnmount(): void {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.keyHandler !== null) {
      window.removeEventListener('keydown', this.keyHandler);
      this.keyHandler = null;
    }
    this.ctx2d = null;
  }

  protected override onPause(): void {
    this.tetrisPaused = true;
  }

  protected override onResume(): void {
    this.tetrisPaused = false;
    this.lastDrop = performance.now();
  }

  protected override onRestart(): void {
    this.reset();
    /* reset 不修改 GameStatus，重新开始需回到 playing 态 */
    this.setStatus('playing');
  }

  /* ============================================================
     游戏逻辑
     ============================================================ */

  private reset(): void {
    this.grid = Array.from({ length: ROWS }, () => new Array<number>(COLS).fill(-1));
    this.lines = 0;
    this.level = 1;
    this.dropInterval = 1000;
    this.holdColor = -1;
    this.canHold = true;
    this.clearingRows = [];
    this.clearAnimEnd = 0;
    this.floatTexts = [];
    this.bag = [];
    this.bagPos = 0;
    this.refillBag();
    this.next = this.makePiece(this.nextPieceType());
    this.spawn();
    this.updateScore(0, 1);
    this.lastDrop = performance.now();
    this.tetrisPaused = false;
  }

  /** 重新填充 7-bag（Fisher-Yates 洗牌 0..6） */
  private refillBag(): void {
    this.bag = shuffle([0, 1, 2, 3, 4, 5, 6]);
    this.bagPos = 0;
  }

  /** 从 7-bag 取出下一个形状索引；bag 耗尽时自动补充 */
  private nextPieceType(): number {
    if (this.bagPos >= this.bag.length) {
      this.refillBag();
    }
    const idx = this.bag[this.bagPos];
    this.bagPos++;
    return idx ?? 0;
  }

  /** 按形状索引构造一个新方块（重置到顶部居中、未旋转） */
  private makePiece(idx: number): Piece {
    const shape = SHAPES[idx];
    if (shape === undefined) {
      return { shape: SHAPES[0]!.map((row) => [...row]), color: 0, x: 3, y: 0 };
    }
    return {
      shape: shape.map((row) => [...row]),
      color: idx,
      x: Math.floor((COLS - (shape[0]?.length ?? 0)) / 2),
      y: 0,
    };
  }

  private spawn(): void {
    const color = this.next !== null ? this.next.color : this.nextPieceType();
    this.current = this.makePiece(color);
    this.next = this.makePiece(this.nextPieceType());
    this.canHold = true;
    if (this.collides(this.current, 0, 0)) {
      /* 顶到天花板：游戏结束 */
      this.setStatus('gameover');
      this.tetrisPaused = true;
    }
  }

  /** Hold：将当前方块暂存到 HOLD 槽，取出原暂存方块（若空槽则直接出新方块） */
  private holdCurrent(): void {
    const c = this.current;
    if (c === null || !this.canHold) return;
    const curColor = c.color;
    if (this.holdColor === -1) {
      /* 空槽：暂存当前方块，从 next 取下一个 */
      this.holdColor = curColor;
      this.spawn();
    } else {
      /* 非空：交换当前与暂存，重置到顶部居中 */
      const prevHold = this.holdColor;
      this.holdColor = curColor;
      this.current = this.makePiece(prevHold);
      if (this.collides(this.current, 0, 0)) {
        this.setStatus('gameover');
        this.tetrisPaused = true;
      }
    }
    this.canHold = false;
  }

  private collides(piece: Piece, dx: number, dy: number, shape?: number[][]): boolean {
    const s = shape ?? piece.shape;
    for (let i = 0; i < s.length; i++) {
      for (let j = 0; j < s[i]!.length; j++) {
        if (s[i]![j] !== 1) continue;
        const nx = piece.x + j + dx;
        const ny = piece.y + i + dy;
        if (nx < 0 || nx >= COLS || ny >= ROWS) return true;
        if (ny >= 0 && this.grid[ny]?.[nx] !== -1) return true;
      }
    }
    return false;
  }

  private merge(): void {
    const c = this.current;
    if (c === null) return;
    for (let i = 0; i < c.shape.length; i++) {
      for (let j = 0; j < c.shape[i]!.length; j++) {
        if (c.shape[i]![j] === 1) {
          const y = c.y + i;
          const x = c.x + j;
          if (y >= 0 && y < ROWS && x >= 0 && x < COLS) {
            this.grid[y]![x] = c.color;
          }
        }
      }
    }
  }

  /** 锁定当前方块并检测满行；若有满行则启动消行动画（延迟塌缩），否则立即出新方块 */
  private mergeAndCheckClear(): void {
    this.merge();
    this.current = null;
    const rows: number[] = [];
    for (let y = ROWS - 1; y >= 0; y--) {
      if (this.grid[y]!.every((v) => v !== -1)) rows.push(y);
    }
    if (rows.length > 0) {
      this.clearingRows = rows;
      this.clearAnimEnd = performance.now() + CLEAR_ANIM_MS;
    } else {
      this.spawn();
    }
  }

  /** 消行动画结束后塌缩行、计分、升级、出新方块 */
  private finishClear(): void {
    const cleared = this.clearingRows.length;
    const sorted = [...this.clearingRows].sort((a, b) => a - b);
    for (const y of sorted) {
      this.grid.splice(y, 1);
      this.grid.unshift(new Array<number>(COLS).fill(-1));
    }
    this.lines += cleared;
    const scoreMap = [0, 100, 300, 500, 800];
    const gained = (scoreMap[cleared] ?? 0) * this.level;
    /* 飘字定位到清除行中点 */
    const midRow = sorted.length > 0
      ? sorted.reduce((a, b) => a + b, 0) / sorted.length
      : ROWS / 2;
    this.addFloatText(`+${gained}`, BOARD_W / 2, midRow * CELL + CELL / 2, this.themeTokens.fg);
    this.updateScore(this.currentScore + gained, this.level);
    const newLevel = Math.floor(this.lines / 10) + 1;
    if (newLevel > this.level) {
      this.level = newLevel;
      this.dropInterval = Math.max(100, 1000 - (this.level - 1) * 80);
      this.addFloatText('LEVEL UP!', BOARD_W / 2, H / 2 - 48, this.themeTokens.accent);
      this.updateScore(this.currentScore, this.level);
    }
    this.clearingRows = [];
    this.clearAnimEnd = 0;
    this.spawn();
  }

  private drop(): void {
    const c = this.current;
    if (c === null) return;
    if (this.clearingRows.length > 0) return;
    if (!this.collides(c, 0, 1)) {
      c.y++;
    } else {
      this.mergeAndCheckClear();
    }
  }

  /** 软降：手动下移一格，每格 +1 分 */
  private softDrop(): void {
    const c = this.current;
    if (c === null) return;
    if (this.clearingRows.length > 0) return;
    if (!this.collides(c, 0, 1)) {
      c.y++;
      this.updateScore(this.currentScore + 1, this.level);
    } else {
      this.mergeAndCheckClear();
    }
    this.lastDrop = performance.now();
  }

  /** 硬降：直接落到底，每格 +2 分 */
  private hardDrop(): void {
    const c = this.current;
    if (c === null) return;
    if (this.clearingRows.length > 0) return;
    let dist = 0;
    while (!this.collides(c, 0, dist + 1)) dist++;
    c.y += dist;
    if (dist > 0) {
      this.updateScore(this.currentScore + dist * 2, this.level);
    }
    this.mergeAndCheckClear();
  }

  private move(dx: number): void {
    const c = this.current;
    if (c === null) return;
    if (this.clearingRows.length > 0) return;
    if (!this.collides(c, dx, 0)) c.x += dx;
  }

  private rotateCurrent(): void {
    const c = this.current;
    if (c === null) return;
    if (this.clearingRows.length > 0) return;
    const rotated = rotate(c.shape);
    /* 简单 SRS：尝试原位 + 偏移踢墙 */
    const kicks: readonly (readonly [number, number])[] = [[0, 0], [1, 0], [-1, 0], [0, -1], [2, 0], [-2, 0]] as const;
    for (const [kx, ky] of kicks) {
      if (!this.collides(c, kx, ky, rotated)) {
        c.shape = rotated;
        c.x += kx;
        c.y += ky;
        return;
      }
    }
  }

  private tick(now: number): void {
    if (this.tetrisPaused || this.currentStatus !== 'playing') return;
    /* 消行动画期间不下落；动画结束时塌缩并出新方块 */
    if (this.clearingRows.length > 0) {
      if (now >= this.clearAnimEnd) {
        this.finishClear();
        this.lastDrop = now;
      }
      return;
    }
    if (now - this.lastDrop >= this.dropInterval) {
      this.drop();
      this.lastDrop = now;
    }
  }

  private onKey(e: KeyboardEvent): void {
    /* 游戏结束：仅允许 R 重新开始 */
    if (this.currentStatus === 'gameover') {
      if (e.key === 'r' || e.key === 'R') this.restart();
      return;
    }
    /* 暂停期间仅允许 P 切换 */
    if (this.tetrisPaused && e.key !== 'p' && e.key !== 'P') return;
    if (this.currentStatus !== 'playing') return;
    switch (e.key) {
      case 'ArrowLeft':  this.move(-1); break;
      case 'ArrowRight': this.move(1); break;
      case 'ArrowDown':  this.softDrop(); break;
      case 'ArrowUp':    this.rotateCurrent(); break;
      case ' ':          e.preventDefault(); this.hardDrop(); break;
      case 'c':
      case 'C':          this.holdCurrent(); break;
      case 'p':
      case 'P':          this.togglePause(); break;
      default: return;
    }
  }

  /* ============================================================
     飘字效果
     ============================================================ */

  private addFloatText(text: string, x: number, y: number, color: string): void {
    this.floatTexts.push({ text, x, y, born: performance.now(), ttl: FLOAT_TEXT_MS, color });
  }

  private drawFloatTexts(ctx: CanvasRenderingContext2D, now: number): void {
    for (const f of this.floatTexts) {
      const elapsed = now - f.born;
      const t = elapsed / f.ttl; /* 0→1 */
      const alpha = Math.max(0, 1 - t);
      const dy = -t * FLOAT_TEXT_RISE;
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.fillStyle = f.color;
      ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      /* 描边增强可读性 */
      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 3;
      ctx.strokeText(f.text, f.x, f.y + dy);
      ctx.fillText(f.text, f.x, f.y + dy);
      ctx.restore();
    }
  }

  /* ============================================================
     渲染
     ============================================================ */

  private draw(): void {
    const ctx = this.ctx2d;
    if (ctx === null) return;
    const theme = this.themeTokens;
    const now = performance.now();

    /* 清理过期飘字 */
    this.floatTexts = this.floatTexts.filter((f) => now - f.born < f.ttl);

    /* 背景 */
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, W, H);

    /* 侧边栏背景 */
    ctx.fillStyle = 'rgba(255,255,255,0.025)';
    ctx.fillRect(SIDE_X, 0, SIDE_W, H);
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(SIDE_X + 0.5, 0);
    ctx.lineTo(SIDE_X + 0.5, H);
    ctx.stroke();

    /* 网格线（仅游戏区域，非常淡） */
    ctx.save();
    ctx.strokeStyle = theme.fg;
    ctx.globalAlpha = 0.05;
    ctx.lineWidth = 1;
    for (let i = 0; i <= COLS; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL, 0);
      ctx.lineTo(i * CELL, H);
      ctx.stroke();
    }
    for (let i = 0; i <= ROWS; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * CELL);
      ctx.lineTo(BOARD_W, i * CELL);
      ctx.stroke();
    }
    ctx.restore();

    /* 消行动画判定：满行白闪 */
    const clearingSet = new Set<number>(this.clearingRows);
    const isClearing = clearingSet.size > 0 && now < this.clearAnimEnd;

    /* 已落地的方块（消行动画期间对满行叠加白色脉冲） */
    for (let y = 0; y < ROWS; y++) {
      for (let x = 0; x < COLS; x++) {
        const v = this.grid[y]![x];
        if (v !== undefined && v >= 0) {
          this.drawCell(ctx, x, y, v);
          if (isClearing && clearingSet.has(y)) {
            const pulse = 0.5 + 0.5 * Math.sin(now * 0.045);
            ctx.fillStyle = `rgba(255,255,255,${(0.45 + 0.5 * pulse).toFixed(3)})`;
            ctx.fillRect(x * CELL, y * CELL, CELL, CELL);
          }
        }
      }
    }

    /* 当前方块的"幻影"（落点预测，ghost piece：虚线轮廓） */
    const c = this.current;
    if (c !== null && !this.tetrisPaused && this.currentStatus === 'playing' && this.clearingRows.length === 0) {
      let dist = 0;
      while (!this.collides(c, 0, dist + 1)) dist++;
      for (let i = 0; i < c.shape.length; i++) {
        for (let j = 0; j < c.shape[i]!.length; j++) {
          if (c.shape[i]![j] === 1) {
            this.drawGhostCell(ctx, c.x + j, c.y + i + dist, c.color);
          }
        }
      }
    }

    /* 当前方块 */
    if (c !== null) {
      for (let i = 0; i < c.shape.length; i++) {
        for (let j = 0; j < c.shape[i]!.length; j++) {
          if (c.shape[i]![j] === 1) {
            this.drawCell(ctx, c.x + j, c.y + i, c.color);
          }
        }
      }
    }

    /* 飘字效果（分数 / 升级） */
    this.drawFloatTexts(ctx, now);

    /* 侧边栏：HOLD / NEXT 预览 / 分数 / 关卡 / 行数 / 操作提示 */
    this.drawSidebar(ctx);

    /* 暂停遮罩（毛玻璃模拟） */
    if (this.tetrisPaused && this.currentStatus === 'paused') {
      this.drawPauseOverlay(ctx);
    }

    /* 游戏结束遮罩 */
    if (this.currentStatus === 'gameover') {
      this.drawGameOverOverlay(ctx);
    }
  }

  /** 绘制暂停遮罩：canvas filter blur 模拟 backdrop-filter，叠加半透明深色 + 居中文字 */
  private drawPauseOverlay(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    const cv = ctx.canvas;
    /* 毛玻璃：将游戏区域模糊重绘到自身（侧边栏保持清晰） */
    ctx.save();
    ctx.filter = 'blur(6px)';
    ctx.drawImage(cv, 0, 0, BOARD_W, H, 0, 0, BOARD_W, H);
    ctx.restore();
    /* 深色遮罩 */
    ctx.fillStyle = 'rgba(8,10,18,0.55)';
    ctx.fillRect(0, 0, BOARD_W, H);
    /* 居中文字 */
    ctx.fillStyle = theme.fg;
    ctx.font = 'bold 24px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.tr(this.ctx, 'game.tetris.hud.paused', 'Paused'), BOARD_W / 2, H / 2 - 12);
    ctx.font = '13px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillStyle = theme.muted;
    ctx.fillText(this.tr(this.ctx, 'game.tetris.hud.resumeKey', 'Press P to resume'), BOARD_W / 2, H / 2 + 16);
  }

  /** 绘制游戏结束遮罩：毛玻璃 + GAME OVER + 最终分数 + 重新开始提示 */
  private drawGameOverOverlay(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    const cv = ctx.canvas;
    ctx.save();
    ctx.filter = 'blur(5px)';
    ctx.drawImage(cv, 0, 0, BOARD_W, H, 0, 0, BOARD_W, H);
    ctx.restore();
    ctx.fillStyle = 'rgba(6,8,14,0.7)';
    ctx.fillRect(0, 0, BOARD_W, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = theme.fg;
    ctx.font = 'bold 26px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillText('GAME OVER', BOARD_W / 2, H / 2 - 28);
    ctx.fillStyle = theme.muted;
    ctx.font = '11px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillText(this.tr(this.ctx, 'game.tetris.hud.finalScore', 'Final Score'), BOARD_W / 2, H / 2 - 8);
    ctx.fillStyle = theme.accent;
    ctx.font = 'bold 18px ui-monospace, "SF Mono", Menlo, Consolas, monospace';
    ctx.fillText(`${this.currentScore}`, BOARD_W / 2, H / 2 + 12);
    ctx.fillStyle = theme.fg;
    ctx.font = '13px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    ctx.fillText(this.tr(this.ctx, 'game.common.restartKey', 'Press R to restart'), BOARD_W / 2, H / 2 + 40);
  }

  /** 绘制侧边栏：HOLD / NEXT 预览 / 统计信息 / 操作提示 */
  private drawSidebar(ctx: CanvasRenderingContext2D): void {
    const theme = this.themeTokens;
    const padX = 12;
    const innerL = SIDE_X + padX;
    const innerR = SIDE_X + SIDE_W - padX;
    const cx = SIDE_X + SIDE_W / 2;
    const monoFont = 'ui-monospace, "SF Mono", Menlo, Consolas, monospace';
    const sansFont = '-apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';

    /* ---- HOLD 背景框 + 标题（主题适配） ---- */
    let y = 12;
    const holdBoxH = 76;
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = theme.bg;
    ctx.fillRect(innerL - 4, y, innerR - innerL + 8, holdBoxH);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 1;
    ctx.strokeRect(innerL - 3.5, y + 0.5, innerR - innerL + 7, holdBoxH - 1);
    ctx.fillStyle = theme.muted;
    ctx.font = `bold 10px ${sansFont}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText('HOLD', innerL, y + 6);
    /* HOLD 预览（空槽显示占位提示） */
    if (this.holdColor !== -1) {
      this.drawPreviewPiece(ctx, this.holdColor, cx, y + 22, 15);
    } else {
      ctx.fillStyle = theme.muted;
      ctx.globalAlpha = 0.4;
      ctx.font = `9px ${sansFont}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(this.tr(this.ctx, 'game.tetris.hud.empty', '— Empty —'), cx, y + holdBoxH / 2 + 6);
      ctx.globalAlpha = 1;
    }
    y += holdBoxH + 10;

    /* ---- NEXT 背景框 + 标题（主题适配） ---- */
    const nextBoxH = 100;
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = theme.bg;
    ctx.fillRect(innerL - 4, y, innerR - innerL + 8, nextBoxH);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 1;
    ctx.strokeRect(innerL - 3.5, y + 0.5, innerR - innerL + 7, nextBoxH - 1);

    ctx.fillStyle = theme.muted;
    ctx.font = `bold 10px ${sansFont}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText('NEXT', innerL, y + 6);

    /* ---- NEXT 预览（居中） ---- */
    const next = this.next;
    if (next !== null) {
      this.drawPreviewPiece(ctx, next.color, cx, y + 26, 16);
    }
    y += nextBoxH + 10;

    /* ---- 统计面板（色点 + 标签 + 等宽数字 + 分隔线） ---- */
    const drawStat = (label: string, value: string, valueColor: string): void => {
      ctx.fillStyle = valueColor;
      ctx.beginPath();
      ctx.arc(innerL + 3, y + 6, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = theme.muted;
      ctx.font = `10px ${sansFont}`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(label, innerL + 10, y);
      ctx.fillStyle = valueColor;
      ctx.font = `bold 17px ${monoFont}`;
      ctx.textAlign = 'right';
      ctx.textBaseline = 'top';
      ctx.fillText(value, innerR, y + 11);
      y += 32;
      ctx.strokeStyle = theme.border;
      ctx.globalAlpha = 0.5;
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(innerL, y - 4);
      ctx.lineTo(innerR, y - 4);
      ctx.stroke();
      ctx.globalAlpha = 1;
    };
    drawStat('LEVEL', String(this.level).padStart(2, '0'), theme.accent);
    drawStat('LINES', String(this.lines).padStart(3, '0'), theme.fg);
    drawStat('SCORE', String(this.currentScore).padStart(5, '0'), theme.fg);
    y += 4;

    /* ---- 操作提示（分组：移动 / 旋转 / 降下 / 其他） ---- */
    ctx.fillStyle = theme.muted;
    ctx.font = `bold 10px ${sansFont}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText('Controls', innerL, y);
    y += 16;

    interface Hint {
      readonly key: string;
      readonly desc: string;
    }
    const drawHintGroup = (groupTitle: string, hints: readonly Hint[]): void => {
      ctx.fillStyle = theme.accent;
      ctx.globalAlpha = 0.75;
      ctx.font = `9px ${sansFont}`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(groupTitle, innerL, y);
      ctx.globalAlpha = 1;
      y += 12;
      for (const hint of hints) {
        ctx.font = `bold 9px ${monoFont}`;
        const keyW = Math.max(22, ctx.measureText(hint.key).width + 10);
        ctx.fillStyle = 'rgba(255,255,255,0.07)';
        ctx.fillRect(innerL, y, keyW, 14);
        ctx.strokeStyle = theme.border;
        ctx.lineWidth = 0.5;
        ctx.strokeRect(innerL + 0.5, y + 0.5, keyW - 1, 13);
        ctx.fillStyle = theme.fg;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(hint.key, innerL + keyW / 2, y + 7);
        ctx.fillStyle = theme.muted;
        ctx.font = `10px ${sansFont}`;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.fillText(hint.desc, innerL + keyW + 6, y + 2);
        y += 18;
      }
    };
    drawHintGroup(this.tr(this.ctx, 'game.tetris.hint.move', 'Move'), [{ key: '\u2190 \u2192', desc: this.tr(this.ctx, 'game.tetris.hint.moveDesc', 'Move') }]);
    drawHintGroup(this.tr(this.ctx, 'game.tetris.hint.rotate', 'Rotate'), [{ key: '\u2191', desc: this.tr(this.ctx, 'game.tetris.hint.rotateDesc', 'Rotate piece') }]);
    drawHintGroup(this.tr(this.ctx, 'game.tetris.hint.drop', 'Drop'), [{ key: '\u2193', desc: this.tr(this.ctx, 'game.tetris.hint.softDrop', 'Soft drop +1') }, { key: 'Space', desc: this.tr(this.ctx, 'game.tetris.hint.hardDrop', 'Hard drop +2') }]);
    drawHintGroup(this.tr(this.ctx, 'game.tetris.hint.other', 'Other'), [{ key: 'C', desc: this.tr(this.ctx, 'game.tetris.hint.hold', 'Hold') }, { key: 'P', desc: this.tr(this.ctx, 'game.tetris.hint.pauseResume', 'Pause/Resume') }]);
  }

  /** 绘制预览方块（HOLD/NEXT 通用）：按形状索引居中渲染 */
  private drawPreviewPiece(ctx: CanvasRenderingContext2D, colorIdx: number, cx: number, startY: number, cellSize: number): void {
    const shape = SHAPES[colorIdx];
    if (shape === undefined) return;
    const rows = shape.length;
    const cols = shape[0]?.length ?? 0;
    const previewW = cols * cellSize;
    const startX = cx - previewW / 2;
    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        if (shape[i]?.[j] === 1) {
          this.drawBlock(ctx, startX + j * cellSize, startY + i * cellSize, cellSize, colorIdx);
        }
      }
    }
  }

  /** 绘制方块格子（渐变 + 高光 + 阴影 + 投影），可复用于任意尺寸 */
  private drawBlock(ctx: CanvasRenderingContext2D, px: number, py: number, size: number, colorIdx: number): void {
    const c = COLORS[colorIdx];
    if (c === undefined) return;
    /* 投影 */
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(px + 1.5, py + 2, size - 2, size - 2);
    /* 渐变主体（左上浅 → 右下深） */
    const g = ctx.createLinearGradient(px, py, px + size, py + size);
    g.addColorStop(0, c.light);
    g.addColorStop(1, c.dark);
    ctx.fillStyle = g;
    ctx.fillRect(px + 1, py + 1, size - 2, size - 2);
    /* 内部高光：左上 1px 浅色边 */
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(px + 1.5, py + size - 1.5);
    ctx.lineTo(px + 1.5, py + 1.5);
    ctx.lineTo(px + size - 1.5, py + 1.5);
    ctx.stroke();
    /* 内部阴影：右下 1px 深色边 */
    ctx.strokeStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.moveTo(px + size - 1.5, py + 1.5);
    ctx.lineTo(px + size - 1.5, py + size - 1.5);
    ctx.lineTo(px + 1.5, py + size - 1.5);
    ctx.stroke();
  }

  /** 绘制 ghost piece 格子（虚线轮廓） */
  private drawGhostCell(ctx: CanvasRenderingContext2D, x: number, y: number, colorIdx: number): void {
    const c = COLORS[colorIdx];
    if (c === undefined) return;
    const px = x * CELL;
    const py = y * CELL;
    ctx.save();
    ctx.strokeStyle = c.light;
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 3]);
    ctx.strokeRect(px + 2.5, py + 2.5, CELL - 5, CELL - 5);
    ctx.restore();
  }

  private drawCell(ctx: CanvasRenderingContext2D, x: number, y: number, colorIdx: number): void {
    this.drawBlock(ctx, x * CELL, y * CELL, CELL, colorIdx);
  }
}


  /* =========================================================
     6. 样式（game-host.css 同源，内嵌注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * game-host.css — 小游戏宿主样式
 *
 * Phase 5.8.1 交付物：小游戏模块基础设施。
 *
 * 设计要点：
 *   - 容器铺满窗口 body（.game-host-root）
 *   - HUD 顶部固定（分数 + 控制按钮）
 *   - 画布居中、保持比例、自适应缩放
 *   - 主题色由 CSS 变量驱动（--bg-canvas / --fg-primary / --accent-cool 等）
 *   - 暂停时画布半透明遮罩 + "Paused"提示
 *   - 隐藏滚动条（项目记忆：避免底部水平滚动条）
 *
 * @see prd/ZBY-CODING-CREATION-HUB-ROADMAP_V2.md §24.3
 */

.game-host-root {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  /* 玻璃配方（GlassSidePanel 同款）：垫底随主题模式/皮肤，半透明白透出坊市体验层毛玻璃 */
  background: var(--skin-pattern-image, none), color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 95%, var(--surface-solid-primary, #ffffff) 5%);
  backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
  color: var(--glass-text-primary, #e8e8e8);
  font-family: var(--skin-font-body, -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif);
  overflow: hidden;
  /* 防止 iOS 弹性滚动影响游戏体验 */
  overscroll-behavior: contain;
  -webkit-user-select: none;
  user-select: none;
}

/* ============================================================
   HUD（顶部条）
   ============================================================ */

.game-host-hud {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
  background: color-mix(in srgb, var(--bg-glass, rgba(255, 255, 255, 0.55)) 92%, var(--surface-solid-primary, #ffffff) 8%);
  border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  -webkit-backdrop-filter: blur(var(--skin-blur-l1, 16px)) saturate(var(--skin-saturate, 1.5));
  flex-shrink: 0;
}

/* G2 F 头：皮肤色渐细发丝线（HUD 底缘） */
.game-host-hud::after {
  content: '';
  position: absolute;
  left: var(--layout-row-pad-x, 0.875rem);
  right: var(--layout-row-pad-x, 0.875rem);
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
  pointer-events: none;
}

.game-host-hud-left {
  display: flex;
  align-items: baseline;
  gap: 0.875rem;
  min-width: 0;
  overflow: hidden;
}

/* G2 F 头：mono kicker（与宿主 .zby-page-head__kicker 同配方，自包含 fallback） */
.game-host-hud-kicker {
  font-family: var(--type-mono, var(--skin-font-mono, ui-monospace, monospace));
  font-size: 0.5625rem;
  font-weight: 700;
  letter-spacing: 0.32em;
  color: var(--deco-primary, var(--accent, #3cb371));
  white-space: nowrap;
  flex-shrink: 0;
}

.game-host-hud-title {
  /* F 语言：衬线显示字体 + 字距（UI-REMAINING-WAVES Wave G L2；--type-display 经沙箱白名单注入） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 0.875rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--glass-text-primary, #e8e8e8);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}

/* 计分区（2026-09-15 改双行）：分数 / 最高分各占一行——左信息带宽度有限，
   同行合并文案窄屏时截断显示不全；行内 nowrap（单值不会溢出），行间堆叠 */
.game-host-hud-score {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  min-width: 0;
}

.game-host-hud-score-line {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 0.5rem;
  min-width: 0;
}

.game-host-hud-score-label {
  font-family: var(--type-mono, monospace);
  font-size: 0.6875rem;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--glass-text-tertiary, #999);
  flex-shrink: 0;
}

.game-host-hud-score-value {
  font-size: 0.8125rem;
  font-variant-numeric: tabular-nums;
  color: var(--glass-text-secondary, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.game-host-hud-right {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
}

/* P4.7：按钮基座化（铁律 9）——ui-kit btn 片段内嵌快照（assets/ui-kit/btn.css），
 * 选择器扩列桥接 .game-host-hud-btn（HUD 暂停/重开/难度控件），
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：次按钮 + 小尺寸变体。 */

.btn, .game-host-hud-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .game-host-hud-btn:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .game-host-hud-btn:disabled,
.btn[disabled], .game-host-hud-btn[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 次按钮：卡片玻璃底（HUD 暂停/重开/难度选择） */
.btn--secondary, .game-host-hud-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .game-host-hud-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 尺寸变体：小尺寸（HUD 紧凑布局） */
.btn--sm, .game-host-hud-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .game-host-hud-btn{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}

/* =========================================================
   P4.7b：皮肤按钮形状钩子表（皮肤形状语言内嵌快照）
   ---------------------------------------------------------
   宿主端按钮形状 = tokens.css data-interaction-model 通用规则
   （src/shared/design-tokens/tokens.css）+ 各皮肤 Manifest extraCSS
   （src/domains/themes/skins/*.ts）；iframe 无法继承宿主样式表，
   此处内嵌按钮形状语言子集，由 MultiFileSandbox 同步的
   data-skin / data-interaction-model / data-theme-mode 属性驱动，
   使游戏按钮获得与宿主同款手绘边框/糖果胶囊 3D/像素厚度/粗描边
   错位/油墨细线/浮雕等形状语言。
   约定：
   - 顺序与宿主一致：交互模型通用规则在前，皮肤 extraCSS 在后
     （同特异性后注入者胜，island 默认态即依赖此顺序让位 toy hover）
   - 深色变体选择器用 [data-theme-mode="dark"]（iframe 同步属性，
     非宿主的 data-theme-mode-effective）
   - 皮肤自定义变量（--is-ink/--is-cream/--toy-shadow/--ra-ink/
     --neumo-dark/--neumo-light）不在沙箱注入白名单
     （sandbox-skin-var-names.ts），一律 var(..., fallback)
   - iframe 内按钮必挂 .btn 类（core.tpl 受控），钩子表只写 .btn
   - 修改需同步宿主真相源（tokens.css + skins/*.ts extraCSS）
   ========================================================= */

/* —— 1. 交互模型通用规则子集（tokens.css data-interaction-model 快照） —— */

/* 交互类统一过渡节奏 */
[data-interaction-model] .btn{
  transition:
    background var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    color var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1)),
    transform var(--motion-dur, 200ms) var(--motion-ease, cubic-bezier(0.4, 0, 0.2, 1));
}

/* lightweight：轻反馈 — 按下微缩放 */
[data-interaction-model="lightweight"] .btn:active{
  transform: scale(var(--motion-travel-press, 0.98));
}

/* responsive：标准反馈 — hover 上浮 + 按下微缩放 */
[data-interaction-model="responsive"] .btn:hover{
  transform: translateY(var(--motion-travel-hover, -1px));
}
[data-interaction-model="responsive"] .btn:active{
  transform: translateY(0) scale(var(--motion-travel-press, 0.98));
}

/* terminal：命令行式反馈 — hover 品红下划线、按下反白、focus 品红描边
   （硬编码色 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="terminal"] .btn:hover{
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(255, 46, 136, 0.55);
}
[data-interaction-model="terminal"] .btn:active{
  color: rgba(232, 237, 246, 1);
  background: rgba(255, 46, 136, 1);
  text-decoration: none;
}
[data-interaction-model="terminal"] .btn:focus-visible{
  outline: 1px solid rgba(255, 46, 136, 1);
  outline-offset: 2px;
}

/* print：印刷批注式反馈 — hover 印刷红下划线、按下墨底反白、focus 红细描边（深色反白）。
   硬编码色一律 rgba 等价书写（皮肤契约 forbidHardcodedColors 不认裸 hex） */
[data-interaction-model="print"] .btn:hover{
  color: rgba(192, 57, 43, 1);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: rgba(192, 57, 43, 0.55);
}
[data-interaction-model="print"] .btn:active{
  color: rgba(240, 231, 211, 1);
  background: rgba(26, 26, 24, 1);
  text-decoration: none;
}
[data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(192, 57, 43, 0.5);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:hover{
  color: rgba(226, 112, 90, 1);
  text-decoration-color: rgba(226, 112, 90, 0.6);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:active{
  color: rgba(32, 31, 27, 1);
  background: rgba(240, 231, 211, 1);
}
[data-theme-mode="dark"][data-interaction-model="print"] .btn:focus-visible{
  outline: 1px solid rgba(226, 112, 90, 0.6);
}

/* snap：瞬时反馈 — hover 黑白互换、按下黑底黄字、focus 2px 黑描边（深色对称反转；
   硬编码色一律 rgba 等价书写，皮肤契约不认裸 hex） */
[data-interaction-model="snap"] .btn:hover{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 255, 255, 1);
  transition-duration: 0ms;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:hover{
  background: rgba(255, 255, 255, 1);
  color: rgba(17, 17, 17, 1);
}
[data-interaction-model="snap"] .btn:active{
  background: rgba(17, 17, 17, 1);
  color: rgba(255, 195, 0, 1);
  transition-duration: 0ms;
}
[data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(17, 17, 17, 1);
  outline-offset: 2px;
}
[data-theme-mode="dark"][data-interaction-model="snap"] .btn:focus-visible{
  outline: 2px solid rgba(255, 255, 255, 1);
  outline-offset: 2px;
}

/* doodle：手绘反馈 — hover 蜡笔红波浪下划线 + 微旋转、按下反向回弹、focus 蜡笔虚线 */
[data-interaction-model="doodle"] .btn:hover{
  transform: rotate(-0.5deg);
  text-decoration: underline;
  text-underline-offset: 4px;
  text-decoration-style: wavy;
  text-decoration-color: rgba(232, 96, 76, 0.75);
  text-decoration-thickness: 1.5px;
}
[data-theme-mode="dark"][data-interaction-model="doodle"] .btn:hover{
  text-decoration-color: rgba(91, 168, 201, 0.8);
}
[data-interaction-model="doodle"] .btn:active{
  transform: rotate(0.5deg) scale(0.97);
  text-decoration: none;
}
[data-interaction-model="doodle"] .btn:focus-visible{
  outline: 2px dashed rgba(232, 96, 76, 0.8);
  outline-offset: 2px;
}

/* hygge：柔和暖色反馈 — hover 暖色高亮、按下轻微缩放、focus 暖色细描边 */
[data-interaction-model="hygge"] .btn:hover{
  background: color-mix(in srgb, var(--accent-warm, #C08552) 10%, transparent);
}
[data-interaction-model="hygge"] .btn:active{
  transform: scale(0.99);
}
[data-interaction-model="hygge"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-warm, #C08552) 65%, transparent);
  outline-offset: 2px;
}

/* neumorphic：同色浮雕反馈 — hover 外凸、按下内凹、focus 柔和高亮 */
[data-interaction-model="neumorphic"] .btn:hover{
  box-shadow:
    4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:active{
  box-shadow:
    inset 4px 4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(0, 0, 0, 0.35)),
    inset -4px -4px 8px color-mix(in srgb, var(--bg-primary, #E0E5EC) 60%, rgba(255, 255, 255, 0.8));
}
[data-interaction-model="neumorphic"] .btn:focus-visible{
  outline: 1px solid color-mix(in srgb, var(--accent-cool, #7A8BA6) 50%, transparent);
  outline-offset: 2px;
}

/* toy：玩具 3D 按压 — hover 抬升（底沿加深）、按下塌陷（下沉 + 底沿归零） */
[data-interaction-model="toy"] .btn:hover:not(:disabled){
  transform: translateY(-2px);
  box-shadow: 0 5px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:active:not(:disabled){
  transform: translateY(2px) scale(0.96);
  box-shadow: 0 1px 0 var(--toy-shadow, rgba(0, 0, 0, 0.14));
}
[data-interaction-model="toy"] .btn:focus-visible{
  outline: 2px solid color-mix(in srgb, var(--deco-primary, #14B8A6) 65%, transparent);
  outline-offset: 2px;
}

/* —— 2. 皮肤形状规则子集（各皮肤 Manifest extraCSS 快照，最后注入覆盖交互模型） —— */

/* doodle：手绘边框 — 不规则圆角 + 微旋转 + 蜡笔 2px 边框（hover 换蜡笔红/深色湖水蓝） */
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect){
  border-radius: 15px 8px 17px 7px / 8px 16px 7px 18px; /* 皮肤形状快照：手绘不规则圆角，无 token 语义，同 skins.css 豁免决策 */
  transform: rotate(-0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn:not(.btn--rect):nth-child(even of .btn){
  transform: rotate(0.35deg);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary{
  border: 2px solid rgba(43, 43, 43, 0.62);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary{
  border-color: rgba(242, 237, 227, 0.55);
}
[data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(232, 96, 76, 0.85);
}
[data-theme-mode="dark"][data-skin="xy-skin-official-doodle"] .btn--secondary:hover{
  border-color: rgba(91, 168, 201, 0.85);
}

/* island：糖果胶囊 + 3D 底沿（默认态让位 toy hover/active；次按钮奶油卡纸） */
[data-skin="xy-skin-official-island"] .btn:not(:hover):not(:active){
  border: 1px solid var(--is-ink, rgba(92, 74, 50, 0.55));
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}
[data-skin="xy-skin-official-island"] .btn:not(.btn--rect){
  border-radius: 999px;
}
[data-skin="xy-skin-official-island"] .btn--secondary:not(:hover):not(:active){
  background: var(--is-cream, rgba(255, 253, 245, 0.92));
  border-color: var(--is-ink, rgba(92, 74, 50, 0.55));
  color: var(--text-primary, #5C4A32);
  box-shadow: 0 3px 0 var(--toy-shadow, rgba(92, 74, 50, 0.18));
}

/* pixel：块状厚度 — 无描线 + 底部 3px 厚度（NES 街机按键），按压塌陷
   （皮肤自定义变量不在沙箱白名单，改引注入变量 --bg-elevated/--text-primary） */
[data-skin="xy-skin-official-pixel"] .btn{
  border: none;
  border-radius: 0;
  background: var(--bg-elevated, #FFFDF6);
  box-shadow: 0 3px 0 var(--text-primary, #1A1C2C);
  transition: none;
}
[data-skin="xy-skin-official-pixel"] .btn:active{
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--text-primary, #1A1C2C);
}

/* popart：漫画粗描边 + CMYK 三色错位叠印投影（丝网印刷注册错位，波普签名） */
[data-skin="xy-skin-official-popart"] .btn{
  border: 3px solid var(--text-primary, #1A1A1A);
  box-shadow:
    2.5px 2.5px 0 rgba(230, 57, 70, 0.5),
    -2px 2.5px 0 rgba(0, 119, 182, 0.45),
    4px 4px 0 rgba(26, 26, 26, 0.28);
}

/* red-age：油墨细线（印刷品边线） */
[data-skin="xy-skin-official-red-age"] .btn{
  border: 1px solid var(--ra-ink, rgba(31, 26, 18, 0.75));
}

/* neumorphism：无描边浮雕（外凸双阴影） */
[data-skin="xy-skin-official-neumorphism"] .btn{
  border: none;
  box-shadow:
    3px 3px 6px var(--neumo-dark, rgba(163, 177, 198, 0.55)),
    -3px -3px 6px var(--neumo-light, rgba(255, 255, 255, 0.9));
}

/* cyber-city：glitch 重影 — hover RGB 通道错位（静态 text-shadow，零动画开销） */
[data-skin="xy-skin-official-cyber-city"] .btn:hover{
  text-shadow:
    1px 0 rgba(0, 229, 255, 0.75),
    -1px 0 rgba(255, 46, 136, 0.75);
}

/* 动效偏好降级：形状钩子表的位移/旋转一律禁用（保留形状与描边） */
[data-reduce-motion="true"] .btn:hover,
[data-reduce-motion="true"] .btn:active{
  transform: none;
}

/* v5.0: 难度选择器 */
.game-host-hud-difficulty-wrap {
  display: flex;
  align-items: center;
}

.game-host-hud-difficulty-select {
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23888' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  padding-right: 1.375rem !important;
  cursor: pointer;
}

.game-host-hud-difficulty-select option {
  background: var(--bg-elevated, #1a1a1a);
  color: var(--glass-text-primary, #e8e8e8);
}


/* ============================================================
   Phase 4（EDITORIAL-LAYOUT PRD §4.1 G2）：左信息带 + 右主舞台
   ------------------------------------------------------------
   放在 css-hud.tpl 末尾是有意的：注入顺序为 HUD → CANVAS → OVERLAY →
   RESPONSIVE，同特异性下后出现者胜，故本段安全覆写上面的顶条配方。
   ============================================================ */

.game-host-body {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  flex-direction: row;
  align-items: stretch;
}

/* HUD 由「顶条」改为「左侧信息带」：竖向堆叠 */
.game-host-hud {
  flex: 0 0 208px;
  width: 208px;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  gap: var(--space-3, 0.75rem);
  padding: var(--space-4, 1rem) var(--space-3, 0.875rem);
  border-bottom: none;
  border-right: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
  overflow-y: auto;
  overscroll-behavior: contain;
}
/* 发丝线由「底缘」转为「右缘」（信息带与舞台的分界） */
.game-host-hud::after {
  left: auto;
  right: 0;
  top: var(--space-4, 1rem);
  bottom: var(--space-4, 1rem);
  width: 1px;
  height: auto;
  background: linear-gradient(
    to bottom,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}

/* 信息带内三段纵排：身份（kicker + 标题） / 分数 / 控制 */
.game-host-hud-left {
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1, 0.25rem);
  overflow: visible;
}
.game-host-hud-right {
  flex-direction: column;
  align-items: stretch;
  width: 100%;
  gap: var(--space-2, 0.5rem);
}
.game-host-hud-right > * { width: 100%; }
.game-host-hud-difficulty-wrap { width: 100%; }
.game-host-hud-difficulty-select { width: 100%; }

.game-host-hud-kicker {
  font-size: 0.5625rem;
  letter-spacing: 0.24em;
}
.game-host-hud-title {
  font-size: 1.0625rem;
  letter-spacing: 0.1em;
  line-height: 1.2;
}
.game-host-hud-score {
  margin-top: var(--space-2, 0.5rem);
  gap: 0.25rem;
}
.game-host-hud-score-value {
  font-size: 0.75rem;
}

/* 右主舞台：画布在其中等比居中，永不挤占信息带 */
.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-width: 0;
}

/* ============================================================
   Phase 4 收口（EDITORIAL §16 定版）：信息带升级「统一大标题 + 小标题分区」
   ------------------------------------------------------------
   与宿主 .zby-page-head / .zby-sec-title 同配方（自包含 fallback，
   Token 经沙箱白名单注入 computed 值）。注入序在 css-responsive 之前，
   <720 折行态的覆写见 css-responsive.tpl 末段。
   ============================================================ */

/* 信息带纵向节奏单源：分区 margin-top 走 --layout-section-gap（与宿主分区间隔同源）。
 * box-sizing 收敛为 border-box：flex-basis 208px 从此含内距（恒宽名副其实），
 * 窄窗折行态不再因 content-box 的 28px 水平内距溢出视口。 */
.game-host-hud {
  gap: 0;
  box-sizing: border-box;
}

/* 身份块 = 页头语言：mono kicker + 衬线大标题 + 标题下发丝线 */
.game-host-hud-left {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1, 0.25rem);
  width: 100%;
  min-width: 0;
  padding-bottom: var(--space-3, 0.875rem);
  position: relative;
}
/* 大标题下发丝线（宿主 .zby-page-head::after 同配方：--deco-primary 55% → 12% → 透明） */
.game-host-hud-left::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}
/* 大标题三件套：字号/字距/字族全部走布局维度 Token（与宿主内页大标题同构）。
 * 白名单注入的是宿主 root computed 值，方案切换（刊物/经典/紧凑）随广播生效。 */
.game-host-hud-title {
  font-family: var(--type-title-font, var(--font-serif-cn, var(--type-display, inherit)));
  font-size: var(--type-title, var(--layout-display, 2rem));
  font-weight: 700;
  letter-spacing: var(--tracking-title, 0.04em);
  line-height: 1.16;
  color: var(--glass-text-primary, #e8e8e8);
  /* 窄带允许自然换行（杂志标题语言），不再省略号截断 */
  white-space: normal;
  overflow: visible;
  text-overflow: clip;
  min-width: 0;
}

/* 分区容器：分区间距 = --layout-section-gap（宿主分区节奏同源，非自造间隔） */
.game-host-sec {
  display: flex;
  flex-direction: column;
  gap: var(--space-2, 0.5rem);
  margin-top: var(--layout-section-gap, var(--space-5, 1.5rem));
  min-width: 0;
}

/* 分区小标题（宿主 .zby-sec-title 同配方）：中文 12px/0.2em + EN mono 小注 + 渐细横线 */
.game-host-sec-head {
  display: flex;
  align-items: baseline;
  gap: var(--space-2, 8px);
  font-size: var(--type-scale-1, 0.75rem);
  font-weight: 650;
  letter-spacing: 0.2em;
  color: var(--glass-text-secondary, #666);
  white-space: nowrap;
}
.game-host-sec-head::after {
  content: '';
  flex: 1;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #3cb371)) 12%, transparent) 60%,
    transparent
  );
}
.game-host-sec-sub {
  font-family: var(--type-mono, ui-monospace, 'JetBrains Mono', monospace);
  font-size: calc(var(--type-scale-1, 0.75rem) * 0.71);
  font-weight: 600;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--glass-text-tertiary, #707070);
  opacity: 0.85;
}

/* 计分行归入战况分区：分区间距由 .game-host-sec 承担，行内不再带顶距 */
.game-host-hud-score {
  margin-top: 0;
  font-size: 0.8125rem;
}
/* ============================================================
   画布容器
   ============================================================ */

.game-host-canvas-wrap {
  flex: 1 1 auto;
  min-height: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  position: relative;
  overflow: hidden;
}

.game-host-canvas {
  display: block;
  max-width: 100%;
  max-height: 100%;
  /* canvas 由游戏引擎自绘背景（棋盘/Phaser backgroundColor），CSS 背景置透明防泛白 */
  background: transparent;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.06));
  border-radius: 0.5rem;
  box-shadow: var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
  outline: none;
  cursor: default;
  touch-action: none;
}

.game-host-canvas:focus-visible {
  border-color: var(--accent-cool, #4a9eff);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent-cool, #4a9eff) 25%, transparent), var(--skin-shadow-card, 0 6px 20px rgba(0, 0, 0, 0.25));
}

/* ============================================================
   暂停遮罩（由 GameHost 在 paused 状态下注入）
   ============================================================ */

.game-host-root[data-status="paused"] .game-host-canvas-wrap::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.55));
  backdrop-filter: blur(4px);
  pointer-events: none;
}

.game-host-root[data-status="paused"] .game-host-canvas-wrap::before {
  content: attr(data-paused-text);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* 遮罩底为皮肤感知玻璃（--glass-overlay-bg：浅色皮肤浅底 / 深色皮肤深底），
     文字跟随皮肤明暗取 --glass-text-primary，任意皮肤 × 明暗下恒可读 */
  color: var(--glass-text-primary, #f1f5f9);
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: 1.125rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.6));
  padding: 0.625rem 1.25rem;
  border-radius: 0.5rem;
  border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.1));
  z-index: 1;
  pointer-events: none;
}

/* ============================================================
   游戏结束 / 胜利覆盖层
   ============================================================ */

.game-host-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-4, 0.875rem);
  background: var(--glass-overlay-bg, rgba(0, 0, 0, 0.7));
  backdrop-filter: blur(6px);
  z-index: 5;
  pointer-events: auto;
}

.game-host-overlay-title {
  /* F 语言：衬线显示字体 + 页面显示档字号 + 编辑头同款字距（Wave G L2） */
  font-family: var(--type-display, var(--skin-font-display, inherit));
  font-size: calc(var(--layout-display, 2.125rem) * 0.7);
  font-weight: 700;
  color: var(--glass-text-primary, #e8e8e8);
  letter-spacing: 0.14em;
}

.game-host-overlay-title--win {
  color: var(--accent-warm, #ffb04a);
}

.game-host-overlay-title--lose {
  color: var(--danger, #ff6b8a);
}

.game-host-overlay-msg {
  font-size: 0.875rem;
  color: var(--glass-text-secondary, #888);
  text-align: center;
  max-width: 80%;
}

.game-host-overlay-actions {
  display: flex;
  gap: 0.625rem;
}

/* P4.7：.game-host-overlay-btn 系列已删除（无 JS 创建者，历史死样式）；
 * 覆盖层操作统一走 HUD 重新开始按钮（game-host-hud-btn，已基座化）。 */

/* ============================================================
   响应式（窄窗口时缩小 HUD）
   ============================================================ */

@media (max-width: 480px) {
  .game-host-hud {
    padding: 0.375rem 0.625rem;
    gap: 0.5rem;
  }
  .game-host-hud-title {
    font-size: 1.0625rem;
  }
  .game-host-hud-score {
    font-size: 0.75rem;
  }
  .game-host-hud-btn {
    font-size: 0.6875rem;
    padding: 0.3125rem 0.5rem;
  }
  .game-host-canvas-wrap {
    padding: 0.375rem;
  }
}



/* Phase 4：窄窗（<720px）整组折行 —— 信息带收为舞台上方横排，
   画布仍占主区居中。信息带靠「折」保持可见，不靠挤。 */
@media (max-width: 720px) {
  .game-host-body {
    flex-direction: column;
  }
  .game-host-hud {
    flex: 0 0 auto;
    width: 100%;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-2, 0.5rem);
    padding: var(--space-2, 0.5rem) var(--layout-row-pad-x, 0.875rem);
    border-right: none;
    border-bottom: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.08));
    overflow: visible;
  }
  .game-host-hud::after { display: none; }
  .game-host-hud-left {
    flex-direction: row;
    align-items: baseline;
    gap: var(--space-2, 0.5rem);
  }
  .game-host-hud-right {
    flex-direction: row;
    align-items: center;
    width: auto;
    gap: var(--space-2, 0.5rem);
  }
  .game-host-hud-right > * { width: auto; }
  .game-host-hud-difficulty-wrap { width: auto; }
  .game-host-hud-difficulty-select { width: auto; }
  .game-host-hud-score { margin-top: 0; font-size: 0.6875rem; }
  /* 分区折行态收为横排：小标题隐藏、内容内联（身份 | 战况 | 操作 三段一行）；
     身份块的下发丝线与底部内距同步移除（横条内无线）。 */
  .game-host-sec {
    flex-direction: row;
    align-items: center;
    margin-top: 0;
    gap: var(--space-2, 0.5rem);
    min-width: 0;
  }
  .game-host-sec-head { display: none; }
  /* 宽窗块的 width:100% / padding 在折行态复位（否则左段撑满整行、右段溢出视口） */
  .game-host-hud-left { padding-bottom: 0; width: auto; flex: 0 1 auto; min-width: 0; }
  .game-host-hud-left::after { display: none; }
  .game-host-hud { flex-wrap: wrap; }
  /* 折行态标题降档（横条内不撑高）：衬线 20px，保留层级 */
  .game-host-hud-title { font-size: 1.25rem; line-height: 1.1; }
}
/* ============================================================
   无障碍：减少动效
   ============================================================ */

@media (prefers-reduced-motion: reduce) {
  .game-host-hud-btn {
    transition: none;
  }
}
/* 动态创建元素类名锚点（CSS_CLASS_MISSING 校验 + 结构契约）
   EDITORIAL-LAYOUT Phase 4：.game-host-body 是 GameHost 模板在运行时创建的
   「左信息带 + 右主舞台」两栏容器，真实规则在模板 css-hud.tpl 内（构建期注入），
   此处仅放空规则供打包校验识别，勿删。 */
.game-host-body {}
.game-host-loading-overlay {}
.game-host-spinner {}
.game-host-error-overlay {}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'tetris-game-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  let host: TetrisHost | null = null;

  /** 挂载游戏：创建 Host 并启动（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    injectAppStyle(ctx.container);
    host = new TetrisHost({
      gameId: 'game-tetris',
      width: 420,
      height: 560,
    });
    void host.mount(ctx).catch((e: unknown) => {
      console.error('[tetris] mount failed:', e);
    });
  }

  /** 卸载游戏：清理监听 / 定时器 / DOM */
  function unmount(): void {
    if (host !== null) {
      host.unmount();
      host = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: { nameKey: 'game.tetrisName', nameFallback: 'Tetris' },
      t: createTranslator(),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__tetrisApp = {
    unmount,
  };
})();
