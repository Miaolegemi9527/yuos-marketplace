/**
 * json-beautifier — JSON 美化应用入口（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：tools/json-beautifier/index.html + src/pages/tools/json-beautifier/
 * （app.ts / JsonBeautifierController.ts / types.ts）。转包改造点（对齐 PRD §4.2 /
 * hex-color 模板）：
 *   1. i18n：宿主 5 语包 → 内嵌最小词表（tools.json* 快照），零语言包依赖
 *   2. 设置读取：宿主设置（SettingsService + bootToolSkin）→ 语言按浏览器
 *      navigator.language 就近匹配，皮肤变量由沙箱注入
 *   3. 皮肤：tokens.css 依赖 → CSS 变量 + fallback（styles.css），运行时由入口
 *      注入 <style>
 *   4. 入口签名：页面自启动 → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. 生命周期：window/document 全局 → 作用域限定挂载容器，unmount 清理全部监听
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=noop）并调用；样式同源内容以 <style> 注入挂载容器。
 */
(function () {
  'use strict';

  /* =========================================================
     1. 词表（宿主 i18n tools.json* 快照，5 语；运行时零语言包依赖）
     ========================================================= */

  interface LangBundle {
    readonly [key: string]: string;
  }

  const LANG_BUNDLES: Readonly<Record<string, LangBundle>> = {
    'zh-CN': {
      'tools.jsonBeautifierTitle': 'JSON 美化',
      'tools.jsonBeautifierDesc': '粘贴 JSON 文本，一键格式化、排序键名、压缩或高亮预览。',
      'tools.jsonIndentLabel': '缩进',
      'tools.jsonIndent2': '2 空格',
      'tools.jsonIndent4': '4 空格',
      'tools.jsonIndentTab': 'Tab',
      'tools.jsonSortLabel': '排序键',
      'tools.jsonCompactLabel': '压缩',
      'tools.format': '格式化',
      'tools.jsonInputLabel': '输入 JSON',
      'tools.jsonInputPlaceholder': '在此粘贴需要格式化的 JSON...',
      'tools.jsonOutputLabel': '格式化结果',
      'tools.jsonParseError': 'JSON 解析错误：{err}',
      'tools.jsonOn': '开启',
      'tools.jsonOff': '关闭',
      'tools.jsonDownload': '下载',
      'tools.jsonSampleName': '小语',
      'tools.jsonSampleDesc': '小语平台',
      'tools.copy': '复制',
      'tools.copyDone': '已复制',
      'tools.clearAll': '清空',
      'tools.sample': '示例',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    'zh-TW': {
      'tools.jsonBeautifierTitle': 'JSON 美化',
      'tools.jsonBeautifierDesc': '貼上 JSON 文本，一鍵格式化、排序鍵名、壓縮或高亮預覽。',
      'tools.jsonIndentLabel': '縮排',
      'tools.jsonIndent2': '2 空格',
      'tools.jsonIndent4': '4 空格',
      'tools.jsonIndentTab': 'Tab',
      'tools.jsonSortLabel': '排序鍵',
      'tools.jsonCompactLabel': '壓縮',
      'tools.format': '格式化',
      'tools.jsonInputLabel': '輸入 JSON',
      'tools.jsonInputPlaceholder': '在此貼上需要格式化的 JSON...',
      'tools.jsonOutputLabel': '格式化結果',
      'tools.jsonParseError': 'JSON 解析錯誤：{err}',
      'tools.jsonOn': '開啟',
      'tools.jsonOff': '關閉',
      'tools.jsonDownload': '下載',
      'tools.jsonSampleName': '小語',
      'tools.jsonSampleDesc': '小語平台',
      'tools.copy': '複製',
      'tools.copyDone': '已複製',
      'tools.clearAll': '清空',
      'tools.sample': '範例',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    en: {
      'tools.jsonBeautifierTitle': 'JSON Beautifier',
      'tools.jsonBeautifierDesc': 'Paste JSON to format, sort keys, minify or syntax-highlight in one click.',
      'tools.jsonIndentLabel': 'Indent',
      'tools.jsonIndent2': '2 spaces',
      'tools.jsonIndent4': '4 spaces',
      'tools.jsonIndentTab': 'Tab',
      'tools.jsonSortLabel': 'Sort keys',
      'tools.jsonCompactLabel': 'Minify',
      'tools.format': 'Format',
      'tools.jsonInputLabel': 'Input JSON',
      'tools.jsonInputPlaceholder': 'Paste JSON to format...',
      'tools.jsonOutputLabel': 'Result',
      'tools.jsonParseError': 'JSON parse error: {err}',
      'tools.jsonOn': 'On',
      'tools.jsonOff': 'Off',
      'tools.jsonDownload': 'Download',
      'tools.jsonSampleName': 'Xiaoyu',
      'tools.jsonSampleDesc': 'Xiaoyu Platform',
      'tools.copy': 'Copy',
      'tools.copyDone': 'Copied',
      'tools.clearAll': 'Clear',
      'tools.sample': 'Sample',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    ja: {
      'tools.jsonBeautifierTitle': 'JSON 整形',
      'tools.jsonBeautifierDesc': 'JSON を貼り付けて、整形・キー名ソート・圧縮・ハイライトを一発で。',
      'tools.jsonIndentLabel': 'インデント',
      'tools.jsonIndent2': '2 スペース',
      'tools.jsonIndent4': '4 スペース',
      'tools.jsonIndentTab': 'タブ',
      'tools.jsonSortLabel': 'キーソート',
      'tools.jsonCompactLabel': '圧縮',
      'tools.format': '整形',
      'tools.jsonInputLabel': 'JSON 入力',
      'tools.jsonInputPlaceholder': 'フォーマットする JSON をここに貼り付け...',
      'tools.jsonOutputLabel': '結果',
      'tools.jsonParseError': 'JSON 解析エラー：{err}',
      'tools.jsonOn': 'オン',
      'tools.jsonOff': 'オフ',
      'tools.jsonDownload': 'ダウンロード',
      'tools.jsonSampleName': '小語',
      'tools.jsonSampleDesc': '小語プラットフォーム',
      'tools.copy': 'コピー',
      'tools.copyDone': 'コピーしました',
      'tools.clearAll': 'クリア',
      'tools.sample': 'サンプル',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    ko: {
      'tools.jsonBeautifierTitle': 'JSON 정리',
      'tools.jsonBeautifierDesc': 'JSON을 붙여넣고 한 번의 클릭으로 정리, 키 정렬, 압축, 하이라이트.',
      'tools.jsonIndentLabel': '들여쓰기',
      'tools.jsonIndent2': '2칸',
      'tools.jsonIndent4': '4칸',
      'tools.jsonIndentTab': '탭',
      'tools.jsonSortLabel': '키 정렬',
      'tools.jsonCompactLabel': '압축',
      'tools.format': '정리',
      'tools.jsonInputLabel': 'JSON 입력',
      'tools.jsonInputPlaceholder': '정리할 JSON을 여기에 붙여넣기...',
      'tools.jsonOutputLabel': '결과',
      'tools.jsonParseError': 'JSON 구문 오류: {err}',
      'tools.jsonOn': '켜기',
      'tools.jsonOff': '끄기',
      'tools.jsonDownload': '다운로드',
      'tools.jsonSampleName': '샤오위',
      'tools.jsonSampleDesc': '샤오위 플랫폼',
      'tools.copy': '복사',
      'tools.copyDone': '복사됨',
      'tools.clearAll': '비우기',
      'tools.sample': '샘플',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
  };

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 语言检测（沙箱无宿主设置，按浏览器语言就近匹配） */
  function detectLang(): string {
    const lang = navigator.language || 'zh-CN';
    if (lang.startsWith('zh-TW') || lang.startsWith('zh-HK') || lang.startsWith('zh-Hant')) return 'zh-TW';
    if (lang.startsWith('zh')) return 'zh-CN';
    if (lang.startsWith('ja')) return 'ja';
    if (lang.startsWith('ko')) return 'ko';
    return 'en';
  }

  /** 创建翻译器；key 缺失时回退 key 本身（不抛错） */
  function createTranslator(lang: string): Translator {
    const bundle = LANG_BUNDLES[lang] ?? LANG_BUNDLES['zh-CN'];
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const template = (bundle !== undefined && bundle[key] !== undefined) ? (bundle[key] ?? key) : key;
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. 纯函数：JSON 处理（原 JsonBeautifierController.ts 平移，零 DOM 依赖）
     ========================================================= */

  type IndentMode = '2' | '4' | 'tab';

  interface JsonFormatOptions {
    indent: IndentMode;
    sort: boolean;
    compact: boolean;
  }

  interface JsonFormatResult {
    text: string;
    error: string | null;
  }

  /** HTML 转义（& < >） */
  function escapeHtml(str: string): string {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /** 递归排序对象键（返回新对象） */
  function sortKeys<T>(obj: T): T {
    if (Array.isArray(obj)) {
      return obj.map(sortKeys) as unknown as T;
    }
    if (obj !== null && typeof obj === 'object') {
      const sorted: Record<string, unknown> = {};
      Object.keys(obj as Record<string, unknown>)
        .sort()
        .forEach((key) => {
          sorted[key] = sortKeys((obj as Record<string, unknown>)[key]);
        });
      return sorted as unknown as T;
    }
    return obj;
  }

  /** 解析缩进模式为 JSON.stringify 的 space 参数 */
  function resolveSpace(indent: IndentMode, compact: boolean): string | number | undefined {
    if (compact) return undefined;
    if (indent === 'tab') return '\t';
    return parseInt(indent, 10);
  }

  /** 格式化 JSON 文本；成功返回 { text, error: null }，失败返回 { text: '', error: msg } */
  function formatJson(raw: string, options: JsonFormatOptions): JsonFormatResult {
    const trimmed = raw.trim();
    if (trimmed === '') {
      return { text: '', error: null };
    }

    let obj: unknown;
    try {
      obj = JSON.parse(trimmed);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { text: '', error: msg };
    }

    if (options.sort) {
      obj = sortKeys(obj);
    }

    const space = resolveSpace(options.indent, options.compact);
    const formatted = JSON.stringify(obj, null, space);
    return { text: formatted, error: null };
  }

  /** JSON 语法高亮（简易 tokenizer，返回 HTML 字符串） */
  function highlightJSON(json: string): string {
    let html = '';
    let inString = false;
    let escape = false;
    let stringBuf = '';

    for (let i = 0; i < json.length; i++) {
      const ch = json.charAt(i);
      if (inString) {
        if (escape) {
          stringBuf += ch;
          escape = false;
        } else if (ch === '\\') {
          stringBuf += ch;
          escape = true;
        } else if (ch === '"') {
          stringBuf += ch;
          inString = false;
          // 向前看，跳过空白找 :
          let j = i + 1;
          while (j < json.length && /\s/.test(json.charAt(j))) j++;
          const isKey = json.charAt(j) === ':';
          if (isKey) {
            html += '<span class="json-key">' + escapeHtml(stringBuf) + '</span>';
          } else {
            html += '<span class="json-str">' + escapeHtml(stringBuf) + '</span>';
          }
          stringBuf = '';
        } else {
          stringBuf += ch;
        }
      } else {
        if (ch === '"') {
          inString = true;
          stringBuf = ch;
        } else if (/[0-9-]/.test(ch)) {
          let num = ch;
          while (i + 1 < json.length && /[0-9.eE+-]/.test(json.charAt(i + 1))) {
            i++;
            num += json.charAt(i);
          }
          html += '<span class="json-num">' + escapeHtml(num) + '</span>';
        } else {
          const rest = json.slice(i);
          const m = rest.match(/^(true|false|null)\b/);
          if (m !== null) {
            html += '<span class="json-bool">' + m[0] + '</span>';
            i += m[0].length - 1;
          } else {
            html += escapeHtml(ch);
          }
        }
      }
    }
    return html;
  }

  /* =========================================================
     3. Controller：DOM 引用 + UI 绑定（原 JsonBeautifierController.ts
        平移，注入 Translator 替代 I18nService；dispose 移除全部监听）
     ========================================================= */

  class JsonBeautifierController {
    private readonly t: Translator;
    private state: JsonFormatOptions = { indent: '2', sort: false, compact: false };
    private lastFormatted = '';
    private offs: Array<() => void> = [];

    readonly inputJson: HTMLTextAreaElement;
    readonly indentGroup: HTMLElement;
    readonly btnSort: HTMLButtonElement;
    readonly btnCompact: HTMLButtonElement;
    readonly btnFormat: HTMLButtonElement;
    readonly btnClear: HTMLButtonElement;
    readonly btnSample: HTMLButtonElement;
    readonly btnCopy: HTMLButtonElement;
    readonly btnDownload: HTMLButtonElement;
    readonly errorMsg: HTMLElement;
    readonly outputPanel: HTMLElement;
    readonly outputCode: HTMLElement;

    constructor(t: Translator) {
      this.t = t;

      this.inputJson = JsonBeautifierController.requireTextArea('inputJson');
      this.indentGroup = JsonBeautifierController.requireEl('indentGroup');
      this.btnSort = JsonBeautifierController.requireButton('btnSort');
      this.btnCompact = JsonBeautifierController.requireButton('btnCompact');
      this.btnFormat = JsonBeautifierController.requireButton('btnFormat');
      this.btnClear = JsonBeautifierController.requireButton('btnClear');
      this.btnSample = JsonBeautifierController.requireButton('btnSample');
      this.btnCopy = JsonBeautifierController.requireButton('btnCopy');
      this.btnDownload = JsonBeautifierController.requireButton('btnDownload');
      this.errorMsg = JsonBeautifierController.requireEl('errorMsg');
      this.outputPanel = JsonBeautifierController.requireEl('outputPanel');
      this.outputCode = JsonBeautifierController.requireEl('outputCode');
    }

    private static requireEl(id: string): HTMLElement {
      const el = document.getElementById(id);
      if (el === null) throw new Error('JsonBeautifier: required element not found: ' + id);
      return el;
    }

    private static requireTextArea(id: string): HTMLTextAreaElement {
      const el = document.getElementById(id);
      if (!(el instanceof HTMLTextAreaElement)) {
        throw new Error('JsonBeautifier: required textarea not found: ' + id);
      }
      return el;
    }

    private static requireButton(id: string): HTMLButtonElement {
      const el = document.getElementById(id);
      if (!(el instanceof HTMLButtonElement)) {
        throw new Error('JsonBeautifier: required button not found: ' + id);
      }
      return el;
    }

    getState(): JsonFormatOptions {
      return { ...this.state };
    }

    getLastFormatted(): string {
      return this.lastFormatted;
    }

    setIndent(indent: IndentMode): void {
      if (indent === this.state.indent) return;
      this.state.indent = indent;
      this.indentGroup.querySelectorAll('[data-indent]').forEach((b) => {
        if (!(b instanceof HTMLElement)) return;
        b.classList.toggle('active', b.dataset.indent === indent);
      });
      this.format();
    }

    toggleSort(): void {
      this.state.sort = !this.state.sort;
      this.btnSort.dataset.active = this.state.sort ? 'true' : 'false';
      this.btnSort.textContent = this.state.sort ? this.t('tools.jsonOn') : this.t('tools.jsonOff');
      this.btnSort.classList.toggle('active', this.state.sort);
      this.format();
    }

    toggleCompact(): void {
      this.state.compact = !this.state.compact;
      this.btnCompact.dataset.active = this.state.compact ? 'true' : 'false';
      this.btnCompact.textContent = this.state.compact ? this.t('tools.jsonOn') : this.t('tools.jsonOff');
      this.btnCompact.classList.toggle('active', this.state.compact);
      this.format();
    }

    /** 执行格式化并更新 UI */
    format(): void {
      const raw = this.inputJson.value.trim();
      if (raw === '') {
        this.errorMsg.classList.remove('visible');
        this.outputPanel.style.display = 'none';
        this.lastFormatted = '';
        return;
      }

      const result = formatJson(raw, this.state);
      if (result.error !== null) {
        this.errorMsg.textContent = this.t('tools.jsonParseError', { err: result.error });
        this.errorMsg.classList.add('visible');
        this.outputPanel.style.display = 'none';
        this.lastFormatted = '';
        return;
      }

      this.lastFormatted = result.text;
      this.errorMsg.classList.remove('visible');
      this.outputCode.innerHTML = highlightJSON(result.text);
      this.outputPanel.style.display = '';
    }

    /** 清空输入与输出 */
    clear(): void {
      this.inputJson.value = '';
      this.errorMsg.classList.remove('visible');
      this.outputPanel.style.display = 'none';
      this.lastFormatted = '';
      this.inputJson.focus();
    }

    /** 填充示例并格式化 */
    fillSample(): void {
      const sample = JSON.stringify(
        {
          name: this.t('tools.jsonSampleName'),
          version: '1.0.0',
          features: ['极简', '安静', '克制'],
          description: this.t('tools.jsonSampleDesc'),
          settings: {
            theme: 'light',
            font: 'Inter',
            decoration: true,
          },
          active: true,
          count: 42,
          ratio: 3.14,
        },
        null,
        2,
      );
      this.inputJson.value = sample;
      this.format();
    }

    /** 绑定事件（监听器登记到 offs，dispose 时统一移除） */
    bindEvents(): void {
      const onIndentClick = (e: Event): void => {
        const target = e.target;
        if (!(target instanceof HTMLElement)) return;
        const btn = target.closest('[data-indent]');
        if (!(btn instanceof HTMLElement)) return;
        const indent = btn.dataset.indent;
        if (indent !== '2' && indent !== '4' && indent !== 'tab') return;
        this.setIndent(indent);
      };
      this.indentGroup.addEventListener('click', onIndentClick);
      this.offs.push(() => this.indentGroup.removeEventListener('click', onIndentClick));

      const onSort = (): void => {
        this.toggleSort();
      };
      this.btnSort.addEventListener('click', onSort);
      this.offs.push(() => this.btnSort.removeEventListener('click', onSort));

      const onCompact = (): void => {
        this.toggleCompact();
      };
      this.btnCompact.addEventListener('click', onCompact);
      this.offs.push(() => this.btnCompact.removeEventListener('click', onCompact));

      const onFormat = (): void => {
        this.format();
      };
      this.btnFormat.addEventListener('click', onFormat);
      this.offs.push(() => this.btnFormat.removeEventListener('click', onFormat));

      const onClear = (): void => {
        this.clear();
      };
      this.btnClear.addEventListener('click', onClear);
      this.offs.push(() => this.btnClear.removeEventListener('click', onClear));

      const onSample = (): void => {
        this.fillSample();
      };
      this.btnSample.addEventListener('click', onSample);
      this.offs.push(() => this.btnSample.removeEventListener('click', onSample));
    }

    /** 卸载：移除全部监听 */
    dispose(): void {
      for (const off of this.offs) off();
      this.offs = [];
    }
  }

  /* =========================================================
     4. 页脚诗句（原 app.ts POEMS 快照）
     ========================================================= */

  interface Poem {
    text: string;
    author: string;
    work: string;
  }

  const POEMS: readonly Poem[] = [
    { text: 'Simplicity is the ultimate sophistication.', author: 'Leonardo da Vinci', work: '' },
    { text: 'The details are not the details. They make the design.', author: 'Charles Eames', work: '' },
    { text: 'Less is more.', author: 'Ludwig Mies van der Rohe', work: '' },
    { text: 'Form follows function.', author: 'Louis Sullivan', work: '' },
    { text: 'Good design is as little design as possible.', author: 'Dieter Rams', work: '' },
  ];

  function renderFooterPoem(): void {
    const poem = POEMS[Math.floor(Math.random() * POEMS.length)];
    if (poem === undefined) return;
    const footerPoem = document.getElementById('footerPoem');
    const footerAuthor = document.getElementById('footerAuthor');
    if (footerPoem !== null) {
      footerPoem.textContent = '\u201C' + poem.text + '\u201D';
    }
    if (footerAuthor !== null) {
      footerAuthor.textContent = '\u2014 ' + poem.author + (poem.work !== '' ? ' \u00B7 ' + poem.work : '');
    }
  }

  /* =========================================================
     5. 复制 / 下载（原 app.ts 平移；copied 态 1800ms 回退）
     ========================================================= */

  function fallbackCopy(text: string, btn: HTMLElement, t: Translator): void {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand('copy');
      showCopied(btn, t);
    } catch (_e) {
      /* ignore */
    }
    document.body.removeChild(textarea);
  }

  function showCopied(btn: HTMLElement, t: Translator): void {
    const originalHTML = btn.innerHTML;
    btn.innerHTML =
      '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> ' +
      t('tools.copyDone');
    btn.style.color = 'var(--success)';
    btn.style.borderColor = 'var(--success)';
    setTimeout(() => {
      btn.innerHTML = originalHTML;
      btn.style.color = '';
      btn.style.borderColor = '';
    }, 1800);
  }

  function bindCopyButton(btn: HTMLButtonElement, getText: () => string, t: Translator): () => void {
    const onClick = (): void => {
      const text = getText();
      if (text === '') return;
      if (navigator.clipboard !== undefined && typeof navigator.clipboard.writeText === 'function') {
        navigator.clipboard
          .writeText(text)
          .then(() => showCopied(btn, t))
          .catch(() => fallbackCopy(text, btn, t));
      } else {
        fallbackCopy(text, btn, t);
      }
    };
    btn.addEventListener('click', onClick);
    return () => btn.removeEventListener('click', onClick);
  }

  function bindDownloadButton(btn: HTMLButtonElement, getText: () => string): () => void {
    const onClick = (): void => {
      const text = getText();
      if (text === '') return;
      const blob = new Blob([text], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'formatted.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    };
    btn.addEventListener('click', onClick);
    return () => btn.removeEventListener('click', onClick);
  }

  /* =========================================================
     6. 样式（styles.css 同源，内嵌注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * json-beautifier — JSON 美化应用样式（zby-creation 扁平包）
 *
 * 依赖的 CSS 变量全部带 fallback（var(--token, fallback)）：
 * 沙箱皮肤注入缺失时仍可渲染，不白屏。
 * 变量取值对齐宿主 design-tokens 默认（沙箱注入优先覆盖）。
 * 原 tools/json-beautifier/index.html 内联样式（含 [data-embedded] 嵌入态分支），
 * 沙箱即嵌入态，嵌入态规则已直接合并进主规则。
 */

*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  scroll-behavior: smooth;
  -webkit-font-smoothing: antialiased;
  font-family: var(--font-family, 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif);
  font-size: var(--font-size-base, 16px);
}

body {
  font-family: var(--font-family, 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif);
  font-size: 1rem;
  line-height: 1.6;
  color: var(--glass-text-primary, #1f2937);
  background: transparent;
}

::selection {
  background: var(--glass-bg-L4, rgba(255, 255, 255, 0.85));
  color: var(--glass-text-primary, #1f2937);
}

.container {
  width: 100%;
  max-width: 720px;
  margin: 0 auto;
  padding: 0 var(--space-5, 20px);
}

/* ===== 装饰光球 ===== */
.deco-orb {
  position: fixed;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 30%,
    var(--deco-primary, #3CB371) 0%,
    var(--deco-secondary, #00A86B) 50%,
    transparent 75%);
  filter: blur(80px);
  opacity: 0.18;
  pointer-events: none;
  z-index: 0;
}

/* 页头 */
.page-header {
  padding: var(--space-6, 24px) 0 var(--space-4, 16px);
}

.page-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--glass-text-primary, #1f2937);
  letter-spacing: -0.01em;
  margin-bottom: var(--space-1, 4px);
}

.page-desc {
  font-size: 0.9375rem;
  color: var(--glass-text-secondary, #4b5563);
}

/* 主区域 */
.tool-main {
  padding: var(--space-4, 16px) 0 var(--space-10, 40px);
  position: relative;
  z-index: 1;
}

/* 控制栏 */
.control-bar {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-4, 16px);
  align-items: flex-end;
  margin-bottom: var(--space-5, 20px);
}

.control-group {
  display: flex;
  flex-direction: column;
  gap: var(--space-1, 4px);
}

.control-label {
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--glass-text-tertiary, #9ca3af);
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.control-actions {
  display: flex;
  gap: var(--space-2, 8px);
  margin-left: auto;
}

/* 连体按钮组 */
.btn-group {
  display: flex;
}

.btn-group .compact-btn {
  border-radius: 0;
  margin-left: -1px;
}

.btn-group .compact-btn:first-child {
  border-radius: var(--radius-sm, 8px) 0 0 var(--radius-sm, 8px);
  margin-left: 0;
}

.btn-group .compact-btn:last-child {
  border-radius: 0 var(--radius-sm, 8px) var(--radius-sm, 8px) 0;
}

.btn-group .compact-btn.active {
  background: var(--glass-bg-L3, rgba(255, 255, 255, 0.65));
  border-color: var(--glass-divider-strong, rgba(31, 41, 55, 0.2));
  color: var(--glass-text-primary, #1f2937);
  font-weight: 500;
  z-index: 1;
}

.compact-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 32px;
  padding: 0 var(--space-3, 12px);
  font-family: var(--font-family, 'Inter', -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif);
  font-size: 0.8125rem;
  font-weight: 500;
  color: var(--glass-text-secondary, #4b5563);
  background: transparent;
  border: 1px solid var(--glass-border-L4, rgba(31, 41, 55, 0.12));
  border-radius: var(--radius-sm, 8px);
  cursor: pointer;
  transition: all 200ms ease;
  white-space: nowrap;
}

.compact-btn:hover {
  color: var(--glass-text-primary, #1f2937);
  border-color: var(--deco-primary, #3CB371);
  background: var(--glass-bg-L3-hover, rgba(255, 255, 255, 0.75));
}

.compact-btn.active {
  background: var(--glass-bg-L3, rgba(255, 255, 255, 0.65));
  border-color: var(--glass-divider-strong, rgba(31, 41, 55, 0.2));
  color: var(--glass-text-primary, #1f2937);
}

.compact-btn svg {
  flex-shrink: 0;
}

/* 按钮 */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-1, 4px);
  height: 40px;
  padding: 0 var(--space-4, 16px);
  font-family: var(--font-family, 'Inter', -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif);
  font-size: 0.9375rem;
  font-weight: 500;
  border-radius: var(--radius-md, 12px);
  cursor: pointer;
  transition: background-color 200ms ease, color 200ms ease, border-color 200ms ease;
  white-space: nowrap;
  text-decoration: none;
  border: none;
}

.btn-primary {
  color: var(--on-accent, #FFFFFF);
  background: var(--accent, #0A2540);
}

.btn-primary:hover {
  background: var(--accent-hover, #061A30);
}

.btn-secondary {
  color: var(--glass-text-primary, #1f2937);
  background: var(--glass-bg-L4, rgba(255, 255, 255, 0.85));
  border: 1px solid var(--glass-border-L4, rgba(31, 41, 55, 0.12));
}

.btn-secondary:hover {
  background: var(--glass-bg-L3-hover, rgba(255, 255, 255, 0.75));
}

.btn-sm {
  height: 32px;
  padding: 0 var(--space-3, 12px);
  font-size: 0.875rem;
}

/* 输入输出区 */
.io-panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-2, 8px);
  margin-bottom: var(--space-4, 16px);
}

.io-label {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-2, 8px);
}

.io-label-text {
  font-size: 0.8125rem;
  font-weight: 600;
  color: var(--glass-text-tertiary, #9ca3af);
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.io-label-actions {
  display: flex;
  gap: var(--space-2, 8px);
  align-items: center;
}

.io-textarea {
  width: 100%;
  min-height: 180px;
  padding: var(--space-3, 12px);
  font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
  font-size: 0.9375rem;
  line-height: 1.7;
  color: var(--glass-text-primary, #1f2937);
  background: var(--glass-bg-L4, rgba(255, 255, 255, 0.85));
  border: 1px solid var(--glass-border-L4, rgba(31, 41, 55, 0.12));
  border-radius: var(--radius-md, 12px);
  resize: vertical;
  transition: border-color 200ms ease;
}

.io-textarea:focus {
  outline: none;
  border-color: var(--deco-primary, #3CB371);
}

.io-textarea:focus-visible {
  outline: 2px solid var(--deco-primary, #3CB371);
  outline-offset: 1px;
}

.io-textarea::placeholder {
  color: var(--glass-text-tertiary, #9ca3af);
}

/* 错误提示 */
.error-msg {
  font-size: 0.8125rem;
  color: var(--danger, #dc2626);
  margin-bottom: var(--space-4, 16px);
  display: none;
}

.error-msg.visible {
  display: block;
}

/* JSON 高亮输出 */
.json-pre {
  background: var(--glass-bg-L3, rgba(255, 255, 255, 0.65));
  border: 1px solid var(--glass-border-L3, rgba(31, 41, 55, 0.12));
  border-radius: var(--radius-md, 12px);
  padding: var(--space-3, 12px);
  overflow: auto;
  max-height: 480px;
  font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
  font-size: 0.875rem;
  line-height: 1.6;
  white-space: pre;
  word-break: normal;
  tab-size: 2;
}

.json-pre code {
  font-family: inherit;
  background: none;
  padding: 0;
}

.json-key {
  color: #3B7DD8;
}

.json-str {
  color: #2D7D4E;
}

.json-num {
  color: #B85C3A;
}

.json-bool {
  color: #B8860B;
}

/* 深色模式：JSON 语法高亮提亮，确保在暗底上可读 */
[data-theme-mode="dark"] .json-key {
  color: #7BAEFF;
}

[data-theme-mode="dark"] .json-str {
  color: #6FCB95;
}

[data-theme-mode="dark"] .json-num {
  color: #E89571;
}

[data-theme-mode="dark"] .json-bool {
  color: #E8C264;
}

/* 页脚 */
footer {
  padding: 3rem 0;
  text-align: center;
  border-top: 1px solid var(--glass-divider, rgba(31, 41, 55, 0.12));
  background: var(--glass-bg-L2, rgba(255, 255, 255, 0.55));
}

.footer-credit {
  font-size: 0.75rem;
  color: var(--glass-text-tertiary, #9ca3af);
  letter-spacing: 0.04em;
}

.footer-credit strong {
  color: var(--glass-text-primary, #1f2937);
  font-weight: 600;
}

.footer-poem {
  font-style: italic;
  color: var(--glass-text-secondary, #4b5563);
  max-width: 480px;
  margin: 0.5rem auto 0;
  line-height: 1.6;
  font-size: 0.75rem;
}

.footer-author {
  font-size: 0.6875rem;
  letter-spacing: 0.06em;
  color: var(--glass-text-tertiary, #9ca3af);
  margin: 0.25rem 0 0;
}

@media (max-width: 640px) {
  .container {
    padding: 0 var(--space-4, 16px);
  }
  .io-textarea {
    min-height: 140px;
  }
  .control-bar {
    gap: var(--space-3, 12px);
  }
  .control-actions {
    width: 100%;
    margin-left: 0;
  }
  .control-actions .btn {
    flex: 1;
  }
  .json-pre {
    max-height: 320px;
  }
}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'json-beautifier-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /** 构建 UI 结构（与 index.html 的 id/class 契约一致，文案走词表） */
  function buildHtml(t: Translator): string {
    return (
      '<div id="json-beautifier-app">' +
      '<div class="deco-orb" style="width: 320px; height: 320px; top: -100px; right: -70px;"></div>' +
      '<div class="deco-orb" style="width: 260px; height: 260px; bottom: -90px; left: -50px;"></div>' +
      '<div class="container">' +
      '<header class="page-header">' +
      '<h1 class="page-title">' + t('tools.jsonBeautifierTitle') + '</h1>' +
      '<p class="page-desc">' + t('tools.jsonBeautifierDesc') + '</p>' +
      '</header>' +
      '<main class="tool-main">' +
      '<div class="control-bar">' +
      '<div class="control-group">' +
      '<span class="control-label">' + t('tools.jsonIndentLabel') + '</span>' +
      '<div class="btn-group" id="indentGroup">' +
      '<button class="compact-btn active" data-indent="2" type="button">' + t('tools.jsonIndent2') + '</button>' +
      '<button class="compact-btn" data-indent="4" type="button">' + t('tools.jsonIndent4') + '</button>' +
      '<button class="compact-btn" data-indent="tab" type="button">' + t('tools.jsonIndentTab') + '</button>' +
      '</div>' +
      '</div>' +
      '<div class="control-group">' +
      '<span class="control-label">' + t('tools.jsonSortLabel') + '</span>' +
      '<button class="compact-btn" id="btnSort" data-active="false" type="button">' + t('tools.jsonOff') + '</button>' +
      '</div>' +
      '<div class="control-group">' +
      '<span class="control-label">' + t('tools.jsonCompactLabel') + '</span>' +
      '<button class="compact-btn" id="btnCompact" data-active="false" type="button">' + t('tools.jsonOff') + '</button>' +
      '</div>' +
      '<div class="control-actions">' +
      '<button class="btn btn-primary btn-sm" id="btnFormat" type="button">' + t('tools.format') + '</button>' +
      '<button class="btn btn-secondary btn-sm" id="btnClear" type="button">' + t('tools.clearAll') + '</button>' +
      '</div>' +
      '</div>' +
      '<div class="io-panel">' +
      '<div class="io-label">' +
      '<span class="io-label-text">' + t('tools.jsonInputLabel') + '</span>' +
      '<div class="io-label-actions">' +
      '<button class="compact-btn" id="btnSample" type="button">' +
      '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M8 8h8M8 12h6M8 16h4"/></svg>' +
      '<span>' + t('tools.sample') + '</span>' +
      '</button>' +
      '</div>' +
      '</div>' +
      '<textarea class="io-textarea" id="inputJson" placeholder="' + t('tools.jsonInputPlaceholder') + '" autocomplete="off" spellcheck="false"></textarea>' +
      '</div>' +
      '<p class="error-msg" id="errorMsg"></p>' +
      '<div class="io-panel" id="outputPanel" style="display:none;">' +
      '<div class="io-label">' +
      '<span class="io-label-text">' + t('tools.jsonOutputLabel') + '</span>' +
      '<div class="io-label-actions">' +
      '<button class="compact-btn" id="btnCopy" type="button">' +
      '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>' +
      '<span>' + t('tools.copy') + '</span>' +
      '</button>' +
      '<button class="compact-btn" id="btnDownload" type="button">' +
      '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>' +
      '<span>' + t('tools.jsonDownload') + '</span>' +
      '</button>' +
      '</div>' +
      '</div>' +
      '<pre class="json-pre" id="outputPre"><code id="outputCode"></code></pre>' +
      '</div>' +
      '</main>' +
      '</div>' +
      '<footer>' +
      '<p class="footer-credit">' + t('tools.footerCredit') + '</p>' +
      '<p class="footer-poem" id="footerPoem"></p>' +
      '<p class="footer-author" id="footerAuthor"></p>' +
      '</footer>' +
      '</div>'
    );
  }

  /* =========================================================
     7. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: unknown;
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
  }

  interface MountedState {
    readonly ctrl: JsonBeautifierController;
    readonly offKeydown: () => void;
    readonly offCopy: () => void;
    readonly offDownload: () => void;
  }

  let mounted: MountedState | null = null;

  /** 挂载应用：渲染 UI 到 ctx.container 并绑定交互（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (mounted !== null) unmount();
    const container = ctx.container;
    const t = ctx.t;
    injectAppStyle(container);
    container.innerHTML = buildHtml(t);

    const ctrl = new JsonBeautifierController(t);
    ctrl.bindEvents();
    const offCopy = bindCopyButton(ctrl.btnCopy, () => ctrl.getLastFormatted(), t);
    const offDownload = bindDownloadButton(ctrl.btnDownload, () => ctrl.getLastFormatted());
    renderFooterPoem();

    /* 快捷键 Ctrl/Cmd+Enter 格式化（监听登记到 offKeydown，unmount 时移除） */
    const onKeydown = (e: KeyboardEvent): void => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        ctrl.format();
      }
    };
    document.addEventListener('keydown', onKeydown);

    mounted = {
      ctrl,
      offKeydown: () => document.removeEventListener('keydown', onKeydown),
      offCopy,
      offDownload,
    };
  }

  /** 卸载应用：清理监听与挂载内容 */
  function unmount(): void {
    if (mounted !== null) {
      mounted.ctrl.dispose();
      mounted.offKeydown();
      mounted.offCopy();
      mounted.offDownload();
      mounted = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: null,
      t: createTranslator(detectLang()),
      onThemeChange: () => () => undefined,
    };
    try {
      mount(ctx);
    } catch (e) {
      console.error('[json-beautifier] 挂载失败：', e);
      root.innerHTML = '<p style="padding: 24px; color: #dc2626;">应用挂载失败</p>';
    }
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__jsonBeautifierApp = {
    unmount,
  };
})();
