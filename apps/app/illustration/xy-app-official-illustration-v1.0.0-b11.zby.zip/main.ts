/**
 * illustration — 手绘配图（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：home/illustration-view.html（单体 1280 行）+ src/pages/illustration/app.ts。
 * 转包改造点（对齐 PRD §7.3 Step 2.4 C 级评审）：
 *   1. 页面内嵌：样式（styles.css 同源）+ 页面模板（原 body）+ 业务逻辑三段内联，
 *      沙箱 classic script 无模块系统（原 app.ts 设置服务不内嵌——皮肤变量由沙箱
 *      :root 静态注入，voiceGuide 由宿主 WindowManager 按 manifest 声明注入）
 *   2. 源参数协议：宿主 URL query → WindowManager.launch(data) → 沙箱
 *      window.__SANDBOX_DATA__（宿主 setIllustrationSource 模块桥已退役）
 *   3. 保存配图宿主代理：沙箱 opaque origin 下 html2canvas 不可执行，改由
 *      宿主 MultiFileSandbox 拦截 captureElementToPng 同源渲染 + 截图
 *   4. confirm 两段式：沙箱无 allow-modals，confirm() 静默失败
 *   5. 嵌入态模拟：mount 时给文档根加 data-embedded（透明玻璃 + 隐藏返回链接）
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（同 tank）：MultiFileSandbox 以 classic <script> 执行 Sucrase
 * 编译后的入口代码，顶层 export/import 会触发语法错误并连累同块注入全部失效；
 * 沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用 IIFE 自启动：
 * 内部实现 mount()/unmount() 等价契约，由 boot() 构造 AppMountContext
 * （container=#sandbox-root、api=window.ZbyAPI、manifest={nameKey,nameFallback}）
 * 并调用；样式同源内容以 <style> 注入挂载容器文档。
 */
(function () {
  'use strict';

  /* =========================================================
     1. 样式内嵌（styles.css 同源 + 缺失变量补充块；注入挂载容器文档）
     ========================================================= */

  const APP_CSS: string = `/**
 * 手绘配图（zby-creation 扁平包）
 *
 * 源：home/illustration-view.html <style> 平移（2026-08-12 C 级评审转包）。
 * 依赖的皮肤变量由沙箱运行时注入（--deco-* / --glass-* / --font-family 等），
 * 缺失变量由文末补充块兜底：沙箱内不白屏、玻璃样式可用。
 * 嵌入态规则（[data-embedded]）由 main.ts mount 时设置 data-embedded 触发。
 */

    /* ===== 基础 ===== */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; -webkit-font-smoothing: antialiased; font-size: var(--font-size-base, 16px); }
    body {
      font-family: var(--font-family);
      font-size: 1rem;
      line-height: 1.6;
      color: var(--glass-text-primary);
      /* v3.0：独立访问时使用 skin-aware 实底；嵌入态透明，让 WindowFrame 玻璃透显 */
      background: var(--surface-solid-primary);
      overflow-x: hidden;
    }
    [data-embedded] body {
      background: transparent;
    }
    ::selection { background: var(--glass-bg-L4); color: var(--glass-text-primary); }

    /* ===== 顶部导航栏 ===== */
    .top-bar {
      position: sticky;
      top: 0;
      z-index: 50;
      /* 独立访问：使用统一玻璃底；嵌入态：透明，让 WindowFrame 玻璃透显 */
      background: var(--bg-glass);
      backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
      -webkit-backdrop-filter: blur(var(--skin-blur-l1, 24px)) saturate(var(--skin-saturate, 1.6));
      border-bottom: 1px solid var(--glass-divider);
    }
    [data-embedded] .top-bar {
      /* 嵌入态：隐藏顶部导航（WindowFrame 标题栏已含应用名），避免 71px 实高与
       calc(100vh - 60px) 布局假设错位导致底部内容被裁 / 滚动时面板顶部被遮挡 */
      display: none;
    }
    [data-embedded] .top-bar-inner {
      display: none;
    }
    .top-bar-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      /* 左流收口（EDITORIAL 定版）：去居中 max-width，独立访问态与内容同左缘 */
      padding: 0.75rem 3rem;
    }
    .top-bar-left {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    /* 嵌入态隐藏返回主页链接（用浮窗关闭按钮代替） */
    [data-embedded] .back-link { display: none; }
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 0.375rem;
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--glass-text-secondary);
      text-decoration: none;
      padding: 0.375rem 0.75rem;
      border-radius: var(--radius-md);
      transition: background 200ms ease, color 200ms ease;
    }
    .back-link:hover {
      background: var(--glass-bg-L4);
      color: var(--glass-text-primary);
    }
    /* ===== 编辑台页头（EDITORIAL 定版 §16，同批修复 §16.2 只落生成物未进运行时的漂移） =====
       标题块已从 top-bar（嵌入态隐藏）迁入内容面板：kicker + 衬线大标题 + 发丝线 + 幽灵大字，
       与宿主 .zby-page-head / [data-ghost] 同配方（Token 带沙箱 fallback）。 */
    .page-header {
      position: relative;
      padding: 0 calc(var(--layout-display, 2rem) * 4.5 + var(--space-5, 24px)) 1.25rem 0;
      margin-bottom: 1.75rem;
    }
    .page-header::after {
      content: '';
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      height: 1px;
      background: linear-gradient(
        to right,
        color-mix(in srgb, var(--deco-primary, var(--accent)) 55%, transparent),
        color-mix(in srgb, var(--deco-primary, var(--accent)) 12%, transparent) 60%,
        transparent
      );
    }
    .page-header[data-ghost]::before {
      content: attr(data-ghost);
      position: absolute;
      top: 0;
      right: 0;
      font-family: var(--type-title-font, var(--type-display, inherit));
      font-size: calc(var(--layout-display, 2rem) * 4.5);
      font-weight: 700;
      line-height: 1;
      color: transparent;
      -webkit-text-stroke: 1px color-mix(
        in srgb,
        var(--deco-primary, #3CB371) 34%,
        var(--glass-divider, rgba(31, 41, 55, 0.12)) 66%
      );
      opacity: 0.5;
      pointer-events: none;
      user-select: none;
    }
    .crate-kicker {
      font-family: var(--type-mono, ui-monospace, 'JetBrains Mono', monospace);
      font-size: calc(var(--type-scale-1, 12px) * 0.79);
      font-weight: 700;
      letter-spacing: 0.32em;
      color: var(--deco-primary, var(--accent));
      margin-bottom: var(--space-1, 4px);
    }
    .page-title {
      /* 版式契约：字号/字距/字族走布局维度 Token（与宿主内页大标题同构） */
      font-family: var(--type-title-font, var(--type-display, inherit));
      font-size: var(--type-title, var(--layout-display, 2rem));
      font-weight: 700;
      letter-spacing: var(--tracking-title, 0.04em);
      line-height: 1.16;
      color: var(--glass-text-primary);
      margin-bottom: var(--space-1, 4px);
    }
    .page-subtitle {
      font-size: 0.9375rem;
      color: var(--glass-text-secondary);
      font-weight: 400;
    }
    /* EN mono 小注（固定英文装饰标签，aria-hidden，与宿主 .zby-sec-sub 同配方） */
    .crate-sec-sub {
      font-family: var(--type-mono, ui-monospace, 'JetBrains Mono', monospace);
      font-size: calc(var(--type-scale-1, 12px) * 0.71);
      font-weight: 600;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: var(--glass-text-tertiary);
      opacity: 0.85;
    }
    .top-bar-actions {
      display: flex;
      gap: 0.5rem;
      align-items: center;
    }
                            /* ===== 主布局：左步骤 + 右配图 ===== */
    .illustration-layout {
      display: grid;
      grid-template-columns: 280px 1fr;
      /* 左流收口：铺满窗口（去居中 max-width），与宿主应用视图同构图 */
      min-height: calc(100vh - 60px);
    }

    /* ===== 左侧步骤面板 ===== */
    .steps-panel {
      border-right: 1px solid var(--glass-divider);
      background: var(--glass-bg-L3);
      padding: 2rem 1.5rem;
      overflow-y: auto;
      position: sticky;
      top: 60px;
      height: calc(100vh - 60px);
    }
    [data-embedded] .steps-panel {
      /* 嵌入态：透明底 + 轻玻璃边框，让 WindowFrame 玻璃透显；
       两栏独立滚动：布局容器固定视口高，面板占满左栏（height:100%），
       内部滚动承接所有步骤，滚动到底全部可见（不再 sticky+100vh 裁剪底部） */
      background: transparent;
      position: static;
      top: auto;
      height: 100%;
      min-height: 0;
    }
    [data-embedded] .illustration-layout {
      /* 嵌入态：固定视口高，文档不滚动，左右两栏各自内部滚动互不干扰 */
      height: 100vh;
      min-height: 100vh;
    }
    [data-embedded] .content-panel {
      /* 嵌入态：右栏占满容器独立滚动（overflow-y:auto 继承基础样式） */
      height: 100%;
      min-height: 0;
    }
    .steps-panel-title {
      display: flex;
      align-items: baseline;
      gap: 0.5rem;
      font-size: var(--type-scale-1, 0.75rem);
      font-weight: 650;
      color: var(--glass-text-secondary);
      letter-spacing: 0.2em;
      margin-bottom: 1.25rem;
      white-space: nowrap;
    }
    .steps-panel-title::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(
        to right,
        color-mix(in srgb, var(--deco-primary, var(--accent)) 55%, transparent),
        color-mix(in srgb, var(--deco-primary, var(--accent)) 12%, transparent) 60%,
        transparent
      );
    }
    .step-list {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }
    .step-item {
      display: flex;
      align-items: flex-start;
      gap: 0.875rem;
      padding: 0.75rem 0.875rem;
      border-radius: var(--radius-md);
      cursor: pointer;
      transition: background 200ms ease;
      border: none;
      background: transparent;
      width: 100%;
      text-align: left;
      font-family: inherit;
    }
    .step-item:hover {
      background: var(--glass-bg-L4-hover);
    }
    .step-item.active {
      background: var(--glass-bg-L4);
      box-shadow: var(--skin-shadow-card, 0 1px 3px rgba(0,0,0,0.04));
    }
    .step-number {
      font-size: 0.875rem;
      font-weight: 700;
      color: var(--glass-text-tertiary);
      min-width: 28px;
      line-height: 1.4;
    }
    .step-item.active .step-number {
      color: var(--deco-text, var(--accent));
    }
    .step-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .step-name {
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--glass-text-secondary);
      line-height: 1.4;
    }
    .step-item.active .step-name {
      color: var(--glass-text-primary);
      font-weight: 600;
    }
    .step-desc {
      font-size: 0.75rem;
      color: var(--glass-text-tertiary);
      line-height: 1.5;
      display: none;
    }
    .step-item.active .step-desc {
      display: block;
    }

    /* ===== 右侧内容区 ===== */
    .content-panel {
      padding: 2.5rem 3rem;
      overflow-y: auto;
    }
    .content-panel-inner {
      /* 左流收口：内容左对齐（可读栏宽保留 max-width，不再水平居中） */
      max-width: 800px;
    }

    /* 信息卡片 */
    .info-card {
      background: var(--glass-bg-L3);
      border: 1px solid var(--glass-border-L3);
      border-radius: var(--radius-md);
      padding: 1.5rem;
      margin-bottom: 2rem;
    }
    [data-embedded] .info-card {
      background: var(--surface-card);
      border-color: var(--surface-card-border);
    }
    .info-card-title {
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--glass-text-tertiary);
      letter-spacing: 0.06em;
      text-transform: uppercase;
      margin-bottom: 0.75rem;
    }
    .info-card-meta {
      display: flex;
      gap: 1rem;
      margin-top: 0.75rem;
      font-size: 0.75rem;
      color: var(--glass-text-tertiary);
      /* 与输入框内容文字左对齐（输入框 padding-left: 0.625rem） */
      margin-left: 0.625rem;
    }
    /* 可编辑字段 */
    .info-card-field {
      margin-top: 0.75rem;
    }
    /* 首字段（标题）无上间距：去掉「源内容」标题后顶部 1.5rem padding
       与底部 1.5rem padding 视觉对称（2026-08-19） */
    .info-card-field:first-child {
      margin-top: 0;
    }
    .info-card-field-label {
      display: block;
      font-size: 0.6875rem;
      font-weight: 600;
      color: var(--glass-text-tertiary);
      letter-spacing: 0.04em;
      margin-bottom: 0.375rem;
      /* 与输入框内容文字左对齐（输入框 padding-left: 0.625rem） */
      margin-left: 0.625rem;
    }
    .info-card-text,
    .info-card-summary {
      font-size: 0.9375rem;
      color: var(--glass-text-primary);
      line-height: 1.7;
      padding: 0.5rem 0.625rem;
      border-radius: var(--radius-sm, 6px);
      border: 1px solid var(--glass-border-L4);
      background: var(--glass-bg-L4);
      transition: border-color 200ms ease, box-shadow 200ms ease, background 200ms ease;
      outline: none;
      word-break: break-word;
      white-space: pre-wrap;
    }
    .info-card-summary {
      font-size: 0.875rem;
      color: var(--glass-text-secondary);
      min-height: 3.5rem;
    }
    .info-card-text:focus,
    .info-card-summary:focus {
      border-color: var(--accent);
      background: var(--glass-bg-L4-focus);
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 25%, transparent);
    }
    [contenteditable][data-placeholder]:empty::before {
      content: attr(data-placeholder);
      color: var(--glass-text-tertiary);
      pointer-events: none;
      opacity: 0.8;
    }

    /* ===== 步骤内容 ===== */
    .step-content {
      display: none;
    }
    .step-content.active {
      display: block;
      animation: fadeIn 300ms ease;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* 步骤说明区 */
    .step-detail {
      margin-bottom: 2rem;
    }
    .step-detail h2 {
      display: flex;
      align-items: baseline;
      gap: 0.5rem;
      font-size: var(--type-scale-1, 0.75rem);
      font-weight: 650;
      letter-spacing: 0.2em;
      color: var(--glass-text-secondary);
      margin-bottom: 1rem;
    }
    .step-detail h2::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(
        to right,
        color-mix(in srgb, var(--deco-primary, var(--accent)) 55%, transparent),
        color-mix(in srgb, var(--deco-primary, var(--accent)) 12%, transparent) 60%,
        transparent
      );
    }
    .step-detail p {
      font-size: 0.9375rem;
      color: var(--glass-text-secondary);
      line-height: 1.7;
      margin-bottom: 1rem;
    }
    .step-detail ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .step-detail ul li {
      position: relative;
      padding-left: 1.25rem;
      font-size: 0.9375rem;
      color: var(--glass-text-secondary);
      line-height: 1.8;
      margin-bottom: 0.25rem;
    }
    .step-detail ul li::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0.7rem;
      width: 5px;
      height: 5px;
      border-radius: 50%;
      background: var(--deco-primary, var(--accent));
    }
    .step-detail .tip-box {
      background: var(--glass-bg-L3);
      border: 1px solid var(--glass-border-L3);
      border-radius: var(--radius-md);
      padding: 1rem 1.25rem;
      margin-top: 1rem;
      font-size: 0.875rem;
      color: var(--glass-text-secondary);
      line-height: 1.7;
    }
    [data-embedded] .step-detail .tip-box {
      background: var(--surface-card);
      border-color: var(--surface-card-border);
    }
    .step-detail .tip-box strong {
      color: var(--glass-text-primary);
      font-weight: 600;
    }

    /* ===== 配图上传与展示 ===== */
    .gallery-section {
      margin-top: 2rem;
    }
    .gallery-header {
      display: flex;
      align-items: baseline;
      gap: 0.5rem;
      margin-bottom: 1rem;
    }
    .gallery-title {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: baseline;
      gap: 0.5rem;
      font-size: var(--type-scale-1, 0.75rem);
      font-weight: 650;
      letter-spacing: 0.2em;
      color: var(--glass-text-secondary);
      white-space: nowrap;
    }
    .gallery-title::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(
        to right,
        color-mix(in srgb, var(--deco-primary, var(--accent)) 55%, transparent),
        color-mix(in srgb, var(--deco-primary, var(--accent)) 12%, transparent) 60%,
        transparent
      );
    }
    .gallery-count {
      font-size: 0.75rem;
      color: var(--glass-text-tertiary);
      font-weight: 400;
    }

    /* 上传区 */
    .upload-zone {
      border: 2px dashed var(--glass-divider);
      border-radius: var(--radius-md);
      padding: 2rem;
      text-align: center;
      cursor: pointer;
      transition: border-color 200ms ease, background 200ms ease;
      background: var(--glass-bg-L3);
      margin-top: 1.5rem;
    }
    .upload-zone:hover {
      border-color: var(--accent);
      background: var(--glass-bg-L3-hover);
    }
    .upload-zone.drag-over {
      border-color: var(--accent);
      background: color-mix(in srgb, var(--accent) 8%, transparent);
    }
    .upload-zone-icon {
      width: 40px;
      height: 40px;
      margin: 0 auto 0.75rem;
      color: var(--glass-text-tertiary);
    }
    .upload-zone-text {
      font-size: 0.875rem;
      color: var(--glass-text-secondary);
      margin-bottom: 0.25rem;
    }
    .upload-zone-hint {
      font-size: 0.75rem;
      color: var(--glass-text-tertiary);
    }

    /* 图片纵向列表 */
    .gallery-list {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }
    .gallery-item {
      position: relative;
      background: var(--surface-card);
      border: 1px solid var(--surface-card-border);
      border-radius: var(--radius-md);
      overflow: hidden;
      transition: box-shadow 200ms ease, border-color 200ms ease;
    }
    .gallery-item:hover {
      box-shadow: var(--skin-shadow-card, 0 4px 12px rgba(0,0,0,0.06));
      border-color: var(--glass-divider-strong);
    }
    .gallery-item img {
      width: 100%;
      height: auto;
      display: block;
      object-fit: contain;
      max-height: 500px;
    }
    .gallery-item-info {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.625rem 1rem;
      background: var(--glass-bg-L4);
      border-top: 1px solid var(--glass-divider);
    }
    .gallery-item-name {
      font-size: 0.8125rem;
      color: var(--glass-text-secondary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 60%;
    }
    .gallery-item-actions {
      display: flex;
      gap: 0.5rem;
    }
            /* 空状态 */
    .gallery-empty {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 3rem 2rem;
      color: var(--glass-text-tertiary);
      gap: 0.5rem;
    }
    .gallery-empty svg {
      opacity: 0.4;
      margin-bottom: 0.5rem;
    }
    .gallery-empty p {
      font-size: 0.875rem;
    }

    /* 保存按钮区域 */
    .save-action {
      margin-top: 2rem;
      padding-top: 1.5rem;
      border-top: 1px solid var(--glass-divider);
      display: flex;
      justify-content: flex-end;
    }

    /* ===== 装饰层（与 home 主页一致） ===== */
    .deco-orb {
      position: absolute;
      border-radius: 50%;
      background: radial-gradient(circle at 30% 30%,
        var(--deco-primary) 0%,
        var(--deco-secondary) 50%,
        transparent 75%);
      filter: blur(70px);
      opacity: 0.28;
      pointer-events: none;
      user-select: none;
    }
    [data-embedded] .deco-orb {
      opacity: 0.18;
    }
    @media (prefers-contrast: more) {
      .deco-orb { display: none; }
    }

    /* ===== 响应式 ===== */
    @media (max-width: 1023px) {
      .illustration-layout {
        grid-template-columns: 240px 1fr;
      }
      .content-panel {
        padding: 1.5rem 2rem;
      }
    }
    @media (max-width: 767px) {
      .illustration-layout {
        grid-template-columns: 1fr;
      }
      .steps-panel {
        position: static;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--glass-divider);
        padding: 1rem;
      }
      .step-list {
        flex-direction: row;
        overflow-x: auto;
        gap: 0.5rem;
      }
      .step-item {
        min-width: 120px;
        flex-shrink: 0;
      }
      .step-desc {
        display: none !important;
      }
      .content-panel {
        padding: 1.5rem;
      }
      .top-bar-inner {
        padding: 0.75rem 1rem;
      }
      .page-subtitle {
        display: none;
      }
      /* 嵌入态单列：恢复文档流滚动（height:100% 会溢出固定视口高） */
      [data-embedded] .illustration-layout { height: auto; }
      [data-embedded] .steps-panel { height: auto; }
      [data-embedded] .content-panel { height: auto; }
    }

    /* ========================================================= */

/* ── CSS 变量缺失补充块 ─────────────────────────────────────────
   沙箱注入的皮肤变量（SANDBOX_SKIN_VAR_NAMES）不含下列变量，此处补
   light 默认值（对齐宿主 tokens.css；与注入变量零交集，不冲突）。
   皮肤注入优先：宿主切换主题时这些变量由沙箱 :root 覆盖。 */
:root {
  --fg-on-accent: var(--on-accent, #FFFFFF);
  --glass-border-L4: 1px solid rgba(15, 25, 45, 0.08);
  --glass-bg-L4-focus: linear-gradient(180deg, rgba(255, 255, 255, 0.96), rgba(255, 255, 255, 0.90));
}

/* 导出视图（保存图片用，仅出现在宿主渲染序列化中）：应用实底背景 + 与内容面板
   一致的左右留白（1.5rem 对齐信息卡内容缩进），保存图不贴边、含背景色、无滚动条 */
.export-area {
  background: var(--surface-solid-primary, #F6F7FA);
  padding: 2rem 1.5rem;
}
/* ── P4.4 ui-kit btn 片段（assets/ui-kit/btn.css 内嵌快照，选择器扩列桥接既有类名） ── */
/* ui-kit/btn.css — 层 C 按钮片段（生成时内嵌进 zip，shadcn 式快照）
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：主/次/危险/裸 四变体 + 降级分支。
 * 引用规则：var(--x, fallback) 强制；token 名见 assets/tokens.json。 */

.btn, .copy-btn, .compact-btn, .mode-btn, .btn-icon-sm{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .copy-btn:focus-visible, .compact-btn:focus-visible, .mode-btn:focus-visible, .btn-icon-sm:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .copy-btn:disabled, .compact-btn:disabled, .mode-btn:disabled, .btn-icon-sm:disabled,
.btn[disabled], .copy-btn[disabled], .compact-btn[disabled], .mode-btn[disabled], .btn-icon-sm[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 主按钮：装饰色底 + 亮度自适应文字（对比度铁律） */
.btn--primary{
  background: var(--deco-primary, #3CB371);
  color: var(--fg-on-accent, #FFFFFF);
  border-color: var(--deco-primary, #3CB371);
}
.btn--primary:hover:not(:disabled){
  transform: translateY(var(--skin-motion-travel-hover, -1px));
  opacity: 0.92;
}
.btn--primary:active:not(:disabled){
  transform: scale(var(--skin-motion-travel-press, 0.98));
}

/* 次按钮：卡片玻璃底 */
.btn--secondary, .copy-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .copy-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 危险按钮：危险色文字 + 淡化边框 */
.btn--danger {
  color: var(--danger, #B23A48);
  border-color: color-mix(in srgb, var(--danger, #B23A48) 35%, transparent);
}
.btn--danger:hover:not(:disabled) {
  border-color: color-mix(in srgb, var(--danger, #B23A48) 60%, transparent);
}

/* 裸按钮：无底无边框，hover 弱化底 */
.btn--bare, .mode-btn, .btn-icon-sm{
  color: var(--glass-text-secondary, #666666);
}
.btn--bare:hover:not(:disabled), .mode-btn:hover:not(:disabled), .btn-icon-sm:hover:not(:disabled){
  background: var(--surface-hover, rgba(0, 0, 0, 0.04));
  color: var(--glass-text-primary, #1A1A1A);
}

/* 尺寸变体 */
.btn--sm, .compact-btn, .copy-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}
.btn--lg {
  padding: 0.75rem 1.375rem;
  font-size: var(--skin-type-scale-3, 16px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .copy-btn, [data-reduce-motion="true"] .compact-btn, [data-reduce-motion="true"] .mode-btn, [data-reduce-motion="true"] .btn-icon-sm{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}
[data-reduce-motion="true"] .btn--primary:hover:not(:disabled),
[data-reduce-motion="true"] .btn--primary:active:not(:disabled){
  transform: none;
}


/* ── P4.4 ui-kit toast 片段（assets/ui-kit/toast.css 内嵌快照，无宿主 API 时兜底） ── */
/* ui-kit/toast.css — 层 C 吐司片段（生成时内嵌进 zip，shadcn 式快照）
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback）。
 * 定位：应用内私有吐司兜底（离线/无宿主 API 时）；宿主环境首选 ZbyAPI.toast.show。
 * 用法：JS 动态创建 <div class="zby-toast zby-toast--info">消息</div> 追加到挂载根。 */

.zby-toast {
  position: fixed;
  left: 50%;
  bottom: var(--space-6, 2rem);
  transform: translateX(-50%);
  z-index: 9999;
  display: flex;
  align-items: center;
  gap: var(--space-2, 0.5rem);
  max-width: min(90vw, 420px);
  padding: 0.625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-family: var(--skin-font-body, inherit);
  line-height: var(--skin-line-height, 1.4);
  color: var(--glass-text-primary, #1A1A1A);
  background: var(--glass-bg-L3, rgba(255, 255, 255, 0.4));
  border: var(--glass-border-L3, 1px solid rgba(15, 25, 45, 0.06));
  border-radius: var(--radius-md, 8px);
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
  backdrop-filter: blur(var(--skin-blur-l1, 24px));
  pointer-events: none;
  animation: zby-toast-in 200ms var(--skin-motion-ease-snap, ease);
}

@keyframes zby-toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, var(--space-3, 0.75rem));
  }
  to {
    opacity: 1;
    transform: translate(-50%, 0);
  }
}

/* 状态变体：左侧状态条 */
.zby-toast--success {
  border-color: color-mix(in srgb, var(--success, #2D7D4E) 45%, transparent);
  color: var(--success, #2D7D4E);
}
.zby-toast--error {
  border-color: color-mix(in srgb, var(--danger, #B23A48) 45%, transparent);
  color: var(--danger, #B23A48);
}
.zby-toast--warning {
  border-color: color-mix(in srgb, var(--warning, #8B6914) 45%, transparent);
  color: var(--warning, #8B6914);
}

/* 动效偏好降级：无入场动画 */
[data-reduce-motion="true"] .zby-toast {
  animation: none;
}
`;

  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'illustration-app-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /* =========================================================
     2. 页面模板（原 home/illustration-view.html body，挂载时注入）
     ========================================================= */

  const PAGE_HTML: string = `
  <!-- 装饰光球（固定在视口，最底层） -->
  <div class="deco-orb" style="position: fixed; width: 320px; height: 320px; top: -100px; right: -80px; opacity: 0.28; filter: blur(100px); z-index: 0;" aria-hidden="true"></div>

  <!-- 顶部导航 -->
  <header class="top-bar">
    <div class="top-bar-inner">
      <div class="top-bar-left">
        <a href="index.html" class="back-link">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
          返回主页
        </a>
      </div>
      <div class="top-bar-actions">
        <button class="btn btn--secondary" id="btnCopyPrompt" type="button">复制 Prompt</button>
        <button class="btn btn--primary" id="btnGenerate" type="button">生成配图</button>
      </div>
    </div>
  </header>
  <div class="illustration-layout">
    <!-- 左侧步骤 -->
    <aside class="steps-panel">
      <div class="steps-panel-title">生成步骤<span class="crate-sec-sub" aria-hidden="true">STEPS</span></div>
      <nav class="step-list" id="stepList">
        <button class="step-item active" data-step="title">
          <span class="step-number"></span>
          <span class="step-text">
            <span class="step-name">标题</span>
            <span class="step-desc">源内容与配图预览</span>
          </span>
        </button>
        <button class="step-item" data-step="0">
          <span class="step-number">01</span>
          <span class="step-text">
            <span class="step-name">理解内容</span>
            <span class="step-desc">分析文章核心观点与认知锚点</span>
          </span>
        </button>
        <button class="step-item" data-step="1">
          <span class="step-number">02</span>
          <span class="step-text">
            <span class="step-name">提取结构</span>
            <span class="step-desc">识别流程、对比、隐喻等结构</span>
          </span>
        </button>
        <button class="step-item" data-step="2">
          <span class="step-number">03</span>
          <span class="step-text">
            <span class="step-name">选择视角</span>
            <span class="step-desc">为每张图确定一个核心动作</span>
          </span>
        </button>
        <button class="step-item" data-step="3">
          <span class="step-number">04</span>
          <span class="step-text">
            <span class="step-name">设计构图</span>
            <span class="step-desc">安排留白、元素、批注位置</span>
          </span>
        </button>
        <button class="step-item" data-step="4">
          <span class="step-number">05</span>
          <span class="step-text">
            <span class="step-name">生成配图</span>
            <span class="step-desc">输出 16:9 白底手绘插图</span>
          </span>
        </button>
        <button class="step-item" data-step="5">
          <span class="step-number">06</span>
          <span class="step-text">
            <span class="step-name">检查迭代</span>
            <span class="step-desc">QA 检查：留白、错字、风格</span>
          </span>
        </button>
      </nav>
    </aside>

    <!-- 右侧内容 -->
    <main class="content-panel">
      <div class="content-panel-inner">

        <!-- 编辑台页头（EDITORIAL 定版 §16：kicker + 衬线大标题 + 发丝线 + 幽灵大字）。
             top-bar 在嵌入态整体隐藏（WindowFrame 标题栏承载应用名），本页头是应用窗内
             唯一标题载体（先例 = 音节跳动「大标题入右栏」，用户 §17 定版）；幽灵字「画」。 -->
        <header class="page-header" data-ghost="画">
          <div class="crate-kicker" aria-hidden="true">TOOLS · ILLUSTRATION</div>
          <div class="page-title">手绘配图生成</div>
          <div class="page-subtitle" id="sourceSubtitle">为内容生成极简手绘风格配图</div>
        </header>

        <!-- ============ 步骤：标题（源内容 + 配图预览） ============ -->
        <div class="step-content active" data-step-content="title">
          <!-- 待捕获区域：源内容 + 配图（不含上传按钮） -->
          <div id="captureArea">
            <!-- 源内容信息卡（无标题标签；传值打开时按有无值显隐字段） -->
            <div class="info-card" id="sourceInfoCard">
              <div class="info-card-field" id="sourceTitleField">
                <div class="info-card-text" id="sourceTitle" contenteditable="true" data-placeholder="请输入标题…"></div>
              </div>
              <div class="info-card-field" id="sourceSummaryField">
                <label class="info-card-field-label">摘要</label>
                <div class="info-card-summary" id="sourceSummary" contenteditable="true" data-placeholder="请输入摘要，用于生成配图 Prompt…"></div>
              </div>
              <div class="info-card-meta" id="sourceMeta"></div>
            </div>

            <!-- 配图画廊 -->
            <div class="gallery-section">
              <div class="gallery-header">
                <span class="gallery-title">配图预览<span class="crate-sec-sub" aria-hidden="true">PREVIEW</span></span>
                <span class="gallery-count" id="galleryCount">0 张配图</span>
              </div>

              <!-- 图片纵向列表 -->
              <div class="gallery-list" id="galleryList">
                <div class="gallery-empty" id="galleryEmpty">
                  <svg viewBox="0 0 64 64" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="8" y="12" width="48" height="40" rx="3"/>
                    <circle cx="24" cy="28" r="5"/>
                    <path d="M8 44l12-12 8 8 10-10 6 6"/>
                  </svg>
                  <p>暂无配图，点击下方区域添加</p>
                </div>
              </div>

              <!-- 上传区：始终在最底部 -->
              <div class="upload-zone" id="uploadZone">
                <input type="file" id="fileInput" accept="image/*" multiple style="display:none">
                <div class="upload-zone-icon">
                  <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17 8 12 3 7 8"/>
                    <line x1="12" y1="3" x2="12" y2="15"/>
                  </svg>
                </div>
                <div class="upload-zone-text">点击或拖拽添加本地配图</div>
                <div class="upload-zone-hint">支持 PNG、JPG、WebP 格式</div>
              </div>
            </div>
          </div>

          <!-- 保存按钮（在 captureArea 之外，不纳入截图） -->
          <div class="save-action">
            <button class="btn btn--primary" id="btnSaveImage" type="button">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
              </svg>
              保存成图片
            </button>
          </div>
        </div>

        <!-- ============ 步骤 01：理解内容 ============ -->
        <div class="step-content" data-step-content="0">
          <div class="step-detail">
            <h2>理解内容<span class="crate-sec-sub" aria-hidden="true">UNDERSTAND</span></h2>
            <p>先读用户给的正文、链接或截图内容。提炼核心观点是什么，哪些段落承担认知转折，哪些内容适合用图解释，哪些地方只适合文字不需要图。</p>
            <ul>
              <li>通读全文，标记认知转折点和核心论点</li>
              <li>区分"需要配图"和"纯文字即可"的段落</li>
              <li>找出文章中最难用文字直接表达的概念</li>
              <li>不要平均配图——优先选择"认知锚点"</li>
            </ul>
            <div class="tip-box">
              <strong>提示：</strong>一张好配图应该能让读者在 3 秒内 get 到一个原本需要读 3 分钟才能理解的概念。
            </div>
          </div>
        </div>

        <!-- ============ 步骤 02：提取结构 ============ -->
        <div class="step-content" data-step-content="1">
          <div class="step-detail">
            <h2>提取结构<span class="crate-sec-sub" aria-hidden="true">STRUCTURE</span></h2>
            <p>为每张图选择结构类型。结构类型只用于内部思考，不要在图上写出来。</p>
            <ul>
              <li><strong>Workflow 流程</strong>：时间线、步骤链、循环过程</li>
              <li><strong>系统局部</strong>：一个系统的切面、内部运转机制</li>
              <li><strong>前后对比</strong>：Before / After 的状态差异</li>
              <li><strong>角色状态</strong>：人在某个场景下的姿势/情绪/动作</li>
              <li><strong>概念隐喻</strong>：用一个具体事物映射抽象概念</li>
              <li><strong>方法分层</strong>：层级、分类、矩阵</li>
              <li><strong>地图路线</strong>：空间关系、导航、路径选择</li>
              <li><strong>小漫画分镜</strong>：2-4 格的微型叙事</li>
            </ul>
            <div class="tip-box">
              <strong>提示：</strong>同一篇文章的不同配图尽量使用不同的结构类型，避免视觉疲劳。
            </div>
          </div>
        </div>

        <!-- ============ 步骤 03：选择视角 ============ -->
        <div class="step-content" data-step-content="2">
          <div class="step-detail">
            <h2>选择视角<span class="crate-sec-sub" aria-hidden="true">PERSPECTIVE</span></h2>
            <p>重新发明一个低科技、怪诞但成立的物理隐喻。画面主体必须承担核心动作。</p>
            <ul>
              <li>主体承担核心动作——去掉主体画面就不成立</li>
              <li>优先选择"正在发生"的动态瞬间</li>
              <li>用物理世界的荒谬感映射抽象概念</li>
              <li>避免符号化、图标化、PPT 化</li>
            </ul>
            <div class="tip-box">
              <strong>示例：</strong>讲"认知升级"，不要画一个向上的箭头。画一个人在旧房间里试图把窗户拆掉装成门——动作本身在说"升级"。
            </div>
          </div>
        </div>

        <!-- ============ 步骤 04：设计构图 ============ -->
        <div class="step-content" data-step-content="3">
          <div class="step-detail">
            <h2>设计构图<span class="crate-sec-sub" aria-hidden="true">COMPOSE</span></h2>
            <p>安排留白、元素、批注位置。让画面既有信息量又有呼吸感。</p>
            <ul>
              <li>主体占画面约 40%-60%，至少 35% 空白</li>
              <li>少量中文手写批注：最多 5-8 处</li>
              <li>每处批注尽量 2-8 个字，不要写句子</li>
              <li>颜色克制：黑色主体、橙色流程、红色重点、蓝色补充</li>
              <li>批注像随手写的，不是打印体</li>
            </ul>
            <div class="tip-box">
              <strong>提示：</strong>如果画面看起来像一个精心排版的 PPT 页面，说明留白不够、批注太多。删掉一半文字再看看。
            </div>
          </div>
        </div>

        <!-- ============ 步骤 05：生成配图 ============ -->
        <div class="step-content" data-step-content="4">
          <div class="step-detail">
            <h2>生成配图<span class="crate-sec-sub" aria-hidden="true">GENERATE</span></h2>
            <p>点击上方「复制 Prompt」或「生成配图」按钮，开始生图。每张图单独生成，便于迭代调整。</p>
            <ul>
              <li>提示词必须包含：16:9 横版、纯白背景、黑色手绘线稿</li>
              <li>强调大量留白、少量红橙蓝中文手写批注</li>
              <li>禁止 PPT、商业插画、幼稚可爱风格</li>
              <li>生成后如果不满意，先改 Prompt 再重新生成</li>
            </ul>
            <div class="tip-box">
              <strong>提示：</strong>可以先让 AI 生成草图描述（文字版），确认构图合理后再正式出图，节省 token。
            </div>
          </div>
        </div>

        <!-- ============ 步骤 06：检查迭代 ============ -->
        <div class="step-content" data-step-content="5">
          <div class="step-detail">
            <h2>检查迭代<span class="crate-sec-sub" aria-hidden="true">REVIEW</span></h2>
            <p>生成后逐条 QA 检查，不通过就回到对应步骤重新调整。</p>
            <ul>
              <li>主体是否只是装饰？去掉主体画面是否仍然完全成立？</li>
              <li>画面是否太满？留白是否足够？</li>
              <li>是否太像 PPT、课程配图或商业插画？</li>
              <li>中文批注是否太多？是否有错字？</li>
              <li>左上角是否出现了不该有的标题？</li>
              <li>画风是否太可爱、太卡通、太死板？</li>
              <li>背景是否为干净的纯白底？有无多余纹理？</li>
            </ul>
            <div class="tip-box">
              <strong>提示：</strong>QA 不通过时，不要只改 Prompt 细节。回到"选择视角"或"设计构图"重新思考，往往效果更好。
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>

  `;

  /* =========================================================
     3. 页面业务逻辑（原内联脚本转写：源参数协议 / html2canvas ESM / 两段式确认）
     ========================================================= */

  function initPage(): void {
    /* =========================================================
       源内容参数（沙箱 __SANDBOX_DATA__ ← 宿主 WindowManager.launch(data)
       协议；沙箱 srcdoc 无 URL query，原 getQueryParam 解析不可用）
       ========================================================= */
    function readSourceData() {
      var w = window;
      var data = w.__SANDBOX_DATA__;
      if (!data || typeof data !== 'object') return { type: '', title: '', source: '', summary: '', url: '' };
      return {
        type: String(data.type || ''),
        title: String(data.title || ''),
        source: String(data.source || ''),
        summary: String(data.summary || ''),
        url: String(data.url || '')
      };
    }
    var sourceData = readSourceData();
    var sourceType = sourceData.type;
    var sourceTitleParam = sourceData.title;
    var sourceSource = sourceData.source;
    var sourceSummaryParam = sourceData.summary;
    var sourceUrl = sourceData.url;

    var titleEl = document.getElementById('sourceTitle');
    var summaryEl = document.getElementById('sourceSummary');
    var metaEl = document.getElementById('sourceMeta');
    var subtitleEl = document.getElementById('sourceSubtitle');

    /* 预填源内容 + 源信息 meta（初始化与单例热传共用；
       2026-08-19：信息流等宿主在窗口已打开时再次 launch(data)，
       经 window.__SANDBOX_ON_DATA__ 刷新源内容） */
    function applySourceData(data, fromLaunch) {
      var d = {
        type: String((data && data.type) || ''),
        title: String((data && data.title) || ''),
        source: String((data && data.source) || ''),
        summary: String((data && data.summary) || ''),
        url: String((data && data.url) || '')
      };
      sourceType = d.type;
      sourceTitleParam = d.title;
      sourceSource = d.source;
      sourceSummaryParam = d.summary;
      sourceUrl = d.url;

      titleEl.textContent = sourceTitleParam;
      summaryEl.textContent = sourceSummaryParam;

      /* 传值打开/热传刷新：无值字段整体隐藏（直接打开时均显示，供用户输入） */
      var titleField = document.getElementById('sourceTitleField');
      var summaryField = document.getElementById('sourceSummaryField');
      titleField.style.display = fromLaunch && !sourceTitleParam ? 'none' : '';
      summaryField.style.display = fromLaunch && !sourceSummaryParam ? 'none' : '';

      var metaParts = [];
      /* 来源：优先 source；缺失时以消息网址域名兜底（如 weibo.com）；两者皆无则不显示 */
      var sourceShown = sourceSource;
      if (!sourceShown && sourceUrl) {
        try {
          sourceShown = new URL(sourceUrl).hostname.replace(/^www\./, '');
        } catch (e) {
          sourceShown = sourceUrl;
        }
      }
      if (sourceShown) metaParts.push('来源：' + sourceShown);
      if (sourceType) {
        var typeMap = { worldnews: '世界情报', article: '文章', daily: '日报' };
        metaParts.push('类型：' + (typeMap[sourceType] || sourceType));
      }
      if (metaParts.length > 0) {
        metaEl.innerHTML = metaParts.map(function(p) { return '<span>' + escapeHtml(p) + '</span>'; }).join('');
      } else {
        metaEl.innerHTML = '<span>直接输入标题与摘要即可生成配图，也可从主页内容点击「手绘配图」进入</span>';
      }
      updateSubtitle();
    }
    var rawPayload = window.__SANDBOX_DATA__;
    var hasPayload = !!(rawPayload && typeof rawPayload === 'object' && Object.keys(rawPayload).length > 0);
    applySourceData(sourceData, hasPayload);

    /* 单例热传（2026-08-19）：窗口已打开时宿主再次 launch(appId, { data })，
       AppCreatorLoader.onDataUpdate → eval 本回调刷新源内容；未注册时仅更新
       window.__SANDBOX_DATA__，行为与旧版一致（只聚焦） */
    window.__SANDBOX_ON_DATA__ = function(newData) {
      applySourceData(newData || {}, true);
    };

    /* 副标题随标题编辑实时更新 */
    function updateSubtitle() {
      var t = (titleEl.textContent || '').trim();
      subtitleEl.textContent = t
        ? '为「' + t.substring(0, 20) + (t.length > 20 ? '…' : '') + '」生成配图'
        : '为内容生成极简手绘风格配图';
    }
    updateSubtitle();
    titleEl.addEventListener('input', updateSubtitle);

    function escapeHtml(str) {
      if (!str) return '';
      return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\x22/g, '&quot;');
    }

    /* =========================================================
       步骤切换逻辑
       ========================================================= */
    var stepItems = document.querySelectorAll('.step-item');
    var stepContents = document.querySelectorAll('.step-content');

    stepItems.forEach(function(item) {
      item.addEventListener('click', function() {
        var step = item.dataset.step;
        stepItems.forEach(function(si) { si.classList.remove('active'); });
        item.classList.add('active');
        stepContents.forEach(function(sc) { sc.classList.remove('active'); });
        var target = document.querySelector('.step-content[data-step-content="' + step + '"]');
        if (target) target.classList.add('active');
      });
    });

    /* =========================================================
       配图上传与画廊管理
       ========================================================= */
    var fileInput = document.getElementById('fileInput');
    var uploadZone = document.getElementById('uploadZone');
    var galleryList = document.getElementById('galleryList');
    var galleryEmpty = document.getElementById('galleryEmpty');
    var galleryCount = document.getElementById('galleryCount');
    var galleryItems = [];

    function updateGalleryCount() {
      galleryCount.textContent = galleryItems.length + ' 张配图';
      if (galleryItems.length === 0) {
        galleryList.innerHTML = '';
        galleryList.appendChild(galleryEmpty);
        galleryEmpty.style.display = 'flex';
      } else {
        galleryEmpty.style.display = 'none';
      }
    }

    function createGalleryItem(file, dataUrl) {
      var item = document.createElement('div');
      item.className = 'gallery-item';
      item.dataset.id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);

      item.innerHTML =
        '<img src="' + dataUrl + '" alt="' + escapeHtml(file.name) + '" draggable="false">' +
        '<div class="gallery-item-info">' +
          '<span class="gallery-item-name" title="' + escapeHtml(file.name) + '">' + escapeHtml(file.name) + '</span>' +
          '<div class="gallery-item-actions">' +
            '<button class="btn-icon-sm" data-action="delete-img" title="删除">' +
              '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>' +
              '</svg>' +
            '</button>' +
          '</div>' +
        '</div>';

      var delBtn = item.querySelector('[data-action="delete-img"]');
      /* 沙箱无 allow-modals，confirm() 静默返回 false：改两段式确认——
         首次点击进入确认态（红字），3 秒内再次点击执行删除 */
      var deleteArmed = false;
      delBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        if (deleteArmed) {
          deleteArmed = false;
          item.remove();
          galleryItems = galleryItems.filter(function(g) { return g !== item; });
          updateGalleryCount();
          return;
        }
        deleteArmed = true;
        var oldHtml = delBtn.innerHTML;
        delBtn.innerHTML = '<span style="font-size:11px;line-height:1;color:#fff;background:var(--danger,#B23A48);padding:3px 6px;border-radius:4px;">' +
          '\u786e\u8ba4\u5220\u9664\uff1f</span>';
        setTimeout(function() {
          if (deleteArmed) {
            deleteArmed = false;
            delBtn.innerHTML = oldHtml;
          }
        }, 3000);
      });

      return item;
    }

    function handleFiles(files) {
      Array.from(files).forEach(function(file) {
        if (!file.type.startsWith('image/')) return;
        var reader = new FileReader();
        reader.onload = function(e) {
          if (galleryItems.length === 0) {
            galleryList.innerHTML = '';
          }
          var item = createGalleryItem(file, e.target.result);
          galleryList.appendChild(item);
          galleryItems.push(item);
          updateGalleryCount();
        };
        reader.readAsDataURL(file);
      });
    }

    uploadZone.addEventListener('click', function() {
      fileInput.click();
    });

    fileInput.addEventListener('change', function() {
      if (fileInput.files && fileInput.files.length > 0) {
        handleFiles(fileInput.files);
        fileInput.value = '';
      }
    });

    uploadZone.addEventListener('dragover', function(e) {
      e.preventDefault();
      uploadZone.classList.add('drag-over');
    });

    uploadZone.addEventListener('dragleave', function(e) {
      e.preventDefault();
      uploadZone.classList.remove('drag-over');
    });

    uploadZone.addEventListener('drop', function(e) {
      e.preventDefault();
      uploadZone.classList.remove('drag-over');
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handleFiles(e.dataTransfer.files);
      }
    });

    document.addEventListener('dragover', function(e) { e.preventDefault(); });
    document.addEventListener('drop', function(e) { e.preventDefault(); });

    /* =========================================================
       保存成图片
       ========================================================= */
    var btnSaveImage = document.getElementById('btnSaveImage');

    /* 宿主代理截图（沙箱 opaque origin 下 html2canvas 跨 frame 安全检查失败，
       已由宿主 MultiFileSandbox 拦截 captureElementToPng 实现同源代理）。
       导出视图（2026-08-19）：克隆捕获区 → 应用内边距/背景（保存图左右不贴边、
       与顶部信息卡对齐、含背景色）→ 剔除编辑型 UI（上传区/文件名与删除按钮/计数）
       → 3 倍超采样输出（清晰） */
    function captureAreaToPng() {
      var captureArea = document.getElementById('captureArea');
      if (!captureArea) return Promise.reject(new Error('captureArea 不存在'));

      var exportArea = document.createElement('div');
      exportArea.className = 'export-area';
      exportArea.appendChild(captureArea.cloneNode(true));

      /* 剔除编辑型 UI：上传区、计数徽标、空态占位、每张图的信息栏（文件名+删除按钮） */
      var upload = exportArea.querySelector('.upload-zone');
      if (upload) upload.remove();
      var count = exportArea.querySelector('.gallery-count');
      if (count) count.remove();
      var empty = exportArea.querySelector('.gallery-empty');
      if (empty) empty.remove();
      var itemInfos = exportArea.querySelectorAll('.gallery-item-info');
      Array.prototype.forEach.call(itemInfos, function(el) { el.remove(); });

      var styleEl = document.getElementById('illustration-app-style');
      return window.ZbyAPI.captureElementToPng({
        html: exportArea.outerHTML,
        css: styleEl ? styleEl.textContent : '',
        width: captureArea.offsetWidth,
        scale: 3
      });
    }

    btnSaveImage.addEventListener('click', function() {
      var captureArea = document.getElementById('captureArea');
      var uploadZone = document.getElementById('uploadZone');
      if (!captureArea) return;

      if (galleryItems.length === 0) {
        showToast('请先添加至少一张配图', 'danger');
        return;
      }

      btnSaveImage.disabled = true;
      btnSaveImage.textContent = '正在生成...';

      // 临时隐藏上传区，不纳入截图
      var uploadZoneOriginalDisplay = uploadZone.style.display;
      uploadZone.style.display = 'none';

      captureAreaToPng().then(function(dataUrl) {
        var currentTitle = (titleEl.textContent || '').trim();
        var fileName = 'illustration_' + (currentTitle ? currentTitle.replace(/[^\w\u4e00-\u9fa5]/g, '_').substring(0, 30) : 'untitled') + '.png';
        /* 宿主 saveImageAs：弹系统保存对话框让用户自选保存位置（沙箱内 a[download]
           无 allow-downloads 会被当作导航执行，图片从不落盘且破坏应用，已废弃） */
        return window.ZbyAPI.saveImageAs(dataUrl, fileName).then(function(savedPath) {
          if (savedPath) {
            showToast('图片已保存：' + savedPath);
          } else {
            showToast('已取消保存');
          }
        });
      }).catch(function(err) {
        console.error(err);
        showToast('保存失败，请重试', 'danger');
      }).finally(function() {
        // 恢复上传区显示
        uploadZone.style.display = uploadZoneOriginalDisplay;
        btnSaveImage.disabled = false;
        btnSaveImage.innerHTML =
          '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>' +
            '<polyline points="7 10 12 15 17 10"/>' +
            '<line x1="12" y1="15" x2="12" y2="3"/>' +
          '</svg>' +
          '保存成图片';
      });
    });

    /* =========================================================
       生成配图按钮
       ========================================================= */
    var btnGenerate = document.getElementById('btnGenerate');
    var btnCopyPrompt = document.getElementById('btnCopyPrompt');

    function buildPrompt() {
      var title = (titleEl.textContent || '').trim();
      var summary = (summaryEl.textContent || '').trim();
      var prompt = 'Generate one standalone 16:9 horizontal Chinese article illustration.\n\n';
      prompt += 'Visual DNA:\n';
      prompt += 'Pure white background. Minimalist black hand-drawn line art. Slightly wobbly pen lines. Lots of empty white space. Sparse red/orange/blue handwritten Chinese annotations. Clean absurd product-sketch feeling. No gradients, no shadows, no paper texture, no complex background, no commercial vector style, no PPT infographic look, no cute mascot poster, no children\'s illustration, no realistic UI.\n\n';
      prompt += 'Theme:\n';
      prompt += (title || '中文文章配图') + '\n\n';
      if (summary) {
        prompt += 'Core idea:\n';
        prompt += summary + '\n\n';
      }
      prompt += 'Color use:\n';
      prompt += 'Black for main line art. Orange for main flow/path/arrows. Red only for key warnings/problems/results. Blue only for secondary notes or feedback/system state.\n\n';
      prompt += 'Constraints:\n';
      prompt += 'One image explains only one core structure. Keep the main subject around 40%-60% of the canvas. Preserve at least 35% blank white space. Use at most 5-8 short handwritten Chinese labels. Do not write a title in the top-left corner. Do not write the structure type on the image. Do not make it a formal diagram, course slide, or dense explainer. Invent a fresh visual metaphor. It should be clear but not instructional, interesting but not childish, strange but clean.';
      return prompt;
    }

    btnCopyPrompt.addEventListener('click', function() {
      var prompt = buildPrompt();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(prompt).then(function() {
          showToast('Prompt 已复制');
        }).catch(function() {
          fallbackCopy(prompt);
        });
      } else {
        fallbackCopy(prompt);
      }
    });

    function fallbackCopy(text) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        showToast('Prompt 已复制');
      } catch (e) {
        showToast('复制失败，请手动复制', 'danger');
      }
      document.body.removeChild(ta);
    }

    btnGenerate.addEventListener('click', function() {
      showToast('请先点击「复制 Prompt」，在 AI 生图工具中粘贴使用');
    });

    /* Toast 通知（400ms 内相同消息去重，防重复触发/重复绑定导致的双提示） */
    var lastToastMsg = '';
    var lastToastAt = 0;
    function showToast(message, type) {
      var now = Date.now();
      if (message === lastToastMsg && now - lastToastAt < 400) return;
      lastToastMsg = message;
      lastToastAt = now;
      /* P4.4：ui-kit toast 片段（.zby-toast 三变体），视觉与宿主吐司同构；
         宿主 ZbyAPI 无轻量 toast API（showNotification 走三渠道通知，过重），纯片段降级 */
      var existingToast = document.querySelector('.zby-toast');
      if (existingToast !== null) existingToast.remove();
      var toast = document.createElement('div');
      toast.className = 'zby-toast' + (type === 'danger' ? ' zby-toast--error' : '');
      toast.textContent = message;
      document.body.appendChild(toast);
      setTimeout(function() { toast.remove(); }, 2200);
    }
  }

  /* =========================================================
     4. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: { readonly nameKey?: string; readonly nameFallback: string };
    readonly t: (key: string, params?: Readonly<Record<string, string | number>>) => string;
    readonly onThemeChange: (cb: () => void) => () => void;
    readonly data?: Readonly<Record<string, unknown>>;
  }

  /** 挂载页面：注入样式 + 页面结构 + 业务逻辑（幂等：重复挂载先清空） */
  function mount(ctx: AppMountContext): void {
    const root = ctx.container;
    injectAppStyle(root);
    root.innerHTML = PAGE_HTML;
    /* 模拟宿主嵌入态：透明玻璃 + 隐藏返回链接（与宿主 iframe 加载时一致） */
    document.documentElement.setAttribute('data-embedded', '');
    initPage();
  }

  /** 卸载页面：清理 DOM（监听由 WindowManager 销毁容器一并回收） */
  function unmount(): void {
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
    document.documentElement.removeAttribute('data-embedded');
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI、t=恒等） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const ctx: AppMountContext = {
      container: root,
      api: (window as unknown as Record<string, unknown>).ZbyAPI,
      manifest: { nameKey: 'illustration.toolName', nameFallback: '手绘配图' },
      t: (key: string) => key,
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    mount(ctx);
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__illustrationApp = {
    unmount,
  };
})();
