/**
 * hex-color — 16 进制颜色转换应用入口（zby-creation 扁平包，v1.0.0）
 *
 * 原宿主实现：tools/hex-color/index.html + src/pages/tools/hex-color/（app.ts /
 * HexColorController.ts / types.ts）。转包改造点（对齐 PRD §4.2）：
 *   1. i18n：宿主 5 语包 → 内嵌最小词表（tools.hex* 快照），零语言包依赖
 *   2. 设置读取：宿主设置（含浏览器存储）→ 默认色改读注入的 --deco-primary CSS 变量
 *   3. 皮肤：tokens.css 依赖 → CSS 变量 + fallback（styles.css），运行时由入口注入 <style>
 *   4. 入口签名：页面自启动 → mount(ctx)/unmount() 契约 + boot() 自启动
 *   5. 生命周期：window/document 全局 → 作用域限定挂载容器，unmount 清理全部监听
 *
 * 入口契约（跨文件校验锚点，与 contract.json modules.exports 一致）：
 *   export function mount(ctx: AppMountContext): void
 *   export function unmount(): void
 *
 * 沙箱运行时说明（2026-08-12）：
 *   MultiFileSandbox 以 classic <script> 执行 Sucrase 编译后的入口代码，顶层
 *   export/import 会触发语法错误并连累同块注入（FS / API 代理 / runtime）全部
 *   失效；且沙箱仅执行入口 JS（不加载 index.html / styles.css）。故本文件采用
 *   IIFE 自启动：内部实现 mount()/unmount() 等价契约，由 boot() 构造
 *   AppMountContext（container=#sandbox-root、api=window.ZbyAPI、t=词表翻译、
 *   onThemeChange=主题桥订阅）并调用；样式同源内容以 <style> 注入挂载容器。
 */
(function () {
  'use strict';

  /* =========================================================
     1. 词表（宿主 i18n tools.hex* 快照，5 语；运行时零语言包依赖）
     ========================================================= */

  interface LangBundle {
    readonly [key: string]: string;
  }

  const LANG_BUNDLES: Readonly<Record<string, LangBundle>> = {
    'zh-CN': {
      'tools.hexColorTitle': '16进制颜色转换',
      'tools.hexColorDesc': '输入 Hex 色值，实时预览颜色，一键转换为 RGB、HSL 格式。',
      'tools.hexError': '请输入有效的十六进制颜色值（如 #3CB371 或 3CB371）',
      'tools.hexDescription': '十六进制颜色值',
      'tools.colorPicker': '取色器',
      'tools.copyLabel': '复制',
      'tools.copyHex': '复制 HEX',
      'tools.copyRgb': '复制 RGB',
      'tools.copyHsl': '复制 HSL',
      'tools.copyDone': '已复制',
      'tools.rgbDesc': '红 {r} · 绿 {g} · 蓝 {b}',
      'tools.hslDesc': '色相 {h}° · 饱和度 {s}% · 亮度 {l}%',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    'zh-TW': {
      'tools.hexColorTitle': '16進制顏色轉換',
      'tools.hexColorDesc': '輸入 Hex 色值，即時預覽顏色，一鍵轉換為 RGB、HSL 格式。',
      'tools.hexError': '請輸入有效的十六進制顏色值（如 #3CB371 或 3CB371）',
      'tools.hexDescription': '十六進制顏色值',
      'tools.colorPicker': '取色器',
      'tools.copyLabel': '複製',
      'tools.copyHex': '複製 HEX',
      'tools.copyRgb': '複製 RGB',
      'tools.copyHsl': '複製 HSL',
      'tools.copyDone': '已複製',
      'tools.rgbDesc': '紅 {r} · 綠 {g} · 藍 {b}',
      'tools.hslDesc': '色相 {h}° · 飽和度 {s}% · 亮度 {l}%',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    en: {
      'tools.hexColorTitle': 'Hex Color Converter',
      'tools.hexColorDesc': 'Enter a hex value, preview live, convert to RGB / HSL in one click.',
      'tools.hexError': 'Please enter a valid hex color (e.g. #3CB371 or 3CB371)',
      'tools.hexDescription': 'Hex color value',
      'tools.colorPicker': 'Color picker',
      'tools.copyLabel': 'Copy',
      'tools.copyHex': 'Copy HEX',
      'tools.copyRgb': 'Copy RGB',
      'tools.copyHsl': 'Copy HSL',
      'tools.copyDone': 'Copied',
      'tools.rgbDesc': 'R {r} · G {g} · B {b}',
      'tools.hslDesc': 'H {h}° · S {s}% · L {l}%',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    ja: {
      'tools.hexColorTitle': '16進数カラー変換',
      'tools.hexColorDesc': 'Hex 値を入力すると即時プレビュー、ワンクリックで RGB / HSL に変換。',
      'tools.hexError': '有効な16進数カラーを入力してください（例: #3CB371 または 3CB371）',
      'tools.hexDescription': '16進数カラー値',
      'tools.colorPicker': 'カラーピッカー',
      'tools.copyLabel': 'コピー',
      'tools.copyHex': 'HEX をコピー',
      'tools.copyRgb': 'RGB をコピー',
      'tools.copyHsl': 'HSL をコピー',
      'tools.copyDone': 'コピーしました',
      'tools.rgbDesc': 'R {r} · G {g} · B {b}',
      'tools.hslDesc': '色相 {h}° · 彩度 {s}% · 輝度 {l}%',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
    ko: {
      'tools.hexColorTitle': '16진수 색상 변환',
      'tools.hexColorDesc': 'Hex 값을 입력하면 실시간 미리보기, 한 번의 클릭으로 RGB / HSL로 변환.',
      'tools.hexError': '유효한 16진수 색상을 입력해 주세요 (예: #3CB371 또는 3CB371)',
      'tools.hexDescription': '16진수 색상 값',
      'tools.colorPicker': '색상 선택기',
      'tools.copyLabel': '복사',
      'tools.copyHex': 'HEX 복사',
      'tools.copyRgb': 'RGB 복사',
      'tools.copyHsl': 'HSL 복사',
      'tools.copyDone': '복사됨',
      'tools.rgbDesc': 'R {r} · G {g} · B {b}',
      'tools.hslDesc': '색상 {h}° · 채도 {s}% · 명도 {l}%',
      'tools.footerCredit': 'Designed by @zibuyu',
    },
  };

  /** 翻译函数签名（对齐 AppMountContext.t） */
  type Translator = (key: string, params?: Readonly<Record<string, string | number>>) => string;

  /** 语言检测（沙箱无宿主设置，按浏览器语言就近匹配） */
  function detectLang(): string {
    const lang = navigator.language || 'zh-CN';
    if (lang.startsWith('zh-TW') || lang.startsWith('zh-HK') || lang.startsWith('zh-Hant')) return 'zh-TW';
    if (lang.startsWith('zh')) return 'zh-CN';
    if (lang.startsWith('ja')) return 'ja';
    if (lang.startsWith('ko')) return 'ko';
    return 'en';
  }

  /** 创建翻译器；key 缺失时回退 key 本身（不抛错） */
  function createTranslator(lang: string): Translator {
    const bundle = LANG_BUNDLES[lang] ?? LANG_BUNDLES['zh-CN'];
    return (key: string, params?: Readonly<Record<string, string | number>>): string => {
      const template = (bundle !== undefined && bundle[key] !== undefined) ? (bundle[key] ?? key) : key;
      if (params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (_match: string, name: string): string => {
        const value = params[name];
        return value !== undefined ? String(value) : '';
      });
    };
  }

  /* =========================================================
     2. 纯函数：颜色转换（原 HexColorController.ts 平移，零 DOM 依赖）
     ========================================================= */

  interface RGB {
    readonly r: number;
    readonly g: number;
    readonly b: number;
  }

  interface HSL {
    readonly h: number;
    readonly s: number;
    readonly l: number;
  }

  /** HEX → RGB；输入为 6 位大写 HEX（不含 #）；解析失败返回 null */
  function hexToRgb(hex: string): RGB | null {
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return null;
    return { r, g, b };
  }

  /** RGB → HSL；输入 r/g/b 为 0-255 */
  function rgbToHsl(r: number, g: number, b: number): HSL {
    const rn = r / 255;
    const gn = g / 255;
    const bn = b / 255;
    const max = Math.max(rn, gn, bn);
    const min = Math.min(rn, gn, bn);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === rn) h = ((gn - bn) / d + (gn < bn ? 6 : 0)) / 6;
      else if (max === gn) h = ((bn - rn) / d + 2) / 6;
      else h = ((rn - gn) / d + 4) / 6;
    }
    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100),
    };
  }

  /**
   * 验证 HEX 字符串；支持 3 位缩写与 6 位标准格式，可带 # 前缀。
   * @returns 6 位大写 HEX（不含 #）；非法返回 null
   */
  function validateHex(raw: string): string | null {
    let s = raw.replace(/^#/, '');
    if (/^[0-9A-Fa-f]{3}$/.test(s)) {
      const c0 = s.charAt(0);
      const c1 = s.charAt(1);
      const c2 = s.charAt(2);
      s = c0 + c0 + c1 + c1 + c2 + c2;
    }
    if (/^[0-9A-Fa-f]{6}$/.test(s)) {
      return s.toUpperCase();
    }
    return null;
  }

  /** 判断 HEX 颜色是否为深色（用于决定预览文字颜色）；输入为 6 位 HEX（不含 #） */
  function isDarkColor(hex: string): boolean {
    const rgb = hexToRgb(hex);
    if (rgb === null) return false;
    const brightness = (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
    return brightness < 128;
  }

  /* =========================================================
     3. Controller：DOM 引用 + UI 绑定（原 HexColorController.ts 平移，
        注入 Translator 替代 I18nService；dispose 移除全部监听）
     ========================================================= */

  class HexColorController {
    private readonly t: Translator;
    private lastRgb: RGB | null = null;
    private lastHsl: HSL | null = null;
    private offs: Array<() => void> = [];

    readonly hexInput: HTMLInputElement;
    readonly colorPicker: HTMLInputElement;
    readonly colorPreview: HTMLElement;
    readonly colorPreviewLabel: HTMLElement;
    readonly errorMsg: HTMLElement;
    readonly resultHex: HTMLElement;
    readonly resultRgb: HTMLElement;
    readonly resultRgbMeta: HTMLElement;
    readonly resultHsl: HTMLElement;
    readonly resultHslMeta: HTMLElement;

    constructor(t: Translator) {
      this.t = t;
      this.hexInput = HexColorController.requireInput('hexInput');
      this.colorPicker = HexColorController.requireInput('colorPicker');
      this.colorPreview = HexColorController.requireEl('colorPreview');
      this.colorPreviewLabel = HexColorController.requireEl('colorPreviewLabel');
      this.errorMsg = HexColorController.requireEl('errorMsg');
      this.resultHex = HexColorController.requireEl('resultHex');
      this.resultRgb = HexColorController.requireEl('resultRgb');
      this.resultRgbMeta = HexColorController.requireEl('resultRgbMeta');
      this.resultHsl = HexColorController.requireEl('resultHsl');
      this.resultHslMeta = HexColorController.requireEl('resultHslMeta');
    }

    private static requireEl(id: string): HTMLElement {
      const el = document.getElementById(id);
      if (el === null) throw new Error('HexColor: required element not found: ' + id);
      return el;
    }

    private static requireInput(id: string): HTMLInputElement {
      const el = document.getElementById(id);
      if (!(el instanceof HTMLInputElement)) {
        throw new Error('HexColor: required input not found: ' + id);
      }
      return el;
    }

    /** 更新 UI；输入为用户原始输入（可带 #、可 3 位缩写） */
    updateUI(raw: string): void {
      const validHex = validateHex(raw);
      if (validHex === null) {
        this.hexInput.classList.add('invalid');
        this.errorMsg.classList.add('visible');
        return;
      }
      this.hexInput.classList.remove('invalid');
      this.errorMsg.classList.remove('visible');

      const rgb = hexToRgb(validHex);
      if (rgb === null) return;
      const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
      const dark = isDarkColor(validHex);

      const fullHex = '#' + validHex;
      this.colorPreview.style.backgroundColor = fullHex;
      this.colorPreviewLabel.textContent = fullHex;
      this.colorPreviewLabel.style.color = dark ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.7)';
      this.colorPreviewLabel.style.background = dark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.15)';

      this.resultHex.textContent = fullHex;
      this.resultRgb.textContent = `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
      this.resultHsl.textContent = `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`;
      this.resultRgbMeta.textContent = this.t('tools.rgbDesc', { r: rgb.r, g: rgb.g, b: rgb.b });
      this.resultHslMeta.textContent = this.t('tools.hslDesc', { h: hsl.h, s: hsl.s, l: hsl.l });

      this.colorPicker.value = fullHex;

      this.lastRgb = rgb;
      this.lastHsl = hsl;
    }

    /** 语言变更后重渲动态文案（RGB/HSL meta） */
    rerenderOnLangChange(): void {
      if (this.lastRgb !== null) {
        this.resultRgbMeta.textContent = this.t('tools.rgbDesc', {
          r: this.lastRgb.r,
          g: this.lastRgb.g,
          b: this.lastRgb.b,
        });
      }
      if (this.lastHsl !== null) {
        this.resultHslMeta.textContent = this.t('tools.hslDesc', {
          h: this.lastHsl.h,
          s: this.lastHsl.s,
          l: this.lastHsl.l,
        });
      }
    }

    /** 绑定输入与色盘事件（监听器登记到 offs，dispose 时统一移除） */
    bindEvents(): void {
      const onInput = (): void => {
        this.updateUI(this.hexInput.value);
      };
      this.hexInput.addEventListener('input', onInput);
      this.offs.push(() => this.hexInput.removeEventListener('input', onInput));

      const onPick = (): void => {
        const hex = this.colorPicker.value.replace('#', '');
        this.hexInput.value = hex;
        this.updateUI(hex);
      };
      this.colorPicker.addEventListener('input', onPick);
      this.offs.push(() => this.colorPicker.removeEventListener('input', onPick));
    }

    /** 清理：移除全部事件监听 */
    dispose(): void {
      for (const off of this.offs) {
        try {
          off();
        } catch {
          /* ignore */
        }
      }
      this.offs = [];
    }
  }

  /* =========================================================
     4. 页脚诗句 + 复制按钮（原 app.ts 平移，改为容器内操作）
     ========================================================= */

  interface Poem {
    readonly text: string;
    readonly author: string;
    readonly work: string;
  }

  const POEMS: readonly Poem[] = [
    { text: 'Color is the place where our brain and the universe meet.', author: 'Paul Klee', work: '' },
    { text: 'Simplicity is the ultimate sophistication.', author: 'Leonardo da Vinci', work: '' },
    { text: 'In nature, light creates the color. In the picture, color creates the light.', author: 'Hans Hofmann', work: '' },
    { text: 'The purest and most thoughtful minds are those which love color the most.', author: 'John Ruskin', work: 'The Stones of Venice' },
    { text: 'Color is a power which directly influences the soul.', author: 'Wassily Kandinsky', work: 'Concerning the Spiritual in Art' },
  ];

  /** 渲染页脚诗句（无事件监听，返回 noop 保持统一清理接口） */
  function renderFooterPoem(): () => void {
    const poem = POEMS[Math.floor(Math.random() * POEMS.length)];
    if (poem !== undefined) {
      const footerPoem = document.getElementById('footerPoem');
      const footerAuthor = document.getElementById('footerAuthor');
      if (footerPoem !== null) {
        footerPoem.textContent = '\u201C' + poem.text + '\u201D';
      }
      if (footerAuthor !== null) {
        footerAuthor.textContent = '\u2014 ' + poem.author + (poem.work !== '' ? ' \u00B7 ' + poem.work : '');
      }
    }
    return () => undefined;
  }

  function fallbackCopy(text: string, btn: HTMLElement, t: Translator): void {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand('copy');
      showCopied(btn, t);
    } catch {
      /* ignore */
    }
    document.body.removeChild(textarea);
  }

  function showCopied(btn: HTMLElement, t: Translator): void {
    btn.classList.add('copied');
    const originalHTML = btn.innerHTML;
    const copyDone = t('tools.copyDone');
    btn.innerHTML =
      '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> ' +
      copyDone;
    window.setTimeout(() => {
      btn.classList.remove('copied');
      btn.innerHTML = originalHTML;
    }, 1800);
  }

  /** 绑定复制按钮（返回清理函数） */
  function bindCopyButtons(t: Translator): () => void {
    const buttons = document.querySelectorAll('.copy-btn');
    const offs: Array<() => void> = [];
    buttons.forEach((btn) => {
      if (!(btn instanceof HTMLElement)) return;
      const onClick = (): void => {
        const targetId = btn.dataset.copy;
        if (targetId === undefined) return;
        const el = document.getElementById(targetId);
        if (el === null) return;
        const text = el.textContent?.trim() ?? '';
        if (navigator.clipboard !== undefined && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard
            .writeText(text)
            .then(() => showCopied(btn, t))
            .catch(() => fallbackCopy(text, btn, t));
        } else {
          fallbackCopy(text, btn, t);
        }
      };
      btn.addEventListener('click', onClick);
      offs.push(() => btn.removeEventListener('click', onClick));
    });
    return () => {
      for (const off of offs) {
        try {
          off();
        } catch {
          /* ignore */
        }
      }
    };
  }

  /* =========================================================
     5. 样式 + 结构（styles.css 同源内嵌，沙箱仅执行入口 JS）
     ========================================================= */

  /** 与 styles.css 同源的样式（注入挂载容器 <style>，皮肤变量带 fallback） */
  const APP_CSS: string = `
*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  -webkit-font-smoothing: antialiased;
  font-family: var(--font-family, 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif);
  font-size: var(--font-size-base, 16px);
}

body {
  font-family: var(--font-family, 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif);
  font-size: 1rem;
  line-height: 1.6;
  color: var(--glass-text-primary, #1f2937);
  background: transparent;
}

#hex-color-app {
  width: 100%;
  min-height: 100%;
}

#hex-color-app .container {
  width: 100%;
  /* EDITORIAL 定版收口：左流内容视图，左缘单源 --view-pad-x（与宿主内页同 Token），
     去居中 max-width 版式（G2 Step 4.3 遗留欠账）。 */
  margin: 0;
  padding: 0 var(--view-pad-x, var(--layout-page-pad, 48px));
}

#hex-color-app .deco-orb {
  position: fixed;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 30%,
    var(--deco-primary, #3CB371) 0%,
    var(--deco-secondary, #00A86B) 50%,
    transparent 75%);
  filter: blur(80px);
  opacity: 0.18;
  pointer-events: none;
  z-index: 0;
}

/* 页头 = EDITORIAL 定版（§16）：kicker + 衬线大标题 + 发丝线 + 右缘幽灵大字。
   同批修复：§16.2 标题 Token 化曾只落生成物 styles.css 未进运行时 APP_CSS，以本文件为真相源重写。 */
#hex-color-app .page-header {
  position: relative;
  padding: var(--layout-head-pad-t, var(--space-6, 24px)) 0 var(--space-5, 20px);
  /* 右侧净空 = 幽灵字宽（4.5×display）+ 右距，随字号缩放 */
  padding-right: calc(var(--layout-display, 2rem) * 4.5 + var(--space-5, 24px));
}
#hex-color-app .page-header::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 1px;
  background: linear-gradient(
    to right,
    color-mix(in srgb, var(--deco-primary, var(--accent, #0A2540)) 55%, transparent),
    color-mix(in srgb, var(--deco-primary, var(--accent, #0A2540)) 12%, transparent) 60%,
    transparent
  );
}
#hex-color-app .page-header[data-ghost]::before {
  content: attr(data-ghost);
  position: absolute;
  top: 0;
  right: var(--space-4, 16px);
  font-family: var(--type-title-font, var(--type-display, inherit));
  font-size: calc(var(--layout-display, 2rem) * 4.5);
  font-weight: 700;
  line-height: 1;
  color: transparent;
  -webkit-text-stroke: 1px color-mix(
    in srgb,
    var(--deco-primary, #3CB371) 34%,
    var(--glass-divider, rgba(31, 41, 55, 0.12)) 66%
  );
  opacity: 0.5;
  pointer-events: none;
  user-select: none;
}
@media (max-width: 640px) {
  #hex-color-app .page-header { padding-right: 0; }
  #hex-color-app .page-header[data-ghost]::before { display: none; }
}

#hex-color-app .page-title {
  /* 版式契约：字号/字距/字族走布局维度 Token（与宿主内页大标题同构） */
  font-family: var(--type-title-font, var(--type-display, var(--skin-font-display, inherit)));
  font-size: var(--type-title, var(--layout-display, 2rem));
  font-weight: 700;
  letter-spacing: var(--tracking-title, 0.04em);
  color: var(--glass-text-primary, #1f2937);
  margin-bottom: var(--space-1, 4px);
}

#hex-color-app .page-desc {
  font-size: 0.9375rem;
  color: var(--glass-text-secondary, #4b5563);
}

#hex-color-app .tool-main {
  /* 内容体顶距走布局 Token（§27 节奏单源） */
  padding: var(--view-pad-t, var(--space-4, 16px)) 0 var(--space-10, 40px);
  position: relative;
  z-index: 1;
}

#hex-color-app .color-preview-section {
  /* 分区间隔单源：--layout-section-gap（宿主分区节奏同值，去私有 24px） */
  margin-bottom: var(--layout-section-gap, var(--space-6, 24px));
}

#hex-color-app .color-preview {
  width: 100%;
  height: 160px;
  border-radius: var(--radius-md, 12px);
  border: 1px solid var(--glass-divider, rgba(31, 41, 55, 0.12));
  position: relative;
  overflow: hidden;
  transition: background-color 200ms ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

#hex-color-app .color-preview-label {
  font-size: 0.875rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.7);
  padding: var(--space-2, 8px) var(--space-4, 16px);
  border-radius: var(--radius-full, 9999px);
  background: rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
}

#hex-color-app .input-section {
  /* 分区间隔单源：--layout-section-gap */
  margin-bottom: var(--layout-section-gap, var(--space-6, 24px));
}

#hex-color-app .input-group {
  display: flex;
  gap: var(--space-3, 12px);
  align-items: center;
}

#hex-color-app .input-prefix {
  font-size: 1.25rem;
  font-weight: 600;
  color: var(--glass-text-tertiary, #9ca3af);
  line-height: 48px;
}

#hex-color-app .input-hex {
  flex: 1;
  height: 48px;
  padding: 0 var(--space-3, 12px);
  font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
  font-size: 1.125rem;
  color: var(--glass-text-primary, #1f2937);
  background: var(--glass-bg-L4, rgba(255, 255, 255, 0.85));
  border: 1px solid var(--glass-divider, rgba(31, 41, 55, 0.12));
  border-radius: var(--radius-md, 12px);
  transition: border-color 200ms ease, background 200ms ease;
  letter-spacing: 0.04em;
}

#hex-color-app .input-hex:focus {
  outline: none;
  border-color: var(--deco-primary, #3CB371);
}

#hex-color-app .input-hex:focus-visible {
  outline: 2px solid var(--deco-primary, #3CB371);
  outline-offset: 1px;
}

#hex-color-app .input-hex.invalid {
  border-color: var(--danger, #dc2626);
}

#hex-color-app .input-hex::placeholder {
  color: var(--glass-text-tertiary, #9ca3af);
}

#hex-color-app .color-picker-btn {
  width: 48px;
  height: 48px;
  border-radius: var(--radius-md, 12px);
  border: 1px solid var(--glass-divider, rgba(31, 41, 55, 0.12));
  cursor: pointer;
  padding: 0;
  background: var(--glass-bg-L4, rgba(255, 255, 255, 0.85));
  flex-shrink: 0;
  transition: border-color 200ms ease;
  position: relative;
  overflow: hidden;
}

#hex-color-app .color-picker-btn:hover {
  border-color: var(--glass-divider-strong, rgba(31, 41, 55, 0.2));
}

#hex-color-app .color-picker-btn input[type="color"] {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
}

#hex-color-app .color-picker-btn svg {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  pointer-events: none;
  color: var(--glass-text-tertiary, #9ca3af);
}

#hex-color-app .results-section {
  display: flex;
  flex-direction: column;
  gap: var(--space-4, 16px);
}

#hex-color-app .result-card {
  background: var(--glass-bg-L3, rgba(255, 255, 255, 0.65));
  border: 1px solid var(--glass-divider, rgba(31, 41, 55, 0.12));
  border-radius: var(--radius-md, 12px);
  padding: var(--space-4, 16px);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 12px);
  transition: border-color 200ms ease, background 200ms ease;
}

#hex-color-app .result-card:hover {
  background: var(--glass-bg-L3-hover, rgba(255, 255, 255, 0.75));
  border-color: var(--deco-primary, #3CB371);
}

#hex-color-app .result-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

#hex-color-app .result-label {
  font-size: 0.75rem;
  font-weight: 600;
  color: var(--glass-text-tertiary, #9ca3af);
  letter-spacing: 0.06em;
  text-transform: uppercase;
}

#hex-color-app .result-value {
  font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
  font-size: 0.9375rem;
  color: var(--glass-text-primary, #1f2937);
  font-weight: 500;
  word-break: break-all;
}

#hex-color-app .result-meta {
  font-size: 0.75rem;
  color: var(--glass-text-tertiary, #9ca3af);
}

#hex-color-app .copy-btn.copied {
  color: var(--success, #16a34a);
  border-color: var(--success, #16a34a);
  background: color-mix(in srgb, var(--success, #16a34a) 8%, transparent);
}

#hex-color-app .error-msg {
  font-size: 0.8125rem;
  color: var(--danger, #dc2626);
  margin-top: var(--space-2, 8px);
  display: none;
}

#hex-color-app .error-msg.visible {
  display: block;
}

#hex-color-app footer {
  padding: 3rem 0;
  text-align: center;
  border-top: 1px solid var(--glass-divider, rgba(31, 41, 55, 0.12));
  background: var(--glass-bg-L2, rgba(255, 255, 255, 0.55));
}

#hex-color-app .footer-credit {
  font-size: 0.75rem;
  color: var(--glass-text-tertiary, #9ca3af);
  letter-spacing: 0.04em;
}

#hex-color-app .footer-poem {
  font-style: italic;
  color: var(--glass-text-secondary, #4b5563);
  max-width: 480px;
  margin: 0.5rem auto 0;
  line-height: 1.6;
  font-size: 0.75rem;
}

#hex-color-app .footer-author {
  font-size: 0.6875rem;
  letter-spacing: 0.06em;
  color: var(--glass-text-tertiary, #9ca3af);
  margin: 0.25rem 0 0;
}

@media (max-width: 640px) {
  #hex-color-app .container {
    padding: 0 var(--space-4, 16px);
  }
  #hex-color-app .color-preview {
    height: 120px;
  }
  #hex-color-app .result-card {
    flex-direction: column;
    align-items: flex-start;
  }
  }
/* ── P4.4 ui-kit btn 片段（assets/ui-kit/btn.css 内嵌快照，选择器扩列桥接既有类名） ── */
/* ui-kit/btn.css — 层 C 按钮片段（生成时内嵌进 zip，shadcn 式快照）
 * 消费 uiContract.semanticTokens 语义 token（一律带 fallback），
 * 视觉与宿主 .btn 基座同构：主/次/危险/裸 四变体 + 降级分支。
 * 引用规则：var(--x, fallback) 强制；token 名见 assets/tokens.json。 */

.btn, .copy-btn, .compact-btn, .mode-btn, .btn-icon-sm{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2, 0.5rem);
  padding: 0.5625rem 1rem;
  font-size: var(--skin-type-scale-2, 14px);
  font-weight: 500;
  font-family: var(--skin-font-body, inherit);
  letter-spacing: var(--skin-letter-spacing, 0.01em);
  line-height: var(--skin-line-height, 1.4);
  border-radius: var(--radius-control, 8px);
  border: 1px solid transparent;
  background: transparent;
  color: var(--glass-text-primary, #1A1A1A);
  cursor: pointer;
  white-space: nowrap;
  user-select: none;
  text-decoration: none;
  transition:
    background 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    border-color 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1)),
    transform 200ms var(--skin-motion-ease-snap, cubic-bezier(0.2, 0, 0, 1));
}
.btn:focus-visible, .copy-btn:focus-visible, .compact-btn:focus-visible, .mode-btn:focus-visible, .btn-icon-sm:focus-visible{
  outline: 2px solid var(--accent, #0A2540);
  outline-offset: 2px;
}
.btn:disabled, .copy-btn:disabled, .compact-btn:disabled, .mode-btn:disabled, .btn-icon-sm:disabled,
.btn[disabled], .copy-btn[disabled], .compact-btn[disabled], .mode-btn[disabled], .btn-icon-sm[disabled]{
  opacity: 0.5;
  cursor: not-allowed;
}

/* 主按钮：装饰色底 + 亮度自适应文字（对比度铁律） */
.btn--primary{
  background: var(--deco-primary, #3CB371);
  color: var(--fg-on-accent, #FFFFFF);
  border-color: var(--deco-primary, #3CB371);
}
.btn--primary:hover:not(:disabled){
  transform: translateY(var(--skin-motion-travel-hover, -1px));
  opacity: 0.92;
}
.btn--primary:active:not(:disabled){
  transform: scale(var(--skin-motion-travel-press, 0.98));
}

/* 次按钮：卡片玻璃底 */
.btn--secondary, .copy-btn{
  background: var(--surface-card, rgba(255, 255, 255, 0.78));
  color: var(--glass-text-secondary, #666666);
  border-color: var(--surface-card-border, rgba(15, 25, 45, 0.06));
  box-shadow: var(--glass-shadow-L3, 0 2px 8px -2px rgba(10, 30, 60, 0.08));
}
.btn--secondary:hover:not(:disabled), .copy-btn:hover:not(:disabled){
  background: var(--surface-card-hover, rgba(255, 255, 255, 0.92));
  color: var(--glass-text-primary, #1A1A1A);
  border-color: var(--glass-divider-strong, rgba(15, 25, 45, 0.12));
}

/* 危险按钮：危险色文字 + 淡化边框 */
.btn--danger {
  color: var(--danger, #B23A48);
  border-color: color-mix(in srgb, var(--danger, #B23A48) 35%, transparent);
}
.btn--danger:hover:not(:disabled) {
  border-color: color-mix(in srgb, var(--danger, #B23A48) 60%, transparent);
}

/* 裸按钮：无底无边框，hover 弱化底 */
.btn--bare, .mode-btn, .btn-icon-sm{
  color: var(--glass-text-secondary, #666666);
}
.btn--bare:hover:not(:disabled), .mode-btn:hover:not(:disabled), .btn-icon-sm:hover:not(:disabled){
  background: var(--surface-hover, rgba(0, 0, 0, 0.04));
  color: var(--glass-text-primary, #1A1A1A);
}

/* 尺寸变体 */
.btn--sm, .compact-btn, .copy-btn{
  padding: 0.3125rem 0.625rem;
  font-size: var(--skin-type-scale-1, 12px);
  border-radius: var(--radius-sm, 4px);
}
.btn--lg {
  padding: 0.75rem 1.375rem;
  font-size: var(--skin-type-scale-3, 16px);
}

/* 动效偏好降级：关闭位移/缩放，保留颜色过渡 */
[data-reduce-motion="true"] .btn, [data-reduce-motion="true"] .copy-btn, [data-reduce-motion="true"] .compact-btn, [data-reduce-motion="true"] .mode-btn, [data-reduce-motion="true"] .btn-icon-sm{
  transition: background 200ms var(--skin-motion-ease-snap, ease),
    color 200ms var(--skin-motion-ease-snap, ease),
    border-color 200ms var(--skin-motion-ease-snap, ease);
}
[data-reduce-motion="true"] .btn--primary:hover:not(:disabled),
[data-reduce-motion="true"] .btn--primary:active:not(:disabled){
  transform: none;
}

`;

  /** 注入应用样式（幂等：已存在则跳过） */
  function injectAppStyle(root: HTMLElement): void {
    const styleId = 'hex-color-style';
    const doc = root.ownerDocument;
    if (doc.getElementById(styleId) !== null) return;
    const style = doc.createElement('style');
    style.id = styleId;
    style.textContent = APP_CSS;
    doc.head.appendChild(style);
  }

  /** 构建 UI 结构（与 index.html 的 id/class 契约一致，文案走词表） */
  function buildHtml(t: Translator): string {
    return (
      '<div id="hex-color-app">' +
      '<div class="deco-orb" style="width: 300px; height: 300px; top: -100px; right: -60px;"></div>' +
      '<div class="deco-orb" style="width: 220px; height: 220px; bottom: -80px; left: -50px;"></div>' +
      '<div class="container">' +
      '<header class="page-header" data-ghost="色">' +
      '<div class="crate-kicker" aria-hidden="true">TOOLS · COLOR</div>' +
      '<h1 class="page-title">' + t('tools.hexColorTitle') + '</h1>' +
      '<p class="page-desc">' + t('tools.hexColorDesc') + '</p>' +
      '</header>' +
      '<main class="tool-main">' +
      '<section class="color-preview-section">' +
      '<div class="color-preview" id="colorPreview" style="background-color: #3CB371;">' +
      '<span class="color-preview-label" id="colorPreviewLabel">#3CB371</span>' +
      '</div>' +
      '</section>' +
      '<section class="input-section">' +
      '<div class="input-group">' +
      '<span class="input-prefix">#</span>' +
      '<input type="text" class="input-hex" id="hexInput" placeholder="3CB371" maxlength="7" autocomplete="off" spellcheck="false">' +
      '<label class="color-picker-btn" title="' + t('tools.colorPicker') + '">' +
      '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>' +
      '<input type="color" id="colorPicker" value="#3CB371">' +
      '</label>' +
      '</div>' +
      '<p class="error-msg" id="errorMsg">' + t('tools.hexError') + '</p>' +
      '</section>' +
      '<section class="results-section">' +
      '<div class="result-card">' +
      '<div class="result-info">' +
      '<span class="result-label">HEX</span>' +
      '<span class="result-value" id="resultHex">#3CB371</span>' +
      '<span class="result-meta">' + t('tools.hexDescription') + '</span>' +
      '</div>' +
      '<button class="copy-btn" data-copy="resultHex" aria-label="' + t('tools.copyHex') + '">' +
      '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>' +
      '<span>' + t('tools.copyLabel') + '</span>' +
      '</button>' +
      '</div>' +
      '<div class="result-card">' +
      '<div class="result-info">' +
      '<span class="result-label">RGB</span>' +
      '<span class="result-value" id="resultRgb">rgb(60, 179, 113)</span>' +
      '<span class="result-meta" id="resultRgbMeta">' + t('tools.rgbDesc', { r: 60, g: 179, b: 113 }) + '</span>' +
      '</div>' +
      '<button class="copy-btn" data-copy="resultRgb" aria-label="' + t('tools.copyRgb') + '">' +
      '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>' +
      '<span>' + t('tools.copyLabel') + '</span>' +
      '</button>' +
      '</div>' +
      '<div class="result-card">' +
      '<div class="result-info">' +
      '<span class="result-label">HSL</span>' +
      '<span class="result-value" id="resultHsl">hsl(147, 50%, 47%)</span>' +
      '<span class="result-meta" id="resultHslMeta">' + t('tools.hslDesc', { h: 147, s: 50, l: 47 }) + '</span>' +
      '</div>' +
      '<button class="copy-btn" data-copy="resultHsl" aria-label="' + t('tools.copyHsl') + '">' +
      '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>' +
      '<span>' + t('tools.copyLabel') + '</span>' +
      '</button>' +
      '</div>' +
      '</section>' +
      '</main>' +
      '</div>' +
      '<footer>' +
      '<p class="footer-credit">' + t('tools.footerCredit') + '</p>' +
      '<p class="footer-poem" id="footerPoem"></p>' +
      '<p class="footer-author" id="footerAuthor"></p>' +
      '</footer>' +
      '</div>'
    );
  }

  /** 默认色：优先读注入的 --deco-primary 皮肤变量，失败回退 3CB371 */
  function readDefaultColor(): string {
    try {
      const root = document.documentElement;
      const value = getComputedStyle(root).getPropertyValue('--deco-primary').trim();
      if (/^#[0-9A-Fa-f]{6}$/.test(value)) return value.slice(1).toUpperCase();
    } catch {
      /* 读取失败回退默认 */
    }
    return '3CB371';
  }

  /* =========================================================
     6. 入口契约实现（内部 mount/unmount + boot 自启动）
     ========================================================= */

  interface AppMountContext {
    readonly container: HTMLElement;
    readonly api: unknown;
    readonly manifest: unknown;
    readonly t: Translator;
    readonly onThemeChange: (cb: () => void) => () => void;
  }

  interface MountedState {
    readonly ctrl: HexColorController;
    readonly offCopies: () => void;
  }

  let mounted: MountedState | null = null;

  /** 挂载应用：渲染 UI 到 ctx.container 并绑定交互（幂等：重复挂载先卸载） */
  function mount(ctx: AppMountContext): void {
    if (mounted !== null) unmount();
    const container = ctx.container;
    const t = ctx.t;
    injectAppStyle(container);
    container.innerHTML = buildHtml(t);

    const ctrl = new HexColorController(t);
    ctrl.bindEvents();
    const offCopies = bindCopyButtons(t);
    renderFooterPoem();

    const defaultColor = readDefaultColor();
    ctrl.hexInput.value = defaultColor;
    ctrl.colorPicker.value = '#' + defaultColor;
    ctrl.updateUI(defaultColor);

    mounted = { ctrl, offCopies };
  }

  /** 卸载应用：清理监听与挂载内容 */
  function unmount(): void {
    if (mounted !== null) {
      mounted.ctrl.dispose();
      mounted.offCopies();
      mounted = null;
    }
    const root = document.getElementById('sandbox-root');
    if (root !== null) root.innerHTML = '';
  }

  /** 自启动：构造 AppMountContext（container=#sandbox-root、api=ZbyAPI 代理、t=词表） */
  function boot(): void {
    const root = document.getElementById('sandbox-root');
    if (root === null) return;
    const w = window as unknown as Record<string, unknown>;
    const ctx: AppMountContext = {
      container: root,
      api: w.ZbyAPI,
      manifest: null,
      t: createTranslator(detectLang()),
      onThemeChange:
        ((window as unknown as Record<string, unknown>).__SANDBOX_SUBSCRIBE_THEME__ as
          | ((cb: () => void) => () => void)
          | undefined) ?? (() => () => undefined),
    };
    try {
      mount(ctx);
    } catch (e) {
      console.error('[hex-color] 挂载失败：', e);
      /* EDITORIAL-LAYOUT Phase 4：兜底错误文案走危险色 token（原裸 hex #dc2626），
         并补齐内距 Token —— 沙箱白名单已含 --danger，可直接消费 */
      root.innerHTML = '<p style="padding: var(--space-5, 24px); color: var(--danger, #dc2626);">应用挂载失败</p>';
    }
  }

  /* 启动：DOM 就绪后挂载（沙箱 srcdoc 中脚本位于 body 内，通常已就绪） */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  /* 对外暴露卸载句柄（供沙箱宿主 eval 清理；AppEntry.unmount 由加载器管理 iframe） */
  (window as unknown as Record<string, unknown>).__hexColorApp = {
    unmount,
  };
})();
